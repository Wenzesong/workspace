package jp.co.daiwa.jbpos1000;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.daiwa.common.constant.ExchangeKbnEnum.ExchangeKbn;
import jp.co.daiwa.common.constant.ProductEnum;
import jp.co.daiwa.common.constant.TradeKbnEnum.TradeKbn;
import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfitCustomerMstBean;
import jp.co.daiwa.dao.bean.TDfitTradeExchangeBean;
import jp.co.daiwa.dto.PosSumSourceDto;

/**
 * ポジション集計データ操作クラス
 *
 * @author MatsuFumizawa
 *
 */
public class JpPositionDataOperation {
    /** 通貨マスタ */
    private List<TCurrencyMstBean> currencyMstList;
    /** DFIT部課別顧客マスタ */
    private List<TDfitCustomerMstBean> dfitCurrencyMstList;
    /** DFIT為替トレードデータ */
    private List<TDfitTradeExchangeBean> dfitTradeExchangeList;
    /** ポジション集計元:FXDS取引管理データ */
    private List<PosSumSourceDto> fxdsInfoList;
    /** ポジション集計元:DFITデータ */
    private List<PosSumSourceDto> dfitInfoList;
    /** ポジション集計元:BID為替トレードデータ */
    private List<PosSumSourceDto> bidInfoList;
    /** ポジション集計元:BID外Mデータ仕分けデータ */
    private List<PosSumSourceDto> bidOutMInfoList;

    private static String REMARKS_POSITION = "ポジション表示";

    /**
     * コンストラクタ
     *
     */
    public JpPositionDataOperation() {
    }

    /**
     * FXDS取引管理データ・DFITデータマッチング処理 </br>
     *
     * @see 単独為替、利金為替、償還為替 ※bondFlg:false
     * @see 外株円決、外投円決 ※bondFlg:true
     *
     * @param bondFlg               外債売買フラグ <br>
     * @param tradeMngFxAllList     FXDSポジション集計元情報データ
     * @param dfitTradeList         DFIT為替トレードデータ
     * @param dfitcustList          DFIT部課別顧客マスタデータ
     * @return
     */
    public List<PosSumSourceDto> matchTradeMngDataForDfit(boolean bondFlg) {

        List<PosSumSourceDto> retList = new ArrayList<>();
        if (!bondFlg) {
            // 単独為替、利金為替、償還為替
            retList = fxdsInfoList.stream()
                    .filter(t -> !TradeKbn.SECURITY.getCode().equals(t.getTradeDivision()))
                    .filter(t -> !ProductEnum.FBOND_TRADE.getCode().equals(t.getProduct()) || t.getTradeDivision() == null)
                    .collect(Collectors.toList());
            List<String> inputIdList = dfitTradeExchangeList.stream().map(d -> d.getInputDataId()).distinct().collect(Collectors.toList());
            Iterator<PosSumSourceDto> i = retList.iterator();
            while (i.hasNext()) {
                PosSumSourceDto item = i.next();
                if (inputIdList.contains(item.getOrderNumber().toString() + "_" + item.getRevisionNumber().toString() + "_" + item.getExchangeDivision())) {
                    i.remove();
                }
            }
        } else {
            // 外株円決、外投円決
            retList = fxdsInfoList.stream()
                    .filter(t -> TradeKbn.SECURITY.getCode().equals(t.getTradeDivision()))
                    .filter(t -> ProductEnum.FBOND_TRADE.getCode().equals(t.getProduct()) || t.getProduct() == null || "1".equals(t.getCustomerDivision()))
                    .collect(Collectors.toList());

        }
        // 顧客名前設定
        setDealerBook(retList);
        return retList;
    }

    /**
     * DFIT為替トレードデータ・FXDSマッチング処理 </br>
     *
     * @return
     */
    public List<PosSumSourceDto> matchDfitTradeExchangeDataForFxds() {
        List<String> currencyList = currencyMstList.stream()
                .map(c -> c.getDealCurrency() + c.getSettleCurrency()).collect(Collectors.toList());
        Iterator<PosSumSourceDto> i = dfitInfoList.iterator();
        while (i.hasNext()) {
            PosSumSourceDto item = i.next();
            if (!currencyList.contains(item.getDealCurrency() + item.getSettleCurrency())) {
                i.remove();
            }
            TCurrencyMstBean cmst = currencyMstList.stream()
                    .filter(t -> t.getDealCurrency().equals(item.getDealCurrency()))
                    .filter(t -> t.getSettleCurrency().equals(item.getSettleCurrency()))
                    .findFirst().orElse(null);
            item.setDealAmount(new BigDecimal(item.getDealAmount().stripTrailingZeros().toPlainString()));
            item.setTradeRate(new BigDecimal(item.getTradeRate().stripTrailingZeros().toPlainString()));
            item.setSettleAmount(new BigDecimal(item.getSettleAmount().stripTrailingZeros().toPlainString()));
            if ("1".equals(item.getInputDataSource()) || "2".equals(item.getInputDataSource())) {
                item.setDeliveryDate(cmst.getSpotDate());
            }
            item.setInputDataSource("DFIT");
        }
        return dfitInfoList;
    }

    /**
     * BID為替トレードデータ・FXDSマッチング処理 </br>
     *
     * @param autoFlg 自動約定フラグ
     * @return
     */
    public List<PosSumSourceDto> matchBidTradeForFxds(boolean autoFlg) {
        List<PosSumSourceDto> retList = new ArrayList<>();
        if (autoFlg) {
            // 営業店自動約定データ
            retList = bidInfoList.stream().filter(t -> "1".equals(t.getBidHonkbn())).collect(Collectors.toList());
        } else {
            // インターナル伝票仕分け
            retList = bidInfoList.stream().filter(t -> !"1".equals(t.getBidHonkbn()) || t.getBidHonkbn() == null)
                    .filter(t -> "DD1".equals(t.getBidAtbutcd()))
                    .filter(t -> "911513".equals(t.getBidAkokcd1()))
                    .collect(Collectors.toList());

        }
        // 顧客名前設定
        setDealerBook(retList);
        return retList;
    }
    /**
     * BID外Mデータ仕分けデータ・FXDSマッチング処理 </br>
     *
     * @return
     */
    public List<PosSumSourceDto> matchBidOutSideMForFxds() {
        // 顧客名前設定
        setDealerBook(bidOutMInfoList);
        return bidOutMInfoList;
    }

    /**
     * 顧客名前設定処理
     *
     * @param posSumSourceList ポジション集計元情報データ
     */
    private void setDealerBook(List<PosSumSourceDto> posSumSourceList) {
        TDfitCustomerMstBean posCust = new TDfitCustomerMstBean();
        TDfitCustomerMstBean spotCust = new TDfitCustomerMstBean();
        TDfitCustomerMstBean swapCust = new TDfitCustomerMstBean();
        for (PosSumSourceDto item : posSumSourceList) {
            posCust = dfitCurrencyMstList.stream()
                    .filter(t -> t.getDepartmentCode().equals(item.getDepartmentCode()))
                    .filter(t -> t.getCustomerCode().equals(item.getCustomerCode()))
                    .findFirst().orElse(null);
            spotCust = dfitCurrencyMstList.stream()
                    .filter(t -> t.getDepartmentCode().equals(item.getDepartmentCodeSpot()))
                    .filter(t -> t.getCustomerCode().equals(item.getCustomerCodeSpot()))
                    .findFirst().orElse(null);
            swapCust = dfitCurrencyMstList.stream()
                    .filter(t -> t.getDepartmentCode().equals(item.getDepartmentCodeSwap()))
                    .filter(t -> t.getCustomerCode().equals(item.getCustomerCodeSwap()))
                    .findFirst().orElse(null);

            if ("0".equals(item.getDealerBook())) {
                // フォワードから生成したスポット
                item.setExchangeDivision(ExchangeKbn.SPOT.getCode());
                if (posCust != null && posCust.getCustomerName() != null && posCust.getRemarks() != null && posCust.getRemarks().contains(REMARKS_POSITION)) {
                    item.setDealerBook(posCust.getCustomerName());
                } else if (spotCust != null && spotCust.getCustomerName() != null) {
                    item.setDealerBook(spotCust.getCustomerName());
                } else {
                    item.setDealerBook(null);
                }
            }
            if ("1".equals(item.getDealerBook()) || "2".equals(item.getDealerBook())) {
                // フォワードから生成したスワップスタート・エンド
                if ("1".equals(item.getDealerBook())) {
                    item.setExchangeDivision(ExchangeKbn.SWAP_START.getCode());
                } else {
                    item.setExchangeDivision(ExchangeKbn.SWAP_END.getCode());
                }
                if (posCust != null && posCust.getCustomerName() != null && posCust.getRemarks() != null && posCust.getRemarks().contains(REMARKS_POSITION)) {
                    item.setDealerBook(posCust.getCustomerName());
                } else if (swapCust != null && swapCust.getCustomerName() != null) {
                    item.setDealerBook(swapCust.getCustomerName());
                } else {
                    item.setDealerBook(null);
                }
            }
            if ("10".equals(item.getDealerBook())) {
                // スポット、スワップ
                if (posCust != null && posCust.getCustomerName() != null && posCust.getRemarks() != null && posCust.getRemarks().contains(REMARKS_POSITION)) {
                    item.setDealerBook(posCust.getCustomerName());
                } else if (ExchangeKbn.SPOT.getCode().equals(item.getExchangeDivision()) && spotCust != null && spotCust.getCustomerName() != null) {
                    item.setDealerBook(spotCust.getCustomerName());
                } else if (swapCust != null && swapCust.getCustomerName() != null) {
                    item.setDealerBook(swapCust.getCustomerName());
                } else {
                    item.setDealerBook(null);
                }
            }
        }
    }
    /**
     * @param currencyMstList セットする currencyMstList
     */
    public void setCurrencyMstList(List<TCurrencyMstBean> currencyMstList) {
        this.currencyMstList = currencyMstList;
    }

    /**
     * @param dfitCurrencyMstList セットする dfitCurrencyMstList
     */
    public void setDfitCurrencyMstList(List<TDfitCustomerMstBean> dfitCurrencyMstList) {
        this.dfitCurrencyMstList = dfitCurrencyMstList;
    }

    /**
     * @param dfitTradeExchangeList セットする dfitTradeExchangeList
     */
    public void setDfitTradeExchangeList(List<TDfitTradeExchangeBean> dfitTradeExchangeList) {
        this.dfitTradeExchangeList = dfitTradeExchangeList;
    }

    /**
     * @param fxdsInfoList セットする fxdsInfoList
     */
    public void setFxdsInfoList(List<PosSumSourceDto> fxdsInfoList) {
        this.fxdsInfoList = fxdsInfoList;
    }

    /**
     * @param dfitInfoList セットする dfitInfoList
     */
    public void setDfitInfoList(List<PosSumSourceDto> dfitInfoList) {
        this.dfitInfoList = dfitInfoList;
    }

    /**
     * @param bidInfoList セットする bidInfoList
     */
    public void setBidInfoList(List<PosSumSourceDto> bidInfoList) {
        this.bidInfoList = bidInfoList;
    }

    /**
     * @param bidOutMInfoList セットする bidOutMInfoList
     */
    public void setBidOutMInfoList(List<PosSumSourceDto> bidOutMInfoList) {
        this.bidOutMInfoList = bidOutMInfoList;
    }
}
 