package jp.co.daiwa.jbpos1000;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.DBUtil;
import jp.co.daiwa.common.DateUtil;
import jp.co.daiwa.common.TargetFileFilter;
import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.common.constant.ExchangeKbnEnum.ExchangeKbn;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.TBatchExecBaseDateRepository;
import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.TCurrencyMstRepository;
import jp.co.daiwa.dao.TDfCalcResultRepository;
import jp.co.daiwa.dao.TDfHistoryDateRepository;
import jp.co.daiwa.dao.TPosSumManualRateRepository;
import jp.co.daiwa.dao.TPosSumSourceDataRepository;
import jp.co.daiwa.dao.TPositionPlDeltaDataRepository;
import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.TPositionSwapSumDataRepository;
import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TDfarmBbgRateBean;
import jp.co.daiwa.dao.bean.TDfitCustomerMstBean;
import jp.co.daiwa.dao.bean.TDfitTradeExchangeBean;

import jp.co.daiwa.dao.bean.TPositionPlDeltaDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.daobid.Tb86bet0Repository;
import jp.co.daiwa.daodfit.TDfarmBbgRateRepository;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.dto.PosBaseRateDto;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.dto.TPositionSwapSumDataDto;

/**
 * ポジション集計処理
 *
 * @author CHEN
 */
@Component
@Scope("step")
public class Jbpos1000PosSumTasklet implements Tasklet {

    @Inject
    @Named("jobTransactionManager")
    PlatformTransactionManager transactionManager;
    // 売買区分(買)
    private static final String BUY = "1";
    // レート取得先(ST)
    private static final String RATESOURCESMART = "1";
    // レート取得先(BBG)
    private static final String RATESOURCEBBG = "0";
    // 対円通貨
    private static final String JPY = "JPY";
    // データ取得元(BID_R)
    private static final String DATA_SOURCE_BIDR = "BID_R";
    // ACフラグ(インタイム)
    private static final String NONAC = "0";
    // ACフラグ(アフタークローズ)
    private static final String AC = "1";
    public static final SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
    public static final String DATE_PATTERN = "yyyy/MM/dd HH:mm:ss";
    // 累積確定PL取得用リスト
    List<TPositionSpotSumDataBean> tPositionSpotSumDataPlBeanList = new ArrayList<>();

    /** 評価レートファイル格納場所 */
    @Value("${job.jbpos1000.input.path}")
    private String inputFilePath;

    @Value("${job.jbpos1000.input.filename.prefix}")
    private String closeRateFileNamePrefix;

    /** ベースレートファイル格納場所 */
    @Value("${job.jbpos1000.output.path}")
    private String baseRateFilePath;

    @Value("${job.jbpos1000.output.filename.prefix}")
    private String inputFileNamePrefix;

    /** 出力ファイル格納場所 */
    @Value("${job.jbpos1000.path}")
    private String outputFilePath;

    @Value("${job.jbpos1000.file.stop}")
    private String stopFile;

    @Value("${job.jbpos1000.interval}")
    private String jobInterval;

    @Value("${bulk.insert.unit}")
    private int bulkInsertUnit;

    @Value("${job.jbpos1000.time}")
    private String dayCloseTime;

    @Inject
    Tb86bet0Repository tb86bet0Dao;
    @Inject
    TBatchExecBaseDateRepository tBatchExecBaseDateDao;
    @Inject
    TPosSumManualRateRepository tPosSumManualRateDao;
    @Inject
    TPosSumSourceDataRepository tPosSumSourceDataDao;
    @Inject
    TPositionPlDeltaDataRepository tPosPlDeltaDataDao;
    @Inject
    TPositionSpotSumDataRepository tPosSoptSumDataDao;
    @Inject
    TPositionSwapSumDataRepository tPosSwapSumDataDao;
    @Inject
    TByCcyDeltaCashBalanceRepository tByCcyDeltaCashDataDao;
    @Inject
    TSwapPlSumDateRepository tSwapPlSumDateDao;
    @Inject
    TDfCalcResultRepository tDfCalcResultDao;
    @Inject
    TDfHistoryDateRepository tDfHistoryDateDao;
    @Inject
    TDfarmBbgRateRepository tDfarmBbgRateDao;
    @Inject
    TCurrencyMstRepository tCurrencyMstRepository;

    /** 基準日 */
    private static Date targetDate;
    /** 前日営業日 */
    private static Date busiDaysBefore;
    /** 為替トレードデータ.ステータス */
    private static final List<String> STATUS_LIST = new ArrayList<String>(Arrays.asList("2", "3"));

    /** DB操作クラス */
    @Inject
    @Named("dbOperation")
    private JbPositionDbOperation dbOperation;
    /** データ操作クラス */
    @Inject
    @Named("dataOperation")
    private JpPositionDataOperation dataOperation;

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(Jbpos1000PosSumTasklet.class);

    @Override
public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

    Path p = Paths.get(stopFile);
    // 常駐バッチの実行間隔(単位:秒)
    int intJobInterval = Integer.parseInt(jobInterval) * 1000;
    // バッチの実行間隔
    int handleInterval = 60000;
    Runtime r = Runtime.getRuntime();
    while (true) {
        try {
            long startTime = System.currentTimeMillis();
            if (Files.exists(p)) {
                // ジョブ停止ファイルがある場合
                Files.deleteIfExists(p);
                logger.info(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_I001", stopFile);
                break;
            }
            // 初期化
            init();
            if (targetDate != null) {
                // バッチ実行基準日が営業日の場合
                posSumTask(contribution, targetDate);
                // 営業日の場合のバッチの実行間隔
                Thread.sleep(intJobInterval);
            } else {
                // 営業日でない場合のバッチの実行間隔
                Thread.sleep(handleInterval);
            }
            // ガベージコレクションを強制的に実行する
            r.gc();
            long endTime = System.currentTimeMillis();
            logger.trace(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_I028",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), "処理時間:" + (endTime - startTime) + " ms");
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                logger.error(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_E001", "DB接続", e);
                // DB切断された時、処理終了
                break;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                    JobConstants.Jbpos1000_Name, e);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);

            try {
                // ガベージコレクションを強制的に実行する
                r.gc();
                // 大量エラーログの出力を回避する
                Thread.sleep(handleInterval);
            } catch (InterruptedException ie) {
            }
        }
    }
    return RepeatStatus.FINISHED;
}

    /**
     * ポジション集計メイン処理
     *
     * @param contribution
     * @param targetDate
     * @throws Exception
     */
    private void posSumTask(StepContribution contribution, Date targetDate) throws Exception {

        List<TPosSumSourceDataBean> posSumSourceDataList = new ArrayList<>();
        // 現在日時を取得
        String nowDateYmdhms = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HHmmss"));
        try {
            // マニュアルレート取得
            List<TPosSumManualRateBean> tPosSumManualRateList = getPosSumManualRate(contribution, targetDate);
            // BBGレート取得
            List<TDfarmBbgRateBean> tDfarmBbgRateBeanList = getDfarmBbgRateBean(contribution, targetDate);
            // ポジション集計元情報削除
            // ①処理基準日=バッチ実行日(当日)かつseq_no≠0(当日スタートポジションを除く)
            // ②処理基準日<バッチ実行日(処理基準日が前日取得した約定、前日スタートポジションを含む)
            TPosSumSourceDataBean tPosSumSourceDataBean = new TPosSumSourceDataBean();
            // パラメータを渡す
            tPosSumSourceDataBean.setProcessBaseDate(targetDate);
            posSumSourceDataDelete(contribution, tPosSumSourceDataBean);

            // 残ったポジション集計元情報を取り出す(日締めで作成したスタートポジション)
            // ポジション集計元情報データ取得する
            TPosSumSourceDataBean startposSumSourceData = new TPosSumSourceDataBean();
            // パラメータを渡す(処理基準日=バッチ実行日)
            startposSumSourceData.setProcessBaseDate(targetDate);
            List<TPosSumSourceDataBean> startposSumSourceDataList = tPosSumSourceDataDao
                    .getPosSumSourceDataAll(startposSumSourceData);
            // 対象となるデータ(スタートポジション)が存在した場合
            if (startposSumSourceDataList.size() > 0) {
                // マッピング処理
                List<TPosSumSourceDataBean> starttPosSumSourceDataList = posSumSourceDataMapping(contribution,
                        targetDate, startposSumSourceDataList, tPosSumManualRateList, tDfarmBbgRateBeanList);
                // ポジション集計元情報へアップデート
                posSumSourceDataUpdate(contribution, starttPosSumSourceDataList);
            }
            // 1.2各DBから取引データをかき集める
            // <単独為替、利金為替、償還為替(FXDS取得分)>
            List<PosSumSourceDto> tPosSourceDataList = dataOperation.matchTradeMngDataForDfit(false);
            // <外株円決、外投円決(FXDS)>
            tPosSourceDataList.addAll(dataOperation.matchTradeMngDataForDfit(true));
            // <単独為替(DFIT取得分)>
            tPosSourceDataList.addAll(dataOperation.matchDfitTradeExchangeDataForFxds());
            // <リテール分営業店自動約定データ(BID)>
            tPosSourceDataList.addAll(dataOperation.matchBidTradeForFxds(true));
            // <リテール分インターナル伝票仕分け(BID)>
            tPosSourceDataList.addAll(dataOperation.matchBidTradeForFxds(false));
            // <リテール分外Mデータ仕分け(BID)>
            tPosSourceDataList.addAll(dataOperation.matchBidOutSideMForFxds());

            // PosSumSourceDtoからポジション集計元情報型に変換
            List<TPosSumSourceDataBean> tPosSumSourceSumDataList = setSourceData(contribution, targetDate,
                    tPosSourceDataList);
            // 対象となるデータが存在した場合
            if (tPosSumSourceSumDataList.size() > 0) {
                // マッピング処理
                List<TPosSumSourceDataBean> tPosSumSourceDataList = posSumSourceDataMapping(contribution, targetDate,
                        tPosSumSourceSumDataList, tPosSumManualRateList, tDfarmBbgRateBeanList);
                // 1.4.ポジション集計元情報Insert処理(中間コミット)
                posSumSourceDataInsert(contribution, tPosSumSourceDataList);
            }
            // ポジション集計元情報データ取得する
            TPosSumSourceDataBean posSumSourceData = new TPosSumSourceDataBean();
            // パラメータを渡す(処理基準日=バッチ実行日)
            posSumSourceData.setProcessBaseDate(targetDate);
            List<TPosSumSourceDataBean> posSumSourceList = tPosSumSourceDataDao
                    .getPosSumSourceDataAll(posSumSourceData);

            // 集計となる対象データが存在した場合
            if (posSumSourceList.size() > 0) {
                // :処理フロー2.Real集計処理
                setPosRealData(contribution, targetDate, busiDaysBefore, EvaluationRateKbn.REAL.getCode(),
                        posSumSourceList, nowDateYmdhms);

                List<CloseRateDto> closeRateList;
                try {

                            // 引値レート取得
                    closeRateList = getCloseRateInfo(contribution, targetDate, inputFilePath);
                    // 引値レート取得有無処理判断
                    if (closeRateList.size() > 0) {
                        // 集計対象データの引値レート有無チェック、再設定
                        posSumSourceDataList = setClosingRate(contribution, targetDate, posSumSourceList, closeRateList,
                                tPosSumManualRateList, tDfarmBbgRateBeanList);

                        // 処理フロー3.プレ引値集計処理(スポットのみ)
                        setPosPreClosingData(contribution, targetDate, busiDaysBefore,
                                EvaluationRateKbn.PRE_CLOSING.getCode(), posSumSourceDataList, nowDateYmdhms);
                        // 処理フロー4.決済通貨外貨のPLデルタ登録
                        setPosPlDeltaValueData(contribution, targetDate, closeRateList);
                        // 処理フロー5.引値集計処理
                        setClosingValueData(contribution, targetDate, busiDaysBefore,
                                EvaluationRateKbn.CLOSING_PRICE.getCode(), posSumSourceDataList, nowDateYmdhms);
                        // 処理フロー6.引値以降集計処理
                        setClosingAfterValueData(contribution, targetDate, busiDaysBefore,
                                EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode(), posSumSourceDataList,
                                tPosSumManualRateList, tDfarmBbgRateBeanList, nowDateYmdhms);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } 
        } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                    // DB切断された時、処理終了
                    throw e;
                }
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", JobConstants.Jbpos1000_Name,
                        e);

                // ジョブ警告状態を設定
                contribution.getStepExecution().getJobExecution().getExecutionContext()
                        .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
    }

    /**
     * 引値レートチェック、再設定
     *
     * @param contribution
     * @param targetDate
     * @param posSumSourceList
     * @param closeRateList
     * @return
     * @throws Exception
     */
    static List<TPosSumSourceDataBean> setClosingRate(StepContribution contribution, Date targetDate,
            List<TPosSumSourceDataBean> posSumSourceList, List<CloseRateDto> closeRateList,
            List<TPosSumManualRateBean> tPosSumManualRateList, List<TDfarmBbgRateBean> tDfarmBbgRateBeanList)
            throws Exception {

        List<TPosSumSourceDataBean> posSumSourceDataList = new ArrayList<>();

        for (TPosSumSourceDataBean item : posSumSourceList) {

            String str = new SimpleDateFormat("yyyy/MM/dd").format(targetDate);
            TPosSumSourceDataBean pos = new TPosSumSourceDataBean();

            // ポジション集計マニュアル対円レート
            TPosSumManualRateBean manualYenRate = tPosSumManualRateList.stream()
                    // 集計となる対象データの売買通貨 = ポジション集計マニュアルレートの売買通貨
                    .filter(c -> c.getDealCurrency().equals(item.getSettleCurrency().trim()))
                    // 集計となる対象データの決済通貨 = ポジション集計マニュアルレートの決済通貨
                    .filter(c -> c.getSettleCurrency().equals("JPY")).findFirst().orElse(null);

            // シーケンスNO
            pos.setSeqNo(item.getSeqNo());
            // 処理基準日
            pos.setProcessBaseDate(item.getProcessBaseDate());
            // 約定日時
            pos.setTradeDatetime(item.getTradeDatetime());
            // ディーラーブック
            pos.setDealerBook(item.getDealerBook());
            // データ源泉
            pos.setInputDataSource(item.getInputDataSource());
            // AC
            pos.setAc(item.getAc());
            // 売買通貨
            pos.setDealCurrency(item.getDealCurrency());
            // 決済通貨
            pos.setSettleCurrency(item.getSettleCurrency());
            // 通貨ペア
            pos.setCurrencyPair(item.getCurrencyPair());
            // 為替区分
            pos.setExchangeDivision(item.getExchangeDivision());
            // 受渡日
            pos.setDeliveryDate(item.getDeliveryDate());
            // 売買区分
            pos.setDealDivision(item.getDealDivision());
            // 売買金額
            pos.setDealAmount(item.getDealAmount());
            // 取引レート
            pos.setTradeRate(item.getTradeRate());
            // 決済金額
            pos.setSettleAmount(item.getSettleAmount());
            // 評価レート区分
            pos.setEvaluationRateDivision(item.getEvaluationRateDivision());
            // Real評価レート
            pos.setRealRate(item.getRealRate());
            // 引値レートがNULLの場合、再設定
            if (item.getClosingRate() == null) {

                CloseRateDto closeRate = closeRateList.stream()
                        // 評価レートファイルの基準日 = バッチ実行日取得
                        .filter(b -> str.equals(b.getBaseDate()))
                        // 評価レートファイルの売買通貨 = 集計となる対象データの売買通貨
                        .filter(b -> b.getDealCurrency().equals(item.getDealCurrency().trim()))
                        // 評価レートファイルの決済通貨 = 集計となる対象データの決済通貨
                        .filter(b -> b.getSettleCurrency().equals(item.getSettleCurrency().trim())).findFirst()
                        .orElse(null);
                if (JPY.equals(item.getDealCurrency()) && JPY.equals(item.getSettleCurrency())) {
                    pos.setClosingRate(BigDecimal.ONE);
                } else {
                    // 評価レートがNULLでない場合、評価レートを設定、NULLの場合NULLを設定
                    pos.setClosingRate(closeRate != null ? closeRate.getCloseRate() : null);
                }
            } else {
                pos.setClosingRate(item.getClosingRate());
            }
            // マニュアル(日中時価評価レート)
            pos.setManualDailyRate(item.getManualDailyRate());
            // マニュアル(引値レート、TTM)
            pos.setManualClosingTtmRate(item.getManualClosingTtmRate());
            // レート取得先
            pos.setRateSource(item.getRateSource());
            // BBGレート
            pos.setBbgRate(item.getBbgRate());
            // Real円転レート
            pos.setRealYenRate(item.getRealYenRate());
            // 引値円転レート
            // 引値円転レートがNULLの場合、再設定
            if (item.getClosingYenRate() == null) {
                // マニュアル(引値レート、TTM)がNULLでない場合
                if (item.setManualClosingTtmRate() != null) {
                    // 集計となる対象データの通貨ペア(売買通貨)がJPYの場合
                    if (JPY.equals(item.getSettleCurrency().trim())) {
                        pos.setClosingYenRate(BigDecimal.ONE);
                    }else{
                        pos.setClosingYenRate(manualYenRate != null ? manualYenRate.getManualClosingTtmRate():null);
                    }
                } else 
                        // 為替区分が約定済以外の場合
                        if (ExchangeKbn.TRADEDCF.getCode().equals(item.getExchangeDivision())) {
                            CloseRateDto closeYenRate = closeRateList.stream()
                                    // 評価レートファイルの基準日＝バッチ基準日である
                                    .filter(b -> b.getBaseDate().equals(str))
                                    // 評価レートファイルの売買通貨 = 集計となる対象データの決済通貨
                                    .filter(b -> b.getDealCurrency().equals(item.getSettleCurrency().replaceAll("", "")))
                                    // 評価レートファイルの決済通貨 = JPY
                                    .filter(b -> JPY.equals(b.getSettleCurrency())).findFirst()
                                    .orElse(null);
                            if (JPY.equals(item.getSettleCurrency().replaceAll(" ",""))) {
                                pos.setClosingYenRate(BigDecimal.ONE);
                            } else {
                                // 評価レートがNULLでない場合、評価レートを設定、NULLの場合>NULLを設定
                                pos.setClosingYenRate(closeYenRate == null ? null : closeYenRate.getCloseRate());
                            }
                } else {
                    CloseRateDto closeYenRate = closeRateList.stream()
                            // 評価レートファイルの基準日＝バッチ基準日である
                            .filter(b -> b.getBaseDate().equals(str))
                            // 評価レートファイルの売買通貨 = 評集計となる対象データの売買通貨
                            .filter(b -> b.getDealCurrency().equals(item.getDealCurrency().replaceAll("", "")))
                            // 評価レートファイルの決済通貨 = JPY
                            .filter(b -> b.getSettleCurrency().equals("JPY")).findFirst()
                            // 評価レートファイルの対JPY = 詳細レートファイルの対JPYがNULL()でない場合
                            .orElse(null);
                    if (JPY.equals(item.getDealCurrency().trim())) {
                        pos.setClosingYenRate(BigDecimal.ONE);
                    } else {
                        // 評価レートがNULLでない場合、評価レートを設定、NULの場合>NULLを設定
                        pos.setClosingYenRate(closeYenRate != null ? closeYenRate.getCloseRate() : null);
                    }
                }
            } else {
                pos.setClosingYenRate(item.getClosingYenRate());
            }
            // 前日繰越
            pos.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
            // 前日取引金PV(引値)
            pos.setBeforeTradeAmountPvCls(item.getBeforeTradeAmountPvCls());
            // 前日取引金PV(引値)円転
            pos.setBeforeTradeAmountPvClsYen(item.getBeforeTradeAmountPvClsYen());
            // 登録者
            pos.setRegisterUser(item.getRegisterUser());
            // 登録日時
            pos.setRegisterDatetime(item.getRegisterDatetime());
            // 更新者
            pos.setUpdateUser(item.getUpdateUser());
            // 更新日時
            pos.setUpdateDatetime(item.getUpdateDatetime());

            // リストに追加
            posSumSourceDataList.add(pos);
        }
        return posSumSourceDataList;
    }

    /**
     * 各DBから取得したデータをポジション取得元に変換
     *
     * @param contribution
     * @param targetDate
     * @param tPosSumSourceDataList
     * @throws Exception
     */
    private List<TPosSumSourceDataBean> setSourceData(StepContribution contribution, Date targetDate,
            List<PosSumSourceDto> tPosSourceDataList) {

        List<TPosSumSourceDataBean> tPosSumSourceSumDataList = new ArrayList<>();

        for (PosSumSourceDto item : tPosSourceDataList) {

            TPosSumSourceDataBean posSpotSourceData = new TPosSumSourceDataBean();
            // 取引レートがNULL以外の場合
            if (item.getTradeRate() == null && item.getDealerBook() == null && item.getDeliveryDate() == null) {
                // 処理基準日
                posSpotSourceData.setProcessBaseDate(targetDate);
                // 約定日時
                posSpotSourceData.setTradeDatetime(new Timestamp(item.getTradeDate().getTime()));
                // データ種類
                posSpotSourceData.setDealerBook(item.getDealerBook());
                // データ源別
                posSpotSourceData.setInputDataSource(item.getInputDataSource());
                // ACラック
                posSpotSourceData.setAc(item.getAc());
                // 売買通貨
                posSpotSourceData.setDealCurrency(item.getDealCurrency());
                // 決済通貨
                posSpotSourceData.setSettleCurrency(item.getSettleCurrency());
                // 通貨ペア
                posSpotSourceData.setCurrencyPair(item.getCurrencyPair());
                // 為替区分
                posSpotSourceData.setExchangeDivision(item.getExchangeDivision());
                // 受渡日
                posSpotSourceData.setDeliveryDate(item.getDeliveryDate());
                // 売買区分
                posSpotSourceData.setDealDivision(item.getDealDivision());
                // 売買金額
                posSpotSourceData.setDealAmount(item.getDealAmount());
                // レート
                posSpotSourceData.setTradeRate(item.getTradeRate());
                // 決済金額
                posSpotSourceData.setSettleAmount(item.getSettleAmount());

                // リストに追加
                tPosSumSourceSumDataList.add(posSpotSourceData);
                continue;
            // 取引レートが存在しないかつデータ源泉がBID_Rの場合
            } else if (item.getTradeRate() == null && DATA_SOURCE_BIDR.equals(item.getInputDataSource())) {
                // 該当通貨ペアの取引レートと決済金額が存在しない場合、ログに出力
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジション集計データ取得処理",
                        "ディーラーブック:" + item.getDealerBook() + FxdConstants.COMMA
                                + "通貨ペア:" + item.getCurrencyPair() + FxdConstants.COMMA
                                + "受渡日:" + DateUtil.convertDateToStrYmd(item.getDeliveryDate()) + FxdConstants.COMMA
                                + "データ源別:" + item.getInputDataSource() + FxdConstants.COMMA
                                + "の該当FWDポイントが取得できなかったため処理から除外。");
            // 取引レートが存在しない場合
            } else if (item.getTradeRate() == null) {
                // 該当通貨ペアの取引レートが存在しない場合、ログに出力
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジション集計データ取得処理",
                        "通貨ペア:" + item.getCurrencyPair() + FxdConstants.COMMA
                                + "データ源別:" + item.getInputDataSource() + FxdConstants.COMMA
                                + "の取引レートがNULLであるため処理から除外。");
            } else if (item.getDealerBook() == null) {
                // ディーラーブックが存在しない場合、ログに出力
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジション集計データ取得処理",
                        "通貨ペア:" + item.getCurrencyPair() + FxdConstants.COMMA
                        + "データ源泉:" + item.getInputDataSource() + FxdConstants.COMMA
                                + "のディーラーブックがNULLであるため処理から除外");
            } else if (item.getDeliveryDate() == null) {
                // 受渡日存在しない場合
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジション集計データ取得処理",
                    "ディーラーブック:" + item.getDealerBook() + FxdConstants.COMMA
                            + "通貨ペア:" + item.getCurrencyPair() + FxdConstants.COMMA
                            + "データ源泉:" + item.getInputDataSource()
                            + "の該当受渡日が取得できなかったため処理から除外。");
        }
        // ジョブ警告状態を設定
        contribution.getStepExecution().getJobExecution().getExecutionContext()
                .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
        return tPosSumSourceSumDataList;
    }

/**
 * ポジション集計データマッピング処理
 *
 * @param contribution
 * @param targetDate
 * @param posSumSourceSumDataList ポジション集計元情報
 * @param tPosSumManualRateList マニュアルレート情報
 * @param tDfarmBbgRateBeanList BBGレート情報
 * @throws Exception
 */
private List<TPosSumSourceDataBean> posSumSourceDataMapping(StepContribution contribution, Date targetDate,
        List<TPosSumSourceDataBean> tPosSumSourceSumDataList, List<TPosSumManualRateBean> tPosSumManualRateList,
        List<TDfarmBbgRateBean> tDfarmBbgRateBeanList) throws Exception {

    List<TPosSumSourceDataBean> posSumSourceDataList = new ArrayList<>();
    String strTargetDate = new SimpleDateFormat("yyyy/MM/dd").format(targetDate);
    BigDecimal max = BigDecimal.ZERO;
    BigDecimal index = BigDecimal.ONE;

    // ベースレート取得
    List<PosBaseRateDto> baseRateMap = getBaseRateInfo(contribution, baseRateFilePath);
    // 詳細レート
    List<CloseRateDto> closeRateList = getCloseRateInfo(contribution, targetDate, inputFilePath);
    // 通貨マスタ
    List<TCurrencyMstBean> tCurrencyMstList = tCurrencyMstRepository.getTCurrencyMstAll();
    // 外貨対円レート情報
    List<TCurrencyMstBean> cMstSettleJpyList = tCurrencyMstRepository.getTCurrencyMstAll()
            .filter(d -> JPY.equals(d.getSettleCurrency()))
            .collect(Collectors.toList());
    // ポジション集計元情報データ取得する
    List<TPosSumSourceDataBean> posSumSourceList = tPosSumSourceDataDao.getPosSumSourceData();

    if (posSumSourceList.size() > 0) {
        // SeqNo最大値取得
        max = posSumSourceList.stream().max(Comparator.comparing(p -> p.getSeqNo())).get().getSeqNo();
    }

    // ポジション集計元情報マッピング設定処理
    for (TPosSumSourceDataBean d : tPosSumSourceSumDataList) {
        // レート取得処理
        TCurrencyMstBean currencyMst = tCurrencyMstList.stream()
                .filter(c -> c.getDealCurrency().equals(d.getDealCurrency()))
                .filter(c -> c.getSettleCurrency().equals(d.getSettleCurrency())).findFirst()
                .orElse(null);
        // BBGレート情報
        TDfarmBbgRateBean bbgRate = tDfarmBbgRateBeanList.stream()
                .filter(c -> c.getDealCurrency().equals(d.getCurrencyPair())).findFirst()
                .orElse(null);
        // ギション集計マニュアルレート情報データ取得する
        TPosSumManualRateBean manualRate = tPosSumManualRateList.stream()
                .filter(c -> c.getDealCurrency().equals(d.getDealCurrency()))
                .filter(c -> c.getSettleCurrency().equals(d.getSettleCurrency())).findFirst()
                .orElse(null);
        // 引値(レート)情報
        CloseRateDto closeRate = closeRateList.stream()
                .filter(b -> strTargetDate.equals(b.getBaseDate()))
                .filter(b -> b.getDealCurrency().equals(d.getDealCurrency()))
                .filter(b -> b.getSettleCurrency().equals(d.getSettleCurrency())).findFirst()
                .orElse(null);
        // ベースレート
        PosBaseRateDto BaseRate = baseRateMap.stream()
                .filter(a -> a.getCurrencyPair().equals(d.getCurrencyPair())).findFirst()
                .orElse(null);

            try {
                TPosSumSourceDataBean data = new TPosSumSourceDataBean();
                // SEQNO
                if (d.getSeqNo() != null) {
                    data.setSeqNo(d.getSeqNo());
                } else {
                    data.setSeqNo(max.add(index));
                }
                // 処理基準日
                data.setProcessBaseDate(targetDate);
                // 約定日時
                data.setTradeDatetime(new Timestamp(d.getTradeDate().getTime()));
                // ディーラーブック
                data.setDealerBook(d.getDealerBook());
                // データ源泉
                data.setInputDataSource(d.getInputDataSource());
                // AC
                data.setAc(d.getAc().trim());
                // 売買通貨
                data.setDealCurrency(d.getDealCurrency().trim());
                // 決済通貨
                data.setSettleCurrency(d.getSettleCurrency().trim());
                // 通貨ペア
                data.setCurrencyPair(d.getCurrencyPair());
                // 為替区分
                data.setExchangeDivision(d.getExchangeDivision().substring(0, 1));
                // 受渡日
                data.setDeliveryDate(d.getDeliveryDate());
                // 売買区分
                data.setDealDivision(d.getDealDivision().trim());
                // 売買金額
                data.setDealAmount(d.getDealAmount());
                // 取引レート
                data.setTradeRate(d.getTradeRate());
                // 決済金額
                data.setSettleAmount(d.getSettleAmount());
                // 評価レート区分
                data.setEvaluationRateDivision(null);
                if (JPY.equals(d.getDealCurrency()) && JPY.equals(d.getSettleCurrency())) {
                    // Realレート
                    data.setRealRate(BigDecimal.ONE);
                    // 引値レート
                    data.setClosingRate(BigDecimal.ONE);
                } else {
                    // Realレート
                    data.setRealRate(BaseRate != null ? new BigDecimal(BaseRate.getBidRate()).add(new BigDecimal(BaseRate.getAskRate()))
                            .divide(new BigDecimal(2)) : null);
                    // 引値レート
                    data.setClosingRate(closeRate != null ? closeRate.getCloseRate() : null);
                }
                // マニュアル(日中時価評価レート)
                data.setManualDailyRate(manualRate != null ? manualRate.getManualDailyRate() : null);
                // マニュアル(引値レート、TTM)
                data.setManualClosingTtmRate(manualRate != null ? manualRate.getManualClosingTtmRate() : null);
                // レート取得先
                data.setRateSource(currencyMst != null ? currencyMst.getRateSource() : null);
                // BBGレート情報
                data.setBbgRate(bbgRate != null ? bbgRate.getRate() : null);
                // Real円転レート
                data.setRealYenRate(getRealJpyRate(baseRateMap, d, tPosSumManualRateList, tDfarmBbgRateBeanList, cMstSettleJpyList));
                // 引値円転レート
                data.setClosingYenRate(getClosingJpyRate(closeRateList, d, strTargetDate, tPosSumManualRateList));
                // 前日繰越
                data.setBeforeEvaluationPosition(d.getBeforeEvaluationPosition());
                // 前日取引金PV(引値)
                data.setBeforeTradeAmountPvCls(d.getBeforeTradeAmountPvCls());
                // 前日取引金PV(引値)円転
                data.setBeforeTradeAmountPvClsYen(d.getBeforeTradeAmountPvClsYen());
                // 登録者
                data.setRegisterUser(JobConstants.Jbpos1000);
                // 登録日時
                data.setRegisterDatetime(null);
                // 更新者
                data.setUpdateUser(JobConstants.Jbpos1000);
                // 更新日時
                data.setUpdateDatetime(null);

                // リスト追加
                posSumSourceDataList.add(data);
                index = index.add(BigDecimal.ONE);
            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                    // DB切断された時、処理終了
                    throw e;
                }
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジション集計データマッピング処理", e);
                // ジョブ警告状態を設定
                contribution.getStepExecution().getJobExecution().getExecutionContext()
                        .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
            }
        }
    return posSumSourceDataList;
}

    /**
     * 引値円転レート取得処理
     *
     * @param closeRateList 引値レート情報
     * @param data ポジション集計元情報データ
     * @param strTargetDate バッチ実行基準日
     * @param manualRateList マニュアルレート情報
     * @return
     */
    private BigDecimal getClosingJpyRate(
            List<CloseRateDto> closeRateList,
            TPosSumSourceDataBean data,
            String strTargetDate,
            List<TPosSumManualRateBean> manualRateList) {
        // 初期設定
        BigDecimal closeRate = null;
        CloseRateDto closeYenRate = new CloseRateDto();
        TPosSumManualRateBean manualYenRate = new TPosSumManualRateBean();
        if (ExchangeKbn.TRADEDCF.getCode().equals(data.getExchangeDivision())) {
            // スワップかつスタートポジション(為替区分=約定済CF)
            if (JPY.equals(data.getDealCurrency())) {
                // 売買通貨がJPYの場合
                return BigDecimal.ONE;
            }
            // 引値円転レート(売買通貨)
            closeYenRate = closeRateList.stream().filter(b -> b.getBaseDate().equals(strTargetDate))
                    .filter(b -> b.getDealCurrency().equals(data.getDealCurrency()))
                    .filter(b -> JPY.equals(b.getSettleCurrency()))
                    .findFirst().orElse(null);
            // マニュアル対円レート情報(売買通貨)
            manualYenRate = manualRateList.stream()
                    .filter(c -> c.getDealCurrency().equals(data.getDealCurrency()))
                    .filter(c -> c.getSettleCurrency().equals(JPY)).findFirst().orElse(null);
        } else {
            if (JPY.equals(data.getSettleCurrency())) {
                // 決済通貨がJPYの場合
                return BigDecimal.ONE;
            }
            // 引値円転レート(決済通貨)
            closeYenRate = closeRateList.stream().filter(b -> b.getBaseDate().equals(strTargetDate))
                    .filter(b -> b.getDealCurrency().equals(data.getSettleCurrency()))
                    .filter(b -> JPY.equals(b.getSettleCurrency()))
                    .findFirst().orElse(null);
            // マニュアル対円レート情報(決済通貨)
            manualYenRate = manualRateList.stream()
                    .filter(c -> c.getDealCurrency().equals(data.getSettleCurrency()))
                    .filter(c -> c.getSettleCurrency().equals(JPY)).findFirst().orElse(null);
        }
        if (manualYenRate != null && manualYenRate.getManualClosingTtmRate() != null) {
            closeRate = manualYenRate.getManualClosingTtmRate();
        } else {
            closeRate = closeYenRate != null ? closeYenRate.getCloseRate() : null;
        }
        return closeRate;
    }

    /**
     * Real円転レート取得処理
     *
     * @param baseRateMap ベースレート情報
     * @param data ポジション集計元情報データ
     * @param manualRateList マニュアルレート情報
     * @param tDfarmBbgRateBeanList BBGレート情報
     * @param cMstSettleJpyList 通貨マスタ決済通貨がJPY情報
     * @return
     */
    private BigDecimal getRealJpyRate(
            List<PosBaseRateDto> baseRateMap,
            TPosSumSourceDataBean data,
            List<TPosSumManualRateBean> manualRateList,
            List<TDfarmBbgRateBean> tDfarmBbgRateBeanList,
            List<TCurrencyMstBean> cMstSettleJpyList) {
        // 初期設定
        BigDecimal jpyRate = null;
        TCurrencyMstBean settleJpyInfo = new TCurrencyMstBean();
        PosBaseRateDto realYenRate = new PosBaseRateDto();
        TDfarmBbgRateBean bbgYenRate = new TDfarmBbgRateBean();
        TPosSumManualRateBean manualYenRate = new TPosSumManualRateBean();

        if (ExchangeKbn.TRADEDCF.getCode().equals(data.getExchangeDivision())) {
            // スワップかつスタートポジション(為替区分=約定済CF)
            if (JPY.equals(data.getDealCurrency())) {
                // 売買通貨がJPYの場合
                return BigDecimal.ONE;
            }
            // 対円レート取得先(売買通貨)
            settleJpyInfo = cMstSettleJpyList.stream()
                    .filter(a -> a.getDealCurrency().equals(data.getDealCurrency())).findFirst().orElse(null);
            // ST対円レート情報(売買通貨)
            realYenRate = baseRateMap.stream()
                    .filter(a -> a.getCurrencyPair().equals(data.getDealCurrency() + JPY)).findFirst().orElse(null);
            // BBG対円レート情報(売買通貨)
            bbgYenRate = tDfarmBbgRateBeanList.stream()
                    .filter(y -> y.getCurrencyPair().substring(0, 3).equals(data.getDealCurrency()))
                    .filter(y -> y.getCurrencyPair().substring(3, 6).equals(data.getSettleCurrency())).findFirst().orElse(null);
            // マニュアル対円レート情報(売買通貨)
            manualYenRate = manualRateList.stream()
                    .filter(c -> c.getDealCurrency().equals(data.getDealCurrency()))
                    .filter(c -> c.getSettleCurrency().equals(JPY)).findFirst().orElse(null);
        } else {
            if (JPY.equals(data.getSettleCurrency())) {
                // 決済通貨がJPYの場合
                return BigDecimal.ONE;
            }
            // 対円レート取得先(決済通貨)
            settleJpyInfo = cMstSettleJpyList.stream()
                    .filter(a -> a.getDealCurrency().equals(data.getSettleCurrency())).findFirst().orElse(null);
            // ST対円レート情報(決済通貨)
            realYenRate = baseRateMap.stream()
                    .filter(a -> a.getCurrencyPair().equals(data.getSettleCurrency() + JPY)).findFirst().orElse(null);
            // BBG対円レート情報(決済通貨)
            bbgYenRate = tDfarmBbgRateBeanList.stream()
                    .filter(y -> y.getCurrencyPair().substring(0, 3).equals(data.getSettleCurrency()))
                    .filter(y -> y.getCurrencyPair().substring(3, 6).equals(JPY)).findFirst().orElse(null);
            // マニュアル対円レート情報(決済通貨)
            manualYenRate = manualRateList.stream()
                    .filter(c -> c.getDealCurrency().equals(data.getSettleCurrency()))
                    .filter(c -> c.getSettleCurrency().equals(JPY)).findFirst().orElse(null);
        }

        if (manualYenRate != null && manualYenRate.getManualDailyRate() != null) {
            // マニュアル情報があり
            jpyRate = manualYenRate.getManualDailyRate();
        } else if (settleJpyInfo != null && RATESOURCESMART.equals(settleJpyInfo.getRateSource())) {
            // レート取得先がST
            jpyRate = realYenRate != null
                    ? new BigDecimal(realYenRate.getBidRate()).add(new BigDecimal(realYenRate.getAskRate())).divide(new BigDecimal(2))
                    : null;
        } else {
            // レート取得先がBBG
            jpyRate = bbgYenRate != null ? bbgYenRate.getRate() : null;
        }
        return jpyRate;
    }
/**
 * ポジション集計元情報テーブルDelete処理 コミット方式:中間コミット
 *
 * @param contribution
 * @param tPosSumSourceDataBean
 * @throws Exception
 */
private void posSumSourceDataDelete(StepContribution contribution, TPosSumSourceDataBean tPosSumSourceDataBean)
        throws Exception {
    DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
    definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    TransactionStatus status = null;
    try {
        // トランザクションを明示的に開始
        status = transactionManager.getTransaction(definition);
        // [ポジション集計元情報]の削除処理
        tPosSumSourceDataDao.delete(tPosSumSourceDataBean);
        // トランザクションをコミット
        transactionManager.commit(status);
    } catch (Exception e) {
        if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
            // DB切断された時、処理終了
            throw e;
        }
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジション集計元情報削除処理", e);
        // トランザクションをロールバック
        transactionManager.rollback(status);
        // ジョブ警告状態を設定
        contribution.getStepExecution().getJobExecution().getExecutionContext()
                .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}

/**
 * ポジション集計元情報テーブル登録処理 コミット方式:中間コミット
 *
 * @param contribution
 * @param PosSumSourceDataList
 * @throws Exception
 */
private void posSumSourceDataInsert(StepContribution contribution, List<TPosSumSourceDataBean> posSumSourceDataList)
        throws Exception {
    DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
    definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    DBUtil dbUtil = new DBUtil();
    for (List<TPosSumSourceDataBean> itemList : dbUtil.divideList(posSumSourceDataList, bulkInsertUnit)) {
        TransactionStatus status = null;
        try {
            // トランザクションを明示的に開始
            status = transactionManager.getTransaction(definition);

            // [ポジション集計元情報]のinsert処理
            tPosSumSourceDataDao.insert(itemList);
            // トランザクションをコミット
            transactionManager.commit(status);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジション集計元情報登録処理", e);
            // トランザクションをロールバック
            transactionManager.rollback(status);
            // insertし直す
            for (TPosSumSourceDataBean bean : itemList) {
                try {
                    List<TPosSumSourceDataBean> tmp = new ArrayList<TPosSumSourceDataBean>();
                    tmp.add(bean);
                    status = transactionManager.getTransaction(definition);
                    tPosSumSourceDataDao.insert(tmp);
                    transactionManager.commit(status);
                } catch (Exception ex) {
                    if (ex.getMessage() != null && ex.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                        // DB切断された時、処理終了
                        throw ex;
                    }
                    transactionManager.rollback(status);
                }
            }
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
    }
}

/**
 * ポジション集計元情報テーブル更新処理 コミット方式:中間コミット
 *
 * @param contribution
 * @param PosSumSourceDataList
 * @throws Exception
 */
private void posSumSourceDataUpdate(StepContribution contribution,
        List<TPosSumSourceDataBean> starttPosSumSourceDataList) throws Exception {
    DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
    definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    TransactionStatus status = null;
    try {
        // トランザクションを明示的に開始
        status = transactionManager.getTransaction(definition);

        // [ポジション集計元情報]のupdate処理
        tPosSumSourceDataDao.update(starttPosSumSourceDataList);

        // トランザクションをコミット
        transactionManager.commit(status);
    } catch (Exception e) {
        if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
            // DB切断された時、処理終了
            throw e;
        }
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジション集計元情報更新処理", e);
        // トランザクションをロールバック
        transactionManager.rollback(status);
        // ジョブ警告状態を設定
        contribution.getStepExecution().getJobExecution().getExecutionContext()
                .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}

/**
 * マニュアルレート取得
 *
 * @return tPosSumManualRateList
 * @throws Exception
 */
private List<TPosSumManualRateBean> getPosSumManualRate(StepContribution contribution, Date targetDate)
        throws Exception {

    // ポジション集計マニュアルレート取得
    TPosSumManualRateBean tPosSumManualRateBean = new TPosSumManualRateBean();
    List<TPosSumManualRateBean> tPosSumManualRateList = new ArrayList<>();
    try {
        // パラメータ
        tPosSumManualRateBean.setBaseDate(targetDate);
        tPosSumManualRateList = tPosSumManualRateDao.getTPosSumManualRateBeanAll(tPosSumManualRateBean);
    } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "マニュアルレート取得処理", e);

            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }

        return tPosSumManualRateList;
    }

    /**
     * BBGレート取得
     *
     * @return
     * @throws Exception
     */
    private List<TDfarmBbgRateBean> getDfarmBbgRateBean(StepContribution contribution, Date targetDate)
            throws Exception {

        // BBGレート情報
        TDfarmBbgRateBean tDfarmBbgRateBean = new TDfarmBbgRateBean();
        List<TDfarmBbgRateBean> bbgRateBeanList = new ArrayList<>();
        try {
            bbgRateBeanList = tDfarmBbgRateDao.getTDfarmBbgRateBeanAll(tDfarmBbgRateBean);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "BBGレート取得処理", e);

            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
        return bbgRateBeanList;
    }

    /**
     * ベースレート取得
     *
     * @param contribution
     * @param baseRateFilePath
     * @return
     * @throws IOException
     */
    private List<PosBaseRateDto> getBaseRateInfo(StepContribution contribution, String baseRateFilePath)
            throws IOException {
        List<PosBaseRateDto> list = new ArrayList<>();

        BufferedReader br = null;

        try {
            File Files[] = new File(baseRateFilePath).listFiles(new TargetFileFilter(inputFileNamePrefix, ".*"));

            // ファイル名の最大日時ファイル取得
            File lastModifiedFile = Files[0];
            for (int i = 1; i < Files.length; i++) {
                if (lastModifiedFile.getName().compareTo(Files[i].getName()) < 0) {
                    lastModifiedFile = Files[i];
                }
            }
            String line; // 読み込み行
            String[] data; // 分割後のデータを保持するFiles配列

            FileReader fileReader = new FileReader(lastModifiedFile);
            br = new BufferedReader(fileReader);

            // 1行分の読み込みデータを表示
            while ((line = br.readLine()) != null) {
                // lineをタブ区切りで分割し、配列dataに設定
                data = line.split("\t");
                PosBaseRateDto item = new PosBaseRateDto();
                item.setCurrencyPair(data[0]);
                item.setMdEntrySize(data[1]);
                item.setBidRate(data[2]);
                item.setAskRate(data[3]);
                list.add(item);
            }
        } catch (Exception e) {
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ベースレート取得処理", e);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        } finally {
            try {
                br.close();
            } catch (Exception e) {
                // 何にもしない
            }
        }
        return list;
    }

    /**
     * 当日引けレート取得(ファイル読込み、List格納)
     *
     * @param contribution
     * @param targetDate
     * @param inputFilePath
     * @return
     * @throws IOException
     */
    private List<CloseRateDto> getCloseRateInfo(StepContribution contribution, Date targetDate, String inputFilePath)
            throws IOException {
        List<CloseRateDto> list = new ArrayList<>();

        String targetDateYmd = fmt.format(targetDate);
        BufferedReader br = null;

        try {
            File Files[] = new File(inputFilePath).listFiles(new TargetFileFilter(closeRateFileNamePrefix, ".*"));

            for (File f : Files) {

                FileReader fileReader = new FileReader(f);
                br = new BufferedReader(fileReader);
                String fileNmae = f.getName().toString();
                String result = fileNmae.substring(11, 19);

                // 当日引値評価レート存在チェック
                if (result.equals(targetDateYmd)) {
                    // readLineで一行ずつ読み込む
                    String line; // 読み込み行
                    String[] data; // 分割後のデータを保持する配列
                    // 1行分の読み込みデータを表示
                    while ((line = br.readLine()) != null) {
                        // lineをタブ区切りで分割し、配列dataに設定
                        data = line.split("\t");
                        CloseRateDto item = new CloseRateDto();
                        item.setBaseDate(data[0]);
                        item.setDealCurrency(data[1]);
                        item.setSettleCurrency(data[2]);
                        item.setCloseRate(new BigDecimal(data[5]));
                        list.add(item);
                    }
                }
            }
                    } catch (Exception e) {
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "当日引けレート取得処理", e);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        } finally {
            try {
                br.close();
            } catch (Exception e) {
                // 何にもしない
            }
        }
        return list;
    }

    /**
     * REAL集計処理
     *
     * @param contribution
     * @param targetDate
     * @param busiDaysBefore
     * @param evaluationRateKbn
     * @param posSumSourceList
     * @throws Exception
     */
    private void setPosRealData(StepContribution contribution, Date targetDate, Date busiDaysBefore,
            String evaluationRateKbn, List<TPosSumSourceDataBean> posSumSourceList, String nowDateYmdhms)
            throws Exception {

        List<TPosSumSourceDataBean> tPosSumSourceDataList = new ArrayList<>();
        List<TPosSumSourceDataBean> tPosSwapSourceDataList = new ArrayList<>();

        String beforeBusiDays = fmt.format(busiDaysBefore);
        String targetDateYmd = fmt.format(targetDate);
        // スポットの場合
        tPosSumSourceDataList = posSumSourceList.stream()
                // 処理基準日=バッチ実行日
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                // 約定日時が当日バッチ実行日
                .filter(d -> fmt.format(d.getTradeDatetime()).equals(fmt.format(targetDate))
                        // 約定日時が前営業日より大きい かつ バッチ実行日より小さい(休日に作成した約定)
                        || (fmt.format(d.getTradeDatetime()).compareTo(beforeBusiDays) > 0
                                && (fmt.format(d.getTradeDatetime()).compareTo(targetDateYmd) < 0))
                        // 約定日時が前営業日以前のアフタークローズ(インタイム扱い)
                        || (fmt.format(d.getTradeDatetime()).compareTo(fmt.format(busiDaysBefore)) <= 0
                                && AC.equals(d.getAc().trim()))
                        // スタートポジション
                        || d.getSeqNo().equals(BigDecimal.ZERO))
                // 為替区分がスポットの場合
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SPOT.getCode()))
                .collect(Collectors.toList());
        // スワップの場合
        tPosSwapSourceDataList = posSumSourceList.stream()
                // 処理基準日=バッチ実行日
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                // 約定日時が当日バッチ実行日(スタートポジション含む)
                .filter(d -> fmt.format(d.getTradeDatetime()).equals(fmt.format(targetDate))
                        // 約定日時が前営業日より大きい かつ バッチ実行日より小さい(休日に作成した約定)
                        || (fmt.format(d.getTradeDatetime()).compareTo(beforeBusiDays) > 0
                                && (fmt.format(d.getTradeDatetime()).compareTo(targetDateYmd) < 0))
                        // 約定日時が前営業日以前のアフタークローズ(インタイム扱い)
                        || (fmt.format(d.getTradeDatetime()).compareTo(fmt.format(busiDaysBefore)) <= 0
                                && AC.equals(d.getAc().trim()))
                        // スタートポジション
                        || d.getSeqNo().equals(BigDecimal.ZERO))
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SWAP_START.getCode())
                        || d.getExchangeDivision().trim().equals(ExchangeKbn.SWAP_END.getCode())
                        || ExchangeKbn.TRADEDCF.getCode().equals(d.getExchangeDivision().trim()))
                .collect(Collectors.toList());
         // スポット集計処理を呼び出し
        setSpotSumDate(contribution, tPosSumSourceDataList, evaluationRateKbn, targetDate, nowDateYmdhms);

        // スワップ集計処理を呼び出し
        mkPositionSwapSumData(contribution, tPosSwapSourceDataList, targetDate, busiDaysBefore, evaluationRateKbn,
                nowDateYmdhms);
    }

    /**
     * プレ引値集計処理
     *
     * @param contribution
     * @param targetDate
     * @param busiDaysBefore
     * @param evaluationRateKbn
     * @param posSumSourceList
     * @throws Exception
     */
    private void setPosPreClosingData(StepContribution contribution, Date targetDate, Date busiDaysBefore,
            String evaluationRateKbn, List<TPosSumSourceDataBean> posSumSourceList, String nowDateYmdhms)
            throws Exception {

        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String targetDateYmd = fmt.format(targetDate);
        String beforeBusiDays = fmt.format(busiDaysBefore);
        String starttime = "000000";
        String endtime = "210000";

        // スポットのみ
        List<TPosSumSourceDataBean> tPosSumSourceDataList = posSumSourceList.stream()
                // 処理基準日=バッチ実行日
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                // 約定日時が当日バッチ基準日の00:00～20:59の間にある約定
                .filter(d -> (formatter.format(d.getTradeDatetime()).compareTo(targetDateYmd.concat(starttime)) >= 0)
                        && (formatter.format(d.getTradeDatetime()).compareTo(targetDateYmd.concat(endtime)) < 0
                        && d.getAc().trim().equals("0"))
                        // 約定日時が前営業日より大きい かつ バッチ実行日より小さい(休日に作成した約定)
                        || (fmt.format(d.getTradeDatetime()).compareTo(beforeBusiDays) > 0
                                && (fmt.format(d.getTradeDatetime()).compareTo(targetDateYmd) < 0))
                        // スタートポジション
                        || (d.getSeqNo().compareTo(BigDecimal.ZERO) == 0)
                        // 約定日時が前営業日以前のアフタークローズ
                        || (fmt.format(d.getTradeDatetime()).compareTo(fmt.format(busiDaysBefore)) <= 0
                                && AC.equals(d.getAc().trim())))
                // 為替区分がスポットの場合
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SPOT.getCode()))
                .collect(Collectors.toList());

        // スポット集計処理を呼び出し
        setSpotSumDate(contribution, tPosSumSourceDataList, evaluationRateKbn, targetDate, nowDateYmdhms);
    }

    /**
     * 4.決済通貨外貨のPLデルタ登録(スポットのみ)
     *
     * @param contribution
     * @param targetDate
     * @param closeRateList
     * @throws Exception
     */
    private void setPosPlDeltaValueData(StepContribution contribution, Date targetDate,
            List<CloseRateDto> closeRateList) throws Exception {

        // 決済通貨外貨PLデルタ生成情報データ取得する
        TPositionPlDeltaDataBean tPositionPlDeltaDataBean = new TPositionPlDeltaDataBean();
        try {
            // パラメータを渡す
            tPositionPlDeltaDataBean.setProcessBaseDate(targetDate);
            List<TPositionPlDeltaDataBean> plDeltaDList = tPosPlDeltaDataDao
                .getTPositionPlDeltaDataBeanAll(tPositionPlDeltaDataBean);

        // バッチ基準日のデータが存在した場合、決済通貨外貨PLデルタ生成情報データ削除
        if (plDeltaDList.size() > 0) {
            // 決済通貨外貨PLデルタ生成情報データ削除
            posPlDeltaDataDelete(contribution, tPositionPlDeltaDataBean);
        }

        // ポジション集計マニュアルレート取得
        TPosSumManualRateBean tPosSumManualRateBean = new TPosSumManualRateBean();
        // パラメータ
        tPosSumManualRateBean.setBaseDate(targetDate);
        List<TPosSumManualRateBean> tPosSumManualRateList = tPosSumManualRateDao
                .getTPosSumManualRateBeanAll(tPosSumManualRateBean);

        // ポジションスポット集計結果データ取得する
        TPositionSpotSumDataBean tPositionSpotSumDataBean = new TPositionSpotSumDataBean();
        // パラメータを渡す
        tPositionSpotSumDataBean.setProcessBaseDate(targetDate);
        List<TPositionSpotSumDataBean> spotSumList = tPosSoptSumDataDao
                .geTPositionSpotSumDataBeanAll(tPositionSpotSumDataBean);

        List<TPositionPlDeltaDataBean> tosPlDeltaDataBeanList = new ArrayList<>();

        List<TPositionSpotSumDataBean> tPosSpotSumData = spotSumList.stream()
                // 処理基準日がバッチ実行日
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                // 評価レート区分がプレ引値の場合
                .filter(d -> (d.getEvaluationRateDivision().equals(EvaluationRateKbn.PRE_CLOSING.getCode())))
                // 決済通貨 <> JPY
                .filter(d -> !(d.getSettleCurrency().equals("JPY")))
                // 評価PL(原通貨) <> 0
                .filter(d -> d.getEvaluationPlUnderlyingCcy() != null).collect(Collectors.toList());
        // 4.4.取得有無処理判断
        if (tPosSpotSumData.size() > 0) {
            // 集計キー:ディーラブック、決済通貨
            Map<String, List<TPositionSpotSumDataBean>> sumMap = tPosSpotSumData.stream()
                    .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getSettleCurrency()));

            for (String bookSettleCcyKey : sumMap.keySet()) {
                String[] split = bookSettleCcyKey.split(",");

                // 引値レート取得
                String str = new SimpleDateFormat("yyyy/MM/dd").format(targetDate);
                CloseRateDto closeRate = closeRateList.stream()
                        // 評価レートファイルの基準日=バッチ実行日取得
                        .filter(b -> b.getBaseDate().equals(str))
                        // 評価レートファイルの売買通貨 = 集計となる対象データの決済通貨
                        .filter(b -> b.getDealCurrency().equals(split[1]))
                        // 評価レートファイルの決済通貨 = JPY
                        .filter(b -> b.getSettleCurrency().equals("JPY")).findFirst().orElse(null);

                // 通貨ペア単位で売買金額集計
                List<TPositionSpotSumDataBean> sList = sumMap.get(bookSettleCcyKey).stream()
                        .filter(a -> a.getSettleCurrency().equals(split[1])).collect(Collectors.toList());
                // 売買金額集計(取得した評価PL(原通貨))
                BigDecimal totalDealAmount = sumBigDecimal(sList,
                        TPositionSpotSumDataBean::getEvaluationPlUnderlyingCcy);

                TPositionPlDeltaDataBean tPosPlDeltaData = new TPositionPlDeltaDataBean();

                // ポジション集計マニュアルレート
                TPosSumManualRateBean manualRate = tPosSumManualRateList.stream()
                        // 集計となる対象データの売買通貨 = 決済通貨
                        .filter(c -> c.getDealCurrency().equals(split[1]))
                        // マニュアル(引けレート、TTM)がNULL以外
                        .filter(m -> m.getManualClosingTtmRate() != null)
                        // 集計となる対象データの決済通貨 = JPY
                        .filter(c -> c.getSettleCurrency().equals("JPY")).findFirst().orElse(null);

                // 評価レートファイル、あるいはマニュアルレートが存在する場合
                if (closeRate != null || manualRate != null) {

                    // 処理基準日
                    tPosPlDeltaData.setProcessBaseDate(targetDate);
                    // ディーラブック
                    tPosPlDeltaData.setDealerBook(split[0]);
                    // 売買通貨
                    tPosPlDeltaData.setDealCurrency(split[1]);
                    // 決済通貨
                    tPosPlDeltaData.setSettleCurrency("JPY");
                    // 通貨ペア(取得した決済通貨+"JPY")
                    tPosPlDeltaData.setCurrencyPair(split[1].concat("JPY"));
                    // 為替区分(スポットのみ)
                    tPosPlDeltaData.setExchangeDivision("0");
                    // ACフラグ
                    tPosPlDeltaData.setAc("0");
                    // 売買区分
                    if (totalDealAmount.compareTo(BigDecimal.ZERO) >= 0) {
                        // 評価PL(原通貨)がプラスの場合、買い
                        tPosPlDeltaData.setDealDivision("1");
                    } else {
                        // 評価PL(原通貨)がマイナスの場合、売り
                        tPosPlDeltaData.setDealDivision("2");
                    }

                    // 売買金額(取得した評価PL(原通貨))(絶対値)
                    tPosPlDeltaData.setDealAmount(totalDealAmount.abs());
                    // 引値評価レート
                    tPosPlDeltaData.setClosingRate(
                            closeRate != null ? closeRate.getCloseRate() : null);
                    // マニュアル(引けレート、TTM)がNULLでない場合、マニュアル(引けレート、TTM)設定、NULLの場合NULLを設定
                    tPosPlDeltaData.setManualClosingTtmRate(
                            manualRate != null ? manualRate.getManualClosingTtmRate() : null);

                    // 取引レート マニュアルレートが存在する場合はマニュアルレートを優先で設定
                    if (manualRate != null) {
                        tPosPlDeltaData.setTradeRate(manualRate.getManualClosingTtmRate());
                    }
                    // マニュアルレートが存在しなければ、評価レートファイルの値を設定
                    else {
                        tPosPlDeltaData.setTradeRate(closeRate.getCloseRate());
                    }

                    // 決済金額(取得した評価PL(原通貨)*取得した引値評価レート)
                    tPosPlDeltaData.setSettleAmount(
                            tPosPlDeltaData.getDealAmount().multiply(tPosPlDeltaData.getTradeRate()));

                    // 引値円転レート
                    tPosPlDeltaData.setClosingYenRate(BigDecimal.ONE);
                    // 登録者
                    tPosPlDeltaData.setRegisterUser(JobConstants.Jbpos1000);
                    // 登録日時
                    tPosPlDeltaData.setRegisterDatetime(null);
                    // 更新者
                    tPosPlDeltaData.setUpdateUser(JobConstants.Jbpos1000);
                    // 更新日時
                    tPosPlDeltaData.setUpdateDatetime(null);

                    // リスト追加
                    tosPlDeltaDataBeanList.add(tPosPlDeltaData);
                } else {
                    // 該当通貨ペアの引値レート、マニュアルレートが存在しない場合
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                            "決済通貨外貨PLデルタ生成情報処理",
                            split[0].concat(",").concat(split[1].concat("JPY")).concat("の引値レート、マニュアルレートが存在しません。"));
                    // ジョブ警告状態を設定
                    contribution.getStepExecution().getJobExecution().getExecutionContext()
                            .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
                }
            }
            if (tosPlDeltaDataBeanList.size() > 0) {
                // 決済通貨外貨PLデルタ生成情報データを登録
                insertPosPlDeltaData(contribution, tosPlDeltaDataBeanList);
            }
        }
    } catch (Exception e) {
        if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
            // DB切断された時、処理終了
            throw e;
        }
    }
    }

    /**
     * 集計用メソッド
     *
     * @param <T>
     * @param list
     * @param mapper
     * @return
     */
    public static <T> BigDecimal sumBigDecimal(List<T> list, Function<T, BigDecimal> mapper) {

        return list.stream().map(mapper).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * 決済通貨外貨PLデルタ生成情報削除処理 <br>
     * コミット方式:中間コミット<br>
     *
     * @param contribution
     * @param tPositionPlDeltaDataBean
     * @throws Exception
     */
    private void posPlDeltaDataDelete(StepContribution contribution, TPositionPlDeltaDataBean tPositionPlDeltaDataBean)
            throws Exception {
        DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
        definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        TransactionStatus status = null;
        try {
            // トランザクションを明示的に開始
            status = transactionManager.getTransaction(definition);

            // [決済通貨外貨PLデルタ生成情報]の削除処理
            tPosPlDeltaDataDao.posPlDeltaDelete(tPositionPlDeltaDataBean);
            // トランザクションをコミット
            transactionManager.commit(status);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "決済通貨外貨PLデルタ生成情報削除処理 ", e);
            // トランザクションをロールバック
            transactionManager.rollback(status);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);

            e.printStackTrace();
        }
    }

    /**
     * 決済通貨外貨PLデルタ生成情報登録処理 コミット方式:中間コミット
     *
     * @param contribution
     * @param insertPosPlDeltaData
     * @throws Exception
     */
    private void insertPosPlDeltaData(StepContribution contribution,
            List<TPositionPlDeltaDataBean> insertPosPlDeltaData) throws Exception {
        DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
        definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        TransactionStatus status = null;
        try {
            // トランザクションを明示的に開始
            status = transactionManager.getTransaction(definition);

            // [決済通貨外貨PLデルタ生成情報]のinsert処理
            tPosPlDeltaDataDao.insert(insertPosPlDeltaData);
            // トランザクションをコミット
            transactionManager.commit(status);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "決済通貨外貨PLデルタ生成情報登録処理 ", e);
            // トランザクションをロールバック
            transactionManager.rollback(status);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
            e.printStackTrace();
        }
    }

    /**
     * 5.引値集計処理(引数:評価レート区分1)
     *
     * @param contribution
     * @param targetDate
     * @param busiDaysBefore
     * @param evaluationRateKbn
     * @param posSumSourceList
     * @throws Exception
     */
    private void setClosingValueData(StepContribution contribution, Date targetDate, Date busiDaysBefore,
            String evaluationRateKbn, List<TPosSumSourceDataBean> posSumSourceList, String nowDateYmdhms)
            throws Exception {

        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String beforeBusiDays = fmt.format(busiDaysBefore);
        String targetDateYmd = fmt.format(targetDate);
        String starttime = "000000";
        String endtime = "210000";

        // ポジションスポット集計結果
        List<TPosSumSourceDataBean> SpotSumDataList = new ArrayList<>();

        // 決済通貨外貨PLデルタ生成情報
        List<TPosSumSourceDataBean> DeltaDataList = new ArrayList<>();

        // ポジション集計元情報取得(スワップ分)
        List<TPosSumSourceDataBean> tPosSwapSourceDataList = new ArrayList<>();

        // ポジションスポット集計結果を取得して型を変換
        SpotSumDataList = setSpotSumData(targetDate);
        // 決済通貨外貨PLデルタ生成情報を取得して型を変換
        DeltaDataList = setDeltaData(targetDate);
        // スポット集計対象データを纏め
        List<TPosSumSourceDataBean> tPosSumSourceDataList = new ArrayList<>();
        tPosSumSourceDataList.addAll(SpotSumDataList);
        if (DeltaDataList.size() > 0) {
            tPosSumSourceDataList.addAll(DeltaDataList);
        }

        // スワップの場合
        tPosSwapSourceDataList = posSumSourceList.stream()
                // 処理基準日=バッチ実行日
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                // 約定日時が当日バッチ基準日の00:00～20:59の間にある約定
                .filter(d -> (formatter.format(d.getTradeDatetime()).compareTo(targetDateYmd.concat(starttime)) >= 0)
                        && (formatter.format(d.getTradeDatetime()).compareTo(targetDateYmd.concat(endtime)) < 0
                                && d.getAc().trim().equals("0"))
                        // 約定日時が前営業日より大きい かつ バッチ実行日より小さい(休日に作成した約定)
                        || (fmt.format(d.getTradeDatetime()).compareTo(beforeBusiDays) > 0
                                && (fmt.format(d.getTradeDatetime()).compareTo(targetDateYmd) < 0))
                        // スタートポジション
                        || (d.getSeqNo().compareTo(BigDecimal.ZERO) == 0)
                        // 約定日時が前営業日以前のアフタークローズ
                        || (fmt.format(d.getTradeDatetime()).compareTo(fmt.format(busiDaysBefore)) <= 0
                                && AC.equals(d.getAc().trim())))
                // 為替区分がスワップ、もしくは為替区分が約定済CFの場合
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SWAP_START.getCode())
                        || d.getExchangeDivision().trim().equals(ExchangeKbn.SWAP_END.getCode())
                        || ExchangeKbn.TRADEDCF.getCode().equals(d.getExchangeDivision().trim()))
                .collect(Collectors.toList());

        // スポット集計処理を呼び出し
        setSpotSumDate(contribution, tPosSumSourceDataList, evaluationRateKbn, targetDate, nowDateYmdhms);

        // スワップ集計処理を呼び出し
        mkPositionSwapSumData(contribution, tPosSwapSourceDataList, targetDate, busiDaysBefore, evaluationRateKbn,
                nowDateYmdhms);
    }

    /**
     * 決済通貨外貨PLデルタ生成情報をポジション取得元に変換
     *
     * @param targetDate
     * @return
     * @throws Exception
     */
    private List<TPosSumSourceDataBean> setDeltaData(Date targetDate) throws Exception {

        List<TPosSumSourceDataBean> tPosSumSourceDeltaDataList = new ArrayList<>();

        // 決済通貨外貨PLデルタ生成情報データ取得する
        TPositionPlDeltaDataBean tPositionPlDeltaDataBean = new TPositionPlDeltaDataBean();
        // パラメータを渡す
        tPositionPlDeltaDataBean.setProcessBaseDate(targetDate);
        List<TPositionPlDeltaDataBean> plDeltaDList = tPosPlDeltaDataDao
                .getTPositionPlDeltaDataBeanAll(tPositionPlDeltaDataBean);

        for (TPositionPlDeltaDataBean item : plDeltaDList) {

            TPosSumSourceDataBean posSpotSourceData = new TPosSumSourceDataBean();

            // 処理基準日
            posSpotSourceData.setProcessBaseDate(item.getProcessBaseDate());
            // 約定日時(ソート時に外貨PLデルタをプレ引値の後に追加するため時刻に+1を設定)
            posSpotSourceData.setTradeDatetime(new Timestamp(targetDate.getTime() + 1));
            // ディーラブック
            posSpotSourceData.setDealerBook(item.getDealerBook());
            // ACフラグ
            posSpotSourceData.setAc(item.getAc());
            // 売買通貨
            posSpotSourceData.setDealCurrency(item.getDealCurrency());
            // 決済通貨
            posSpotSourceData.setSettleCurrency(item.getSettleCurrency());
            // 通貨ペア
            posSpotSourceData.setCurrencyPair(item.getCurrencyPair());
            // 為替区分
            posSpotSourceData.setExchangeDivision(item.getExchangeDivision());
            // 売買区分
            posSpotSourceData.setDealDivision(item.getDealDivision());
            // 売買金額
            posSpotSourceData.setDealAmount(item.getDealAmount());
            // 取引レート
            posSpotSourceData.setTradeRate(item.getTradeRate());
            // 決済金額
            posSpotSourceData.setSettleAmount(item.getSettleAmount());
            // 引値評価レート
            posSpotSourceData.setClosingRate(item.getClosingRate());
            // マニュアル(引けレート、TTM)
            posSpotSourceData.setManualClosingTtmRate(item.getManualClosingTtmRate());
            // 引値円転レート
            posSpotSourceData.setClosingYenRate(item.getClosingYenRate());

            // リストに追加
            tPosSumSourceDeltaDataList.add(posSpotSourceData);
        }

        return tPosSumSourceDeltaDataList;
    }

    /**
     * ポジションスポット集計結果をポジション取得元に変換
     *
     * @param targetDate
     * @return tPosSumSourceSpotSumDataList
     * @throws Exception
     */
    private List<TPosSumSourceDataBean> setSpotSumData(Date targetDate) throws Exception {

        List<TPosSumSourceDataBean> tPosSumSourceSpotSumDataList = new ArrayList<>();

        // ポジションスポット集計結果データ取得する
        TPositionSpotSumDataBean SpotSumData = new TPositionSpotSumDataBean();

        // パラメータを渡す
        SpotSumData.setProcessBaseDate(targetDate);
        List<TPositionSpotSumDataBean> spotSumList = tPosSoptSumDataDao.geTPositionSpotSumDataBeanAll(SpotSumData);
        // ポジションスポット集計結果
        spotSumList = spotSumList.stream()
                // 評価レート区分が99の場合
                .filter(d -> d.getEvaluationRateDivision().equals(EvaluationRateKbn.PRE_CLOSING.getCode()))
                // 処理基準日=バッチ実行日の場合
                .filter(d -> d.getProcessBaseDate().equals(targetDate)).collect(Collectors.toList());

        for (TPositionSpotSumDataBean item : spotSumList) {

            TPosSumSourceDataBean posSpotSourceData = new TPosSumSourceDataBean();

            // 処理基準日
            posSpotSourceData.setProcessBaseDate(item.getProcessBaseDate());
            // 約定日時
            posSpotSourceData.setTradeDatetime(new Timestamp(targetDate.getTime()));
            // ディーラブック
            posSpotSourceData.setDealerBook(item.getDealerBook());
            // ACフラグ
            posSpotSourceData.setAc(item.getAc());
            // 売買通貨
            posSpotSourceData.setDealCurrency(item.getDealCurrency());
            // 決済通貨
            posSpotSourceData.setSettleCurrency(item.getSettleCurrency());
            // 通貨ペア
            posSpotSourceData.setCurrencyPair(item.getCurrencyPair());
            // 為替区分
            posSpotSourceData.setExchangeDivision(item.getExchangeDivision());
            // 売買区分
            if (item.getEvaluationPosition().compareTo(BigDecimal.ZERO) >= 0) {
                posSpotSourceData.setDealDivision("1");
            } else {
                posSpotSourceData.setDealDivision("2");
            }
            // 売買金額
            posSpotSourceData.setDealAmount(item.getEvaluationPosition().abs());
            // 取引レート(Avgコストレート)
            posSpotSourceData.setTradeRate(item.getAvgCostRate());
            // 決済金額(未確定決済金額)
            posSpotSourceData.setSettleAmount(item.getPendingSettleAmount().abs());
            // 引値評価レート
            posSpotSourceData.setClosingRate(item.getClosingRate());
            // マニュアル(引けレート、TTM)
            posSpotSourceData.setManualClosingTtmRate(item.getManualClosingTtmRate());
            // 引値円転レート
            posSpotSourceData.setClosingYenRate(item.getClosingYenRate());
            // 前日繰越
            posSpotSourceData.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());

            // リストに追加
            tPosSumSourceSpotSumDataList.add(posSpotSourceData);
        }

        return tPosSumSourceSpotSumDataList;
    }

    /**
     * 6.引値以降集計処理(引数:評価レート区分2)
     *
     * @param contribution
     * @param targetDate
     * @param busiDaysBefore
     * @param evaluationRateKbn
     * @param posSumSourceList
     * @throws Exception
     */
    private void setClosingAfterValueData(StepContribution contribution, Date targetDate, Date busiDaysBefore,
            String evaluationRateKbn, List<TPosSumSourceDataBean> posSumSourceList,
            List<TPosSumManualRateBean> tPosSumManualRateList, List<TDfarmBbgRateBean> tDfarmBbgRateBeanList,
            String nowDateYmdhms) throws Exception {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String beforeBusiDays = fmt.format(busiDaysBefore);
        String targetDateYmd = fmt.format(targetDate);
        String starttime = "000000";
        String endtime = "210000";

        // ポジション集計元情報取得(スポットのAC分)
        List<TPosSumSourceDataBean> posSumSourceDataSpotAc = new ArrayList<>();

        // ポジション集計元情報取得(スワップのAC分)
        List<TPosSumSourceDataBean> posSumSourceDataSwapAc = new ArrayList<>();

        // ポジション集計元情報取得(スワップのIT分)
        List<TPosSumSourceDataBean> posSumSourceDataSwapIt = new ArrayList<>();
        // ポジションスポット集計結果(スポットのIT分)
        List<TPositionSpotSumDataBean> tPosSpotSumDataIt = new ArrayList<>();

        // 6.1.引値以降集計となるAC対象データを取得(スポット)
        posSumSourceDataSpotAc = posSumSourceList.stream()
                // 約定日時が当日バッチ実行日かつACフラグ=1
                .filter(d -> fmt.format(d.getTradeDatetime()).equals(fmt.format(targetDate))
                        && AC.equals(d.getAc().trim()))
                // 為替区分がスポットの場合
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SPOT.getCode()))
                .collect(Collectors.toList());

        // 6.2.引値以降集計となるAC対象データを取得(スワップ)
        posSumSourceDataSwapAc = posSumSourceList.stream()
                // 約定日時が当日バッチ実行日かつACフラグ=1
                .filter(d -> fmt.format(d.getTradeDatetime()).equals(fmt.format(targetDate))
                        && AC.equals(d.getAc().trim()))
                // 為替区分がスワップ、もしくは為替区分が約定済CFの場合
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SWAP_START.getCode())
                        || d.getExchangeDivision().trim().equals(ExchangeKbn.SWAP_END.getCode())
                        || ExchangeKbn.TRADEDCF.getCode().equals(d.getExchangeDivision().trim()))
                .collect(Collectors.toList());

        // 6.3.スワップのIT分取引を取得する。
        posSumSourceDataSwapIt = posSumSourceList.stream()
                // 処理基準日=バッチ実行日
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                // 約定日時が当日バッチ基準日の00:00～20:59の間にある約定
                .filter(d -> (formatter.format(d.getTradeDatetime()).compareTo(targetDateYmd.concat(starttime)) >= 0)
                        && (formatter.format(d.getTradeDatetime()).compareTo(targetDateYmd.concat(endtime)) < 0
                                && NONAC.equals(d.getAc().trim()))
                        // 約定日時が前営業日より大きい かつ バッチ実行日より小さい(休日に作成した約定)
                        || (fmt.format(d.getTradeDatetime()).compareTo(beforeBusiDays) > 0
                                && (fmt.format(d.getTradeDatetime()).compareTo(targetDateYmd) < 0))
                        // 約定日時が前営業日以前のアフタークローズ
                        || (fmt.format(d.getTradeDatetime()).compareTo(fmt.format(busiDaysBefore)) <= 0
                                && AC.equals(d.getAc().trim()))
                        // スタートポジション
                        || (d.getSeqNo().compareTo(BigDecimal.ZERO) == 0))
                // 為替区分がスワップ、もしくは為替区分が約定済CFの場合
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SWAP_START.getCode())
                        || d.getExchangeDivision().trim().equals(ExchangeKbn.SWAP_END.getCode())
                        || ExchangeKbn.TRADEDCF.getCode().equals(d.getExchangeDivision().trim()))
                .collect(Collectors.toList());

        // 6.3.2.取得した対象となるスワップITデータを設定して、6.4.スワップのIT分取引を通貨別などで纏め処理へ渡す
        List<TPosSumSourceDataBean> tPosSwapSourceDataList = Jbpos1000SwapSummary.setPosSwapItData(contribution,
                posSumSourceDataSwapIt);

        // 6.5.スワップのIT分取引を通貨別などで纏めのマッピング処理
        List<TPosSumSourceDataBean> tPosSwapSumSourceDataList = posSumSourceDataMapping(contribution, targetDate,
                tPosSwapSourceDataList, tPosSumManualRateList, tDfarmBbgRateBeanList);

        // 6.6.ポジションスポット集計結果データ取得する(スポットの引値集計結果データを取得)
        TPositionSpotSumDataBean tPositionSpotSumDataBean = new TPositionSpotSumDataBean();
        // パラメータを渡す
        tPositionSpotSumDataBean.setProcessBaseDate(targetDate);
        List<TPositionSpotSumDataBean> spotSumList = tPosSoptSumDataDao
                .geTPositionSpotSumDataBeanAll(tPositionSpotSumDataBean);
        tPosSpotSumDataIt = spotSumList.stream()
                // 評価レート区分が1(引値)の場合
                .filter(d -> d.getEvaluationRateDivision().trim().equals(EvaluationRateKbn.CLOSING_PRICE.getCode()))
                // 処理基準日=バッチ実行日の場合
                .filter(d -> d.getProcessBaseDate().equals(targetDate)).collect(Collectors.toList());

        // 6.7.取得したスポットの引値集計結果をポジション集計元情報へコスト持ち替え
        List<TPosSumSourceDataBean> tPosSumSpotDataList = setSpotCloseSumCostReplace(tPosSpotSumDataIt, targetDate);

        // 6.8.取得したスポットの引値集計結果をポジション集計元情報へコスト持ち替え後のマッピング処理
        List<TPosSumSourceDataBean> tPositionSpotList = posSumSourceDataMapping(contribution, targetDate,
                tPosSumSpotDataList, tPosSumManualRateList, tDfarmBbgRateBeanList);

        // 6.9.集計となるスポットデータを纏める
        List<TPosSumSourceDataBean> tPosSumSourceDataList = new ArrayList<>();
        tPosSumSourceDataList.addAll(posSumSourceDataSpotAc);
        tPosSumSourceDataList.addAll(tPositionSpotList);

        // 6.10.集計となるスワップデータを纏める
        List<TPosSumSourceDataBean> tPosSumSourceSwapData = new ArrayList<>();
        tPosSumSourceSwapData.addAll(posSumSourceDataSwapAc);
        tPosSumSourceSwapData.addAll(tPosSwapSumSourceDataList);

        // 6.11.スポット集計処理を呼び出し
        setSpotSumDate(contribution, tPosSumSourceDataList, evaluationRateKbn, targetDate, nowDateYmdhms);

        // 6.12.スワップ集計処理を呼び出し
        mkPositionSwapSumData(contribution, tPosSumSourceSwapData, targetDate, busiDaysBefore, evaluationRateKbn,
                nowDateYmdhms);

    }

    /**
     * 6.5スポットの引値集計結果を持ち替え
     *
     * @param tPosSpotSumDataIt
     * @param targetDate
     * @return
     * @throws Exception
     */
    private List<TPosSumSourceDataBean> setSpotCloseSumCostReplace(List<TPositionSpotSumDataBean> tPosSpotSumDataIt,
            Date targetDate) throws Exception {

        List<TPosSumSourceDataBean> tPosSumSourceDataList = new ArrayList<>();

        Map<String, List<TPositionSpotSumDataBean>> wkMap = tPosSpotSumDataIt.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "-" + g.getCurrencyPair()));

        for (String dealerbookccyPair : wkMap.keySet()) {
            for (TPositionSpotSumDataBean item : wkMap.get(dealerbookccyPair)) {

                String[] split = dealerbookccyPair.split("-");
                TPosSumSourceDataBean posSpotSourceData = new TPosSumSourceDataBean();
                // 処理基準日
                posSpotSourceData.setProcessBaseDate(targetDate);
                // ディーラブック
                posSpotSourceData.setDealerBook(split[0]);
                // 約定日時
                posSpotSourceData.setTradeDatetime(new Timestamp(targetDate.getTime()));
                // ACフラグ
                posSpotSourceData.setAc("0");
                // 売買通貨
                posSpotSourceData.setDealCurrency(item.getDealCurrency());
                // 決済通貨
                posSpotSourceData.setSettleCurrency(item.getSettleCurrency());
                // 通貨ペア
                posSpotSourceData.setCurrencyPair(split[1]);
                // 為替区分
                posSpotSourceData.setExchangeDivision(item.getExchangeDivision());
                // 売買区分
                if (item.getEvaluationPosition().compareTo(BigDecimal.ZERO) >= 0) {
                    posSpotSourceData.setDealDivision("1");
                } else {
                    posSpotSourceData.setDealDivision("2");
                }
                // 売買金額(該当通貨ペアの評価ポジション)
                posSpotSourceData.setDealAmount(item.getEvaluationPosition().abs());
                // マニュアルレートが存在する場合、マニュアルレートを設定
                if (item.getManualClosingTtmRate() != null) {
                    posSpotSourceData.setTradeRate(item.getManualClosingTtmRate());
                }
                // マニュアルレートが存在しない場合、評価レートファイルの値を設定
                else {
                    posSpotSourceData.setTradeRate(item.getClosingRate());
                }
                if (posSpotSourceData.getTradeRate() != null) {
                    // 決済金額(通貨ペアの売買金額*取引レート))
                    posSpotSourceData.setSettleAmount(
                            posSpotSourceData.getDealAmount().multiply(posSpotSourceData.getTradeRate()));
                } else {
                    posSpotSourceData.setSettleAmount(null);
                }
                // 評価レート区分
                posSpotSourceData.setEvaluationRateDivision(item.getEvaluationRateDivision());
                // Real評価レート
                posSpotSourceData.setRealRate(item.getRealRate());
                // 引値評価レート
                posSpotSourceData.setClosingRate(item.getClosingRate());
                // マニュアル(日中時価評価レート)
                posSpotSourceData.setManualDailyRate(item.getManualDailyRate());
                // マニュアル(引けレート、TTM)
                posSpotSourceData.setManualClosingTtmRate(item.getManualClosingTtmRate());
                // レート取得先
                posSpotSourceData.setRateSource(item.getRateSource());
                // BBGレート
                posSpotSourceData.setBbgRate(item.getBbgRate());
                // Real円転レート
                posSpotSourceData.setRealYenRate(item.getRealYenRate());
                // 引値円転レート
                posSpotSourceData.setClosingYenRate(item.getClosingYenRate());
                // 前日繰越
                posSpotSourceData.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());

                // リスト追加
                tPosSumSourceDataList.add(posSpotSourceData);
            }
        }
        return tPosSumSourceDataList;
    }

    /**
     * 7.スポット集計処理(共通処理)
     *
     * @param contribution
     * @param tPosSumSourceDataList
     * @param evaluationRateKbn
     * @param targetDate
     * @throws Exception
     */
    private void setSpotSumDate(StepContribution contribution, List<TPosSumSourceDataBean> tPosSumSourceDataList,
            String evaluationRateKbn, Date targetDate, String nowDateYmdhms) throws Exception {

        String evaluationRateName = null;
        switch (evaluationRateKbn) {
        case "00":
            evaluationRateName = EvaluationRateKbn.REAL.getName();
            break;
        case "01":
            evaluationRateName = EvaluationRateKbn.CLOSING_PRICE.getName();
            break;
        case "02":
            evaluationRateName = EvaluationRateKbn.AFTER_CLOSING_PRICE.getName();
            break;
        case "99":
            evaluationRateName = EvaluationRateKbn.PRE_CLOSING.getName();
            break;
        }

        Map<String, List<TPosSumSourceDataBean>> wkMap = tPosSumSourceDataList.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getCurrencyPair()));

        List<TPositionSpotSumDataBean> tPositionSpotSumDataBeanList = new ArrayList<>();
        List<TPositionSpotSumDataBean> posSpotDataList = new ArrayList<>();
        List<TPositionSpotSumDataBean> tPosSpotSumClosingList = new ArrayList<>();
        List<TPositionSpotSumDataBean> spotSumClosingList = new ArrayList<>();
        int index = 0;
        // 前回情報
        List<TPositionSpotSumDataBean> prevList = posSpotDataList;
        for (String dealerBookCcyPair : wkMap.keySet()) {
            String[] split = dealerBookCcyPair.split(",");
            // 前回情報リセット
            if (prevList.size() > 0) {
                prevList.clear();
                index = 0;
            }

            List<TPosSumSourceDataBean> sortedList = new ArrayList<>();
            // 評価レート区分がReal、プレ引値の場合、売買金額が0以外を条件に抽出し、約定日時、ACフラグ順にソート
            if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                    || evaluationRateKbn.equals(EvaluationRateKbn.PRE_CLOSING.getCode())) {
                sortedList = wkMap.get(dealerBookCcyPair).stream()
                        .filter(d -> d.getDealAmount().compareTo(BigDecimal.ZERO) != 0)
                        .sorted(Comparator.comparing(TPosSumSourceDataBean::getTradeDatetime)
                                .thenComparing(TPosSumSourceDataBean::getAc))
                        .collect(Collectors.toList());
                // 評価レート区分が引値、引値以降の場合、約定日時、ACフラグ順にソート
            } else {
                sortedList = wkMap.get(dealerBookCcyPair).stream().sorted(Comparator
                        .comparing(TPosSumSourceDataBean::getTradeDatetime).thenComparing(TPosSumSourceDataBean::getAc))
                        .collect(Collectors.toList());
            }

            // リストが空でない場合に集計処理を実行
            if (sortedList.size() != 0) {
                for (TPosSumSourceDataBean item : sortedList) {
                    TPositionSpotSumDataBean tPositionSpotSumDataBean = new TPositionSpotSumDataBean();
                    List<TPositionSpotSumDataBean> posSpotDataPlList = new ArrayList<>();
                    try {
                        // 引値の場合、ディーラブック、通貨ペア、評価レート区分=99を条件にリストから抽出
                        if (evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
                            posSpotDataPlList = tPositionSpotSumDataPlBeanList.stream()
                                    .filter(d -> d.getDealerBook().equals(item.getDealerBook()))
                                    .filter(c -> c.getCurrencyPair().equals(item.getCurrencyPair()))
                                    .filter(e -> e.getEvaluationRateDivision().equals(EvaluationRateKbn.PRE_CLOSING.getCode()))
                                    .collect(Collectors.toList());
                        }

                        // 売買金額
                        tPositionSpotSumDataBean.setDealAmount(item.getDealAmount());
                        // 決済金額
                        if (item.getSettleAmount() != null) {
                            if (BUY.equals(item.getDealDivision())) {
                                tPositionSpotSumDataBean.setSettleAmount(item.getSettleAmount());
                            } else {
                                // 符号反転
                                tPositionSpotSumDataBean.setSettleAmount(item.getSettleAmount().negate());
                            }
                        } else {
                            tPositionSpotSumDataBean.setSettleAmount(null);
                        }
                        // 評価ポジション
                        // 売買区分が買いの場合
                        if (prevList.size() > 0) {
                            if (BUY.equals(item.getDealDivision())) {
                                // 前回評価ポジション+今回の取引金額
                                tPositionSpotSumDataBean.setEvaluationPosition(
                                        prevList.get(index - 1).getEvaluationPosition().add(item.getDealAmount()));
                            } else {
                                // 前回評価ポジション-今回の取引金額
                                tPositionSpotSumDataBean.setEvaluationPosition(
                                        prevList.get(index - 1).getEvaluationPosition().subtract(item.getDealAmount()));
                            }
                        } else {
                            if (BUY.equals(item.getDealDivision())) {
                                // 初回時、評価ポジションを今回の取引金額設定
                                tPositionSpotSumDataBean.setEvaluationPosition(item.getDealAmount());
                            } else {
                                // 売買区分が売の場合、マイナスに反転
                                tPositionSpotSumDataBean.setEvaluationPosition(item.getDealAmount().negate());
                        }
                    }

                    // 前回評価ポジションの売買区分を設定する
                    String preEva = null;
                    if (prevList.size() > 0
                            && prevList.get(index - 1).getEvaluationPosition().compareTo(BigDecimal.ZERO) >= 0) {
                        preEva = "1";
                    } else {
                        preEva = "2";
                    }

                    // 今回評価ポジションの売買区分を設定する
                    String tposEva;
                    if (tPositionSpotSumDataBean.getEvaluationPosition().compareTo(BigDecimal.ZERO) >= 0) {
                        tposEva = "1";
                    } else {
                        tposEva = "2";
                    }
                    // 【処理順】
                    // 確定ポジションが発生しない場合、未確定決済金額→Avgコストレート
                    // 確定ポジションが発生する場合、Avgコストレート→未確定決済金額
                    // Avgコストレート,未確定決済金額
                    // 前回評価ポジションの売買区分とポジション集計元情報の売買区分が一致している場合(確定ポジションなし)
                    if (prevList.size() > 0) {
                        if (prevList.get(index - 1).getPendingSettleAmount() != null
                                && item.getSettleAmount() != null
                                && prevList.get(index - 1).getAvgCostRate() != null
                                && item.getTradeRate() != null) {
                            if (preEva.equals(item.getDealDivision())) {
                                // 未確定決済金額=前回未確決済金額+追加取引の決済金額(確定ポジション発生しない場合)
                                tPositionSpotSumDataBean.setPendingSettleAmount(prevList.get(index - 1)
                                        .getPendingSettleAmount().add(tPositionSpotSumDataBean.getSettleAmount())
                                        .setScale(2, RoundingMode.HALF_UP));
                                // Avgコストレート=今回未確決済金額÷今回評価ポジション
                                tPositionSpotSumDataBean
                                        .setAvgCostRate(tPositionSpotSumDataBean.getPendingSettleAmount().divide(
                                                tPositionSpotSumDataBean.getEvaluationPosition(), 8,
                                                RoundingMode.HALF_UP));
                            } else {
                                // 前回評価ポジションの売買区分と今回ポジションの売買区分が一致していない場合(確定ポジション発生する場合)
                                if (preEva.equals(tposEva)) {
                                    // Avgコストレート=前回Avgコスト
                                    tPositionSpotSumDataBean
                                            .setAvgCostRate(prevList.get(index - 1).getAvgCostRate());
                                    // 未確定決済金額=今回評価ポジション×前回Avgコスト
                                    tPositionSpotSumDataBean
                                            .setPendingSettleAmount(tPositionSpotSumDataBean.getEvaluationPosition()
                                                    .multiply(prevList.get(index - 1).getAvgCostRate())
                                                    .setScale(2, RoundingMode.HALF_UP));
                                } else {
                                    // Avgコストレート=今回追加された取引レート
                                    tPositionSpotSumDataBean.setAvgCostRate(item.getTradeRate());
                                    // 未確定決済金額=今回評価ポジション×今回追加された取引レート
                                    tPositionSpotSumDataBean.setPendingSettleAmount(tPositionSpotSumDataBean
                                            .getEvaluationPosition().multiply(item.getTradeRate())
                                            .setScale(2, RoundingMode.HALF_UP));
                                }
                            }
                        } else {
                            tPositionSpotSumDataBean.setAvgCostRate(null);
                            tPositionSpotSumDataBean.setPendingSettleAmount(null);
                            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                    "スポット集計処理", "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                            + item.getCurrencyPair() + ":Avgコストレートと未確定決済金額がNULLであるため、計算エラー");
                        }
                        // 初回時
                    } else {
                        if (item.getTradeRate() != null && tPositionSpotSumDataBean.getSettleAmount() != null) {
                            // Avgコストレート=取引レート
                            tPositionSpotSumDataBean.setAvgCostRate(item.getTradeRate());
                            // 売買区分が買の場合
                            if (BUY.equals(item.getDealDivision())) {
                                // 未確決済金額=追加取引の決済金額
                                tPositionSpotSumDataBean
                                        .setPendingSettleAmount(tPositionSpotSumDataBean.getSettleAmount());
                            } else {
                                // 未確決済金額=追加取引の決済金額(マイナス反転)
                                tPositionSpotSumDataBean.setPendingSettleAmount(tPositionSpotSumDataBean.getSettleAmount().negate());
                            }
                        } else {
                            // Avgコストレート
                            tPositionSpotSumDataBean.setAvgCostRate(null);
                            // 未確決済金額
                            tPositionSpotSumDataBean.setPendingSettleAmount(null);
                            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                    "スポット集計処理", "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                            + item.getCurrencyPair() + ":Avgコストレートと未確定決済金額がNULLであるため、計算エラー");
                        }
                    }

                    // 評価PL(原通貨)
                    if (tPositionSpotSumDataBean.getAvgCostRate() != null) {
                        // Realの場合,引値以降の場合
                        if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                                || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                            // マニュアル(日中時価評価レート)が存在した場合
                            if (item.getManualDailyRate() != null) {
                                // 評価ポジション*(マニュアル(日中時価評価レート)-Avgコスト)
                                tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(
                                        tPositionSpotSumDataBean.getEvaluationPosition()
                                                .multiply(item.getManualDailyRate()
                                                    .subtract(tPositionSpotSumDataBean.getAvgCostRate()))
                                                .setScale(2, RoundingMode.HALF_UP));
                                // マニュアル(日中時価評価レート)が存在しない場合
                            } else {
                                // レート取得先がスマトレの場合
                                if (RATESOURCESMART.equals(item.getRateSource())) {
                                    if (item.getRealRate() != null) {
                                        // 評価ポジション*(Real評価レート-Avgコスト)
                                        tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(
                                                tPositionSpotSumDataBean.getEvaluationPosition()
                                                        .multiply(item.getRealRate()
                                                            .subtract(tPositionSpotSumDataBean.getAvgCostRate()))
                                                        .setScale(2, RoundingMode.HALF_UP));
                                    } else {
                                        tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(null);
                                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name,
                                                "MSG_J_W001", "スポット集計処理",
                                                "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                                        + item.getCurrencyPair()
                                                        + ":Real評価レートが取得できなかったため、評価PL(原通貨)の計算エラー");
                                    }
                                    // レート取得先がBBGの場合
                                } else if (RATESOURCEBBG.equals(item.getRateSource())) {
                                    if (item.getBbgRate() != null) {
                                        // 評価ポジション*(BBGレート-Avgコスト)
                                        tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(
                                                tPositionSpotSumDataBean.getEvaluationPosition()
                                                        .multiply(item.getBbgRate()
                                                                .subtract(tPositionSpotSumDataBean.getAvgCostRate()))
                                                        .setScale(2, RoundingMode.HALF_UP));
                                    } else {
                                        tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(null);
                                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name,
                                                "MSG_J_W001",
                                                "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                                        + item.getCurrencyPair()
                                             + ":BBGレートが取得できなかったため、評価PL(原通貨)の計算エラー");
                                        }
                                }
                            }
                        } else {
                            // プレ引値、引値、日締めの場合
                            // マニュアル(引けレート、TTM)が存在した場合
                            if (item.getManualClosingTtmRate() != null) {
                                // 評価ポジション*(マニュアル(引けレート、TTM)-Avgコスト)
                                tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(
                                        tPositionSpotSumDataBean.getEvaluationPosition()
                                                .multiply(item.getManualClosingTtmRate()
                                                        .subtract(tPositionSpotSumDataBean.getAvgCostRate()))
                                                .setScale(2, RoundingMode.HALF_UP));
                            } else {
                                if (item.getClosingRate() != null) {
                                    // 評価ポジション*(引値評価レート-Avgコスト)
                                    tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(
                                            tPositionSpotSumDataBean.getEvaluationPosition()
                                                    .multiply(item.getClosingRate()
                                                            .subtract(tPositionSpotSumDataBean.getAvgCostRate()))
                                                    .setScale(2, RoundingMode.HALF_UP));
                                } else {
                                    tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(null);
                                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                            "スポット集計処理",
                                            "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                                    + item.getCurrencyPair()
                                                    + ":引値評価レートが取得できなかったため、評価PL(原通貨)の計算エラー");
                                }
                            }
                        }
                    } else {
                        tPositionSpotSumDataBean.setEvaluationPlUnderlyingCcy(null);
                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "スポット集計処理",
                                "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                        + item.getCurrencyPair() + ":Avgコストレートが取得できなかったため、評価PL(原通貨)の計算エラー");
                    }
                    // 評価PL(円換算)
                    if (!JPY.equals(item.getSettleCurrency())
                            && tPositionSpotSumDataBean.getEvaluationPlUnderlyingCcy() != null) {
                        if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                                || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                            if (item.getRealYenRate() != null) {
                                // 評価PL(原通貨)*Real円転レート
                                tPositionSpotSumDataBean.setEvaluationPlYenConversion(
                                        tPositionSpotSumDataBean.getEvaluationPlUnderlyingCcy()
                                                .multiply(item.getRealYenRate()).setScale(2, RoundingMode.HALF_UP));
                            } else {
                                tPositionSpotSumDataBean.setEvaluationPlYenConversion(null);
                                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                        "スポット集計処理",
                                        "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                                + item.getSettleCurrency() + "JPY"
                                                + ":Real円転レートが取得できなかったため、評価PL(円換算)の計算エラー");
                            }
                        } else {
                            if (item.getClosingYenRate() != null) {
                                // 評価PL(原通貨)*引値円転レート
                                tPositionSpotSumDataBean.setEvaluationPlYenConversion(tPositionSpotSumDataBean
                                        .getEvaluationPlUnderlyingCcy().multiply(item.getClosingYenRate())
                                        .setScale(2, RoundingMode.HALF_UP));
                            } else {
                                tPositionSpotSumDataBean.setEvaluationPlYenConversion(null);
                                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                        "スポット集計処理",
                                        "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                                + item.getSettleCurrency() + "JPY"
                                                + ":引値円転レートが取得できなかったため、評価PL(円換算)の計算エラー");
                            }
                        }
                        } else {
                            // 評価PL(原通貨)を設定
                            tPositionSpotSumDataBean.setEvaluationPlYenConversion(
                                    tPositionSpotSumDataBean.getEvaluationPlUnderlyingCcy());
                        }
                    // 確定ポジション
                    // 初回かつ評価レートが引値の場合
                    if (prevList.size() == 0
                            && posSpotDataPlList.size() != 0
                            && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
                        // プレ引値で算出した確定ポジションを設定
                        tPositionSpotSumDataBean.setConfirmPosition(posSpotDataPlList.get(0).getConfirmPosition());
                    } else if (prevList.size() > 0) {
                        // 確定ポジションが発生しない場合
                        if (preEva.equals(item.getDealDivision())) {
                            tPositionSpotSumDataBean.setConfirmPosition(BigDecimal.ZERO);
                            // 確定ポジションが発生する場合
                        } else {
                            // 前回評価ポジションの符号と今回評価ポジションの符号が一致している場合
                            if (preEva.equals(tposEva)) {
                                // 前回評価ポジション-今回の評価ポジション(絶対値)
                                tPositionSpotSumDataBean
                                        .setConfirmPosition(prevList.get(index - 1).getEvaluationPosition()
                                                .subtract(tPositionSpotSumDataBean.getEvaluationPosition()));
                            } else {
                                // 前回評価ポジション=今回確定ポジション(絶対値)
                                tPositionSpotSumDataBean
                                        .setConfirmPosition(prevList.get(index - 1).getEvaluationPosition());
                            }
                        }
                    } else {
                        // 初回時、確定ポジションは発生しない
                        tPositionSpotSumDataBean.setConfirmPosition(BigDecimal.ZERO);
                    }
                    // 確定PL(原通貨)
                    // 初回かつ評価レートが引値の場合
                    if (prevList.size() == 0
                            && posSpotDataPlList.size() != 0
                            && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
                        // プレ引値で算出した確定PL(原通貨)を設定
                        tPositionSpotSumDataBean.setConfirmUnderlyingCcy(posSpotDataPlList.get(0).getConfirmUnderlyingCcy());
                    } else if (prevList.size() > 0) {
                        // 確定ポジションが0の場合(二回目以降)
                        if (tPositionSpotSumDataBean.getConfirmPosition() == BigDecimal.ZERO) {
                            tPositionSpotSumDataBean.setConfirmUnderlyingCcy(BigDecimal.ZERO);
                        } else {
                            if (prevList.get(index - 1).getAvgCostRate() != null) {
                                // 確定ポジション*(取引レート-前回Avgコスト)
                                tPositionSpotSumDataBean.setConfirmUnderlyingCcy(tPositionSpotSumDataBean.getConfirmPosition()
                                        .multiply(item.getTradeRate()
                                                .subtract(prevList.get(index - 1).getAvgCostRate()))
                                        .setScale(2, RoundingMode.HALF_UP));
                            } else {
                                tPositionSpotSumDataBean.setConfirmUnderlyingCcy(null);
                                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                        "スポット集計処理",
                                        "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                                + item.getCurrencyPair()
                                                + ":前回Avgコストレートが取得できなかったため、確定PL(原通貨)の計算エラー");
                            }
                        }
                    } else {
                        // 初回時、確定ポジションは発生しない
                        tPositionSpotSumDataBean.setConfirmUnderlyingCcy(BigDecimal.ZERO);
                    }

                    // 累積確定PL(原通貨)
                    // 初回かつ評価レート区分が引値の場合
                    if (prevList.size() == 0
                && posSpotDataPlList.size() != 0
                && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
            tPositionSpotSumDataBean
                    .setSumPlUnderlyingCcy(posSpotDataPlList.get(0).getSumPlUnderlyingCcy());
            // 累積確定PLがNULLの場合
            if (tPositionSpotSumDataBean.getSumPlUnderlyingCcy().equals(null)) {
                tPositionSpotSumDataBean
                        .setSumPlUnderlyingCcy(BigDecimal.ZERO);
            }
        } else {
            if (prevList.size() > 0) {
                // 確定ポジションが0の場合(二回目以降)
                if (tPositionSpotSumDataBean.getConfirmPosition() == BigDecimal.ZERO) {
                    // 前回の累積確定PL(原通貨)を設定
                    tPositionSpotSumDataBean
                            .setSumPlUnderlyingCcy(prevList.get(index - 1).getSumPlUnderlyingCcy());
                } else {
                    if (tPositionSpotSumDataBean.getConfirmUnderlyingCcy() != null) {
                        // 前回の累積確定PL(原通貨)+今回の確定PL(原通貨)を設定
                        tPositionSpotSumDataBean
                                .setSumPlUnderlyingCcy(prevList.get(index - 1).getSumPlUnderlyingCcy()
                                        .add(tPositionSpotSumDataBean.getConfirmUnderlyingCcy()));
                    } else {
                        tPositionSpotSumDataBean.setSumPlUnderlyingCcy(null);
                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                "スポット集計処理",
                                "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                        + item.getCurrencyPair()
                                        + ":今回の確定PL(原通貨)が取得できなかったため、累積確定PL(原通貨)の計算エラー");
                    }
                }
            } else {
                // 初回時、確定ポジションは発生しない
                tPositionSpotSumDataBean.setSumPlUnderlyingCcy(BigDecimal.ZERO);
            }
        }

        // 累積確定PL(円換算)
        // 初回かつ評価レート区分が引値の場合
        if (prevList.size() == 0
                && posSpotDataPlList.size() != 0
                && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
            // 決済通貨がJPY
            if (JPY.equals(item.getSettleCurrency())) {
                tPositionSpotSumDataBean
                        .setSumPlYenConversion(posSpotDataPlList.get(0).getSumPlUnderlyingCcy());
            } else {
                // 引値円転レートがNULLでない場合
                if (posSpotDataPlList.get(0).getClosingYenRate() != null) {
                    // 累積確定PL(原通貨)* 引値円転レート
                    tPositionSpotSumDataBean.setSumPlYenConversion(posSpotDataPlList.get(0)
                            .getSumPlUnderlyingCcy().multiply(posSpotDataPlList.get(0).getClosingYenRate())
                            .setScale(2, RoundingMode.HALF_UP));
                } else {
                    tPositionSpotSumDataBean.setSumPlYenConversion(null);
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                            "スポット集計処理",
                            "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                    + item.getSettleCurrency() + "JPY"
                                    + ":引値円転レートが取得できなかったため、累積確定PL(円換算)の計算エラー");
                }
            }
        } else if (tPositionSpotSumDataBean.getSumPlUnderlyingCcy() != null) {
            if (!JPY.equals(item.getSettleCurrency())) {
                // 評価レート区分がReal、引値以降の場合
                if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                        || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                    if (item.getRealYenRate() != null) {
                        // 累積確定PL(原通貨) * Real円転レート
                        tPositionSpotSumDataBean.setSumPlYenConversion(tPositionSpotSumDataBean
                                .getSumPlUnderlyingCcy().multiply(item.getRealYenRate())
                                .setScale(2, RoundingMode.HALF_UP));
                    } else {
                        tPositionSpotSumDataBean.setSumPlYenConversion(null);
                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                "スポット集計処理",
                                "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                        + item.getSettleCurrency() + "JPY"
                                        + ":Real円転レートが取得できなかったため、累積確定PL(円換算)の計算エラー");
                    }
                    // 評価レート区分が引値の場合
                } else {
                    if (item.getClosingYenRate() != null) {
                        // 累積確定PL(原通貨) * 引値円転レート
                        tPositionSpotSumDataBean.setSumPlYenConversion(tPositionSpotSumDataBean
                                .getSumPlUnderlyingCcy().multiply(item.getClosingYenRate())
                                .setScale(2, RoundingMode.HALF_UP));
                    } else {
                        tPositionSpotSumDataBean.setSumPlYenConversion(null);
                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                "スポット集計処理",
                                "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                        + item.getSettleCurrency() + "JPY"
                                        + ":引値円転レートが取得できなかったため、累積確定PL(円換算)の計算エラー");
                    }
                }
            } else {
                // 決済通貨がJPYの場合、累積確定PL(原通貨)で円転しない
                tPositionSpotSumDataBean
                        .setSumPlYenConversion(tPositionSpotSumDataBean.getSumPlUnderlyingCcy());
            }
        } else {
            tPositionSpotSumDataBean.setSumPlYenConversion(null);
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "スポット集計処理",
                    "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                            + item.getCurrencyPair() + ":累積確定PL(原通貨)が取得できなかったため、累積確定PL(円換算)の計算エラー");
        }
        // 前日繰越
        // 前回の前日繰越が存在する場合
        if (prevList.size() > 0) {
            if (prevList.get(index - 1).getBeforeEvaluationPosition() != null) {
                // 前回の前日繰越を設定
                tPositionSpotSumDataBean.setBeforeEvaluationPosition(
                        prevList.get(index - 1).getBeforeEvaluationPosition());
            } else {
                tPositionSpotSumDataBean.setBeforeEvaluationPosition(null);
            }
        } else {
            if (item.getBeforeEvaluationPosition() != null) {
                tPositionSpotSumDataBean
                        .setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
            } else {
                tPositionSpotSumDataBean.setBeforeEvaluationPosition(null);
            }
        }

        // ネット増減
        if (tPositionSpotSumDataBean.getBeforeEvaluationPosition() != null
                && tPositionSpotSumDataBean.getEvaluationPosition() != null) {
            // 評価ポジション - 前日繰越
            tPositionSpotSumDataBean
                    .setNetIncreaseOrDecrease(tPositionSpotSumDataBean.getEvaluationPosition()
                            .subtract(tPositionSpotSumDataBean.getBeforeEvaluationPosition()));
        } else {
            tPositionSpotSumDataBean
                    .setNetIncreaseOrDecrease(tPositionSpotSumDataBean.getEvaluationPosition());
        }
    } catch (Exception e) {
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", "スポット集計処理",
                "評価レート区分:" + evaluationRateName + "," + dealerBookCcyPair, e);
                    // ジョブ警告状態を設定
                    contribution.getStepExecution().getJobExecution().getExecutionContext()
                            .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
                }
                // 為替区分
                tPositionSpotSumDataBean.setExchangeDivision(item.getExchangeDivision());
                // 基準日
                tPositionSpotSumDataBean.setProcessBaseDate(targetDate);
                // ディーラブック
                tPositionSpotSumDataBean.setDealerBook(split[0]);
                // tPositionSpotSumDataBean.setDealerBook(item.getDealerBook());
                // 評価レート区分
                tPositionSpotSumDataBean.setEvaluationRateDivision(evaluationRateKbn);
                // 売買通貨
                tPositionSpotSumDataBean.setDealCurrency(item.getDealCurrency());
                // 決済通貨
                tPositionSpotSumDataBean.setSettleCurrency(item.getSettleCurrency());
                // 通貨ペア
                tPositionSpotSumDataBean.setCurrencyPair(split[1]);
                // 売買区分
                tPositionSpotSumDataBean.setDealDivision(item.getDealDivision());
                // ACフラグ
                tPositionSpotSumDataBean.setAc(item.getAc());
                // レート取得先
                tPositionSpotSumDataBean.setRateSource(item.getRateSource());
                // BBGレート
                tPositionSpotSumDataBean.setBbgRate(item.getBbgRate());
                // レート取得先がBBGレート(0)の場合
                if (RATESOURCEBBG.equals(item.getRateSource())) {
                    // BBGレートをReal評価レートに設定
                    tPositionSpotSumDataBean.setRealRate(item.getBbgRate());
                } else {
                    // Real評価レート
                    tPositionSpotSumDataBean.setRealRate(item.getRealRate());
                }
                // 引値評価レート
                tPositionSpotSumDataBean.setClosingRate(item.getClosingRate());
                // マニュアル(日中時価評価レート)
                tPositionSpotSumDataBean.setManualDailyRate(item.getManualDailyRate());
                // マニュアル(引けレート、TTM)
                tPositionSpotSumDataBean.setManualClosingTtmRate(item.getManualClosingTtmRate());
                // Real円転レート
                tPositionSpotSumDataBean.setRealYenRate(item.getRealYenRate());
                // 引値円転レート
                tPositionSpotSumDataBean.setClosingYenRate(item.getClosingYenRate());
                // 合計PL額
                if (tPositionSpotSumDataBean.getEvaluationPlYenConversion() != null
                        && tPositionSpotSumDataBean.getSumPlYenConversion() != null) {
                    tPositionSpotSumDataBean.setSumPlYen(tPositionSpotSumDataBean.getEvaluationPlYenConversion()
                            .add(tPositionSpotSumDataBean.getSumPlYenConversion()));
                } else {
                    tPositionSpotSumDataBean.setSumPlYen(null);
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "スポット集計処理",
                            "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + ","
                                    + item.getCurrencyPair() + ":NULLのデータが存在したため、合計PL額の計算エラー");
                }
                // 登録者
                tPositionSpotSumDataBean.setRegisterUser(JobConstants.Jbpos1000);
                // 登録日時
                tPositionSpotSumDataBean.setRegisterDatetime(null);
                // 更新者
                tPositionSpotSumDataBean.setUpdateUser(JobConstants.Jbpos1000);
                // 更新日時
                tPositionSpotSumDataBean.setUpdateDatetime(null);

                posSpotDataList.add(tPositionSpotSumDataBean);
                index++;

            }
            int lastIdx = posSpotDataList.size() - 1;
            // リスト追加
            tPositionSpotSumDataBeanList.add(posSpotDataList.get(lastIdx));
            // プレ引値、引値の場合、累積確定PL取得用リストに追加
            if (evaluationRateKbn.equals(EvaluationRateKbn.PRE_CLOSING.getCode())
                    || evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
                tPositionSpotSumDataPlBeanList.add(posSpotDataList.get(lastIdx));
            }
        }
        }
        // 7.3.集計した結果を評価レート区分にてポジション集計ファイル作成
        // プレ引値以外の場合、ファイル作成
        if (evaluationRateKbn != EvaluationRateKbn.PRE_CLOSING.getCode()) {
            // 7.6.評価レート区分にてポジション集計ファイル作成
            Jbpos1000PositionSumDateFileUtil.writePostSumDateFile(contribution, outputFilePath, evaluationRateKbn,
                    tPositionSpotSumDataBeanList);
        }
        // 7.4.ポジションスポット集計結果取得
        TPositionSpotSumDataBean tPositionSpotSumDataList = new TPositionSpotSumDataBean();
        try {
            // パラメータを渡す
            tPositionSpotSumDataList.setProcessBaseDate(targetDate);
            tPositionSpotSumDataList.setEvaluationRateDivision(evaluationRateKbn);
            List<TPositionSpotSumDataBean> spotSumlList = tPosSoptSumDataDao
                    .geTPositionSpotSumData(tPositionSpotSumDataList);
            // システム日時の時間がdayCloseTime以降の場合
            if (nowDateYmdhms.compareTo(dayCloseTime) >= 0) {
                // 7.4.ポジションスポット集計結果取得
                TPositionSpotSumDataBean tPositionSpotSumClosingData = new TPositionSpotSumDataBean();
                // パラメータを渡す
                tPositionSpotSumClosingData.setProcessBaseDate(targetDate);
                tPositionSpotSumClosingData.setEvaluationRateDivision(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
                spotSumClosingList = tPosSoptSumDataDao.geTPositionSpotSumData(tPositionSpotSumClosingData);
            }
            // システム日時の時間がdayCloseTime以降 かつ評価レート区分が引値の場合
            if (nowDateYmdhms.compareTo(dayCloseTime) >= 0
                    && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {

                // 引値集計結果を別リストに複製して作成
                tPosSpotSumClosingList = setClosingData(tPositionSpotSumDataBeanList);
            }

            String spotSumFlg = null;
            // 評価レート区分が03(日締め)の場合
            if (spotSumClosingList.size() > 0) {
                spotSumFlg = "1";
            } else {
                spotSumFlg = "2";
            }

            // 7.5取得したポジションスポット集計結果が存在した場合、削除処理(中間コミット)
            if (spotSumlList.size() > 0) {
                // ポジションスポット集計データ削除
                spotSumDataDelete(contribution, tPositionSpotSumDataList);
            }
            // 7.6.集計処理でポジションスポット集計結果が存在した場合、集計したデータをsqlコマンドのINSERTで登録する(中間コミット)
            if (tPositionSpotSumDataBeanList.size() > 0) {
                // 7.5.DBに登録処理(中間コミット)
                insertSpotSumData(contribution, tPositionSpotSumDataBeanList);

            }
            // システム日時の時間がdayCloseTime以降、かつ評価レート区分が引値の場合、かつ日締めデータが存在しない場合
            if (tPosSpotSumClosingList.size() > 0 && nowDateYmdhms.compareTo(dayCloseTime) >= 0
                    && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode()) && !spotSumFlg.equals("1")) {
                // 日締めデータを登録
                insertSpotSumData(contribution, tPosSpotSumClosingList);
            }
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
        }
    }
/**
 * スポット引値集計結果を日締め用リスト設定処理
 *
 * @param tPositionSpotSumDataBeanList
 * @return closingDataLsit
 * @throws Exception
 */
static List<TPositionSpotSumDataBean> setClosingData(List<TPositionSpotSumDataBean> tPositionSpotSumDataBeanList)
        throws Exception {

    List<TPositionSpotSumDataBean> closingDataLsit = new ArrayList<>();

    for (TPositionSpotSumDataBean item : tPositionSpotSumDataBeanList) {
        TPositionSpotSumDataBean pos = new TPositionSpotSumDataBean();

        // 処理基準日
        pos.setProcessBaseDate(item.getProcessBaseDate());
        // ディーラブック
        pos.setDealerBook(item.getDealerBook());
        // 評価レート区分(日締め用03を設定)
        pos.setEvaluationRateDivision(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
        // 売買通貨
        pos.setDealCurrency(item.getDealCurrency());
        // 決済通貨
        pos.setSettleCurrency(item.getSettleCurrency());
        // 通貨ペア
        pos.setCurrencyPair(item.getCurrencyPair());
        // 為替区分
        pos.setExchangeDivision(item.getExchangeDivision());
        // 売買金額
        pos.setDealAmount(item.getDealAmount());
        // 決済金額
        pos.setSettleAmount(item.getSettleAmount());
        // ACフラグ
        pos.setAc(item.getAc());
        // 売買区分
        pos.setDealDivision(item.getDealDivision());
        // レート取得先
        pos.setRateSource(item.getRateSource());
        // BBGレート
        pos.setBbgRate(item.getBbgRate());
        // Real評価レート(ストリーミングレート)
        pos.setRealRate(item.getRealRate());
        // 引値評価レート
        pos.setClosingRate(item.getClosingRate());
        // Avgコストレート
        pos.setAvgCostRate(item.getAvgCostRate());
        // マニュアル(日中時価評価レート)
        pos.setManualDailyRate(item.getManualDailyRate());
        // マニュアル(引けレート、TTM)
        pos.setManualClosingTtmRate(item.getManualClosingTtmRate());
        // Real円転レート
        pos.setRealYenRate(item.getRealYenRate());
        // 引値円転レート
        pos.setClosingYenRate(item.getClosingYenRate());
        // 評価ポジション
        pos.setEvaluationPosition(item.getEvaluationPosition());
        // 評価PL(原通貨)
        pos.setEvaluationPlUnderlyingCcy(item.getEvaluationPlUnderlyingCcy());
        // 評価PL(円換算)
        pos.setEvaluationPlYenConversion(item.getEvaluationPlYenConversion());
        // 未確決済金額
        pos.setPendingSettleAmount(item.getPendingSettleAmount());
        // 確定ポジション
        pos.setConfirmPosition(item.getConfirmPosition());
        // 確定PL(原通貨)
        pos.setConfirmUnderlyingCcy(item.getConfirmUnderlyingCcy());
        // 累積確定PL(原通貨)
        pos.setSumPlUnderlyingCcy(item.getSumPlUnderlyingCcy());
        // 累積確定PL(円換算)
        pos.setSumPlYenConversion(item.getSumPlYenConversion());
        // 合計PL額
        pos.setSumPlYen(item.getSumPlYen());
        // 前日繰越
        pos.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
        // ネット増減
        pos.setNetIncreaseOrDecrease(item.getNetIncreaseOrDecrease());
        // 登録者
        pos.setRegisterUser(item.getRegisterUser());
        // 登録日時
        pos.setRegisterDatetime(item.getRegisterDatetime());
        // 更新者
        pos.setUpdateUser(item.getUpdateUser());
        // 更新日時
        pos.setUpdateDatetime(item.getUpdateDatetime());

        closingDataLsit.add(pos);
    }
    return closingDataLsit;
}

/**
 * ポジションスポット集計結果削除処理 <br>
 * コミット方式:中間コミット<br>
 *
 * @param contribution
 * @param tPositionSpotSumDataList
 * @throws Exception
 */
private void spotSumDataDelete(StepContribution contribution, TPositionSpotSumDataBean tPositionSpotSumDataList)
        throws Exception {
    DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
    definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    TransactionStatus status = null;
    try {
        // トランザクションを明示的に開始
        status = transactionManager.getTransaction(definition);
        // [ポジションスポット集計結果]の削除処理
        tPosSoptSumDataDao.delete(tPositionSpotSumDataList);
        // トランザクションをコミット
        transactionManager.commit(status);
    } catch (Exception e) {
        if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
            // DB切断された時、処理終了
            throw e;
        }
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスポット集計結果削除処理 ", e);
        // トランザクションをロールバック
        transactionManager.rollback(status);
        // ジョブ警告状態を設定
        contribution.getStepExecution().getJobExecution().getExecutionContext()
                .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}

/**
 * ポジションスポット集計結果登録処理 <br>
 * コミット方式:中間コミット<br>
 *
 * @param contribution
 * @param insertTPosSpotSumDataList
 * @throws Exception
 */
private void insertSpotSumData(StepContribution contribution,
        List<TPositionSpotSumDataBean> insertTPosSpotSumDataList) throws Exception {
    DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
    definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    TransactionStatus status = null;
        try {
            // トランザクションを明示的に開始
            status = transactionManager.getTransaction(definition);
            // [ポジションスポット集計結果]のinsert処理
            tPosSoptSumDataDao.insert(insertTPosSpotSumDataList);
            // トランザクションをコミット
            transactionManager.commit(status);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスポット集計結果登録処理 ", e);
            // トランザクションをロールバック
            transactionManager.rollback(status);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
    }

    /**
     * ①ポジションスワップ集計メイン
     *
     * @param contribution
     * @param tPosSwapSourceDataList
     * @param targetDate
     * @param evaluationRateKbn
     * @throws Exception
     */
    private void mkPositionSwapSumData(StepContribution contribution,
            List<TPosSumSourceDataBean> tPosSwapSourceDataList, Date targetDate, Date busiDaysBefore,
            String evaluationRateKbn, String nowDateYmdhms) throws Exception {
        List<TPositionSwapSumDataBean> tPositionSwapSumClosingList = new ArrayList<>();
        List<TByCcyDeltaCashBalanceBean> TByCcyDeltaCashClosingList = new ArrayList<>();
        List<TSwapPlSumDateBean> tSwapPlSumClosingList = new ArrayList<>();
        List<TPositionSwapSumDataBean> swapClosingList = new ArrayList<>();
        List<TByCcyDeltaCashBalanceBean> tByCcyDeltaCashClosing = new ArrayList<>();
        List<TSwapPlSumDateBean> swapPlSumClosingList = new ArrayList<>();

        try {
            // DF算出結果取得
            List<TDfCalcResultBean> dfCalcResult = tDfCalcResultDao.getTDfCalcResultBeanAll(busiDaysBefore, targetDate);

            // DF履歴情報取得
            TDfHistoryDateBean tDfHistoryDateBean = new TDfHistoryDateBean();
            // パラメータを渡す
            tDfHistoryDateBean.setBaseDate(targetDate);
            List<TDfHistoryDateBean> dfHistory = tDfHistoryDateDao.getDfHistoryDateBeanAll(tDfHistoryDateBean);

            // 通貨マスタ
            List<TCurrencyMstBean> tCurrencyMst = tCurrencyMstRepository.findAllCurrencyMst();

            // ポジション集計元情報データ取得する
            TPosSumSourceDataBean posSumSourceData = new TPosSumSourceDataBean();
            // パラメータを渡す
            posSumSourceData.setProcessBaseDate(targetDate);
            List<TPosSumSourceDataBean> posSumSourceList = tPosSumSourceDataDao
                    .getPosSumSourceDataAll(posSumSourceData);

            String evaluationRateName = null;
            switch (evaluationRateKbn) {
            case "00":
                evaluationRateName = EvaluationRateKbn.REAL.getName();
                break;
            case "01":
                evaluationRateName = EvaluationRateKbn.CLOSING_PRICE.getName();
                break;
            case "02":
                evaluationRateName = EvaluationRateKbn.AFTER_CLOSING_PRICE.getName();
                break;
            }
            // ①-1スワップ集計を呼び出す
            List<TPositionSwapSumDataDto> tposSwapSumDataList = Jbpos1000SwapSummary.getTPosCashSumData(contribution,
                    tPosSwapSourceDataList, dfCalcResult, dfHistory, tCurrencyMst, targetDate, evaluationRateKbn,
                    evaluationRateName);
            // ①-2スワップ集計を通貨単位纏め処理
            List<TPositionSwapSumDataBean> tposSwapSumCcyDataList = Jbpos1000SwapSummary
                    .sumPositionSwapData(contribution, tposSwapSumDataList);

            // ②通貨別デルタ・キャッシュ残情報集計処理
            List<TByCcyDeltaCashBalanceBean> tByCcyDeltaCashList = Jbpos1000SwapSummary.mkByCcyDeltaCashBalance(
                    contribution, targetDate, evaluationRateKbn, evaluationRateName, tposSwapSumCcyDataList,
                    posSumSourceList);

            // ③スワップPL合計値情報集計処理
            List<TSwapPlSumDateBean> tSwapPlSumDateList = Jbpos1000SwapSummary.mkSwapPlSumDate(contribution, targetDate,
                    evaluationRateKbn, evaluationRateName, tposSwapSumDataList);

            // 7.6.評価レート区分にてポジション集計ファイル作成
            Jbpos1000PositionSumDateFileUtil.writeSwapSumDateFile(contribution, outputFilePath, evaluationRateKbn,
                    tSwapPlSumDateList, tByCcyDeltaCashList, tposSwapSumCcyDataList);

            // ポジションスワップ集計結果取得
            TPositionSwapSumDataBean SwapSumData = new TPositionSwapSumDataBean();
            // パラメータを渡す
            SwapSumData.setProcessBaseDate(targetDate);
            SwapSumData.setEvaluationRateDivision(evaluationRateKbn);
            List<TPositionSwapSumDataBean> posList = tPosSwapSumDataDao.getPositionSwapSumDataList(SwapSumData);
            // システム日時の時間がdayCloseTime以降の場合
            if (nowDateYmdhms.compareTo(dayCloseTime) >= 0) {
                // ポジションスワップ集計結果取得
                TPositionSwapSumDataBean SwapSumClosingData = new TPositionSwapSumDataBean();
                // パラメータを渡す
                SwapSumClosingData.setProcessBaseDate(targetDate);
                SwapSumClosingData.setEvaluationRateDivision(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
                swapClosingList = tPosSwapSumDataDao.getPositionSwapSumDataList(SwapSumClosingData);

            }
            // システム日時の時間がdayCloseTime以降、かつ評価レート区分が引値の場合、日締めデータ作成
            if (nowDateYmdhms.compareTo(dayCloseTime) >= 0
                    && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {

                // 引値集計結果を別リストに複製して作成
                tPositionSwapSumClosingList = setSwapClosingData(tposSwapSumCcyDataList);
                TByCcyDeltaCashClosingList = setCcyDeltaCashClosingData(tByCcyDeltaCashList);
                tSwapPlSumClosingList = setSwapPlSumClosingData(tSwapPlSumDateList);
            }

            String swapSumFlg = null;
            // 評価レート区分が03(日締め)の場合
            if (swapClosingList.size() > 0) {
                swapSumFlg = "1";
            } else {
                swapSumFlg = "2";
            }

            // ポジションスワップ集計削除処理(中間コミット)
            if (posList.size() > 0) {
                // ポジションスワップ集計結果データ削除
                posSwaptSumDataDelete(contribution, SwapSumData);
            }
            // ポジションスワップ集計登録処理(中間コミット)
            if (tposSwapSumCcyDataList.size() > 0) {
                // 7.5.DBに登録処理(中間コミット)
                insertSwapSumData(contribution, tposSwapSumCcyDataList);
            }
            // システム日時の時間がdayCloseTime以降、かつ評価レート区分が引値、かつ日締めデータが存在しないの場合
            if (tPositionSwapSumClosingList.size() > 0 && nowDateYmdhms.compareTo(dayCloseTime) >= 0
                    && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode()) && !swapSumFlg.equals("1")) {
                // 日締めデータを登録
                insertSwapSumData(contribution, tPositionSwapSumClosingList);
            }
        // 通貨別デルタ・キャッシュ残情報取得
        TByCcyDeltaCashBalanceBean tByCcyDeltaCash = new TByCcyDeltaCashBalanceBean();
        // パラメータを渡す
        tByCcyDeltaCash.setProcessBaseDate(targetDate);
        tByCcyDeltaCash.setEvaluationRateDivision(evaluationRateKbn);
        List<TByCcyDeltaCashBalanceBean> tByCcyDeltaCashAll = tByCcyDeltaCashDataDao
                .getByCcyDeltaCashBalanceList(tByCcyDeltaCash);
        // システム日時の時間がdayCloseTime以降の場合
        if (nowDateYmdhms.compareTo(dayCloseTime) >= 0) {
            // 通貨別デルタ・キャッシュ残情報取得
            TByCcyDeltaCashBalanceBean tByCcyDeltaCashClosingList = new TByCcyDeltaCashBalanceBean();
            // パラメータを渡す
            tByCcyDeltaCashClosingList.setProcessBaseDate(targetDate);
            tByCcyDeltaCashClosingList.setEvaluationRateDivision(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
            tByCcyDeltaCashClosing = tByCcyDeltaCashDataDao
                    .getByCcyDeltaCashBalanceList(tByCcyDeltaCashClosingList);
        }
        String byCcyFlg = null;
        // 評価レート区分が03(日締め)の場合
        if (tByCcyDeltaCashClosing.size() > 0) {
            byCcyFlg = "1";
        } else {
            byCcyFlg = "2";
        }

        // 通貨別デルタ・キャッシュ残情報削除処理(中間コミット)
        if (tByCcyDeltaCashAll.size() > 0) {
            // 決済通貨外貨PLデルタ生成情報データ削除
            byCcyDeltaCashDataDelete(contribution, tByCcyDeltaCash);
        }
        // 通貨別デルタ・キャッシュ残情報登録処理(中間コミット)
        if (tByCcyDeltaCashList.size() > 0) {
            // 7.5.DBに登録処理(中間コミット)
            insertByCcyDeltaCashData(contribution, tByCcyDeltaCashList);

        }
        // システム日時の時間がdayCloseTime以降の場合、かつ評価レート区分が引値の場合
        if (TByCcyDeltaCashClosingList.size() > 0 && nowDateYmdhms.compareTo(dayCloseTime) >= 0
                && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode()) && !byCcyFlg.equals("1")) {
            // 日締めデータを登録
            insertByCcyDeltaCashData(contribution, TByCcyDeltaCashClosingList);
        }

        // スワップPL合計値情報集計情報取得
        TSwapPlSumDateBean tSwapPlSumDate = new TSwapPlSumDateBean();
        // パラメータを渡す
        tSwapPlSumDate.setProcessBaseDate(targetDate);
        tSwapPlSumDate.setEvaluationRateDivision(evaluationRateKbn);
        List<TSwapPlSumDateBean> swapPlSumList = tSwapPlSumDateDao.getSwapPlSumDateList(tSwapPlSumDate);
        // システム日時の時間がdayCloseTime以降の場合
        if (nowDateYmdhms.compareTo(dayCloseTime) >= 0) {
            // スワップPL合計値情報集計情報取得
            TSwapPlSumDateBean tSwapPlSumClosingDate = new TSwapPlSumDateBean();
            // パラメータを渡す
            tSwapPlSumClosingDate.setProcessBaseDate(targetDate);
            tSwapPlSumClosingDate.setEvaluationRateDivision(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
            swapPlSumClosingList = tSwapPlSumDateDao.getSwapPlSumDateList(tSwapPlSumClosingDate);
        }
        String swapPlSumFlg = null;
        // 評価レート区分が03(日締め)の場合
        if (swapPlSumClosingList.size() > 0) {
            swapPlSumFlg = "1";
        } else {
            swapPlSumFlg = "2";
        }
        // スワップPL合計値情報集計情報新規、更新処理(中間コミット)
        if (swapPlSumList.size() > 0) {
            // 7.4.DBに更新(中間コミット)
            swapPlSumDateDelete(contribution, tSwapPlSumDate);
        }
        if (tSwapPlSumDateList.size() > 0) {
            // 7.5.DBに登録処理(中間コミット)
            insertSwapPlSumDate(contribution, tSwapPlSumDateList);
        }
        // システム日時の時間がdayCloseTime以降の場合、かつ評価レート区分が引値の場合
        if (tSwapPlSumClosingList.size() > 0 && nowDateYmdhms.compareTo(dayCloseTime) >= 0
                && evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())
                && !swapPlSumFlg.equals("1")) {
            // 日締めデータを登録
            insertSwapPlSumDate(contribution, tSwapPlSumClosingList);
        }
    } catch (Exception e) {
        if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
            // DB切断された時、処理終了
            throw e;
        }
    }
}

    /**
     * ポジションスワップ集計結果削除処理 <br>
     * コミット方式:中間コミット<br>
     *
     * @param contribution
     * @param SwapSumData
     * @throws Exception
     */
    private void posSwaptSumDataDelete(StepContribution contribution, TPositionSwapSumDataBean SwapSumData)
            throws Exception {
        DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
        definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        TransactionStatus status = null;
        try {
            // トランザクションを明示的に開始
            status = transactionManager.getTransaction(definition);
            // [ポジションスワップ集計結果]のDelete処理
            tPosSwapSumDataDao.delete(SwapSumData);
            // トランザクションをコミット
            transactionManager.commit(status);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスワップ集計結果削除処理 ", e);
            // トランザクションをロールバック
            transactionManager.rollback(status);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
    }

/**
 * ポジションスワップ集計結果登録処理 <br>
 * コミット方式:中間コミット<br>
 *
 * @param contribution
 * @param tposSwapSumCcyDataList
 * @throws Exception
 */
private void insertSwapSumData(StepContribution contribution, List<TPositionSwapSumDataBean> tposSwapSumCcyDataList)
        throws Exception {
    DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
    definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    TransactionStatus status = null;
    try {
        // トランザクションを明示的に開始
        status = transactionManager.getTransaction(definition);
        // [ポジションスワップ集計結果]のinsert処理
        tPosSwapSumDataDao.insert(tposSwapSumCcyDataList);
        // トランザクションをコミット
        transactionManager.commit(status);
    } catch (Exception e) {
        if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
            // DB切断された時、処理終了
            throw e;
        }
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスワップ集計結果登録処理 ", e);
        // トランザクションをロールバック
        transactionManager.rollback(status);
        // ジョブ警告状態を設定
        contribution.getStepExecution().getJobExecution().getExecutionContext()
                .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}

/**
 * 通貨別デルタ・キャッシュ残情報削除処理 <br>
 * コミット方式:中間コミット<br>
 *
 * @param contribution
 * @param tByCcyDeltaCash
 * @throws Exception
 */
private void byCcyDeltaCashDataDelete(StepContribution contribution, TByCcyDeltaCashBalanceBean tByCcyDeltaCash)
        throws Exception {
    DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
    definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    TransactionStatus status = null;
    try {
        // トランザクションを明示的に開始
        status = transactionManager.getTransaction(definition);
        // [通貨別デルタ・キャッシュ残情報]のdelete処理
        tByCcyDeltaCashDataDao.delete(tByCcyDeltaCash);
        // トランザクションをコミット
        transactionManager.commit(status);
    } catch (Exception e) {
        if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
            // DB切断された時、処理終了
            throw e;
        }
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "通貨別デルタ・キャッシュ残情報削除処理 ", e);
        // トランザクションをロールバック
        transactionManager.rollback(status);
        // ジョブ警告状態を設定
        contribution.getStepExecution().getJobExecution().getExecutionContext()
                .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}

/**
 * 通貨別デルタ・キャッシュ残情報登録処理 コミット方式:中間コミット
 *
 * @param contribution
 * @param insertByCcyDeltaCashList
 * @throws Exception
 */
private void insertByCcyDeltaCashData(StepContribution contribution,
        List<TByCcyDeltaCashBalanceBean> insertByCcyDeltaCashList) throws Exception {
    DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
    definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    DBUtil dbUtil = new DBUtil();
    for (List<TByCcyDeltaCashBalanceBean> itemList : dbUtil.divideList(insertByCcyDeltaCashList, bulkInsertUnit)) {
        TransactionStatus status = null;
        try {
            // トランザクションを明示的に開始
            status = transactionManager.getTransaction(definition);
            // [通貨別デルタ・キャッシュ残情報]のinsert処理
                tByCcyDeltaCashDataDao.insert(itemList);
                // トランザクションをコミット
                transactionManager.commit(status);
            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                    // DB切断された時、処理終了
                    throw e;
                }
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "通貨別デルタ・キャッシュ残情報登録処理 ",
                        e);
                // トランザクションをロールバック
                transactionManager.rollback(status);
                // insertし直す
                for (TByCcyDeltaCashBalanceBean bean : itemList) {
                    try {
                        List<TByCcyDeltaCashBalanceBean> tmp = new ArrayList<TByCcyDeltaCashBalanceBean>();
                        tmp.add(bean);
                        status = transactionManager.getTransaction(definition);
                        // [通貨別デルタ・キャッシュ残情報]のinsert処理
                        tByCcyDeltaCashDataDao.insert(insertByCcyDeltaCashList);
                        transactionManager.commit(status);
                    } catch (Exception ex) {
                        if (ex.getMessage() != null && ex.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                            // DB切断された時、処理終了
                            throw ex;
                        }
                        transactionManager.rollback(status);
                    }
                }
                // ジョブ警告状態を設定
                contribution.getStepExecution().getJobExecution().getExecutionContext()
                        .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
            }
        }
    }

    /**
     * スワップPL合計値情報集計情報削除処理 <br>
     * コミット方式:中間コミット<br>
     *
     * @param contribution
     * @param tSwapPlSumDate
     * @throws Exception
     */
    private void swapPlSumDateDelete(StepContribution contribution, TSwapPlSumDateBean tSwapPlSumDate)
            throws Exception {
        DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
        definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        TransactionStatus status = null;
        try {
            // トランザクションを明示的に開始
            status = transactionManager.getTransaction(definition);
            // [スワップPL合計値情報集計]のdelete処理
            tSwapPlSumDateDao.delete(tSwapPlSumDate);
            // トランザクションをコミット
            transactionManager.commit(status);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "通貨別デルタ・キャッシュ残情報削除処理 ", e);
            // トランザクションをロールバック
            transactionManager.rollback(status);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
    }
    /**
     * スワップPL合計値情報集計情報登録処理 <br>
     * コミット方式:中間コミット<br>
     *
     * @param contribution
     * @param insertSwapPlSumDateList
     * @throws Exception
     */
    private void insertSwapPlSumDate(StepContribution contribution, List<TSwapPlSumDateBean> insertSwapPlSumDateList)
            throws Exception {
        DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
        definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        TransactionStatus status = null;
        try {
            // トランザクションを明示的に開始
            status = transactionManager.getTransaction(definition);
            // [スワップPL合計値情報集計]のinsert処理
            tSwapPlSumDateDao.insert(insertSwapPlSumDateList);
            // トランザクションをコミット
            transactionManager.commit(status);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                // DB切断された時、処理終了
                throw e;
            }
            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "スワップPL合計値情報集計情報登録処理 ", e);
            // トランザクションをロールバック
            transactionManager.rollback(status);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
    }

    /**
     * スワップ引値集計結果を日締め用リスト設定処理
     *
     * @param tposSwapSumCcyDataList
     * @return tPositionSwapSumClosingList
     * @throws Exception
     */
    static List<TPositionSwapSumDataBean> setSwapClosingData(List<TPositionSwapSumDataBean> tposSwapSumCcyDataList)
            throws Exception {

        List<TPositionSwapSumDataBean> tPositionSwapSumClosingList = new ArrayList<>();

        for (TPositionSwapSumDataBean item : tposSwapSumCcyDataList) {
            TPositionSwapSumDataBean pos = new TPositionSwapSumDataBean();

            // 処理基準日
            pos.setProcessBaseDate(item.getProcessBaseDate());
            // ディーラブック
            pos.setDealerBook(item.getDealerBook());
            // 評価レート区分(日締め用03を設定)
            pos.setEvaluationRateDivision(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
            // 通貨
            pos.setCurrency(item.getCurrency());
            // 為替区分
            pos.setExchangeDivision(item.getExchangeDivision());

            // 受渡日
            pos.setDeliveryDate(item.getDeliveryDate());
            // 売買金額
            pos.setDealAmount(item.getDealAmount());
            // 決済金額
            pos.setSettleAmount(item.getSettleAmount());
            // Real評価レート(ストリーミングレート)
            pos.setRealRate(item.getRealRate());
            // 引値評価レート
            pos.setClosingRate(item.getClosingRate());
            // Real円転レート
            pos.setRealYenRate(item.getRealYenRate());
            // 引値円転レート
            pos.setClosingYenRate(item.getClosingYenRate());
            // 売買円転レート
            pos.setDealYenRate(item.getRealYenRate());
            // 売買円転レート(引値)
            pos.setDealYenClosingRate(item.getClosingYenRate());
            // 取引金PV(引値)
            pos.setTradeAmountPvCls(item.getTradeAmountPvCls());
            // 取引金PV(引値)円転
            pos.setTradeAmountPvClsYen(item.getTradeAmountPvClsYen());
            // 取引金PV
            pos.setTradeAmountPv(item.getTradeAmountPv());
            // 取引金PV円転
            pos.setTradeAmountPvYen(item.getTradeAmountPvYen());
            // 取引金PV評価換算
            pos.setTradeAmountPvEva(item.getTradeAmountPvEva());
            // 取引金PV評価換算円転
            pos.setTradeAmountPvEvaYen(item.getTradeAmountPvEvaYen());
            // 決済円転レート
            pos.setSettleYenRate(item.getRealYenRate());
            // 決済金PV
            pos.setSettleAmountPv(item.getSettleAmountPv());
            // 決済金PV円転
            pos.setSettleAmountPvYen(item.getSettleAmountPvYen());
            // CF金額
            pos.setCashAmount(item.getCashAmount());
            // PL(円)
            pos.setSumPlYen(item.getSumPlYen());
            // 登録者
            pos.setRegisterUser(item.getRegisterUser());
            // 登録日時
            pos.setRegisterDatetime(item.getRegisterDatetime());
            // 更新者
            pos.setUpdateUser(item.getUpdateUser());
            // 更新日時
            pos.setUpdateDatetime(item.getUpdateDatetime());

            tPositionSwapSumClosingList.add(pos);
        }
        return tPositionSwapSumClosingList;
    }

    /**
     * 通貨別デルタ・キャッシュ残情報を日締め用リスト設定処理
     *
     * @param tByCcyDeltaCashList
     * @return TByCcyDeltaCashClosingList
     * @throws Exception
     */
    static List<TByCcyDeltaCashBalanceBean> setCcyDeltaCashClosingData(
            List<TByCcyDeltaCashBalanceBean> tByCcyDeltaCashList) throws Exception {

        List<TByCcyDeltaCashBalanceBean> TByCcyDeltaCashClosingList = new ArrayList<>();

        for (TByCcyDeltaCashBalanceBean item : tByCcyDeltaCashList) {
            TByCcyDeltaCashBalanceBean pos = new TByCcyDeltaCashBalanceBean();

            // 処理基準日
            pos.setProcessBaseDate(item.getProcessBaseDate());
            // 評価レート区分(日締め用03を設定)
            pos.setEvaluationRateDivision(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
            // ディーラブック
            pos.setDealerBook(item.getDealerBook());
            // 通貨
            pos.setCurrency(item.getCurrency());
            // デルタ
            pos.setDelta(item.getDelta());
            // キャッシュ残
            pos.setCashBalance(item.getCashBalance());
            // 登録者
            pos.setRegisterUser(item.getRegisterUser());
            // 登録日時
            pos.setRegisterDatetime(item.getRegisterDatetime());
            // 更新者
            pos.setUpdateUser(item.getUpdateUser());
            // 更新日時
            pos.setUpdateDatetime(item.getUpdateDatetime());

            TByCcyDeltaCashClosingList.add(pos);
        }
        return TByCcyDeltaCashClosingList;
    }

    /**
     * スワップPL合計値情報を日締め用リスト設定処理
     *
     * @param tSwapPlSumDateList
     * @return tSwapPlSumClosingList
     * @throws Exception
     */
    static List<TSwapPlSumDateBean> setSwapPlSumClosingData(List<TSwapPlSumDateBean> tSwapPlSumDateList)
            throws Exception {

        List<TSwapPlSumDateBean> tSwapPlSumClosingList = new ArrayList<>();

        for (TSwapPlSumDateBean item : tSwapPlSumDateList) {
            TSwapPlSumDateBean pos = new TSwapPlSumDateBean();

            // 処理基準日
            pos.setProcessBaseDate(item.getProcessBaseDate());
            // 評価レート区分(日締め用03を設定)
            pos.setEvaluationRateDivision(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
            // ディーラブック
            pos.setDealerBook(item.getDealerBook());
            // PL合計値
            pos.setPlTotal(item.getPlTotal());
            // 登録者
            pos.setRegisterUser(item.getRegisterUser());
            // 登録日時
            pos.setRegisterDatetime(item.getRegisterDatetime());
            // 更新者
            pos.setUpdateUser(item.getUpdateUser());
            // 更新日時
            pos.setUpdateDatetime(item.getUpdateDatetime());

            tSwapPlSumClosingList.add(pos);
        }
        return tSwapPlSumClosingList;
    }

    /**
     * 初期化
     *
     * @throws Exception
     */
    private void init() throws Exception {
        // バッチ実行基準日取得(非営業日の場合、null)
        targetDate = dbOperation.isBizDate();
        if (targetDate == null) {
            // 非営業日の場合、後続処理をスキップする。
            return;
        }
        // 前日営業日
        busiDaysBefore = dbOperation.getPrevBizDay(targetDate);
        // 通貨マスタ
        List<TCurrencyMstBean> currencyMstList = tCurrencyMstRepository.getTCurrencyMstAll();
        // FXDS側ポジション集計元情報
        List<PosSumSourceDto> fxdsList = dbOperation.getPosSumSourceData(busiDaysBefore, dayCloseTime);
        // 【DFIT】為替トレードデータ
        List<TDfitTradeExchangeBean> dfitTradeList = dbOperation.getDfitTradeExchangeFxdsData(STATUS_LIST, busiDaysBefore);
        // 【DFIT】部課別顧客マスタ
        List<TDfitCustomerMstBean> dfitCustList = dbOperation.getDfitCustomerData();
        // 【DFIT】ポジション集計元情報
        List<PosSumSourceDto> dfitList = dbOperation.getDfitTradeExchange(DateUtil.convertDateToStrYmd(busiDaysBefore));
        // 【BID】ポジション集計元情報・為替トレードデータ
        List<PosSumSourceDto> bidList = dbOperation.getBidTradeInfo(targetDate, busiDaysBefore);
        // 【BID】ポジション集計元情報・外Mデータ仕分けデータ
        List<PosSumSourceDto> bidOutMList = dbOperation.getBidOutsideMInfo(targetDate, busiDaysBefore);
        // マッチング元データセット
        dataOperation.setCurrencyMstList(currencyMstList);
        dataOperation.setDfitTradeExchangeList(dfitTradeList);
        dataOperation.setDfitCurrencyMstList(dfitCustList);
        dataOperation.setFxdsInfoList(fxdsList);
        dataOperation.setDfitInfoList(dfitList);
        dataOperation.setBidInfoList(bidList);
        dataOperation.setBidOutMInfoList(bidOutMList);
    }
}
