package jp.co.daiwa.jbpos1000;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import jp.co.daiwa.common.DateUtil;

import jp.co.daiwa.dao.Jbpos1001Repository;
import jp.co.daiwa.dao.TBatchExecBaseDateRepository;
import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.TCurrencyMstRepository;
import jp.co.daiwa.dao.TDfCalcResultRepository;
import jp.co.daiwa.dao.TDfHistoryDateRepository;
import jp.co.daiwa.dao.TPosSumManualRateRepository;
import jp.co.daiwa.dao.TPosSumSourceDataRepository;
import jp.co.daiwa.dao.TPositionPlDeltaDataRepository;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.TPositionSwapSumDataRepository;
import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.dao.bean.TB86bet0Bean;
import jp.co.daiwa.dao.bean.TB86bYg0Bean;
import jp.co.daiwa.dao.bean.TB86bYs0Bean;
import jp.co.daiwa.dao.bean.TDfitCustomerMstBean;
import jp.co.daiwa.dao.bean.TDfitTradeExchangeBean;
import jp.co.daiwa.dao.bean.TTradeMngBean;
import jp.co.daiwa.daobid.Tb86bet0Repository;
import jp.co.daiwa.daodfit.TDfarmBbgRateRepository;
import jp.co.daiwa.daodfit.TDfitCustomerMstRepository;
import jp.co.daiwa.daodfit.TDfitTradeExchangeRepository;
import jp.co.daiwa.dto.PosSumSourceDto;

/**
 * ポジション集計DB操作クラス
 *
 * @author MatsuFumizawa
 *
 */
public class JbPositionDbOperation {
    @Inject
    Tb86bet0Repository tb86bet0Repository;
    @Inject
    TBatchExecBaseDateRepository tBatchExecBaseDateRepository;
    @Inject
    TPosSumManualRateRepository tPosSumManualRateRepository;
    @Inject
    TPosSumSourceDataRepository tPosSumSourceDataRepository;
    @Inject
    TPositionPlDeltaDataRepository tPositionPlDeltaDataRepository;
    @Inject
    TPositionSpotSumDataRepository tPositionSpotSumDataRepository;
    @Inject
    TPositionSwapSumDataRepository tPositionSwapSumDataRepository;
    @Inject
    TByCcyDeltaCashBalanceRepository tByCcyDeltaCashBalanceRepository;
    @Inject
    TSwapPlSumDateRepository tSwapPlSumDateRepository;
    @Inject
    TDfCalcResultRepository tDfCalcResultRepository;
    @Inject
    TDfHistoryDateRepository tDfHistoryDateRepository;
    @Inject
    TDfarmBbgRateRepository tDfarmBbgRateRepository;
    @Inject
    TCurrencyMstRepository tCurrencyMstRepository;
    @Inject
    Jbpos1001Repository jbpos1001Repository;
    @Inject
     TDfitTradeExchangeRepository tDfitTradeExchangeRepository;
    @Inject
    TDfitCustomerMstRepository tDfitCustomerMstRepository;

    private static String FXDS = "FXDS";
    private static String FOREIGN_EXCHANGE_DEPARMENT = "外国為替課";

    /**
     * コンストラクタ
     *
     */
    public JbPositionDbOperation() {
    }

    /**
     * 営業日判定処理
     *
     * @return 営業日の場合バッチ実行基準日を返す
     */
    public Date isBizDate() {
        // バッチ実行基準日取得する
        Date targetDate = tBatchExecBaseDateRepository.getExecBaseDate();
        // 営業日を取得
        TB86BET0Bean tB86BET0Bean = new TB86BET0Bean();
        tB86BET0Bean.setRekiymd(DateUtil.convertDateToStrYmd(targetDate));
        TB86BET0Bean businessDay = tb86bet0Repository.getBusinessDay(tB86BET0Bean);
        TB86BET0Bean lastBusinessDay = tb86bet0Repository.getLastBusinessDay(tB86BET0Bean);
        if (businessDay != null || lastBusinessDay != null) {
            return targetDate;
        } else {
            return null;
        }
    }

    /**
     * 前営業日取得
     *
     * @param targetDate
     * @return
     */
    public Date getPrevBizDay(Date targetDate) {
        TB86BET0Bean tB86BET0Bean = tb86bet0Repository.getWorkingDayPlus(DateUtil.convertDateToStrYmd(targetDate), -1);
        return DateUtil.parsDate(tB86BET0Bean.getRekiymd());
    }

    /**
     * ポジション集計元情報取得処理
     *
     * @param busiDaysBeforeStr 前日営業日
     * @param endTime 終了時刻
     * @return
     */
    public List<PosSumSourceDto> getPosSumSourceData(Date preBizDate, String endTime) {
        TTradeMngBean tTradeMngBean = new TTradeMngBean();
        tTradeMngBean.setTradeDatetime(preBizDate);
        tTradeMngBean.setNote(endTime);
        List<PosSumSourceDto> tradeMngFxAllList = jbpos1001Repository.getTradeMngFxAll(tTradeMngBean);
        return tradeMngFxAllList;
    }

    /**
     * 【DFIT】為替トレードデータ取得
     *
     * @param statuslist
     * @param busiDaysBeforeTimeStr
     * @return
     */
    public List<TDfitTradeExchangeBean> getDfitTradeExchangeFxdsData(List<String> statusList, Date preBizDate){
        List<TDfitTradeExchangeBean> dfitTradeList = new ArrayList<>();
        Timestamp busiDayBeforeTime = new Timestamp(preBizDate.getTime());
        TDfitTradeExchangeBean tDfitTradeExchangeBean = new TDfitTradeExchangeBean();
        tDfitTradeExchangeBean.setTradeDateTime(busiDayBeforeTime);
        dfitTradeList = tDfitTradeExchangeRepository.getFxdsDataByCond(FXDS, statusList, tDfitTradeExchangeBean);
        return dfitTradeList;
    }

    /**
     * 【DFIT】部課別顧客マスタデータ取得
     * @return
     */
    public List<TDfitCustomerMstBean> getDfitCustomerData() {
        List<TDfitCustomerMstBean> dfitcustList = new ArrayList<>();
        TDfitCustomerMstBean custBean = new TDfitCustomerMstBean();
        custBean.setReferAuthSection(FOREIGN_EXCHANGE_DEPARMENT);
        dfitcustList = tDfitCustomerMstRepository.getDfitCustomerMstData(custBean);
        return dfitcustList;
    }

    /**
     * 【DFIT】ポジション集計元フォーマットの為替トレードデータ取得
     *
     * @param preBizDate 前日営業日
     * @return
     */
    public List<PosSumSourceDto> getDfitTradeExchange(String preBizDate) {
        List<PosSumSourceDto> dfitList = new ArrayList<>();
        dfitList = tDfitTradeExchangeRepository.getTDfitTradeExchange(preBizDate);
        return dfitList;
    }

    /**
     * 【BID】ポジション集計元フォーマットの対顧客為替約定(リアル)
     *
     * @param targetDate 基準日
     * @param preBizDate 前日営業日
     * @return
     */
    public List<PosSumSourceDto> getBidTradeInfo(Date targetDate, Date preBizDate) {
        TB86BYG0Bean tB86BYG0Bean = new TB86BYG0Bean();
        tB86BYG0Bean.setSgymd1(DateUtil.convertDateToStrYmd(targetDate));
        tB86BYG0Bean.setYakymd1(DateUtil.convertDateToStrYmd(preBizDate));
        return jbpos1001Repository.getBidTrade(tB86BYG0Bean);
    }

    /**
     * 【BID】ポジション集計元フォーマットの外Mデータ仕分け
     *
     * @param targetDate 基準日
     * @param preBizDate 前日営業日
     * @return
     */
    public List<PosSumSourceDto> getBidOutsideMInfo(Date targetDate, Date preBizDate) {
        TB86BYS0Bean tB86BYS0Bean = new TB86BYS0Bean();
        tB86BYS0Bean.setYakymd1(DateUtil.convertDateToStrYmd(targetDate));
        tB86BYS0Bean.setChuymd(DateUtil.convertDateToStrYmd(preBizDate));
        return jbpos1001Repository.getBidOutsideM(tB86BYS0Bean);
    }
}
