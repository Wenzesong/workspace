# Enterprise AI Review Platform

本番障害を未然に防ぐための AI コードレビュー基盤。
単純なコードチェックではなく、**Runtime Failure Prediction** を目的とした Enterprise グレードのレビューシステム。

---

## コンセプト

### Risk-Based Dynamic Loading
コードの内容に応じて必要な Agent・Skill だけを動的にロードする。
Language-Based（言語ごとに固定ロード）ではなく、検出されたリスクパターンに基づく。

```
@Transactional 検出
  → transaction_agent + deadlock_skill + rollback_skill を自動ロード
```

### AIにゼロから考えさせない
毎回大きな Prompt を渡すのではなく、必要な知識だけを組み合わせて渡す。
Token 効率とレビュー品質の安定化を両立する。

---

## フォルダ構成

```
enterprise-ai-review-platform/
│
├── README.md
│
├── ai-review/
│   ├── platform/        # AI の思考基盤（全レビューで必ずロード）
│   ├── agents/          # 役割別 AI エージェント定義
│   │   ├── shared/      # 言語共通エージェント
│   │   ├── java/        # Java 専用エージェント
│   │   ├── csharp/      # C# 専用エージェント
│   │   ├── linux/       # Linux/Shell 専用エージェント
│   │   └── sql/         # SQL 専用エージェント
│   ├── skills/          # 専門知識ルール
│   │   ├── shared/      # 言語共通スキル（常時ロード）
│   │   ├── java/        # Java 専用スキル
│   │   ├── csharp/      # C# 専用スキル
│   │   ├── linux/       # Linux 専用スキル
│   │   └── sql/         # SQL 専用スキル（Tier1〜3）
│   ├── prompts/         # タスク定義
│   ├── templates/       # AI 出力フォーマット
│   └── routing/         # 動的ロードルール（YAML）
│
├── source-code/
│   ├── new/             # レビュー対象コード（必須）
│   └── old/             # 修正前コード（diff モード時）
│
├── output/              # 生成された Prompt・レポート
│   └── agent_outputs/   # Agent 別出力（デバッグ用）
│
├── scripts/             # 実行スクリプト
│   ├── review.ps1       # エントリポイント（Windows）
│   ├── detect_context.ps1  # コンテキスト検出
│   ├── build_prompt.ps1    # Prompt 組み立て
│   └── review.sh        # エントリポイント（Linux/Mac）
│
└── config/
    └── platform.yaml    # プラットフォーム設定
```

---

## 使い方

### 1. コードを配置する

```
# 新規レビューの場合
source-code/new/ にファイルを配置

# 差分レビューの場合
source-code/old/ に修正前、source-code/new/ に修正後を配置
```

### 2. スクリプトを実行する

```powershell
# Windows
.\scripts\review.ps1 -Language java -Mode new-review
.\scripts\review.ps1 -Language java -Mode diff-review
.\scripts\review.ps1 -Language sql  -Mode new-review
.\scripts\review.ps1 -Language csharp -Mode diff-review

# Linux / Mac
bash scripts/review.sh -l java -m diff-review
```

### 3. 生成された Prompt を Claude に貼り付ける

```
output/final_review_prompt.txt を Claude に貼り付けてレビューを開始する
```

---

## 対応言語・モード

| 言語 | -Language |
|---|---|
| Java / Spring Boot | `java` |
| C# / ASP.NET Core | `csharp` |
| Linux / Shell / Docker / K8s | `linux` |
| SQL | `sql` |

| モード | -Mode | 説明 |
|---|---|---|
| 新規レビュー | `new-review` | 新規コードのレビュー |
| 差分レビュー | `diff-review` | 修正前後の差分レビュー |
| 新規テスト | `new-test` | テストケース生成 |
| 差分テスト | `diff-test` | 回帰テストケース生成 |

---

## Skill Tier について

SQL Skill は検出されたリスクの複雑度に応じて Tier を自動選択する。

| Tier | ロード条件 | 例 |
|---|---|---|
| Tier1 | 必須（常時） | transaction_skill, deadlock_skill, sql_injection_skill |
| Tier2 | コードで検出されたリスクに応じて | index_skill, slow_query_skill, migration_skill |
| Tier3 | 高度な分析が必要な場合 | join_optimization_skill, subquery_skill |

---

## リスクレベル

| Level | 意味 | 対応 |
|---|---|---|
| P0 | Critical: 本番障害・データ破壊 | 即時対応必須 |
| P1 | High: 高負荷時・特定条件で障害 | リリース前に対応 |
| P2 | Medium: 将来の保守・性能に影響 | 次スプリントで対応 |
| P3 | Suggestion: 改善推奨 | 任意対応 |
