param(
    [Parameter(Mandatory = $true)][string]$Language,
    [Parameter(Mandatory = $true)][string]$Mode,
    [Parameter(Mandatory = $true)][string]$RootDir,
    [Parameter(Mandatory = $false)][string]$ConfigPath = "$RootDir\config\platform.yaml",
    [Parameter(Mandatory = $false)][string]$OutputJson = "$RootDir\output\_context.json"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ROUTING_DIR       = Join-Path $RootDir "ai-review\routing"
$RISK_PATTERN_FILE = Join-Path $ROUTING_DIR "risk_patterns.yaml"
$SOURCE_NEW        = Join-Path $RootDir "source-code\new"
$SOURCE_OLD        = Join-Path $RootDir "source-code\old"

function Write-Log {
    param([string]$Level, [string]$Message)
    $ts = Get-Date -Format "HH:mm:ss"
    $color = switch ($Level) {
        "INFO"  { "Cyan" }
        "OK"    { "Green" }
        "WARN"  { "Yellow" }
        "ERROR" { "Red" }
        default { "White" }
    }
    Write-Host "[$ts][$Level] $Message" -ForegroundColor $color
}

function Get-SourceContent {
    $extensions = @("*.java","*.cs","*.sql","*.sh","*.bash","*.xml","*.yaml","*.yml","*.properties","*.json")
    $sb = [System.Text.StringBuilder]::new()

    function Collect-Dir {
        param([string]$Dir, [string]$Label)
        if (-not (Test-Path $Dir)) { return }
        foreach ($ext in $extensions) {
            Get-ChildItem -Path $Dir -Filter $ext -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                $rel = $_.FullName.Replace($Dir, $Label)
                $null = $sb.AppendLine("### [$rel]")
                $null = $sb.AppendLine((Get-Content $_.FullName -Raw -Encoding UTF8))
                $null = $sb.AppendLine()
            }
        }
    }

    Collect-Dir $SOURCE_NEW "[NEW]"
    if ($Mode -in @("diff-review","diff-test")) { Collect-Dir $SOURCE_OLD "[OLD]" }
    return $sb.ToString()
}

function Get-BaseContext {
    $java   = @{ Agents = @("java_architect_agent","review_orchestrator_agent","security_architect_agent","performance_architect_agent"); Skills = @("java_skill","spring_boot_skill","security_skill","performance_skill") }
    $csharp = @{ Agents = @("csharp_architect_agent","review_orchestrator_agent","security_architect_agent","performance_architect_agent"); Skills = @("csharp_skill","aspnet_skill","security_skill","performance_skill") }
    $sql    = @{ Agents = @("sql_runtime_agent","review_orchestrator_agent","query_analysis_agent","security_architect_agent"); Skills = @("sql_skill","transaction_skill","sql_injection_skill","performance_skill") }
    $linux  = @{ Agents = @("bash_agent","review_orchestrator_agent","shell_security_agent","docker_agent"); Skills = @("bash_skill","shell_security_skill","security_skill","docker_skill") }
    $map    = @{ java=$java; csharp=$csharp; sql=$sql; linux=$linux }
    if ($map.ContainsKey($Language)) { return $map[$Language] }
    return @{ Agents = @(); Skills = @() }
}

function Invoke-RiskPatternDetect {
    param([string]$SourceContent)
    Write-Log "INFO" "Loading risk_patterns.yaml ..."

    $detectedAgents = [System.Collections.Generic.List[string]]::new()
    $detectedSkills = [System.Collections.Generic.List[string]]::new()
    $maxTier        = 1
    $matchedRules   = [System.Collections.Generic.List[string]]::new()

    if (Test-Path $RISK_PATTERN_FILE) {
        $yamlText = Get-Content $RISK_PATTERN_FILE -Raw -Encoding UTF8
        $blocks   = $yamlText -split '(?m)^- id:' | Where-Object { $_.Trim() -ne '' }

        foreach ($block in $blocks) {
            $lines      = $block -split "`n"
            $ruleId     = $lines[0].Trim()
            $inP=$false; $inA=$false; $inS=$false
            $patterns   = [System.Collections.Generic.List[string]]::new()
            $agents     = [System.Collections.Generic.List[string]]::new()
            $skills     = [System.Collections.Generic.List[string]]::new()
            $tier       = 1

            foreach ($line in $lines) {
                if ($line -match '^\s+patterns:')     { $inP=$true;  $inA=$false; $inS=$false; continue }
                if ($line -match '^\s+agents:')       { $inA=$true;  $inP=$false; $inS=$false; continue }
                if ($line -match '^\s+skills:')       { $inS=$true;  $inP=$false; $inA=$false; continue }
                if ($line -match '^\s+tier:\s*(\d+)') { $tier=[int]$Matches[1]; $inP=$false; $inA=$false; $inS=$false; continue }
                if ($line -match '^\s+-\s+(.+)$') {
                    $val = $Matches[1].Trim()
                    if ($inP) { $patterns.Add($val) }
                    if ($inA) { $agents.Add($val) }
                    if ($inS) { $skills.Add($val) }
                }
            }

            $matched = $false
            foreach ($p in $patterns) {
                if ($SourceContent -match [regex]::Escape($p)) { $matched = $true; break }
            }

            if ($matched) {
                Write-Log "INFO" "  Matched: [$ruleId] (Tier $tier)"
                $matchedRules.Add($ruleId)
                foreach ($a in $agents) { if (-not $detectedAgents.Contains($a)) { $detectedAgents.Add($a) } }
                foreach ($s in $skills) { if (-not $detectedSkills.Contains($s)) { $detectedSkills.Add($s) } }
                if ($tier -gt $maxTier) { $maxTier = $tier }
            }
        }
    } else {
        Write-Log "WARN" "risk_patterns.yaml not found. Using base context only."
    }

    $base = Get-BaseContext
    foreach ($a in $base.Agents) { if (-not $detectedAgents.Contains($a)) { $detectedAgents.Insert(0, $a) } }
    foreach ($s in $base.Skills) { if (-not $detectedSkills.Contains($s)) { $detectedSkills.Insert(0, $s) } }

    Write-Log "OK" "Detection done: $($matchedRules.Count) rules matched, Tier=$maxTier"

    return @{
        Language     = $Language
        Mode         = $Mode
        Tier         = $maxTier
        MatchedRules = $matchedRules.ToArray()
        Agents       = $detectedAgents.ToArray()
        Skills       = $detectedSkills.ToArray()
    }
}

Write-Log "INFO" "detect_context.ps1 started"

$source = Get-SourceContent
$srcLen = $source.Length
Write-Log "INFO" "Source collected: $([math]::Round($srcLen/1KB,1)) KB"

if ($srcLen -eq 0) {
    Write-Log "ERROR" "No source files found in source-code/new"
    exit 1
}

$context = Invoke-RiskPatternDetect -SourceContent $source

$jsonObj = [ordered]@{
    Language      = $context.Language
    Mode          = $context.Mode
    Tier          = $context.Tier
    MatchedRules  = $context.MatchedRules
    Agents        = $context.Agents
    Skills        = $context.Skills
    SourceContent = $source
}

$jsonObj | ConvertTo-Json -Depth 10 -Compress | Out-File -FilePath $OutputJson -Encoding UTF8
Write-Log "OK" "Context saved: $OutputJson"
exit 0