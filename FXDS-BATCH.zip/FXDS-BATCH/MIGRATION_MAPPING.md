# jbpos1000 → jbpos1100 移行対応表

旧パッケージ `jp.co.daiwa.jbpos1000`（変更禁止・参照のみ）から、新パッケージ
`jp.co.daiwa.jbpos1100` への対応関係を示す。既存コードは一切変更していない。

> **ステータス（2026-06-30）**: 修復済み jbpos1000 を権威リファレンスとして再検証・修正済み。
> jbpos1100 は**コンパイル可・全 58 テストパス**。`runOnce` は権威 `posSumTask` と 1 対 1 で**全結線完了**
> （T-1〜T-4、G-A〜G-I 解消）。詳細は REFACTORING_SUMMARY.md「現在のステータス」を参照。

---

## 1. クラス名の対応（④クラス名刷新）

| 旧クラス（jbpos1000） | 新クラス（jbpos1100） | 責務 |
|---|---|---|
| `Jbpos1000PosSumTasklet`（常駐ループ部） | `tasklet.PositionSummaryTasklet` | 常駐ループのオーケストレーションのみ |
| `Jbpos1000PosSumTasklet`（posSumTask 部） | `tasklet.PositionSummaryComposition#runOnce` | 1 サイクルのワークフロー定義（権威 posSumTask と 1 対 1） |
| `Jbpos1000JobListener` | `tasklet.PositionSummaryJobListener` | ジョブ終了ステータス判定 |
| `JbPositionDbOperation`（取得系） | `source.PositionSourceRepositoryGateway` | 集計元データの取得 |
| `JpPositionDataOperation` | `source.PositionSourceMatcher` | 集計元データの突合・ディーラブック設定 |
| `Jbpos1000PosSumTasklet`（集計元 delete/insert/update） | `source.PositionSourceStore` | 集計元の中間コミット永続化 |
| `Jbpos1000PosSumTasklet`（getBaseRateInfo） | `rate.BaseRateFileReader` | ベースレートファイル読込 |
| `Jbpos1000PosSumTasklet`（getCloseRateInfo） | `rate.CloseRateFileReader` | 当日引けレートファイル読込 |
| `Jbpos1000PosSumTasklet`（spot delete/insert） | `spot.SpotSumStore` | スポット集計結果の中間コミット永続化 |
| `Jbpos1000PosSumTasklet`（swap delete/insert） | `swap.SwapSumStore` | スワップ集計結果の中間コミット永続化 |
| `Jbpos1000PosSumTasklet`（plDelta delete/insert） | `delta.PlDeltaStore` | PL デルタの中間コミット永続化 |
| `Jbpos1000SwapSummary#mkByCcyDeltaCashBalance` | `delta.CurrencyDeltaCashCalculator` | 通貨別デルタ・キャッシュ残の集計（**P0 バグ修正**。NULL PV は `sumNullSafe` で安全集計し行は生成） |
| `Jbpos1000PosSumTasklet`（byCcyDeltaCash delete/insert） | `delta.CurrencyDeltaCashStore` | 通貨別デルタ・キャッシュ残の永続化 |
| `Jbpos1000PosSumTasklet#setPosPlDeltaValueData`（計算部） | `delta.PlDeltaCalculator` | 決済通貨外貨 PL デルタ生成（**T-2**。マニュアル優先・決済金額＝売買×取引レート） |
| `Jbpos1000PosSumTasklet#setClosingData` ほか日締め複製 4 種 | `common.EndOfDayClosingDuplicator` ＋ `tasklet.EndOfDayClosingService` | 引値結果の日締め（03）複製・登録（**T-4**。未登録時のみ INSERT、時刻ゲート） |
| `Jbpos1000PosSumTasklet#posSumTask`（合成ルート） | `tasklet.PositionSummaryComposition` | 1 サイクルの結線（権威 `posSumTask` と 1 対 1） |
| （新規・集計成果物ホルダ） | `tasklet.PositionEvaluationResult` | 1 区分の集計結果（スポット／スワップ各成果物）を日締め複製へ受け渡し |
| `Jbpos1000PosSumTasklet`（swapPlSumDate delete/insert） | `swap.SwapPlSumStore` | スワップ PL 合計の永続化 |
| `Jbpos1000PosSumTasklet#setSpotSumDate` | `spot.SpotPositionAggregator` | スポット集計本体（健全・逐次状態を保持しつつ段階分割。BigDecimal==/equals(null) バグ修正反映） |
| `Jbpos1000PosSumTasklet#setClosingRate` | `spot.SpotClosingRateResolver` | 引値/引値円転レート再設定（**P0破損を修正のうえ移植**） |
| `Jbpos1000PosSumTasklet#setSourceData` | `source.SourceDataMapper` | 集計元DTO→Bean変換＋検証（**P0破損を修正のうえ移植**） |
| `Jbpos1000SwapSummary#mkSwapPlSumDate` | `swap.SwapPlSumCalculator` | スワップPL合計集計（**型不整合を修正のうえ移植**） |
| `Jbpos1000SwapSummary#getTPosCashSumData` | `swap.SwapCashSumAssembler` | スワップCF単位のPV組立（破損なし・段階分割／ロジック不変） |
| `Jbpos1000SwapSummary#sumPositionSwapData` | `swap.SwapCurrencyAggregator` | スワップ通貨単位纏め（破損なし・冗長Map除去／挙動不変） |
| `Jbpos1000PosSumTasklet#sumBigDecimal` | `common.BigDecimalSummer` | BigDecimal 合計ユーティリティ |
| （新規・中間コミット共通化） | `common.TransactionalBatchExecutor` | 中間コミット＋1 件リトライのテンプレート |
| （新規・警告状態の共通化） | `common.JobWarningReporter` | ジョブ警告状態の設定＋警告ログ |
| （新規・DB 切断判定の共通化） | `common.DbConnectionFailures` | DB 切断由来例外の判定 |
| （旧 `DBUtil#divideList` 依存） | `common.ListPartitioner` | リスト分割（テスト容易化のため内製） |
| （定数の二重定義） | `common.BatchConstants` | 共有定数の集約 |

---

## 2. 変数・フィールド名の対応（③変数名適切化）

### 2.1 不適切な綴り・大文字小文字・"0"/"O" 混在

| 旧名 | 新名 | 種別・理由 |
|---|---|---|
| `tPosSoptSumDataDao` | `spot` 関連は `SpotSumStore` 経由（`spotSumRepository`） | `Sopt`→`Spot` の綴り誤り |
| `geTPositionSpotSumDataBeanAll`（呼出側） | （外部 Repository メソッドのため改名不可。呼出は維持） | `ge`→`get` の綴り崩れ。外部 IF のため対応表に明記のみ |
| `Tb86bet0` / `TB86BET0` / `Tb86betO` | `businessDayRepository` / `TB86BET0Bean`（型は外部のため維持） | "0"/"O" 混在・大文字小文字不統一を、用途名（営業日）で吸収 |
| `closingDataLsit` | `closingDataList` | `Lsit`→`List` の綴り誤り |
| `tPosSwapItDataLsit` | `swapItDataList` | 同上 |
| `JbPositionDbOperation` / `JpPositionDataOperation` | `PositionSourceRepositoryGateway` / `PositionSourceMatcher` | `Jb`/`Jp` の紛らわしい接頭辞を責務名へ |
| `posdata` | `swapPositionData` 等 | ローカル変数の大文字小文字・意味不明瞭を解消 |
| `SwapSumData`（ローカル変数） | `swapSumCondition` / `swapSumData` | 変数なのに型風 PascalCase だったものを camelCase へ |
| `Delta`（ローカル変数） | `delta` | 変数なのに PascalCase |
| `dfitCurrencyMstList` | `dfitCustomerMstList` | 実体は「顧客マスタ」であり "Currency" は誤り |
| `tPosSumSourceSumDataList`（参照崩れ） | `sourceBeans` 等、宣言名に統一 | 宣言名と参照名の不一致を解消 |

### 2.2 定数（`private static final` ＋ SCREAMING_SNAKE_CASE へ統一）

| 旧名 | 新名（`common.BatchConstants`） |
|---|---|
| `BUY = "1"` | `DEAL_DIVISION_BUY` |
| `SELL = "2"` | `DEAL_DIVISION_SELL` |
| `RATESOURCESMART = "1"` | `RATE_SOURCE_SMART` |
| `RATESOURCEBBG = "0"` | `RATE_SOURCE_BBG` |
| `JPY = "JPY"` | `CURRENCY_JPY` |
| `DATA_SOURCE_BIDR = "BID_R"` | `DATA_SOURCE_BID_REAL` |
| `NONAC = "0"` | `AC_FLAG_IN_TIME` |
| `AC = "1"` | `AC_FLAG_AFTER_CLOSE` |
| `TRADEDCF = "4"` | `EXCHANGE_DIVISION_TRADED_CF` |
| `public static SimpleDateFormat fmt`（共有可変・スレッド非安全） | 使用箇所でローカル `SimpleDateFormat` 生成、または定数パターン `DATE_PATTERN_*` |

> 注: 旧コードは `Jbpos1000PosSumTasklet` と `Jbpos1000SwapSummary` の双方で
> `JPY` / `RATESOURCESMART` / `fmt` などを**二重定義**（継承による隠蔽）していた。
> `BatchConstants` へ一本化し隠蔽を解消した。

---

## 3. メソッド単位の主な対応

| 旧メソッド | 新クラス.メソッド |
|---|---|
| `posSumSourceDataDelete` | `PositionSourceStore.delete` |
| `posSumSourceDataInsert`（一括＋1 件リトライ） | `PositionSourceStore.insert` → `TransactionalBatchExecutor.bulkInsertWithRetry` |
| `posSumSourceDataUpdate` | `PositionSourceStore.update` |
| `isBizDate` | `PositionSourceRepositoryGateway.resolveBusinessDate` |
| `getPrevBizDay` | `PositionSourceRepositoryGateway.getPreviousBusinessDay` |
| `getPosSumSourceData` | `PositionSourceRepositoryGateway.getTradeMngSourceData` |
| `matchTradeMngDataForDfit` 他 match 系 | `PositionSourceMatcher.*`（同名、ロジック整理） |
| `setDealerBook`（3 分岐の重複条件） | `PositionSourceMatcher.applyDealerBook` ＋ `isPositionCust` に共通化 |
| `getBaseRateInfo` | `BaseRateFileReader.read`（`PositionSummaryComposition.buildRateLookupContext` から呼出） |
| `getCloseRateInfo` | `CloseRateFileReader.read`（同上） |
| `getPosSumManualRate` / `getDfarmBbgRateBean` | `PositionSummaryComposition.buildRateLookupContext`（`RateLookupContext` に集約） |
| `posSumSourceDataMapping`（取得部） | `PositionSummaryComposition.buildRateLookupContext`（マッピング適用は `PositionSourceRateMapper.map`） |
| `setClosingRate` | `SpotClosingRateResolver.resolve`（引値レート＝`resolveClosingRate`、引値円転レート 3 分岐＝`resolveClosingYenRate`） |
| `setPosPlDeltaValueData`（計算部） | `PlDeltaCalculator.calculate`（結線・既存削除→登録は `PositionSummaryComposition.generatePlDelta`／`PlDeltaStore`） |
| `setClosingData` / `setSwapClosingData` / `setCcyDeltaCashClosingData` / `setSwapPlSumClosingData` | `EndOfDayClosingDuplicator.duplicateSpot` / `duplicateSwap` / `duplicateDeltaCash` / `duplicateSwapPlSum`（結線は `EndOfDayClosingService`） |
| `mkByCcyDeltaCashBalance` | `CurrencyDeltaCashCalculator.calculate` / `calculateForKey` / `resolveDelta` |
| `sumBigDecimal` | `BigDecimalSummer.sum` / `sumNullSafe` |
| `init`（取得→`JpPositionDataOperation` へセット） | `PositionSummaryComposition.collectSource` / `buildMatcher`（旧 init L3384–3404 を忠実移植） |
| `getDfitTradeExchange`（DTO 取得） | `PositionSourceRepositoryGateway.getDfitTradeExchange` |
| `getDfitCustomerData` | `PositionSourceRepositoryGateway.getDfitCustomerData` |
| `getBidTradeInfo` / `getBidOutsideMInfo` | `PositionSourceRepositoryGateway.getBidTradeInfo` / `getBidOutsideMInfo` |
| `tCurrencyMstRepository.getTCurrencyMstAll`（旧 init 直呼び） | `PositionSourceRepositoryGateway.getCurrencyMstData`（gateway へ集約） |
| `dbOperation.getDfitTradeExchangeFxdsData(STATUS_LIST, …)` | `PositionSourceRepositoryGateway.getDfitTradeExchangeRawData`（※実体は実 DAO 側。シグネチャ移植のみ） |
| `dayCloseTime`(@Value `${job.jbpos1000.time}`) / `STATUS_LIST=["2","3"]` | `PositionSummaryComposition` に同名・同値で移植 |

---

## 4. ビルド補足・スタブ（本リポジトリ単体コンパイル用）

> §0/REFACTORING_SUMMARY §6 のとおり、外部依存型が未配置のため**コンパイル補足用スタブ**と
> `pom.xml` を追加した。実プロジェクトへ戻す際はスタブを削除し本物の型でビルドすること。

| 追加物 | 内容 |
|---|---|
| `pom.xml` | Spring Batch 4.3 / Spring 5.3 / javax.inject / MyBatis / JUnit5・Mockito・AssertJ。旧 `jbpos1000` はコンパイル除外。 |
| 外部型スタブ（約45） | `jp.co.daiwa.{base,common,common.constant,dao,dao.bean,daobid,daodfit,dto}`。jbpos1100 が参照するメンバのみ。 |
| `dao.TCurrencyMstRepository`（新規スタブ） | `getTCurrencyMstAll()`（collectSource 解決で追加）。 |
| `daodfit.TDfitTradeExchangeRepository`（メソッド追加） | `getDfitTradeExchangeFxdsData(statusList, 前営業日)` を追加（生 Bean 取得）。 |

#### 再検証（T-2/T-4 結線）で追加したスタブ（REFACTORING_SUMMARY §6.6）

| 追加先 | 追加メンバ | 用途 |
|---|---|---|
| `dao.bean.TPositionPlDeltaDataBean` | `registerUser`/`registerDatetime`/`updateUser`/`updateDatetime` | PL デルタ生成（T-2） |
| `dao.TPositionSwapSumDataRepository` | `getPositionSwapSumDataList(condition)` | 日締め（03）既存有無の照会（T-4） |
| `dao.TByCcyDeltaCashBalanceRepository` | `getByCcyDeltaCashBalanceList(condition)` | 同上（T-4） |
| `dao.TSwapPlSumDateRepository` | `getSwapPlSumDateList(condition)` | 同上（T-4） |
| `common.BatchConstants`（スタブではなく jbpos1100 定数） | `EXCHANGE_DIVISION_SPOT = "0"` | PL デルタの為替区分（スポット）定数化 |

### 4.1 コンパイル補助で行った jbpos1100 既存不具合の最小修正

| 対象 | 修正 |
|---|---|
| `spot.SpotClosingRateResolver` | 約定日時を旧 `setClosingRate` L397 同様の**参照コピー**へ修正（H-1）。これに伴い `import java.sql.Timestamp;` は不要となり除去。 |
| `dto.PosSumSourceDto` | `getTradeDate`/`setTradeDate` を `tradeDatetime` と同一フィールドの別名として追加（本体は `getTradeDatetime`、テストは `setTradeDate` を使用する不一致への対応）。 |

> 再検証で判明した移植不忠実（H-1〜H-4）と修正の詳細は REFACTORING_SUMMARY「現在のステータス」／§6.4 を参照。

---

## 5. 結線状況（`runOnce` ＝ 権威 `posSumTask` と 1 対 1、**全結線完了**）

クラス対応（§1）に加え、`PositionSummaryComposition#runOnce` のオーケストレーションも完成した。
かつて未結線（孤立）だったクラスは**すべて結線済み**。

| 移植先クラス | 結線状況 | 対応 ID |
|---|---|---|
| `rate.BaseRateFileReader` / `rate.CloseRateFileReader` | ✅ `buildRateLookupContext` で実行 | G-F / T-1 |
| `spot.SpotClosingRateResolver`（旧 `setClosingRate`） | ✅ `closingResolved` を Pre/Closing/After へ供給 | G-D |
| `source.PositionSourceStore.delete` / `.update` | ✅ runOnce 冒頭で DELETE／スタートポジション UPDATE | G-A / G-B |
| `delta.PlDeltaCalculator` ＋ `delta.PlDeltaStore`（旧 `setPosPlDeltaValueData`） | ✅ `generatePlDelta()`（削除→生成→登録） | G-H / T-2 |
| `tasklet.EndOfDayClosingService` ＋ `common.EndOfDayClosingDuplicator`（旧 日締め複製） | ✅ `afterDayClose` 時刻ゲート下で 4 種を複製・登録 | G-I / T-4 |

> 差分の詳細（G-A〜G-I の最終結線）は REFACTORING_SUMMARY §6.5 を参照。jbpos1100 に未解決 TODO は無く、
> **コンパイル可・全 58 テストパス**。jbpos1000 は一切未変更。
