package jp.co.daiwa.jbpos1100.tasklet;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.batch.core.StepContribution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

import jp.co.daiwa.common.DateUtil;
import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.TPosSumManualRateRepository;
import jp.co.daiwa.dao.TPosSumSourceDataRepository;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.TPositionPlDeltaDataRepository;
import jp.co.daiwa.dao.TPositionSwapSumDataRepository;
import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.dao.TDfCalcResultRepository;
import jp.co.daiwa.dao.TDfHistoryDateRepository;
import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TDfarmBbgRateBean;
import jp.co.daiwa.dao.bean.TDfitCustomerMstBean;
import jp.co.daiwa.dao.bean.TDfitTradeExchangeBean;
import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionPlDeltaDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.daodfit.TDfarmBbgRateRepository;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.dto.PosBaseRateDto;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.jbpos1100.common.EndOfDayClosingDuplicator;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;
import jp.co.daiwa.jbpos1100.common.TransactionalBatchExecutor;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashCalculator;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashStore;
import jp.co.daiwa.jbpos1100.delta.PlDeltaCalculator;
import jp.co.daiwa.jbpos1100.delta.PlDeltaStore;
import jp.co.daiwa.jbpos1100.file.PositionSumFileWriter;
import jp.co.daiwa.jbpos1100.rate.BaseRateFileReader;
import jp.co.daiwa.jbpos1100.rate.CloseRateFileReader;
import jp.co.daiwa.jbpos1100.rate.RateLookupContext;
import jp.co.daiwa.jbpos1100.source.ClosingSpotSourceLoader;
import jp.co.daiwa.jbpos1100.source.PositionSourceMatcher;
import jp.co.daiwa.jbpos1100.source.PositionSourceRateMapper;
import jp.co.daiwa.jbpos1100.source.PositionSourceRepositoryGateway;
import jp.co.daiwa.jbpos1100.source.PositionSourceStore;
import jp.co.daiwa.jbpos1100.source.SourceDataMapper;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplitter;
import jp.co.daiwa.jbpos1100.spot.SpotCloseCostReplacer;
import jp.co.daiwa.jbpos1100.spot.SpotClosingRateResolver;
import jp.co.daiwa.jbpos1100.spot.SpotPositionAggregator;
import jp.co.daiwa.jbpos1100.spot.SpotSumStore;
import jp.co.daiwa.jbpos1100.spot.SpotSummaryService;
import jp.co.daiwa.jbpos1100.swap.SwapCashSumAssembler;
import jp.co.daiwa.jbpos1100.swap.SwapCurrencyAggregator;
import jp.co.daiwa.jbpos1100.swap.SwapItTradeUnitAggregator;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumCalculator;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSummaryService;
import jp.co.daiwa.jbpos1100.rate.YenRateResolver;

/**
 * ポジション集計 1 サイクルの合成ルート（旧 {@code posSumTask} に相当）。
 *
 * <p>{@link PositionSummaryCycle} を実装し、{@link PositionSummaryTasklet}（常駐ループ）から呼ばれる。
 * 1 サイクルで {@link StepContribution} に依存する協調オブジェクトを本クラスが構築し、集計元の収集・登録、
 * Real／プレ引値／引値／引値以降の各評価工程へ委譲する。</p>
 *
 * <p>配線層のため依存数が多く、ここではフィールドインジェクションを用いる（業務ロジック側は
 * すべてコンストラクタインジェクションでテスト容易にしてある）。{@code @Scope("step")} により
 * サイクルごとに新規生成され、可変 static を持たない。</p>
 *
 * <p>旧 {@code posSumTask} の各工程を本クラスの {@link #runOnce} に 1 対 1 で結線済み:
 * 集計元の事前削除（G-A）→ 日締めスタートポジション再マップ＋更新（G-B）→ 収集・検証・レート割当・登録
 * （G-C）→ Real 集計 → 引値レート取得有無ガード（G-E）配下で 引値レート再設定（G-D）・プレ引値集計・
 * 決済通貨外貨 PL デルタ生成（T-2）・引値集計・引値以降集計、引値後の日締めデータ複製（T-4）。</p>
 */
@Component
@Scope("step")
public class PositionSummaryComposition implements PositionSummaryCycle {

    @Inject
    @Named("jobTransactionManager")
    private PlatformTransactionManager transactionManager;

    @Inject
    private PositionSourceRepositoryGateway gateway;
    @Inject
    private TPosSumSourceDataRepository posSumSourceRepository;
    @Inject
    private TPositionSpotSumDataRepository spotSumRepository;
    @Inject
    private TPositionSwapSumDataRepository swapSumRepository;
    @Inject
    private TByCcyDeltaCashBalanceRepository deltaCashRepository;
    @Inject
    private TSwapPlSumDateRepository swapPlSumRepository;
    @Inject
    private TPositionPlDeltaDataRepository plDeltaRepository;
    @Inject
    private TDfCalcResultRepository dfCalcResultRepository;
    @Inject
    private TDfHistoryDateRepository dfHistoryRepository;

    @Inject
    private YenRateResolver yenRateResolver;
    @Inject
    private SourcePositionSplitter splitter;
    @Inject
    private ClosingSpotSourceLoader closingSpotSourceLoader;
    @Inject
    private SpotCloseCostReplacer spotCloseCostReplacer;
    @Inject
    private SpotClosingRateResolver spotClosingRateResolver;
    @Inject
    private PositionSumFileWriter fileWriter;
    @Inject
    private TPosSumManualRateRepository manualRateRepository;
    @Inject
    private TDfarmBbgRateRepository bbgRateRepository;

    @Value("${bulk.insert.unit}")
    private int bulkInsertUnit;
    @Value("${job.jbpos1000.path}")
    private String outputFilePath;
    @Value("${job.jbpos1000.time}")
    private String dayCloseTime;

    // 引値レートファイル（旧 inputFilePath / closeRateFileNamePrefix）
    @Value("${job.jbpos1000.input.path}")
    private String closeRateFilePath;
    @Value("${job.jbpos1000.input.filename.prefix}")
    private String closeRateFileNamePrefix;
    // ベースレートファイル（旧 baseRateFilePath / inputFileNamePrefix）
    @Value("${job.jbpos1000.output.path}")
    private String baseRateFilePath;
    @Value("${job.jbpos1000.output.filename.prefix}")
    private String baseRateFileNamePrefix;

    /** 為替トレードデータ.ステータス（旧 Jbpos1000PosSumTasklet#STATUS_LIST）。 */
    private static final List<String> STATUS_LIST = Arrays.asList("2", "3");

    @Override
    public Date resolveTargetDate() {
        return gateway.resolveBusinessDate();
    }

    @Override
    public void runOnce(StepContribution contribution, Date targetDate) throws Exception {
        // --- 1 サイクル分の協調オブジェクトを構築（状態リーク防止のため毎回新規） ---
        JobWarningReporter reporter = new JobWarningReporter(contribution);
        TransactionalBatchExecutor executor = new TransactionalBatchExecutor(transactionManager, reporter);

        PositionSourceStore sourceStore = new PositionSourceStore(posSumSourceRepository, executor, bulkInsertUnit);
        PositionSourceRateMapper rateMapper = new PositionSourceRateMapper(yenRateResolver, reporter);
        SourceDataMapper sourceDataMapper = new SourceDataMapper(reporter);

        PositionEvaluationService evaluationService = buildEvaluationService(reporter, executor);
        EndOfDayClosingService endOfDayClosingService = buildEndOfDayClosingService(executor);
        ClosingEvaluationService closingService =
                new ClosingEvaluationService(closingSpotSourceLoader, splitter, evaluationService,
                        endOfDayClosingService);
        AfterClosingEvaluationService afterService = new AfterClosingEvaluationService(
                splitter, new SwapItTradeUnitAggregator(reporter), spotCloseCostReplacer, rateMapper,
                evaluationService);

        Date previousBusinessDate = gateway.getPreviousBusinessDay(targetDate);

        // --- レート照会データ一式を構築（旧 posSumSourceDataMapping 内の取得 + getPosSumManualRate/getDfarmBbgRateBean） ---
        RateLookupContext rateContext = buildRateLookupContext(reporter, targetDate);

        // [G-A] 集計元の事前削除（旧 posSumSourceDataDelete）。
        //   削除対象（SQL 側ロジック）: ①処理基準日=当日かつ seq_no≠0（当日スタートポジションを除く）
        //   ②処理基準日<当日（前日取得分・前日スタートポジションを含む）。基準日のみをパラメータで渡す。
        TPosSumSourceDataBean deleteCondition = new TPosSumSourceDataBean();
        deleteCondition.setProcessBaseDate(targetDate);
        sourceStore.delete(deleteCondition);

        // [G-B] 削除後に残った日締めスタートポジション（seq_no=0）を再マップし更新（旧 posSumSourceDataUpdate）。
        TPosSumSourceDataBean startCondition = new TPosSumSourceDataBean();
        startCondition.setProcessBaseDate(targetDate);
        List<TPosSumSourceDataBean> startPositions = posSumSourceRepository.getPosSumSourceDataAll(startCondition);
        if (!startPositions.isEmpty()) {
            List<TPosSumSourceDataBean> mappedStart = rateMapper.map(targetDate, startPositions, rateContext);
            sourceStore.update(mappedStart);
        }

        // --- 集計元の収集 → 検証/変換 → レート割当 → 中間コミット登録 ---
        List<PosSumSourceDto> collected = collectSource(targetDate, previousBusinessDate);
        List<TPosSumSourceDataBean> sourceBeans = sourceDataMapper.map(targetDate, collected);
        // [G-C] レート割当（旧 posSumSourceDataMapping）を登録前に適用
        List<TPosSumSourceDataBean> mappedSource = rateMapper.map(targetDate, sourceBeans, rateContext);
        sourceStore.insert(mappedSource);

        // --- 当該基準日の全集計元を再取得 ---
        TPosSumSourceDataBean condition = new TPosSumSourceDataBean();
        condition.setProcessBaseDate(targetDate);
        List<TPosSumSourceDataBean> allSource = posSumSourceRepository.getPosSumSourceDataAll(condition);

        // --- DF 算出結果 / DF 履歴の取得（スワップ集計の入力） ---
        // 旧 Jbpos1000PosSumTasklet の取得処理を移植（取得元 DAO・引数は原本と同一）
        List<TDfCalcResultBean> dfCalcResult =
                dfCalcResultRepository.getTDfCalcResultBeanAll(previousBusinessDate, targetDate);
        TDfHistoryDateBean dfHistoryCondition = new TDfHistoryDateBean();
        dfHistoryCondition.setBaseDate(targetDate);
        List<TDfHistoryDateBean> dfHistory = dfHistoryRepository.getDfHistoryDateBeanAll(dfHistoryCondition);

        // --- スポット集計のプレ引値→引値の橋渡し用共有リスト ---
        List<TPositionSpotSumDataBean> preClosingPlList = new ArrayList<>();

        // 1. Real 集計（常時）
        SourcePositionSplit realSplit = splitter.splitForReal(allSource, targetDate, previousBusinessDate);
        evaluationService.evaluate(contribution, targetDate, realSplit, allSource, dfCalcResult, dfHistory,
                EvaluationRateKbn.REAL.getCode(), preClosingPlList);

        // [G-E] 引値レートファイルが取得できた場合のみ、プレ引値／引値／引値以降を実施
        //       （旧 posSumTask の closeRateList.size()>0 ガードを踏襲）
        if (!rateContext.getCloseRateList().isEmpty()) {
            // [G-D] 引値レート・引値円転レートを再設定（旧 setClosingRate）。Pre/Closing/After はこの結果を使用
            List<TPosSumSourceDataBean> closingResolved =
                    spotClosingRateResolver.resolve(targetDate, allSource, rateContext.getCloseRateList(),
                            rateContext.getManualRateList());

            // 2. プレ引値集計（スポットのみ）
            SourcePositionSplit preSplit =
                    splitter.splitForPreClosing(closingResolved, targetDate, previousBusinessDate);
            evaluationService.evaluate(contribution, targetDate, preSplit, closingResolved, dfCalcResult, dfHistory,
                    EvaluationRateKbn.PRE_CLOSING.getCode(), preClosingPlList);

            // 4. 決済通貨外貨 PL デルタ登録（旧 setPosPlDeltaValueData）。
            //    直前のプレ引値スポット集計結果（DB 永続化済み）から生成し、既存分は削除→登録する。
            generatePlDelta(executor, reporter, targetDate, rateContext);

            // 3. 引値集計（スポット＝プレ引値結果＋PLデルタ、スワップ＝引値ウィンドウ）。
            //    システム時刻が日締め時刻以降なら引値結果を日締め（03）として複製・登録する（旧 nowDateYmdhms >= dayCloseTime）。
            String nowHhmmss = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HHmmss"));
            boolean afterDayClose = nowHhmmss.compareTo(dayCloseTime) >= 0;
            closingService.evaluate(contribution, targetDate, previousBusinessDate, closingResolved, dfCalcResult,
                    dfHistory, preClosingPlList, afterDayClose);

            // 4. 引値以降集計（再マッピング用 RateLookupContext を供給＝T-3 解消）
            List<TPositionSpotSumDataBean> spotClosingFromDb =
                    closingSpotSourceLoader.loadClosingSpotResults(targetDate);
            afterService.evaluate(contribution, targetDate, previousBusinessDate, closingResolved, spotClosingFromDb,
                    rateContext, dfCalcResult, dfHistory, preClosingPlList);
        }

    }

    /**
     * 決済通貨外貨 PL デルタ生成情報を登録する（旧 {@code setPosPlDeltaValueData}）。
     *
     * <p>当該基準日の既存 PL デルタがあれば削除し、プレ引値スポット集計結果（DB から再取得）を基に
     * {@link PlDeltaCalculator} で生成して中間コミット登録する。生成結果が空の場合は登録しない。</p>
     */
    private void generatePlDelta(TransactionalBatchExecutor executor, JobWarningReporter reporter, Date targetDate,
            RateLookupContext rateContext) throws Exception {
        PlDeltaStore plDeltaStore = new PlDeltaStore(plDeltaRepository, executor, bulkInsertUnit);
        PlDeltaCalculator plDeltaCalculator = new PlDeltaCalculator(reporter);

        // 既存の当該基準日分があれば削除（旧 posPlDeltaDataDelete）
        TPositionPlDeltaDataBean plDeltaCondition = new TPositionPlDeltaDataBean();
        plDeltaCondition.setProcessBaseDate(targetDate);
        if (!plDeltaRepository.getTPositionPlDeltaDataBeanAll(plDeltaCondition).isEmpty()) {
            plDeltaStore.delete(plDeltaCondition);
        }

        // プレ引値スポット集計結果を取得（旧 geTPositionSpotSumDataBeanAll）し PL デルタを生成
        TPositionSpotSumDataBean spotCondition = new TPositionSpotSumDataBean();
        spotCondition.setProcessBaseDate(targetDate);
        List<TPositionSpotSumDataBean> spotSumResults =
                spotSumRepository.geTPositionSpotSumDataBeanAll(spotCondition);

        List<TPositionPlDeltaDataBean> plDeltas = plDeltaCalculator.calculate(targetDate, spotSumResults,
                rateContext.getCloseRateList(), rateContext.getManualRateList());
        if (!plDeltas.isEmpty()) {
            plDeltaStore.insert(plDeltas);
        }
    }

    /**
     * レート割当に必要な照会データ一式（{@link RateLookupContext}）を構築する。
     *
     * <p>旧 {@code posSumSourceDataMapping}（ベースレート／引値レート／通貨マスタ／外貨対円マスタの取得）と
     * 旧 {@code getPosSumManualRate} / {@code getDfarmBbgRateBean}（マニュアル／BBG レートの取得）を集約。
     * ファイルリーダは警告レポータに依存するためサイクル単位で生成する。</p>
     */
    private RateLookupContext buildRateLookupContext(JobWarningReporter reporter, Date targetDate) {
        String baseDate = new SimpleDateFormat(BatchConstants.DATE_PATTERN_SLASH).format(targetDate);

        // ベースレート（ST）／引値レートファイル
        List<PosBaseRateDto> baseRateList =
                new BaseRateFileReader(baseRateFilePath, baseRateFileNamePrefix, reporter).read();
        List<CloseRateDto> closeRateList =
                new CloseRateFileReader(closeRateFilePath, closeRateFileNamePrefix, reporter).read(targetDate);

        // 通貨マスタ／外貨対円（決済通貨=JPY）マスタ
        List<TCurrencyMstBean> currencyMstList = gateway.getCurrencyMstData();
        List<TCurrencyMstBean> jpySettleCurrencyMstList = currencyMstList.stream()
                .filter(c -> BatchConstants.CURRENCY_JPY.equals(c.getSettleCurrency()))
                .collect(Collectors.toList());

        // マニュアルレート（旧 getPosSumManualRate: 基準日で取得）
        TPosSumManualRateBean manualCondition = new TPosSumManualRateBean();
        manualCondition.setBaseDate(targetDate);
        List<TPosSumManualRateBean> manualRateList =
                manualRateRepository.getTPosSumManualRateBeanAll(manualCondition);

        // BBG レート（旧 getDfarmBbgRateBean: 全件取得）
        List<TDfarmBbgRateBean> bbgRateList = bbgRateRepository.getTDfarmBbgRateBeanAll(new TDfarmBbgRateBean());

        return new RateLookupContext(baseDate, baseRateList, closeRateList, currencyMstList,
                jpySettleCurrencyMstList, manualRateList, bbgRateList);
    }

    /**
     * 引値結果の日締め（03）複製・登録サービスをサイクル単位で構築する。
     *
     * <p>各 Store は中間コミット executor に依存するためサイクル単位で生成する。日締めデータの存在確認には
     * 各リポジトリの照会メソッドを用いる。</p>
     */
    private EndOfDayClosingService buildEndOfDayClosingService(TransactionalBatchExecutor executor) {
        SpotSumStore spotSumStore = new SpotSumStore(spotSumRepository, executor, bulkInsertUnit);
        SwapSumStore swapSumStore = new SwapSumStore(swapSumRepository, executor, bulkInsertUnit);
        CurrencyDeltaCashStore deltaCashStore = new CurrencyDeltaCashStore(deltaCashRepository, executor, bulkInsertUnit);
        SwapPlSumStore swapPlSumStore = new SwapPlSumStore(swapPlSumRepository, executor, bulkInsertUnit);
        return new EndOfDayClosingService(new EndOfDayClosingDuplicator(), spotSumStore, swapSumStore, deltaCashStore,
                swapPlSumStore, spotSumRepository, swapSumRepository, deltaCashRepository, swapPlSumRepository);
    }

    /** スワップ計算パイプライン＋永続化＋ファイル出力を束ねる評価サービスをサイクル単位で構築する。 */
    private PositionEvaluationService buildEvaluationService(JobWarningReporter reporter,
            TransactionalBatchExecutor executor) {
        SpotPositionAggregator spotAggregator = new SpotPositionAggregator(reporter);
        SpotSumStore spotSumStore = new SpotSumStore(spotSumRepository, executor, bulkInsertUnit);
        SpotSummaryService spotSummaryService = new SpotSummaryService(spotAggregator, spotSumStore);

        SwapSummaryService swapSummaryService = new SwapSummaryService(
                new SwapCashSumAssembler(reporter),
                new SwapCurrencyAggregator(reporter),
                new CurrencyDeltaCashCalculator(reporter),
                new SwapPlSumCalculator(reporter));

        SwapSumStore swapSumStore = new SwapSumStore(swapSumRepository, executor, bulkInsertUnit);
        CurrencyDeltaCashStore deltaCashStore = new CurrencyDeltaCashStore(deltaCashRepository, executor, bulkInsertUnit);
        SwapPlSumStore swapPlSumStore = new SwapPlSumStore(swapPlSumRepository, executor, bulkInsertUnit);

        return new PositionEvaluationService(spotSummaryService, swapSummaryService,
                swapSumStore, deltaCashStore, swapPlSumStore, fileWriter, outputFilePath);
    }

    /** 各データソース（FXDS/DFIT/BID）から集計元候補を突合・収集する。 */
    private List<PosSumSourceDto> collectSource(Date targetDate, Date previousBusinessDate) {
        PositionSourceMatcher matcher = buildMatcher(targetDate, previousBusinessDate);
        List<PosSumSourceDto> result = matcher.matchTradeMngDataForDfit(false);
        result.addAll(matcher.matchTradeMngDataForDfit(true));
        result.addAll(matcher.matchDfitTradeExchangeDataForFxds());
        result.addAll(matcher.matchBidTradeForFxds(true));
        result.addAll(matcher.matchBidTradeForFxds(false));
        result.addAll(matcher.matchBidOutsideMForFxds());
        return result;
    }

    /**
     * 当該サイクルの集計元マッチャを構築する。
     *
     * <p>旧 {@code Jbpos1000PosSumTasklet#init}（取得→{@code JpPositionDataOperation} へセット）を
     * gateway 経由で忠実移植したもの。マッチャへ供給する 7 入力（通貨マスタ／DFIT 顧客マスタ／
     * DFIT 為替トレード生 Bean／FXDS／DFIT／BID／BID 外 M）をすべて取得して注入する。</p>
     */
    private PositionSourceMatcher buildMatcher(Date targetDate, Date previousBusinessDate) {
        List<TCurrencyMstBean> currencyMstList = gateway.getCurrencyMstData();
        List<TDfitCustomerMstBean> dfitCustomerMstList = gateway.getDfitCustomerData();
        List<TDfitTradeExchangeBean> dfitTradeExchangeList =
                gateway.getDfitTradeExchangeRawData(STATUS_LIST, previousBusinessDate);
        List<PosSumSourceDto> fxdsInfoList = gateway.getTradeMngSourceData(previousBusinessDate, dayCloseTime);
        List<PosSumSourceDto> dfitInfoList =
                gateway.getDfitTradeExchange(DateUtil.convertDateToStrYmd(previousBusinessDate));
        List<PosSumSourceDto> bidInfoList = gateway.getBidTradeInfo(targetDate, previousBusinessDate);
        List<PosSumSourceDto> bidOutsideMInfoList = gateway.getBidOutsideMInfo(targetDate, previousBusinessDate);

        return new PositionSourceMatcher(currencyMstList, dfitCustomerMstList, dfitTradeExchangeList,
                fxdsInfoList, dfitInfoList, bidInfoList, bidOutsideMInfoList);
    }
}
