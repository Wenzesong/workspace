package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.FixLogonStatusInfoDto;
import jp.co.daiwa.enums.FixSessionEnum.FixSession;
import jp.co.daiwa.service.FixEngineService;

/**
 * ORDER セッションの接続／切断要求ファイルの処理。
 *
 * <p>リセット接続 → 接続 → 切断 の優先順に、1回の呼び出しで要求ファイルを1つだけ処理する。</p>
 * <ul>
 *   <li>接続要求は、ログオン完了を確認してから応答ファイルを作る（P-20）。</li>
 *   <li>要求ファイルを処理済みにできない場合は err_ へ退避し、それもできなければジョブを止める（P-10）。
 *       要求ファイルが残ると、毎ポーリングで再接続が繰り返されるため。</li>
 *   <li>再接続時に監視ディレクトリに残っている発注要求の件数を知らせ、設定により err_ へ移す（P-09）。</li>
 * </ul>
 */
class Jbord0001SessionController {

    private static final FixLogger logger = FixLogger.getLogger(Jbord0001SessionController.class);
    private static final long LOGON_POLL_MILLIS = 100L;

    private final Jbord0001Settings settings;
    private final FixEngineService fixEngineService;
    private final FixLogonStatusInfoDto orderLogonStatus;
    private final FixJobStatusInfoDto fixJobStatusInfo;
    private final Jbord0001OrderFiles orderFiles;
    /**
     * H-1 接続要求の直前のログオン状態の更新日時。新しいセッションのログオンイベントが届くまで（この値から変わるまで）
     * 古いセッションの「ログオン中」を信用しない。null は確認済み。
     */
    private Date staleLogonMarker;
    /** 接続要求を受けてから新しいセッションのログオンを確認できていない */
    private boolean awaitingLogon;

    Jbord0001SessionController(Jbord0001Settings settings, FixEngineService fixEngineService,
            FixLogonStatusInfoDto orderLogonStatus, FixJobStatusInfoDto fixJobStatusInfo, Jbord0001OrderFiles orderFiles) {
        this.settings = settings;
        this.fixEngineService = fixEngineService;
        this.orderLogonStatus = orderLogonStatus;
        this.fixJobStatusInfo = fixJobStatusInfo;
        this.orderFiles = orderFiles;
    }

    /** 接続／切断要求ファイルがあれば処理する */
    void handleRequests() throws Exception {
        Path resetConnect = Paths.get(settings.getResetConnectFile());
        Path connect = Paths.get(settings.getConnectFile());
        Path disconnect = Paths.get(settings.getDisconnectFile());
        if (Files.exists(resetConnect)) {
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I012", FixSession.ORDER.getName(), resetConnect);
            if (connect(resetConnect, true)) {
                finishTrigger(resetConnect, () -> Files.deleteIfExists(resetConnect));
            }
        } else if (Files.exists(connect)) {
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I012", FixSession.ORDER.getName(), connect);
            if (connect(connect, false)) {
                Path response = Paths.get(settings.getConnectResFile());
                finishTrigger(connect, () -> Files.move(connect, response, StandardCopyOption.REPLACE_EXISTING));
            }
        } else if (Files.exists(disconnect)) {
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I013", FixSession.ORDER.getName(), disconnect);
            fixEngineService.closeConnect(FixSession.ORDER);
            Path response = Paths.get(settings.getDisconnectResFile());
            finishTrigger(disconnect, () -> Files.move(disconnect, response, StandardCopyOption.REPLACE_EXISTING));
        }
    }

    /**
     * 発注を送ってよいか。ログオン中で、かつ接続要求後は新しいセッションのログオンイベントが届いていること（H-1）。
     */
    boolean isReadyToSend() {
        // 受信側（FixEventHandler）は「ログオン状態 → 更新日時」の順に書くため、こちらは逆順（更新日時 → ログオン状態）に読む。
        // 先にログオン状態を読むと、古いセッションの true を読んだ直後にログアウトで更新日時だけが変わり、
        // ログアウト済みのセッションを「新しいセッションでログオン済み」と誤判定する。
        Date lastLogonDate = orderLogonStatus.getLastLogonDate();
        if (!orderLogonStatus.isLogonStatus()) {
            return false;
        }
        if (awaitingLogon && lastLogonDate == staleLogonMarker) {
            return false;
        }
        awaitingLogon = false;
        staleLogonMarker = null;
        return true;
    }

    /** FIX切断（例外は警告のみ） */
    void closeQuietly() {
        try {
            fixEngineService.closeConnect(FixSession.ORDER);
        } catch (Exception e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "FIX切断", e);
        }
    }

    /**
     * @return ログオン完了まで確認できた場合 true（false の場合、要求ファイルは err_ へ退避済み）
     */
    private boolean connect(Path trigger, boolean resetSeq) throws Exception {
        deleteOldRequestFiles();
        handlePendingRequests();
        // H-1 再接続前の「ログオン中」が残っていても、新しいセッションのログオンイベントが届くまで送らない
        staleLogonMarker = orderLogonStatus.getLastLogonDate();
        awaitingLogon = true;
        initOrQuarantine(trigger, resetSeq);
        if (waitForLogon()) {
            return true;
        }
        fixJobStatusInfo.setWarn(true);
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                settings.getLogonWaitSeconds() + "秒以内にログオン完了を確認できませんでした（ログオン状態は引き続き監視し、"
                        + "完了すれば発注を開始します）：" + trigger);
        quarantine(trigger);
        return false;
    }

    /**
     * FIX接続を初期化する。失敗時（ログオン要求を送れなかった場合）は要求ファイルを err_ へ退避して例外とする。
     * 退避しないと、毎ポーリングで「古い電文削除＋再接続」が繰り返されて新着注文が消える。
     */
    private void initOrQuarantine(Path trigger, boolean resetSeq) throws Exception {
        boolean requested;
        try {
            requested = fixEngineService.init(FixSession.ORDER, settings.getReceiveMsgPoolSize(), resetSeq);
        } catch (Exception e) {
            try {
                quarantine(trigger);
            } catch (Jbord0001FatalException fatal) {
                fatal.addSuppressed(e);
                throw fatal;
            }
            throw e;
        }
        if (!requested) {
            quarantine(trigger);
            throw new IllegalStateException("FIXログオン要求に失敗しました: " + trigger);
        }
    }

    /** P-20 ログオン要求を送っただけで応答ファイルを作らないよう、新しいセッションのログオン完了を待つ */
    private boolean waitForLogon() throws InterruptedException {
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(settings.getLogonWaitSeconds());
        while (!isReadyToSend()) {
            if (System.nanoTime() - deadline >= 0) {
                return false;
            }
            TimeUnit.MILLISECONDS.sleep(LOGON_POLL_MILLIS);
        }
        return true;
    }

    /** P-10 要求ファイルを処理済みにできなければ err_ へ退避し、それもできなければジョブを止める */
    private void finishTrigger(Path trigger, IoAction action) {
        try {
            action.run();
        } catch (IOException e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "要求ファイルの後処理に失敗：" + trigger, e);
            quarantine(trigger);
        }
    }

    /**
     * 要求ファイルを err_ へ退避する。退避できないと毎ポーリングで同じ要求（再接続）が繰り返されるため、
     * 失敗したらジョブを止める（P-10・M-3）。
     */
    private void quarantine(Path trigger) {
        Path quarantined = trigger.resolveSibling(FixConstants.ERR_PREFIX + trigger.getFileName());
        try {
            Files.move(trigger, quarantined, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new Jbord0001FatalException("要求ファイルを退避できないため停止します（再接続の繰り返しを防ぐ）: " + trigger, e);
        }
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                "要求ファイルを退避しました（再実行は要求ファイルを再配置）：" + quarantined);
    }

    /** 送信電文ファイル（job.jbord0000.input.path の req_）の削除。jbord0000 と同じ動作 */
    private void deleteOldRequestFiles() throws IOException {
        int deleted = Jbord0001OrderFiles.deleteRequests(Paths.get(settings.getInputPath()));
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", "古い送信電文削除", deleted);
    }

    /** P-09 監視ディレクトリに残っている発注要求の扱い（既定：接続後に送信する。設定により err_ へ移す） */
    private void handlePendingRequests() throws IOException {
        if (settings.isReconnectDiscardPending()) {
            // M-7 移動できないファイルがあっても他は移し、失敗したものは警告する（接続は続ける）
            List<Path> moved = orderFiles.discardPendingRequests((path, e) -> {
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002",
                        "接続前の発注要求をエラーファイルへ移せませんでした（ログオン後に送信される可能性があります）：" + path, e);
            });
            if (!moved.isEmpty()) {
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                        "接続前の発注要求を送信せずエラーファイルへ移しました（" + moved.size() + "件）：" + moved);
            }
            return;
        }
        int pending = orderFiles.countPendingRequests();
        if (pending > 0) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                    "接続前から置かれている発注要求 " + pending + " 件を、ログオン後に送信します");
        }
    }

    /** 例外を投げるファイル操作 */
    private interface IoAction {
        void run() throws IOException;
    }
}
