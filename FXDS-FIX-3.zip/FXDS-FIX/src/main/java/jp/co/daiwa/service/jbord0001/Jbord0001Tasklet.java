package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Provider;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.config.FixTagConfig;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dao.BatchExecBaseDateRepository;
import jp.co.daiwa.dao.TradeOpeHistoryRepository;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.FixLogonStatusInfoDto;
import jp.co.daiwa.dto.OrdSendDto;
import jp.co.daiwa.enums.FixEnums;
import jp.co.daiwa.handler.FixEventHandler;
import jp.co.daiwa.service.FixEngineService;

/**
 * FIX接続通信（jbord0000 改善版）。
 *
 * <p>停止ファイルを検知するまで、一定間隔で「セッション接続/切断要求」と「発注要求ファイル」を監視する。</p>
 */
@Component
@Scope("step")
public class Jbord0001Tasklet implements Tasklet {

    private static final FixLogger logger = FixLogger.getLogger(Jbord0001Tasklet.class);
    /**
     * 起動時に無応答として登録する注文の送信日時。受信側で「無応答判定後の応答」と判定されるよう、
     * 経過時間が最大になる値にする（P-16）。
     */
    private static final long UNKNOWN_SENT_AT_MILLIS = 0L;

    /** 監視ループの終わり方 */
    private enum StopReason {
        STOP_FILE, INTERRUPTED
    }

    private final Jbord0001Settings settings;
    private final FixLogonStatusInfoDto orderLogonStatus;
    private final FixJobStatusInfoDto fixJobStatusInfo;
    private final Jbord0001OrderFileProcessor orderFileProcessor;
    private final Jbord0001NoreplyChecker noreplyChecker;
    private final TradeOpeHistoryRepository tradeOpeHistoryRepository;
    private final BatchExecBaseDateRepository batchExecBaseDateRepository;
    private final List<Path> orderDirectories;
    private final Jbord0001OrderFiles orderFiles;
    private final Jbord0001SentListIdRegistry sentListIds;
    private final boolean isOcoSendable;
    private final FixEventHandler orderEventHandler;
    private final Jbord0001SessionController session;
    private final Jbord0001ErrorBackoff errorBackoff;
    /** 読めない状態が続いている監視ディレクトリ・ファイル（ログの間引き用、P-21） */
    private final Jbord0001RepeatSuppressor<Path> directoryFailures;
    /** 書き込みが止まらない発注要求ファイル（ログの間引き用、H-2） */
    private final Jbord0001RepeatSuppressor<Path> stalledRequests;
    /** 前回のポーリングで読めなかったディレクトリ・ファイル（回復ログ用） */
    private Set<Path> lastFailedPaths = Collections.emptySet();
    /** 現在の送信済み組番号ファイル（基準日が変わったら切り替える） */
    private Path sentListIdFile;

    @Inject
    public Jbord0001Tasklet(Jbord0001Settings settings,
            @Named("logonstatus_order") FixLogonStatusInfoDto orderLogonStatus,
            @Named("fixjobstatus_order") FixJobStatusInfoDto fixJobStatusInfo,
            @Named("fixEngineService") FixEngineService fixEngineService,
            @Named("jbord0001Processor") Jbord0001Processor processor,
            @Named("jbord0001SuffixCreator") Jbord0001ResourceSuffixCreator suffixCreator,
            Jbord0001NoreplyChecker noreplyChecker,
            @Named("jbord0001OrdSendDto") Provider<OrdSendDto> ordSendDtoProvider,
            Jbord0001OrderSettings orderSettings,
            @Named("jbord0001SentListIdRegistry") Jbord0001SentListIdRegistry sentListIds,
            TradeOpeHistoryRepository tradeOpeHistoryRepository,
            BatchExecBaseDateRepository batchExecBaseDateRepository,
            @Named("fixEventHandler_order") FixEventHandler orderEventHandler) {
        this.settings = settings;
        this.orderLogonStatus = orderLogonStatus;
        this.fixJobStatusInfo = fixJobStatusInfo;
        this.noreplyChecker = noreplyChecker;
        this.tradeOpeHistoryRepository = tradeOpeHistoryRepository;
        this.batchExecBaseDateRepository = batchExecBaseDateRepository;
        this.sentListIds = sentListIds;
        this.orderEventHandler = orderEventHandler;
        this.isOcoSendable = orderSettings.getOcoFormat().isSendable();
        // 監視ディレクトリは優先順に並べる。送信順は「最初に見えたときの更新日時」→ ディレクトリ順
        // （同時刻ならディーラー注文が先。jbord0000 と同じ）→ ファイル名（P-12）
        // P-08 書き込み途中のファイルを処理しないよう、サイズ・更新日時が安定してから処理する
        this.orderDirectories = Collections.unmodifiableList(
                Arrays.asList(Paths.get(settings.getDealerOrderPath()), Paths.get(settings.getSalesOrderPath())));
        this.orderFiles = new Jbord0001OrderFiles(orderDirectories, FixConstants.ERR_PREFIX,
                settings.getRequestSettleMillis(), settings.getRequestHoldMaxMillis(), System::nanoTime);
        // P-19 逆指値価格の小数桁数は通貨ペア別の設定値（設定の無い通貨ペアは項目定義の上限 8 桁）
        Jbord0001ValidationRules rules = orderSettings.toValidationRules(orderSettings.getStopPxScales());
        Jbord0001OrderPlanner planner = new Jbord0001OrderPlanner(rules,
                new Jbord0001GroupValidator(rules, sentListIds::isSent, isOcoSendable), orderSettings.isAllow14Columns());
        Jbord0001FixMessageBuilder builder = new Jbord0001FixMessageBuilder(
                existingTagNumbers(settings.getFixTagMap()), FixFileUtils::convertCnyToCnh,
                String.valueOf(FixEnums.SettleType.SPOT));
        this.orderFileProcessor = new Jbord0001OrderFileProcessor(orderFiles, planner, builder,
                orderSettings.getOcoFormat(), processor, ordSendDtoProvider, noreplyChecker, suffixCreator,
                sentListIds, fixJobStatusInfo, orderSettings.getTsvCharset(), settings.getOutputPath(), settings.getOutputFileName());
        this.session = new Jbord0001SessionController(settings, fixEngineService, orderLogonStatus, fixJobStatusInfo, orderFiles);
        this.errorBackoff = new Jbord0001ErrorBackoff(settings.getPollIntervalMillis(), settings.getErrorBackoffMaxMillis(),
                settings.getErrorMaxConsecutive());
        int logInterval = (int) Math.min(Integer.MAX_VALUE,
                Math.max(1L, settings.getErrorBackoffMaxMillis() / settings.getPollIntervalMillis()));
        this.directoryFailures = new Jbord0001RepeatSuppressor<>(logInterval);
        this.stalledRequests = new Jbord0001RepeatSuppressor<>(logInterval);
    }

    /** 既存タグのタグ番号（OrdSendDto と同じ定義を使う）。追加タグ（99 等）は FIX 標準の番号 */
    private static Map<Jbord0001FixMessageBuilder.Tag, String> existingTagNumbers(Map<String, String> fixTagMap) {
        Map<Jbord0001FixMessageBuilder.Tag, String> m = new EnumMap<>(Jbord0001FixMessageBuilder.Tag.class);
        m.put(Jbord0001FixMessageBuilder.Tag.MSG_TYPE, fixTagMap.get(FixTagConfig.getMsgType()));
        m.put(Jbord0001FixMessageBuilder.Tag.CL_ORD_ID, fixTagMap.get(FixTagConfig.getClOrdId()));
        m.put(Jbord0001FixMessageBuilder.Tag.SYMBOL, fixTagMap.get(FixTagConfig.getSymbol()));
        m.put(Jbord0001FixMessageBuilder.Tag.SIDE, fixTagMap.get(FixTagConfig.getSide()));
        m.put(Jbord0001FixMessageBuilder.Tag.TRANSACT_TIME, fixTagMap.get(FixTagConfig.getTransactTime()));
        m.put(Jbord0001FixMessageBuilder.Tag.ORDER_QTY, fixTagMap.get(FixTagConfig.getOrderQty()));
        m.put(Jbord0001FixMessageBuilder.Tag.SETTL_TYPE, fixTagMap.get(FixTagConfig.getSettlType3()));
        m.put(Jbord0001FixMessageBuilder.Tag.ORD_TYPE, fixTagMap.get(FixTagConfig.getOrdType()));
        m.put(Jbord0001FixMessageBuilder.Tag.PRICE, fixTagMap.get(FixTagConfig.getPrice()));
        m.put(Jbord0001FixMessageBuilder.Tag.TIME_IN_FORCE, fixTagMap.get(FixTagConfig.getTimeInforce()));
        m.put(Jbord0001FixMessageBuilder.Tag.CURRENCY, fixTagMap.get(FixTagConfig.getCurrency()));
        m.put(Jbord0001FixMessageBuilder.Tag.EXPIRE_TIME, fixTagMap.get(FixTagConfig.getExpireTime()));
        return m;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        verifyOrderDirectories();
        verifyNoreplySecondsMatch();
        verifyTagDefinitions();
        warnLeftoverClaims();
        warnIfOcoNotSendable();
        Date baseDate = batchExecBaseDateRepository.getExecBaseDate();
        openSentListIds(baseDate);
        registerLeftoverNoreplyOrders(baseDate);
        // P-01 送信時刻から一定秒数後に判定する（待機中にスレッドを占有しない）
        ScheduledExecutorService noreplyPool = Executors.newScheduledThreadPool(settings.getNoreplyPoolSize());
        StopReason reason = null;
        try {
            reason = runMonitorLoop(noreplyPool);
        } finally {
            // P-14 判定待ちの注文の応答を受け取れるよう、判定を終えてから切断する
            try {
                shutdownNoreplyPool(noreplyPool);
            } finally {
                try {
                    session.closeQuietly();
                } finally {
                    if (reason == StopReason.STOP_FILE) {
                        finishStopRequest();
                    }
                }
            }
        }
        return RepeatStatus.FINISHED;
    }

    private StopReason runMonitorLoop(ScheduledExecutorService noreplyPool) {
        while (true) {
            try {
                if (isStopRequested()) {
                    return StopReason.STOP_FILE;
                }
                session.handleRequests();
                if (session.isReadyToSend()) {
                    processOrderFiles(noreplyPool);
                }
                errorBackoff.onSuccess();
                TimeUnit.MILLISECONDS.sleep(settings.getPollIntervalMillis());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", "監視処理が割り込みにより停止しました");
                return StopReason.INTERRUPTED;
            } catch (Jbord0001FatalException e) {
                throw e;
            } catch (Exception e) {
                if (!waitAfterError(e)) {
                    return StopReason.INTERRUPTED;
                }
            }
        }
    }

    /**
     * P-11 例外が続く場合は待ち時間を延ばし、連続回数の上限に達したら異常終了する。
     *
     * @return 待機を終えた場合 true（割り込まれた場合 false）
     */
    private boolean waitAfterError(Exception e) {
        fixJobStatusInfo.setWarn(true);
        long delay = errorBackoff.onFailure();
        int failures = errorBackoff.getConsecutiveFailures();
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002",
                "監視処理で例外（連続" + failures + "回目、" + delay + "ミリ秒後に再試行）", e);
        if (errorBackoff.isLimitReached()) {
            throw new Jbord0001FatalException("監視処理の例外が " + failures + " 回続いたため停止します", e);
        }
        return sleepUnlessStopRequested(delay);
    }

    /**
     * M-6 長い待機中も停止ファイルに気付けるよう、監視間隔ごとに停止ファイルを確認しながら待つ。
     *
     * @return 待ち終えた、または停止ファイルを検知した場合 true（割り込まれた場合 false）
     */
    private boolean sleepUnlessStopRequested(long millis) {
        long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(millis);
        Path stop = Paths.get(settings.getStopFile());
        try {
            while (System.nanoTime() - deadline < 0 && !Files.exists(stop)) {
                long remaining = TimeUnit.NANOSECONDS.toMillis(deadline - System.nanoTime());
                TimeUnit.MILLISECONDS.sleep(Math.max(1L, Math.min(settings.getPollIntervalMillis(), remaining)));
            }
            return true;
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    // ---------------------------------------------------------------- 起動時処理

    private void verifyOrderDirectories() {
        List<Path> missing = orderFiles.findMissingDirectories();
        if (!missing.isEmpty()) {
            throw new IllegalStateException("発注要求ディレクトリが存在しません: " + missing);
        }
    }

    /**
     * P-03 送信側（本ジョブ）と受信側（FixEventHandler_order）の無応答判定秒数が一致することを確認する。
     * 受信側はプロパティ未解決時に既定 5 秒になるため、食い違いを起動時に検知する。
     */
    private void verifyNoreplySecondsMatch() {
        long expected = TimeUnit.SECONDS.toMillis(settings.getNoreplySeconds());
        long actual = orderEventHandler.getNoreplyMillis();
        if (expected != actual) {
            throw new IllegalStateException("無応答判定秒数が送信側と受信側で異なります（order.noreply.seconds の設定を確認）: 送信側="
                    + expected + "ms 受信側=" + actual + "ms");
        }
    }

    /** P-04 逆指値・OCO のタグ（99・66・1385）の定義が無いと値が黙って落ちるため、起動時に確認する */
    private void verifyTagDefinitions() {
        List<String> problems = Jbord0001TagDefinitions.findProblems(settings.getFixTagMap(), isOcoSendable);
        if (!problems.isEmpty()) {
            throw new IllegalStateException("fix.tag（fix-tag.properties）の定義が不足しています: " + problems);
        }
    }

    /** P-07 前回の一部送信・送信状態不明のファイルは、メモの内容と合わせて知らせる */
    private void warnLeftoverClaims() throws IOException {
        for (Path leftover : orderFiles.findLeftoverClaims()) {
            fixJobStatusInfo.setWarn(true);
            Optional<List<String>> note = orderFiles.readNote(leftover);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                    "前回処理中のまま残った発注要求（再送しません。要確認）：" + leftover
                            + (note.isPresent() ? " メモ=" + note.get() : " メモなし（送信有無不明）"));
        }
    }

    /** P-05 OCO を送れない設定のまま運用されていることに気付けるようにする */
    private void warnIfOcoNotSendable() {
        if (isOcoSendable) {
            return;
        }
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                "OCOの電文形式が送信できない設定のため、OCOを含む発注要求ファイルは全体をエラー（E305）にします。"
                        + "oco.message_format を確認してください");
    }

    /** P-06 送信済み組番号を基準日のファイルから読み込む（再起動後も E304 で二重発注を防ぐ） */
    private void openSentListIds(Date baseDate) throws IOException {
        Path file = Jbord0001SentListIdRegistry.fileFor(Paths.get(settings.getSentListIdDir()), baseDate);
        sentListIds.open(file);
        sentListIdFile = file;
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028",
                "送信済み組番号読込", file + " 件数=" + sentListIds.size());
    }

    /** 稼働中に基準日が変わった場合、送信済み組番号ファイルを新しい基準日のものに切り替える */
    private void switchSentListIdsIfBaseDateChanged() throws IOException {
        Date baseDate = batchExecBaseDateRepository.getExecBaseDate();
        Path file = Jbord0001SentListIdRegistry.fileFor(Paths.get(settings.getSentListIdDir()), baseDate);
        if (!file.equals(sentListIdFile)) {
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028",
                    "基準日変更により送信済み組番号ファイルを切替", sentListIdFile + " → " + file);
            openSentListIds(baseDate);
        }
    }

    /**
     * 起動時に無応答リーブオーダーを応答待ちとして登録する。
     *
     * <p>送信日時は不明なため、経過時間が最大になる値で登録する（P-16）。応答が来れば受信側で
     * 「無応答判定後の応答」として扱われる（jbord0000 は null を登録して NPE になっていた）。</p>
     */
    private void registerLeftoverNoreplyOrders(Date baseDate) {
        List<String> ordList = tradeOpeHistoryRepository.findLvNoRplyOrdNum(baseDate);
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", "起動時無応答注文", ordList);
        if (ordList == null || ordList.isEmpty()) {
            return;
        }
        Map<String, Date> map = fixJobStatusInfo.getReqOrdMap();
        synchronized (map) {
            for (String clOrdId : ordList) {
                map.put(clOrdId, new Date(UNKNOWN_SENT_AT_MILLIS));
            }
        }
    }

    // ---------------------------------------------------------------- 停止

    private boolean isStopRequested() {
        Path stop = Paths.get(settings.getStopFile());
        if (!Files.exists(stop)) {
            return false;
        }
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I001", stop);
        return true;
    }

    /** 切断後、Logout 結果の受信を待ってから停止ファイルを削除する（削除しないと次回起動時に即停止する） */
    private void finishStopRequest() {
        try {
            TimeUnit.SECONDS.sleep(settings.getBeforeStopWaitSeconds());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            deleteQuietly(Paths.get(settings.getStopFile()));
        }
    }

    // ---------------------------------------------------------------- 発注処理

    private void processOrderFiles(ScheduledExecutorService noreplyPool) throws IOException {
        Set<Path> failed = new HashSet<>();
        List<Path> requests = orderFiles.collectRequests((path, e) -> {
            failed.add(path);
            warnDirectoryError(path, e);
        });
        logRecovered(failed);
        warnStalledRequests(orderFiles.getStalledRequests());
        if (requests.isEmpty()) {
            return;
        }
        // 基準日の確認は処理対象があるときだけ行う（毎ポーリングの DB 参照を避ける）
        switchSentListIdsIfBaseDateChanged();
        for (Path request : requests) {
            if (!orderFileProcessor.process(request, noreplyPool) && isStillHoldingFor(request)) {
                // M-1 取得できなかったファイルより後のファイルを先に送らない（次回、同じ順で処理する）
                return;
            }
        }
    }

    /** 取得失敗が保留上限を超えて続くファイルは、後続を止めない（H-2 と同じ考え方） */
    private boolean isStillHoldingFor(Path request) {
        long failedMillis = orderFileProcessor.claimFailureCount(request) * settings.getPollIntervalMillis();
        return failedMillis < settings.getRequestHoldMaxMillis();
    }

    /** H-2 書き込みが止まらないファイルは後続を保留しないため、気付けるよう警告する（間引き） */
    private void warnStalledRequests(List<Path> stalled) {
        for (Path p : stalled) {
            fixJobStatusInfo.setWarn(true);
            if (stalledRequests.shouldReport(p)) {
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                        "発注要求ファイルの書き込みが終わりません（後から置かれたファイルを先に処理します。作成元を確認）：" + p);
            }
        }
    }

    /** P-21 読めない監視ディレクトリ・ファイルがあっても他は処理する（ログは間引く） */
    private void warnDirectoryError(Path path, IOException e) {
        fixJobStatusInfo.setWarn(true);
        if (directoryFailures.shouldReport(path)) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002",
                    "発注要求ディレクトリ・ファイルを読めません（連続" + directoryFailures.countOf(path) + "回目。他は処理を続けます）：" + path, e);
        }
    }

    private void logRecovered(Set<Path> failed) {
        for (Path path : lastFailedPaths) {
            if (!failed.contains(path) && directoryFailures.clear(path)) {
                logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", "発注要求ディレクトリ・ファイル回復", path);
            }
        }
        lastFailedPaths = failed;
    }

    // ---------------------------------------------------------------- 終了処理・補助

    /**
     * 判定待ちの注文を判定し終えてから終了する。
     * ScheduledThreadPoolExecutor は既定で shutdown 後も登録済みの遅延タスクを実行するため、
     * 最後の送信から noreply 秒＋余裕秒で全て終わる。
     */
    private void shutdownNoreplyPool(ScheduledExecutorService pool) {
        pool.shutdown();
        long timeout = (long) settings.getNoreplySeconds() + settings.getShutdownMarginSeconds();
        // 割り込みで停止した場合も判定は行う（フラグが立ったままだと awaitTermination が即座に中断される）
        boolean wasInterrupted = Thread.interrupted();
        try {
            if (pool.awaitTermination(timeout, TimeUnit.SECONDS)) {
                return;
            }
        } catch (InterruptedException e) {
            wasInterrupted = true;
        } finally {
            if (wasInterrupted) {
                Thread.currentThread().interrupt();
            }
        }
        fixJobStatusInfo.setWarn(true);
        Set<String> dropped = noreplyChecker.pendingClOrdIds();
        pool.shutdownNow();
        // P-02 判定されなかった注文を特定できるようにする（無応答の通知・連携が行われていない）
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                "無応答判定を打ち切りました（タイムアウトまたは割り込み）。未判定の注文（要確認）=" + dropped);
    }

    private void deleteQuietly(Path path) {
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "ファイル削除：" + path, e);
        }
    }
}
