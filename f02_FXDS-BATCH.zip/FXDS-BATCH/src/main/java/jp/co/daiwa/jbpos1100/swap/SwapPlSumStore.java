package jp.co.daiwa.jbpos1100.swap;

import java.util.List;

import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.jbpos1100.common.TransactionalBatchExecutor;

/**
 * スワップ PL 合計値情報テーブルの永続化（中間コミット）クラス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#swapPlSumDateDelete} / swapPlSumDate insert を
 * {@link TransactionalBatchExecutor} へ委譲したもの。</p>
 */
public class SwapPlSumStore {

    private static final String LABEL_DELETE = "スワップPL合計値情報削除処理";
    private static final String LABEL_INSERT = "スワップPL合計値情報登録処理";

    private final TSwapPlSumDateRepository repository;
    private final TransactionalBatchExecutor executor;
    private final int bulkInsertUnit;

    public SwapPlSumStore(TSwapPlSumDateRepository repository, TransactionalBatchExecutor executor,
            int bulkInsertUnit) {
        this.repository = repository;
        this.executor = executor;
        this.bulkInsertUnit = bulkInsertUnit;
    }

    public void delete(TSwapPlSumDateBean condition) throws Exception {
        executor.runInNewTransaction(LABEL_DELETE, () -> repository.delete(condition));
    }

    /**
     * [I-9] 同条件の既存データが存在する場合のみ削除する（権威 {@code posSumTask} の
     * 「事前 SELECT → 件数 &gt; 0 のとき delete」を忠実再現。無駄な DELETE 発行を回避）。
     *
     * @param condition 照会・削除条件（基準日＋評価レート区分）
     * @throws Exception DB 切断由来の例外
     */
    public void deleteIfExists(TSwapPlSumDateBean condition) throws Exception {
        List<TSwapPlSumDateBean> existing = repository.getSwapPlSumDateList(condition);
        if (existing != null && !existing.isEmpty()) {
            delete(condition);
        }
    }

    public void insert(List<TSwapPlSumDateBean> items) throws Exception {
        executor.bulkInsertWithRetry(LABEL_INSERT, items, bulkInsertUnit, repository::insert);
    }
}
