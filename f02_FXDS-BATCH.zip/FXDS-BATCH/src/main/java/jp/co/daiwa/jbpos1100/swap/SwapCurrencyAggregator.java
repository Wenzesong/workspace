package jp.co.daiwa.jbpos1100.swap;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dto.TPositionSwapSumDataDto;
import jp.co.daiwa.jbpos1100.common.BigDecimalSummer;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;

/**
 * ポジションスワップ集計を「ディーラブック・受渡日・通貨」単位で纏めるアグリゲータ。
 *
 * <p>旧 {@code Jbpos1000SwapSummary#sumPositionSwapData}（破損なし）の移植版。
 * <b>集計式・NULL チェック時の既定値・符号は変更しない</b>。旧コードで
 * 「{@code map.put(k,v)} 直後に {@code map.get(k)}」と冗長だった一時 Map は、
 * 同値を返すため除去してローカル集計値を直接設定する（挙動不変）。</p>
 */
public class SwapCurrencyAggregator {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(SwapCurrencyAggregator.class);

    private final JobWarningReporter warningReporter;

    /**
     * @param warningReporter 警告レポータ
     */
    public SwapCurrencyAggregator(JobWarningReporter warningReporter) {
        this.warningReporter = warningReporter;
    }

    /**
     * スワップ集計 DTO を通貨単位に纏めた Bean リストへ変換する。
     *
     * @param swapSumDataList スワップ集計 DTO（CF 単位）
     * @return 通貨単位纏め済みスワップ集計 Bean
     */
    public List<TPositionSwapSumDataBean> aggregate(List<TPositionSwapSumDataDto> swapSumDataList) {
        List<TPositionSwapSumDataBean> result = new ArrayList<>();

        // 集計キー: ディーラブック → 受渡日
        Map<String, Map<Date, List<TPositionSwapSumDataDto>>> sumMap = swapSumDataList.stream()
                .collect(Collectors.groupingBy(TPositionSwapSumDataDto::getDealerBook,
                        Collectors.groupingBy(TPositionSwapSumDataDto::getDeliveryDate)));

        for (Map.Entry<String, Map<Date, List<TPositionSwapSumDataDto>>> bookEntry : sumMap.entrySet()) {
            String dealerBook = bookEntry.getKey();
            for (Map.Entry<Date, List<TPositionSwapSumDataDto>> dateEntry : bookEntry.getValue().entrySet()) {
                aggregateForDate(result, dealerBook, dateEntry.getKey(), dateEntry.getValue());
            }
        }
        return result;
    }

    /** 1（ディーラブック, 受渡日）グループを通貨ごとに集計する。 */
    private void aggregateForDate(List<TPositionSwapSumDataBean> result, String dealerBook, Date deliveryDate,
            List<TPositionSwapSumDataDto> group) {
        for (String currency : distinctCurrencies(group)) {
            try {
                result.add(aggregateCurrency(dealerBook, deliveryDate, currency, group));
            } catch (Exception e) {
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002",
                        dealerBook + "," + currency, e);
                warningReporter.markJobWarning();
            }
        }
    }

    /** グループに登場する売買側・決済側通貨の重複なしリストを返す。 */
    private List<String> distinctCurrencies(List<TPositionSwapSumDataDto> group) {
        List<String> currencies = new ArrayList<>();
        group.forEach(d -> {
            currencies.add(dealSide(d));
            currencies.add(settleSide(d));
        });
        return currencies.stream().distinct().collect(Collectors.toList());
    }

    /** 1 通貨分の集計 Bean を生成する。 */
    private TPositionSwapSumDataBean aggregateCurrency(String dealerBook, Date deliveryDate, String currency,
            List<TPositionSwapSumDataDto> group) {

        List<TPositionSwapSumDataDto> dealPosData = group.stream()
                .filter(d -> dealSide(d).equals(currency)).collect(Collectors.toList());
        List<TPositionSwapSumDataDto> settlePosData = group.stream()
                .filter(d -> settleSide(d).equals(currency)).collect(Collectors.toList());
        List<TPositionSwapSumDataDto> anySide = group.stream()
                .filter(d -> dealSide(d).equals(currency) || settleSide(d).equals(currency))
                .collect(Collectors.toList());

        TPositionSwapSumDataBean bean = new TPositionSwapSumDataBean();
        applyHeader(bean, dealerBook, deliveryDate, currency, anySide.get(0));
        applyAmounts(bean, currency, dealPosData, settlePosData);
        applyDealSidePvs(bean, dealPosData);
        applySettleSidePvs(bean, settlePosData);
        applyTotalsAndAudit(bean);
        return bean;
    }

    /** ヘッダ項目とレート群（先頭要素から引継ぎ）を設定する。 */
    private void applyHeader(TPositionSwapSumDataBean bean, String dealerBook, Date deliveryDate, String currency,
            TPositionSwapSumDataDto head) {
        bean.setProcessBaseDate(head.getProcessBaseDate());
        bean.setDealerBook(dealerBook);
        bean.setEvaluationRateDivision(head.getEvaluationRateDivision());
        bean.setCurrency(currency);
        bean.setExchangeDivision(head.getExchangeDivision().substring(0, 1));
        bean.setDeliveryDate(deliveryDate);
        bean.setRealRate(head.getRealRate());
        bean.setClosingRate(head.getClosingRate());
        bean.setRealYenRate(head.getRealYenRate());
        bean.setClosingYenRate(head.getClosingYenRate());
        bean.setDealYenRate(head.getRealYenRate());
        bean.setDealYenClosingRate(head.getClosingYenRate());
        bean.setSettleYenRate(head.getRealYenRate());
    }

    /** 売買金額・決済金額を設定する（決済金額は非 null のみ合計）。 */
    private void applyAmounts(TPositionSwapSumDataBean bean, String currency,
            List<TPositionSwapSumDataDto> dealPosData, List<TPositionSwapSumDataDto> settlePosData) {
        bean.setDealAmount(BigDecimalSummer.sumNonNull(dealPosData, TPositionSwapSumDataDto::getDealAmount));
        List<TPositionSwapSumDataDto> settleNonNull = settlePosData.stream()
                .filter(b -> b.getSettleAmount() != null).collect(Collectors.toList());
        bean.setSettleAmount(BigDecimalSummer.sumNonNull(settleNonNull, TPositionSwapSumDataDto::getSettleAmount));
    }

    /** 売買側 PV（取引金PV(引値)/同円転/取引金PV/同円転/評価換算/同円転）を設定する。 */
    private void applyDealSidePvs(TPositionSwapSumDataBean bean, List<TPositionSwapSumDataDto> dealPosData) {
        // 取引金PV(引値)
        if (!anyNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvCls)) {
            bean.setTradeAmountPvCls(BigDecimalSummer.sumNonNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvCls));
        } else {
            bean.setTradeAmountPvCls(BigDecimal.ZERO);
        }
        // 取引金PV(引値)円転（引値合計が 0 以外のときのみ集計）
        if (!anyNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvClsYen)
                && bean.getTradeAmountPvCls().compareTo(BigDecimal.ZERO) != 0) {
            bean.setTradeAmountPvClsYen(
                    BigDecimalSummer.sumNonNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvClsYen));
        } else {
            bean.setTradeAmountPvClsYen(BigDecimal.ZERO);
        }
        // 取引金PV（NULL 含むと null）
        if (!anyNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPv)) {
            bean.setTradeAmountPv(BigDecimalSummer.sumNonNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPv));
        } else {
            bean.setTradeAmountPv(null);
        }
        // 取引金PV円転（NULL 含むと null）
        if (anyNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvYen)) {
            bean.setTradeAmountPvYen(null);
        } else {
            bean.setTradeAmountPvYen(BigDecimalSummer.sumNonNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvYen));
        }
        // 取引金PV評価換算（NULL 含むと 0）
        if (anyNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvEva)) {
            bean.setTradeAmountPvEva(BigDecimal.ZERO);
        } else {
            bean.setTradeAmountPvEva(BigDecimalSummer.sumNonNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvEva));
        }
        // 取引金PV評価換算円転（NULL 含むと 0）
        if (anyNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvEvaYen)) {
            bean.setTradeAmountPvEvaYen(BigDecimal.ZERO);
        } else {
            bean.setTradeAmountPvEvaYen(
                    BigDecimalSummer.sumNonNull(dealPosData, TPositionSwapSumDataDto::getTradeAmountPvEvaYen));
        }
    }

    /** 決済側 PV（決済金PV/同円転）を設定する（NULL 含むと 0）。 */
    private void applySettleSidePvs(TPositionSwapSumDataBean bean, List<TPositionSwapSumDataDto> settlePosData) {
        if (anyNull(settlePosData, TPositionSwapSumDataDto::getSettleAmountPv)) {
            bean.setSettleAmountPv(BigDecimal.ZERO);
        } else {
            bean.setSettleAmountPv(BigDecimalSummer.sumNonNull(settlePosData, TPositionSwapSumDataDto::getSettleAmountPv));
        }
        if (anyNull(settlePosData, TPositionSwapSumDataDto::getSettleAmountPvYen)) {
            bean.setSettleAmountPvYen(BigDecimal.ZERO);
        } else {
            bean.setSettleAmountPvYen(
                    BigDecimalSummer.sumNonNull(settlePosData, TPositionSwapSumDataDto::getSettleAmountPvYen));
        }
    }

    /** CF 金額・PL(円)・登録更新者を設定する。 */
    private void applyTotalsAndAudit(TPositionSwapSumDataBean bean) {
        // CF金額（売買金額＋決済金額。旧コード同様スケール指定なし）
        bean.setCashAmount(bean.getDealAmount().add(bean.getSettleAmount()));
        // PL(円) はこの工程では未設定（後続の集計で算出）
        bean.setSumPlYen(null);
        bean.setRegisterUser(JobConstants.Jbpos1000);
        bean.setRegisterDatetime(null);
        bean.setUpdateUser(JobConstants.Jbpos1000);
        bean.setUpdateDatetime(null);
    }

    private String dealSide(TPositionSwapSumDataDto dto) {
        return dto.getCurrencyPair().substring(0, 3).trim();
    }

    private String settleSide(TPositionSwapSumDataDto dto) {
        return dto.getCurrencyPair().substring(3, 6).trim();
    }

    private boolean anyNull(List<TPositionSwapSumDataDto> data, Function<TPositionSwapSumDataDto, BigDecimal> getter) {
        return data.stream().anyMatch(d -> getter.apply(d) == null);
    }
}
