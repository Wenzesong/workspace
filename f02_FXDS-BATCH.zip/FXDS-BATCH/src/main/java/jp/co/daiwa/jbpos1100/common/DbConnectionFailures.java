package jp.co.daiwa.jbpos1100.common;

import java.sql.SQLNonTransientConnectionException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTransientConnectionException;

import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.transaction.CannotCreateTransactionException;

import jp.co.daiwa.common.constant.FxdConstants;

/**
 * DB 切断（接続断）の判定ヘルパ。
 *
 * <p>旧コードでは各メソッドが
 * {@code e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)}
 * を直接書き、DB 切断時は処理終了・それ以外は警告継続、という分岐を重複させていた。
 * 判定ロジックを 1 箇所に集約する。</p>
 *
 * <h2>[I-7] 型ベース判定への強化（2026-07-02）</h2>
 * <p>従来はトップレベル例外のメッセージ文字列照合のみで、①メッセージ文言の変更に脆い、
 * ②ラップされた例外（cause 側に切断例外）を見逃す、という弱点があった。以下のとおり強化した:</p>
 * <ul>
 *   <li><b>原因チェーン走査</b>: {@code getCause()} を辿り、チェーン内のいずれかで判定
 *       （自己参照・循環チェーンは深さ上限で打ち切り）。</li>
 *   <li><b>例外型による判定</b>: 接続断を表す標準型
 *       （JDBC: {@link SQLRecoverableException} / {@link SQLTransientConnectionException} /
 *       {@link SQLNonTransientConnectionException}、
 *       Spring: {@link DataAccessResourceFailureException} /
 *       {@link CannotCreateTransactionException}）を優先して判定。</li>
 *   <li><b>メッセージ照合はフォールバックとして維持</b>（旧挙動の上位互換。従来 true だったものは
 *       引き続き true。型判定の追加で検知漏れのみが減る方向の変更）。</li>
 * </ul>
 */
public final class DbConnectionFailures {

    /** 原因チェーン走査の深さ上限（循環チェーン対策）。 */
    private static final int MAX_CAUSE_DEPTH = 20;

    private DbConnectionFailures() {
    }

    /**
     * 例外が DB 切断（I/O 断）由来かどうかを判定する。
     *
     * @param t 判定対象の例外（null 可）
     * @return DB 切断由来なら true
     */
    public static boolean isDisconnect(Throwable t) {
        Throwable current = t;
        for (int depth = 0; current != null && depth < MAX_CAUSE_DEPTH; depth++) {
            if (isConnectionFailureType(current) || hasDbIoMessage(current)) {
                return true;
            }
            Throwable cause = current.getCause();
            current = (cause == current) ? null : cause;
        }
        return false;
    }

    /** 接続断を表す標準例外型かどうか。 */
    private static boolean isConnectionFailureType(Throwable t) {
        return t instanceof SQLRecoverableException
                || t instanceof SQLTransientConnectionException
                || t instanceof SQLNonTransientConnectionException
                || t instanceof DataAccessResourceFailureException
                || t instanceof CannotCreateTransactionException;
    }

    /** 旧来のメッセージ文字列照合（フォールバック）。 */
    private static boolean hasDbIoMessage(Throwable t) {
        return t.getMessage() != null && t.getMessage().contains(FxdConstants.DB_IO_EXCEPTION);
    }
}
