package jp.co.daiwa.jbpos1100.spot;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.common.TransactionalBatchExecutor;

/**
 * {@link SpotSumStore#deleteIfExists} の単体テスト（[I-9] 権威準拠の「事前 SELECT → 存在時のみ delete」）。
 */
class SpotSumStoreTest {

    private TPositionSpotSumDataRepository repository;
    private TransactionalBatchExecutor executor;
    private SpotSumStore store;
    private TPositionSpotSumDataBean condition;

    @BeforeEach
    void setUp() {
        repository = mock(TPositionSpotSumDataRepository.class);
        executor = mock(TransactionalBatchExecutor.class);
        store = new SpotSumStore(repository, executor, 100);
        condition = new TPositionSpotSumDataBean();
        condition.setProcessBaseDate(new Date());
        condition.setEvaluationRateDivision("00");
    }

    @Test
    @DisplayName("既存データが存在する場合のみ削除を実行する")
    void deleteIfExists_existingRows_deletes() throws Exception {
        when(repository.geTPositionSpotSumDataBeanAll(condition))
                .thenReturn(Collections.singletonList(new TPositionSpotSumDataBean()));

        store.deleteIfExists(condition);

        verify(executor).runInNewTransaction(anyString(), any());
    }

    @Test
    @DisplayName("既存データが無い場合は削除を発行しない")
    void deleteIfExists_noRows_skipsDelete() throws Exception {
        when(repository.geTPositionSpotSumDataBeanAll(condition))
                .thenReturn(Collections.<TPositionSpotSumDataBean>emptyList());

        store.deleteIfExists(condition);

        verify(executor, never()).runInNewTransaction(anyString(), any());
    }
}
