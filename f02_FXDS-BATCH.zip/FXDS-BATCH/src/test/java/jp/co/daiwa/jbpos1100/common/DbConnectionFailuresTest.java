package jp.co.daiwa.jbpos1100.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.SQLRecoverableException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.transaction.CannotCreateTransactionException;

/**
 * {@link DbConnectionFailures} の単体テスト（[I-7] 型判定＋原因チェーン走査＋メッセージ照合）。
 */
class DbConnectionFailuresTest {

    @Test
    @DisplayName("null は切断ではない")
    void isDisconnect_null_returnsFalse() {
        assertThat(DbConnectionFailures.isDisconnect(null)).isFalse();
    }

    @Test
    @DisplayName("DB I/O メッセージを含む例外は切断（旧挙動のフォールバック維持）")
    void isDisconnect_dbIoMessage_returnsTrue() {
        Exception e = new RuntimeException("... I/O error ...");

        assertThat(DbConnectionFailures.isDisconnect(e)).isTrue();
    }

    @Test
    @DisplayName("無関係のメッセージ・型は切断ではない")
    void isDisconnect_unrelatedException_returnsFalse() {
        Exception e = new IllegalStateException("計算エラー");

        assertThat(DbConnectionFailures.isDisconnect(e)).isFalse();
    }

    @Test
    @DisplayName("接続断を表す標準型はメッセージに依らず切断と判定する")
    void isDisconnect_connectionFailureTypes_returnTrue() {
        assertThat(DbConnectionFailures.isDisconnect(new SQLRecoverableException("closed"))).isTrue();
        assertThat(DbConnectionFailures.isDisconnect(
                new DataAccessResourceFailureException("pool exhausted"))).isTrue();
        assertThat(DbConnectionFailures.isDisconnect(
                new CannotCreateTransactionException("could not open connection"))).isTrue();
    }

    @Test
    @DisplayName("ラップされた切断例外（cause 側）も検知する")
    void isDisconnect_wrappedCause_returnsTrue() {
        Exception e = new RuntimeException("wrapper",
                new IllegalStateException("middle", new SQLRecoverableException("connection reset")));

        assertThat(DbConnectionFailures.isDisconnect(e)).isTrue();
    }

    @Test
    @DisplayName("自己参照する原因チェーンでも無限ループしない")
    void isDisconnect_selfReferencingCause_terminates() {
        Exception e = new Exception("plain error");
        e.initCause(new Exception("child") {
            @Override
            public synchronized Throwable getCause() {
                return this;
            }
        });

        assertThat(DbConnectionFailures.isDisconnect(e)).isFalse();
    }
}
