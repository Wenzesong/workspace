package jp.co.daiwa.service.jbord0001;

import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.EXPIRE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.line;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.row;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001GroupValidatorTest {

    private static final String STOP = line("DAIWA_D-1-106", "2", "3", "", "6", EXPIRE, "0", "154.50", "G0001");
    private static final String PROFIT = line("DAIWA_D-1-107", "2", "2", "156.00", "6", EXPIRE, "0", "", "G0001");

    private final Jbord0001GroupValidator validator =
            new Jbord0001GroupValidator(Jbord0001OrderFixtures.defaultRules(), "G9999"::equals, true);

    private List<Jbord0001ValidationError> validate(String... lines) {
        Jbord0001OrderRow[] rows = new Jbord0001OrderRow[lines.length];
        for (int i = 0; i < lines.length; i++) {
            rows[i] = row(i + 1, lines[i]);
        }
        return validator.validate(Arrays.asList(rows));
    }

    private static Jbord0001ValidationError err(int lineNo, Jbord0001ErrorCode code, int itemId) {
        return new Jbord0001ValidationError(lineNo, code, itemId);
    }

    @Test
    @DisplayName("T07 損切り＋利確の組は正常")
    void validPair() {
        assertThat(validate(STOP, PROFIT)).isEmpty();
    }

    @Test
    @DisplayName("組番号なしの行は組チェックの対象外")
    void singleRowsIgnored() {
        assertThat(validator.validate(Collections.singletonList(
                row(1, line("DAIWA_D-1-100", "2", "2", "156.00", "6", EXPIRE, "0", "", ""))))).isEmpty();
    }

    @Test
    @DisplayName("T13 OCOの片方のみ → E301")
    void missingPartner() {
        assertThat(validate(STOP)).containsExactly(err(1, Jbord0001ErrorCode.E301, Jbord0001OrderRow.LIST_ID));
    }

    @Test
    @DisplayName("T14 OCOの金額不一致 → E302（2行とも）")
    void mismatch() {
        String profitOtherQty = PROFIT.replace("1000000.00", "2000000.00");

        assertThat(validate(STOP, profitOtherQty)).containsExactly(
                err(1, Jbord0001ErrorCode.E302, Jbord0001OrderRow.ORDER_QTY),
                err(2, Jbord0001ErrorCode.E302, Jbord0001OrderRow.ORDER_QTY));
    }

    @Test
    @DisplayName("T15 OCOが損切り2行 → E303（2行とも）")
    void twoStops() {
        String stop2 = STOP.replace("DAIWA_D-1-106", "DAIWA_D-1-107");

        assertThat(validate(STOP, stop2)).containsExactly(
                err(1, Jbord0001ErrorCode.E303, Jbord0001OrderRow.ORD_TYPE),
                err(2, Jbord0001ErrorCode.E303, Jbord0001OrderRow.ORD_TYPE));
    }

    @Test
    @DisplayName("E304 送信済みの組番号")
    void alreadySent() {
        assertThat(validate(STOP.replace("G0001", "G9999"), PROFIT.replace("G0001", "G9999"))).containsExactly(
                err(1, Jbord0001ErrorCode.E304, Jbord0001OrderRow.LIST_ID),
                err(2, Jbord0001ErrorCode.E304, Jbord0001OrderRow.LIST_ID));
    }

    @Test
    @DisplayName("P-05 OCOの電文形式が送信できない設定（A）なら、組の全行を E305 にする")
    void ocoFormatNotSendable_rejected() {
        Jbord0001GroupValidator notSendable =
                new Jbord0001GroupValidator(Jbord0001OrderFixtures.defaultRules(), id -> false, false);

        assertThat(notSendable.validate(Arrays.asList(row(1, STOP), row(2, PROFIT)))).containsExactly(
                err(1, Jbord0001ErrorCode.E305, Jbord0001OrderRow.LIST_ID),
                err(2, Jbord0001ErrorCode.E305, Jbord0001OrderRow.LIST_ID));
    }

    @Test
    @DisplayName("P-05 OCOの電文形式が送信できない設定でも、組番号なしの行はエラーにしない")
    void ocoFormatNotSendable_singleRowsIgnored() {
        Jbord0001GroupValidator notSendable =
                new Jbord0001GroupValidator(Jbord0001OrderFixtures.defaultRules(), id -> false, false);

        assertThat(notSendable.validate(Collections.singletonList(
                row(1, line("DAIWA_D-1-100", "2", "2", "156.00", "6", EXPIRE, "0", "", ""))))).isEmpty();
    }

    @Test
    @DisplayName("OCOキャンセルは未確定（TBD-07）のため受け付けない")
    void ocoCancelRejected() {
        String cancel = line("DAIWA_D-C-106", "2", "3", "", "", "", "2", "", "G0001");

        assertThat(validate(cancel)).containsExactly(err(1, Jbord0001ErrorCode.E103, Jbord0001OrderRow.LIST_ID));
    }
}
