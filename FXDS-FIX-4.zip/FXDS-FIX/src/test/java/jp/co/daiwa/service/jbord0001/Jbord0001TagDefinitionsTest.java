package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001TagDefinitionsTest {

    private static Map<String, String> tags(String... nameIdPairs) {
        Map<String, String> m = new HashMap<>();
        m.put("msgType", "35");
        m.put("clOrdID", "11");
        for (int i = 0; i < nameIdPairs.length; i += 2) {
            m.put(nameIdPairs[i], nameIdPairs[i + 1]);
        }
        return m;
    }

    @Test
    @DisplayName("P-04 99・66・1385 が正しい名前で定義されていれば問題なし")
    void allDefined_noProblems() {
        Map<String, String> m = tags("stopPx", "99", "listID", "66", "contingencyType", "1385");

        assertThat(Jbord0001TagDefinitions.findProblems(m, true)).isEmpty();
    }

    @Test
    @DisplayName("P-04 名前の大文字小文字は区別しない（パーサーが大文字で扱うため）")
    void caseInsensitiveName() {
        Map<String, String> m = tags("STOPPX", "99", "ListId", "66", "CONTINGENCYTYPE", "1385");

        assertThat(Jbord0001TagDefinitions.findProblems(m, true)).isEmpty();
    }

    @Test
    @DisplayName("P-04 99 の定義が無ければ問題として返す")
    void stopPxMissing() {
        Map<String, String> m = tags("listID", "66", "contingencyType", "1385");

        assertThat(Jbord0001TagDefinitions.findProblems(m, true)).singleElement().asString().contains("99", "stopPx");
    }

    @Test
    @DisplayName("P-04 99 が別の名前で定義されている（電文の値が Bean に入らない）場合も問題として返す")
    void stopPxWrongName() {
        Map<String, String> m = tags("stopPrice", "99", "listID", "66", "contingencyType", "1385");

        assertThat(Jbord0001TagDefinitions.findProblems(m, true)).singleElement().asString().contains("99", "stopPrice");
    }

    @Test
    @DisplayName("P-04 OCO を送らない設定なら 66・1385 は必須にしない")
    void ocoTagsNotRequiredWhenOcoNotSent() {
        Map<String, String> m = tags("stopPx", "99");

        assertThat(Jbord0001TagDefinitions.findProblems(m, false)).isEmpty();
        assertThat(Jbord0001TagDefinitions.findProblems(m, true)).hasSize(2);
    }

    @Test
    @DisplayName("P-04 電文に 99 があるのに Bean の StopPx が空なら、送信前に検知する")
    void missingInBean_stopPxDropped() {
        Jbord0001FixMessages.NewOrderSingle bean = new Jbord0001FixMessages.NewOrderSingle();

        assertThat(Jbord0001TagDefinitions.missingInBean("35=D\t11=X\t40=3\t99=154.50", bean)).containsExactly("99");
    }

    @Test
    @DisplayName("P-04 電文の 66・1385 が Bean に入っていなければ検知する")
    void missingInBean_ocoTagsDropped() {
        Jbord0001FixMessages.NewOrderSingle bean = new Jbord0001FixMessages.NewOrderSingle();
        bean.setListID("G0001");

        assertThat(Jbord0001TagDefinitions.missingInBean("35=D\t66=G0001\t1385=1", bean)).containsExactly("1385");
    }

    @Test
    @DisplayName("P-04 Bean に値が入っていれば問題なし。電文に無いタグは見ない")
    void missingInBean_ok() {
        Jbord0001FixMessages.NewOrderSingle bean = new Jbord0001FixMessages.NewOrderSingle();
        bean.setStopPx("154.50");

        assertThat(Jbord0001TagDefinitions.missingInBean("35=D\t40=3\t99=154.50", bean)).isEmpty();
        assertThat(Jbord0001TagDefinitions.missingInBean("35=D\t40=2\t44=155.00",
                new Jbord0001FixMessages.NewOrderSingle())).isEmpty();
    }

    @Test
    @DisplayName("P-04 同じタグ番号が複数の名前で定義されていれば問題として返す（どちらが使われるか不定）")
    void duplicateDefinition() {
        Map<String, String> m = tags("stopPx", "99", "stopPrice", "99");

        assertThat(Jbord0001TagDefinitions.findProblems(m, false)).singleElement().asString().contains("99", "重複");
    }

    @Test
    @DisplayName("P-04 送信用に変換した後の値も確認できる（変換で失われたタグを返す）")
    void missingValues_afterConversion() {
        Map<String, String> converted = new HashMap<>();
        converted.put("66", "G0001");

        assertThat(Jbord0001TagDefinitions.missingValues("35=D\t99=154.50\t66=G0001\t1385=1", converted::get))
                .containsExactly("99", "1385");
    }
}
