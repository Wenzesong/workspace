package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001SendGateTest {

    @Test
    @DisplayName("ログオン中なら送れる／ログオンしていなければ送れない")
    void opensOnlyWhenLoggedOn() {
        Jbord0001SendGate gate = new Jbord0001SendGate();
        Date logonDate = new Date(1_000L);

        assertThat(gate.isOpen(false, logonDate)).isFalse();
        assertThat(gate.isOpen(true, logonDate)).isTrue();
    }

    @Test
    @DisplayName("P-26 切断要求後は、ログオン状態が true のままでも送らない")
    void closedAfterDisconnectEvenIfStillLoggedOn() {
        // Arrange
        Jbord0001SendGate gate = new Jbord0001SendGate();
        Date logonDate = new Date(1_000L);
        assertThat(gate.isOpen(true, logonDate)).isTrue();

        // Act
        gate.onDisconnectRequested();

        // Assert（ログアウトイベント未受信＝ログオン状態・更新日時とも変わらない）
        assertThat(gate.isOpen(true, logonDate)).isFalse();
    }

    @Test
    @DisplayName("P-26 切断要求後は、ログオンイベントが届いても次の接続要求まで送らない")
    void staysClosedUntilConnectRequested() {
        Jbord0001SendGate gate = new Jbord0001SendGate();
        gate.onDisconnectRequested();

        assertThat(gate.isOpen(true, new Date(2_000L))).isFalse();
    }

    @Test
    @DisplayName("P-26 接続要求で切断状態を解除し、新しいセッションのログオン後に送る")
    void connectRequestReopensAfterNewLogon() {
        // Arrange
        Jbord0001SendGate gate = new Jbord0001SendGate();
        Date oldLogon = new Date(1_000L);
        gate.onDisconnectRequested();

        // Act
        gate.onConnectRequested(oldLogon);

        // Assert
        assertThat(gate.isOpen(true, oldLogon)).as("古いセッションのログオン中は信用しない").isFalse();
        assertThat(gate.isOpen(true, new Date(3_000L))).isTrue();
    }

    @Test
    @DisplayName("H-1 接続要求後は、更新日時が同じ Date インスタンスの間は送らない")
    void awaitsNewLogonEventAfterConnect() {
        Jbord0001SendGate gate = new Jbord0001SendGate();
        Date oldLogon = new Date(1_000L);
        gate.onConnectRequested(oldLogon);

        assertThat(gate.isOpen(true, oldLogon)).isFalse();
        assertThat(gate.isOpen(true, new Date(1_000L))).as("同じ時刻でも新しいイベント").isTrue();
        assertThat(gate.isOpen(true, oldLogon)).as("確認後は更新日時を問わない").isTrue();
    }

    @Test
    @DisplayName("H-1 接続前に一度もログオンしていない（更新日時 null）場合も、ログオンイベント後に送る")
    void connectFromNeverLoggedOn() {
        Jbord0001SendGate gate = new Jbord0001SendGate();
        gate.onConnectRequested(null);

        assertThat(gate.isOpen(true, null)).isFalse();
        assertThat(gate.isOpen(true, new Date(1_000L))).isTrue();
    }
}
