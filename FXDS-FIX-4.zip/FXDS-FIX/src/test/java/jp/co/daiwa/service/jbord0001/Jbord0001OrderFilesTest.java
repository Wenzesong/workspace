package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class Jbord0001OrderFilesTest {

    private static final String ERR = "err_";

    @TempDir
    Path tmp;

    private Path dealer;
    private Path sales;
    private Jbord0001OrderFiles orderFiles;

    @BeforeEach
    void setUp() throws IOException {
        dealer = Files.createDirectory(tmp.resolve("dealer"));
        sales = Files.createDirectory(tmp.resolve("sales"));
        orderFiles = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR);
    }

    @Test
    @DisplayName("両ディレクトリのreq_ファイルを更新日時順に返し、それ以外は無視する")
    void collectRequests_sortsByLastModifiedAcrossDirectories() throws IOException {
        Path salesOld = file(sales, "req_b.tsv", 1_000);
        Path dealerNew = file(dealer, "req_a.tsv", 3_000);
        Path dealerMid = file(dealer, "req_c.tsv", 2_000);
        file(dealer, "err_req_x.tsv", 500);
        file(sales, "prc_req_y.tsv", 500);
        file(sales, "other.tsv", 500);

        List<Path> result = orderFiles.collectRequests();

        assertThat(result).containsExactly(salesOld, dealerMid, dealerNew);
    }

    @Test
    @DisplayName("P-12 同時刻のファイルはディーラー注文を先にし（jbord0000 と同じ優先順）、同じディレクトリ内はファイル名順")
    void collectRequests_sameTime_dealerFirstThenName() throws IOException {
        Path dealer2 = file(dealer, "req_2.tsv", 1_000);
        Path sales1 = file(sales, "req_1.tsv", 1_000);
        Path dealer1 = file(dealer, "req_1.tsv", 1_000);

        assertThat(orderFiles.collectRequests()).containsExactly(dealer1, dealer2, sales1);
    }

    @Test
    @DisplayName("ディレクトリが無い場合は例外（jbord0000はNPEだった）")
    void collectRequests_missingDirectory_throws() throws IOException {
        Files.delete(sales);

        assertThat(orderFiles.findMissingDirectories()).containsExactly(sales);
        assertThatThrownBy(() -> orderFiles.collectRequests()).isInstanceOf(NoSuchFileException.class);
    }

    @Test
    @DisplayName("claim後は収集対象外になり、再送されない")
    void claim_removesFileFromCollection() throws IOException {
        Path req = file(dealer, "req_1.tsv", 1_000);

        Path claimed = orderFiles.claim(req);

        assertThat(claimed.getFileName().toString()).isEqualTo("prc_req_1.tsv");
        assertThat(claimed).exists();
        assertThat(req).doesNotExist();
        assertThat(orderFiles.collectRequests()).isEmpty();
        assertThat(orderFiles.findLeftoverClaims()).containsExactly(claimed);
    }

    @Test
    @DisplayName("req_以外のファイルはclaimできない")
    void claim_nonRequest_throws() throws IOException {
        Path other = file(dealer, "other.tsv", 1_000);

        assertThatThrownBy(() -> orderFiles.claim(other)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("markErrorは元のreq_名にエラープレフィックスを付ける（jbord0000と同じ名前）")
    void markError_restoresOriginalNameWithPrefix() throws IOException {
        Path claimed = orderFiles.claim(file(sales, "req_9.tsv", 1_000));

        Path error = orderFiles.markError(claimed);

        assertThat(error).isEqualTo(sales.resolve("err_req_9.tsv"));
        assertThat(error).exists();
        assertThat(claimed).doesNotExist();
    }

    @Test
    @DisplayName("前回のprc_が残っていても上書きせず別名でclaimする")
    void claim_existingLeftover_isNotOverwritten() throws IOException {
        Path leftover = file(dealer, "prc_req_1.tsv", 500);
        Path req = file(dealer, "req_1.tsv", 1_000);

        Path claimed = orderFiles.claim(req);

        assertThat(claimed.getFileName().toString()).isEqualTo("prc_req_1.tsv.1");
        assertThat(leftover).exists();
    }

    @Test
    @DisplayName("同名のerr_が既にあっても上書きせず別名にする")
    void markError_existingError_isNotOverwritten() throws IOException {
        Path oldError = file(sales, "err_req_9.tsv", 500);
        Path claimed = orderFiles.claim(file(sales, "req_9.tsv", 1_000));

        Path error = orderFiles.markError(claimed);

        assertThat(error.getFileName().toString()).isEqualTo("err_req_9.tsv.1");
        assertThat(oldError).exists();
    }

    @Test
    @DisplayName("completeで処理中ファイルが削除される")
    void complete_deletesClaimedFile() throws IOException {
        Path claimed = orderFiles.claim(file(dealer, "req_1.tsv", 1_000));

        orderFiles.complete(claimed);

        assertThat(claimed).doesNotExist();
        assertThat(orderFiles.findLeftoverClaims()).isEmpty();
    }

    @Test
    @DisplayName("deleteRequestsはreq_ファイルだけを削除し件数を返す")
    void deleteRequests_deletesOnlyRequestFiles() throws IOException {
        file(dealer, "req_1.tsv", 1_000);
        file(dealer, "req_2.tsv", 1_000);
        Path keep = file(dealer, "err_req_3.tsv", 1_000);

        int deleted = Jbord0001OrderFiles.deleteRequests(dealer);

        assertThat(deleted).isEqualTo(2);
        assertThat(keep).exists();
    }

    @Test
    @DisplayName("P-08 安定待ちありの場合、初めて見つけたファイルは返さない（書き込み中の可能性）")
    void collectRequests_settle_newFileNotReturned() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, clock);
        file(dealer, "req_1.tsv", 1_000);

        assertThat(settling.collectRequests()).isEmpty();
    }

    @Test
    @DisplayName("P-08 サイズ・更新日時が変わらないまま安定待ち時間が過ぎたら返す")
    void collectRequests_settle_unchangedAfterSettle_returned() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, clock);
        Path req = file(dealer, "req_1.tsv", 1_000);
        settling.collectRequests();

        clock.advanceMillis(499);
        assertThat(settling.collectRequests()).isEmpty();
        clock.advanceMillis(1);
        assertThat(settling.collectRequests()).containsExactly(req);
    }

    @Test
    @DisplayName("P-08 待っている間にサイズが変わったら（書き込み中）、そこから待ち直す")
    void collectRequests_settle_sizeChanged_restartsWait() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, clock);
        Path req = file(dealer, "req_1.tsv", 1_000);
        settling.collectRequests();

        clock.advanceMillis(400);
        Files.write(req, "longer content".getBytes(StandardCharsets.UTF_8));
        Files.setLastModifiedTime(req, FileTime.fromMillis(1_000));
        assertThat(settling.collectRequests()).isEmpty();

        clock.advanceMillis(499);
        assertThat(settling.collectRequests()).isEmpty();
        clock.advanceMillis(1);
        assertThat(settling.collectRequests()).containsExactly(req);
    }

    @Test
    @DisplayName("P-08 待っている間に更新日時が変わったら、そこから待ち直す")
    void collectRequests_settle_mtimeChanged_restartsWait() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, clock);
        Path req = file(dealer, "req_1.tsv", 1_000);
        settling.collectRequests();

        clock.advanceMillis(400);
        Files.setLastModifiedTime(req, FileTime.fromMillis(2_000));
        assertThat(settling.collectRequests()).isEmpty();

        clock.advanceMillis(500);
        assertThat(settling.collectRequests()).containsExactly(req);
    }

    @Test
    @DisplayName("P-08 安定済みのファイルだけを、更新日時順で返す")
    void collectRequests_settle_onlySettledFilesInOrder() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, clock);
        Path old1 = file(sales, "req_b.tsv", 2_000);
        Path old2 = file(dealer, "req_a.tsv", 1_000);
        settling.collectRequests();
        clock.advanceMillis(500);
        file(dealer, "req_c.tsv", 500);

        assertThat(settling.collectRequests()).containsExactly(old2, old1);
    }

    @Test
    @DisplayName("P-08 消えたファイル（claim 済み等）の記録は捨て、同名で再作成されたら最初から待つ")
    void collectRequests_settle_removedFileForgotten() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, clock);
        Path req = file(dealer, "req_1.tsv", 1_000);
        settling.collectRequests();
        Files.delete(req);
        clock.advanceMillis(500);
        assertThat(settling.collectRequests()).isEmpty();

        file(dealer, "req_1.tsv", 1_000);
        assertThat(settling.collectRequests()).isEmpty();
    }

    @Test
    @DisplayName("P-12 書き込み中のファイルより後から置かれたファイルは、先のファイルが安定するまで待たせる（作成順を守る）")
    void collectRequests_settle_laterFileWaitsForEarlierOne() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, clock);
        Path newOrder = file(dealer, "req_new.tsv", 1_000);
        settling.collectRequests();

        clock.advanceMillis(500);
        Files.setLastModifiedTime(newOrder, FileTime.fromMillis(3_000));
        Path cancel = file(sales, "req_cancel.tsv", 2_000);
        assertThat(settling.collectRequests()).isEmpty();

        clock.advanceMillis(500);
        Files.setLastModifiedTime(newOrder, FileTime.fromMillis(4_000));
        assertThat(settling.collectRequests()).as("取消は安定したが、先に置かれた新規が書き込み中").isEmpty();

        clock.advanceMillis(500);
        assertThat(settling.collectRequests()).as("最初に見えた更新日時の順（新規→取消）").containsExactly(newOrder, cancel);
    }

    @Test
    @DisplayName("P-21 片方のディレクトリが読めなくても、もう片方のファイルは返し、失敗したディレクトリを知らせる")
    void collectRequests_oneDirectoryFails_otherProcessed() throws IOException {
        Path req = file(dealer, "req_1.tsv", 1_000);
        Files.delete(sales);
        List<Path> failed = new ArrayList<>();

        List<Path> result = orderFiles.collectRequests((dir, e) -> failed.add(dir));

        assertThat(result).containsExactly(req);
        assertThat(failed).containsExactly(sales);
    }

    @Test
    @DisplayName("P-21 全てのディレクトリが読めなければ例外")
    void collectRequests_allDirectoriesFail_throws() throws IOException {
        Files.delete(sales);
        Files.delete(dealer);

        assertThatThrownBy(() -> orderFiles.collectRequests((dir, e) -> { }))
                .isInstanceOf(NoSuchFileException.class);
    }

    @Test
    @DisplayName("P-07 処理中ファイルにメモを残せ、メモは収集・残存チェックの対象にならない")
    void note_writtenAndReadBack() throws IOException {
        Path claimed = orderFiles.claim(file(dealer, "req_1.tsv", 1_000));

        Path note = orderFiles.writeNote(claimed, Arrays.asList("理由：一部のみ送信済み", "送信済み=[A]"));

        assertThat(note.getFileName().toString()).isEqualTo("note_prc_req_1.tsv");
        assertThat(orderFiles.readNote(claimed)).contains(Arrays.asList("理由：一部のみ送信済み", "送信済み=[A]"));
        assertThat(orderFiles.collectRequests()).isEmpty();
        assertThat(orderFiles.findLeftoverClaims()).containsExactly(claimed);
    }

    @Test
    @DisplayName("P-07 メモが無ければ空")
    void note_missing_empty() throws IOException {
        Path claimed = orderFiles.claim(file(dealer, "req_1.tsv", 1_000));

        assertThat(orderFiles.readNote(claimed)).isEmpty();
    }

    @Test
    @DisplayName("P-09 再接続時の破棄指定：監視ディレクトリの req_ を err_ へ移す（削除しない）")
    void discardPendingRequests_movesToError() throws IOException {
        Path d = file(dealer, "req_1.tsv", 1_000);
        Path s = file(sales, "req_2.tsv", 1_000);
        file(sales, "prc_req_3.tsv", 1_000);

        List<Path> moved = orderFiles.discardPendingRequests((p, e) -> { throw new AssertionError(String.valueOf(p), e); });

        assertThat(moved).containsExactlyInAnyOrder(dealer.resolve("err_req_1.tsv"), sales.resolve("err_req_2.tsv"));
        assertThat(d).doesNotExist();
        assertThat(s).doesNotExist();
        assertThat(orderFiles.collectRequests()).isEmpty();
    }

    @Test
    @DisplayName("P-09 監視ディレクトリの未処理件数を数える")
    void countPendingRequests() throws IOException {
        file(dealer, "req_1.tsv", 1_000);
        file(sales, "req_2.tsv", 1_000);
        file(sales, "err_req_3.tsv", 1_000);

        assertThat(orderFiles.countPendingRequests()).isEqualTo(2);
    }

    @Test
    @DisplayName("P-08 安定待ち時間が負ならコンストラクタで拒否する")
    void constructor_negativeSettle_throws() {
        assertThatThrownBy(() -> new Jbord0001OrderFiles(Arrays.asList(dealer), ERR, -1, new FakeClock()))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("エラープレフィックス未指定はコンストラクタで拒否する")
    void constructor_emptyErrorPrefix_throws() {
        assertThatThrownBy(() -> new Jbord0001OrderFiles(Arrays.asList(dealer), ""))
                .isInstanceOf(IllegalArgumentException.class);
    }

    /** テスト用の単調増加時計（ナノ秒） */
    private static final class FakeClock implements LongSupplier {
        private long nanos = 1_000_000_000L;

        void advanceMillis(long millis) {
            nanos += TimeUnit.MILLISECONDS.toNanos(millis);
        }

        @Override
        public long getAsLong() {
            return nanos;
        }
    }

    private static Path file(Path dir, String name, long modifiedMillis) throws IOException {
        Path p = Files.write(dir.resolve(name), "x".getBytes(StandardCharsets.UTF_8));
        Files.setLastModifiedTime(p, FileTime.fromMillis(modifiedMillis));
        return p;
    }

    @Test
    @DisplayName("H-2 書き込みが続くファイルが後続を保留するのは保留上限まで。超えたら後続を返し、止まっているファイルとして知らせる")
    void collectRequests_settle_holdLimited() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, 2_000, clock);
        Path busy = file(dealer, "req_busy.tsv", 1_000);
        settling.collectRequests();
        clock.advanceMillis(100);
        Path later = file(sales, "req_later.tsv", 2_000);
        settling.collectRequests();

        for (int i = 0; i < 4; i++) {
            clock.advanceMillis(500);
            Files.setLastModifiedTime(busy, FileTime.fromMillis(3_000 + i));
            if (i < 3) {
                assertThat(settling.collectRequests()).as("保留上限前").isEmpty();
            }
        }
        assertThat(settling.collectRequests()).containsExactly(later);
        assertThat(settling.getStalledRequests()).containsExactly(busy);
    }

    @Test
    @DisplayName("M-2 読めないディレクトリの前回の記録は、処理対象として返さない（消えたファイルを送らない）")
    void collectRequests_failedDirectory_staleNotReturned() throws IOException {
        FakeClock clock = new FakeClock();
        Jbord0001OrderFiles settling = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR, 500, clock);
        file(sales, "req_1.tsv", 1_000);
        settling.collectRequests();
        clock.advanceMillis(500);
        Files.delete(sales.resolve("req_1.tsv"));
        Files.delete(sales);

        assertThat(settling.collectRequests((dir, e) -> { })).isEmpty();
    }

    @Test
    @DisplayName("M-7 再接続時の破棄は、移動できないファイルがあっても他は移し、失敗を知らせる")
    void discardPendingRequests_continuesOnFailure() throws IOException {
        Path d = file(dealer, "req_1.tsv", 1_000);
        Files.delete(sales);
        List<Path> failed = new ArrayList<>();

        List<Path> moved = orderFiles.discardPendingRequests((p, e) -> failed.add(p));

        assertThat(moved).containsExactly(dealer.resolve("err_req_1.tsv"));
        assertThat(d).doesNotExist();
        assertThat(failed).containsExactly(sales);
    }
}
