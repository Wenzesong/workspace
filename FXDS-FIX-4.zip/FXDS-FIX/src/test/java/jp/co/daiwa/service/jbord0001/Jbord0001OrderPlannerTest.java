package jp.co.daiwa.service.jbord0001;

import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.EXPIRE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.line;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001OrderPlannerTest {

    private static final String STOP = line("DAIWA_D-1-106", "2", "3", "", "6", EXPIRE, "0", "154.50", "G0001");
    private static final String PROFIT = line("DAIWA_D-1-107", "2", "2", "156.00", "6", EXPIRE, "0", "", "G0001");

    private final Jbord0001OrderPlanner planner = new Jbord0001OrderPlanner(Jbord0001OrderFixtures.defaultRules(),
            new Jbord0001GroupValidator(Jbord0001OrderFixtures.defaultRules(), id -> false, true), false);

    @Test
    @DisplayName("注文の種類ごとに送信単位へ分ける（既存の注文は既存の組立を使う）")
    void plan_routesByKind() {
        String standard = line("DAIWA_D-0-100", "1", "2", "155.20", "4", "", "0", "", "");
        String market = line("DAIWA_D-0-102", "1", "1", "", "4", "", "0", "", "");
        String cancel = Jbord0001OrderFixtures.cancelLine("DAIWA_D-C-103", "1", "2", "DAIWA_D-0-100");

        Jbord0001OrderPlanner.Plan plan = planner.plan(Arrays.asList(standard, market, STOP, PROFIT, cancel));

        assertThat(plan.hasErrors()).isFalse();
        assertThat(plan.getUnits()).extracting(Jbord0001SendUnit::getKind).containsExactly(
                Jbord0001SendUnit.Kind.NEW_EXISTING, Jbord0001SendUnit.Kind.NEW_EXTENDED,
                Jbord0001SendUnit.Kind.OCO, Jbord0001SendUnit.Kind.CANCEL);
    }

    @Test
    @DisplayName("T09 OCOの行が利確→損切りの順でも、1注文目を損切りにする")
    void plan_ocoReversed_stopFirst() {
        Jbord0001OrderPlanner.Plan plan = planner.plan(Arrays.asList(PROFIT, STOP));

        Jbord0001SendUnit oco = plan.getUnits().get(0);
        assertThat(oco.getListId()).isEqualTo("G0001");
        assertThat(oco.getRows()).extracting(r -> r.get(Jbord0001OrderRow.CL_ORD_ID))
                .containsExactly("DAIWA_D-1-106", "DAIWA_D-1-107");
    }

    @Test
    @DisplayName("T16 ファイル内の1行がエラーなら、ファイル全体を送信しない")
    void plan_anyError_noUnits() {
        String singleWithoutUser = line("DAIWA_D-1-108", "2", "2", "156.00", "6", EXPIRE, "0", "", "")
                .replace("RA00230", "");

        Jbord0001OrderPlanner.Plan plan = planner.plan(Arrays.asList(STOP, PROFIT, singleWithoutUser));

        assertThat(plan.getUnits()).isEmpty();
        assertThat(plan.getErrors()).containsExactly(
                new Jbord0001ValidationError(3, Jbord0001ErrorCode.E101, Jbord0001OrderRow.USER_ID));
    }

    @Test
    @DisplayName("P-05 OCOの電文形式が送信できない設定なら、単独注文を含むファイル全体を送信しない（一部送信を防ぐ）")
    void plan_ocoFormatNotSendable_wholeFileRejected() {
        Jbord0001OrderPlanner notSendable = new Jbord0001OrderPlanner(Jbord0001OrderFixtures.defaultRules(),
                new Jbord0001GroupValidator(Jbord0001OrderFixtures.defaultRules(), id -> false, false), false);
        String standard = line("DAIWA_D-0-100", "1", "2", "155.20", "4", "", "0", "", "");

        Jbord0001OrderPlanner.Plan plan = notSendable.plan(Arrays.asList(standard, STOP, PROFIT));

        assertThat(plan.getUnits()).isEmpty();
        assertThat(plan.getErrors()).containsExactly(
                new Jbord0001ValidationError(2, Jbord0001ErrorCode.E305, Jbord0001OrderRow.LIST_ID),
                new Jbord0001ValidationError(3, Jbord0001ErrorCode.E305, Jbord0001OrderRow.LIST_ID));
    }

    @Test
    @DisplayName("行チェックと組チェックのエラーをまとめて行番号順に返す")
    void plan_collectsAllErrorsSorted() {
        String stopNoPx = STOP.replace("154.50", "");
        String other = line("DAIWA_D-1-109", "2", "1", "155.00", "4", "", "0", "", "");

        Jbord0001OrderPlanner.Plan plan = planner.plan(Arrays.asList(other, stopNoPx));

        assertThat(plan.getErrors()).containsExactly(
                new Jbord0001ValidationError(1, Jbord0001ErrorCode.E204, Jbord0001OrderRow.PRICE),
                new Jbord0001ValidationError(2, Jbord0001ErrorCode.E201, Jbord0001OrderRow.STOP_PX),
                new Jbord0001ValidationError(2, Jbord0001ErrorCode.E301, Jbord0001OrderRow.LIST_ID));
    }
}
