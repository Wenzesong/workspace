package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001ResourceSuffixCreatorTest {

    private static final int THREADS = 8;
    private static final int PER_THREAD = 1_000;

    @Test
    @DisplayName("複数スレッドから採番しても重複しない（jbord0000は重複し得た）")
    void getSuffixIndex_concurrent_isUnique() throws Exception {
        Jbord0001ResourceSuffixCreator creator = new Jbord0001ResourceSuffixCreator();
        ExecutorService pool = Executors.newFixedThreadPool(THREADS);
        try {
            List<Callable<List<Long>>> tasks = new ArrayList<>();
            for (int i = 0; i < THREADS; i++) {
                tasks.add(() -> {
                    List<Long> values = new ArrayList<>();
                    for (int j = 0; j < PER_THREAD; j++) {
                        values.add(creator.getSuffixIndex());
                    }
                    return values;
                });
            }
            Set<Long> all = new HashSet<>();
            for (Future<List<Long>> f : pool.invokeAll(tasks)) {
                all.addAll(f.get());
            }

            assertThat(all).hasSize(THREADS * PER_THREAD);
        } finally {
            pool.shutdownNow();
        }
    }
}
