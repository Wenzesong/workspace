package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001ValidationErrorTest {

    @Test
    @DisplayName("ログには行番号・コード・項目ID・項目名・メッセージ（§7 の項目）を1行で出力する")
    void toLogText_containsSpecItems() {
        Jbord0001ValidationError error = new Jbord0001ValidationError(1, Jbord0001ErrorCode.E102, Jbord0001OrderRow.CL_ORD_ID);

        assertThat(error.toLogText()).isEqualTo("行=1 E102 項目=1(発注番号) 桁数を超えています");
    }

    @Test
    @DisplayName("組番号のエラーは項目ID 15 と項目名を出力する")
    void toLogText_listId() {
        Jbord0001ValidationError error = new Jbord0001ValidationError(2, Jbord0001ErrorCode.E301, Jbord0001OrderRow.LIST_ID);

        assertThat(error.toLogText()).isEqualTo("行=2 E301 項目=15(組番号) 組の相手がありません");
    }

    @Test
    @DisplayName("該当項目が無いエラー（E104 等）は項目ID 0 で出力する")
    void toLogText_noItem() {
        Jbord0001ValidationError error = new Jbord0001ValidationError(3, Jbord0001ErrorCode.E104, Jbord0001ValidationError.NO_ITEM);

        assertThat(error.toLogText()).isEqualTo("行=3 E104 項目=0(－) 項目数が不正です");
    }
}
