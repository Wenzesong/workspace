package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001RepeatSuppressorTest {

    @Test
    @DisplayName("P-22 同じ対象の失敗は 1 回目と、以降 N 回ごとにだけ報告する")
    void reportsFirstAndEveryNth() {
        Jbord0001RepeatSuppressor<String> s = new Jbord0001RepeatSuppressor<>(3);

        assertThat(s.shouldReport("a")).isTrue();
        assertThat(s.shouldReport("a")).isFalse();
        assertThat(s.shouldReport("a")).isFalse();
        assertThat(s.shouldReport("a")).isTrue();
        assertThat(s.countOf("a")).isEqualTo(4);
    }

    @Test
    @DisplayName("P-22 対象ごとに数える")
    void countsPerKey() {
        Jbord0001RepeatSuppressor<String> s = new Jbord0001RepeatSuppressor<>(3);
        s.shouldReport("a");

        assertThat(s.shouldReport("b")).isTrue();
    }

    @Test
    @DisplayName("P-22 回復（clear）したら次の失敗はまた報告し、回復したかどうかを返す")
    void clearResets() {
        Jbord0001RepeatSuppressor<String> s = new Jbord0001RepeatSuppressor<>(3);
        s.shouldReport("a");
        s.shouldReport("a");

        assertThat(s.clear("a")).isTrue();
        assertThat(s.clear("a")).isFalse();
        assertThat(s.shouldReport("a")).isTrue();
    }

    @Test
    @DisplayName("報告間隔が 1 未満ならコンストラクタで拒否する")
    void invalidInterval() {
        assertThatThrownBy(() -> new Jbord0001RepeatSuppressor<String>(0)).isInstanceOf(IllegalArgumentException.class);
    }
}
