package jp.co.daiwa.service.jbord0001;

import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;

/**
 * テスト用データ（発注TSV インタフェース仕様書 §9 の前提値）。
 *
 * <p>USD/JPY、売買金額 1000000.00、約定日時 20261119-01:00:00、有効期間 20261120-21:00:00.000、
 * ユーザID RA00230、発注通貨 USD。</p>
 */
final class Jbord0001OrderFixtures {

    static final String EXPIRE = "20261120-21:00:00.000";
    static final String TRANSACT = "20261119-01:00:00";

    private Jbord0001OrderFixtures() {
    }

    /**
     * 15列の行を作る。
     *
     * @param clOrdId 項目1
     * @param side 項目3
     * @param ordType 項目6
     * @param price 項目7
     * @param tif 項目8
     * @param expire 項目9
     * @param sendType 項目10
     * @param stopPx 項目14
     * @param listId 項目15
     */
    static String line(String clOrdId, String side, String ordType, String price, String tif, String expire,
            String sendType, String stopPx, String listId) {
        return String.join("\t", clOrdId, "USD/JPY", side, TRANSACT, "1000000.00", ordType, price, tif, expire,
                sendType, "RA00230", "", "USD", stopPx, listId);
    }

    /**
     * 単独キャンセル行（発注区分2）。項目7〜9・14・15 は空。
     *
     * @param clOrdId 項目1
     * @param side 項目3
     * @param ordType 項目6
     * @param origClOrdId 項目12（訂正対象発注番号）
     */
    static String cancelLine(String clOrdId, String side, String ordType, String origClOrdId) {
        return String.join("\t", clOrdId, "USD/JPY", side, TRANSACT, "1000000.00", ordType, "", "", "",
                "2", "RA00230", origClOrdId, "USD", "", "");
    }

    /** 新規の単独注文（売買区分2） */
    static String newLine(String ordType, String price, String tif, String expire, String stopPx) {
        return line("DAIWA_D-1-100", "2", ordType, price, tif, expire, "0", stopPx, "");
    }

    /** 同じ値の13列版（項目14・15 を省略） */
    static String to13Columns(String line15) {
        String[] c = line15.split("\t", -1);
        return String.join("\t", Arrays.copyOf(c, 13));
    }

    static Jbord0001OrderRow row(int lineNo, String line) {
        return Jbord0001OrderRow.of(lineNo, Arrays.asList(line.split("\t", -1)));
    }

    /** 仕様書の既定値（§11） */
    static Jbord0001ValidationRules defaultRules() {
        return rules(true);
    }

    static Jbord0001ValidationRules rules(boolean extraPriceIsError) {
        return new Jbord0001ValidationRules("0", new HashSet<>(Collections.singletonList("2")), 22, 20,
                "^[A-Za-z0-9]+$", "4", extraPriceIsError, symbol -> "USD/JPY".equals(symbol) ? 3 : null);
    }

    /** FIX 標準のタグ番号（fix-tag.properties の想定値） */
    static Map<Jbord0001FixMessageBuilder.Tag, String> standardTags() {
        Map<Jbord0001FixMessageBuilder.Tag, String> m = new EnumMap<>(Jbord0001FixMessageBuilder.Tag.class);
        m.put(Jbord0001FixMessageBuilder.Tag.MSG_TYPE, "35");
        m.put(Jbord0001FixMessageBuilder.Tag.CL_ORD_ID, "11");
        m.put(Jbord0001FixMessageBuilder.Tag.SYMBOL, "55");
        m.put(Jbord0001FixMessageBuilder.Tag.SIDE, "54");
        m.put(Jbord0001FixMessageBuilder.Tag.TRANSACT_TIME, "60");
        m.put(Jbord0001FixMessageBuilder.Tag.ORDER_QTY, "38");
        m.put(Jbord0001FixMessageBuilder.Tag.SETTL_TYPE, "63");
        m.put(Jbord0001FixMessageBuilder.Tag.ORD_TYPE, "40");
        m.put(Jbord0001FixMessageBuilder.Tag.PRICE, "44");
        m.put(Jbord0001FixMessageBuilder.Tag.TIME_IN_FORCE, "59");
        m.put(Jbord0001FixMessageBuilder.Tag.CURRENCY, "15");
        m.put(Jbord0001FixMessageBuilder.Tag.EXPIRE_TIME, "126");
        return m;
    }

    /** 仕様書の表記（| 区切り）をタブ区切りにする */
    static String tabs(String pipeSeparated) {
        return pipeSeparated.replace('|', '\t');
    }
}
