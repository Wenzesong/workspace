package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Calendar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class Jbord0001SentListIdRegistryTest {

    @TempDir
    Path tmp;

    @Test
    @DisplayName("P-06 登録した組番号はファイルに残り、再起動後（新しいインスタンス）も送信済みと判定する")
    void register_persistsAcrossRestart() throws IOException {
        Path file = tmp.resolve("sent_listid.txt");
        Jbord0001SentListIdRegistry before = new Jbord0001SentListIdRegistry();
        before.open(file);

        before.register("G0001");

        Jbord0001SentListIdRegistry after = new Jbord0001SentListIdRegistry();
        after.open(file);
        assertThat(after.isSent("G0001")).isTrue();
        assertThat(after.isSent("G0002")).isFalse();
    }

    @Test
    @DisplayName("P-06 ファイルが無ければ空として開き、登録時に作成する")
    void open_missingFile_startsEmpty() throws IOException {
        Path file = tmp.resolve("sub").resolve("sent_listid.txt");
        Jbord0001SentListIdRegistry registry = new Jbord0001SentListIdRegistry();

        registry.open(file);
        assertThat(registry.isSent("G0001")).isFalse();

        registry.register("G0001");
        assertThat(Files.readAllLines(file, StandardCharsets.UTF_8)).containsExactly("G0001");
    }

    @Test
    @DisplayName("P-06 既存ファイルの空行・前後の空白は無視する")
    void open_ignoresBlankLines() throws IOException {
        Path file = Files.write(tmp.resolve("sent_listid.txt"),
                Arrays.asList("G0001", "", "  G0002  "), StandardCharsets.UTF_8);
        Jbord0001SentListIdRegistry registry = new Jbord0001SentListIdRegistry();

        registry.open(file);

        assertThat(registry.isSent("G0001")).isTrue();
        assertThat(registry.isSent("G0002")).isTrue();
        assertThat(registry.isSent("")).isFalse();
    }

    @Test
    @DisplayName("P-06 既存ファイルの末尾に改行が無くても（書き込み途中で停止等）、次の組番号は別の行に書く")
    void register_noTrailingNewline_writesOnNewLine() throws IOException {
        Path file = Files.write(tmp.resolve("sent_listid.txt"), "G0001".getBytes(StandardCharsets.UTF_8));
        Jbord0001SentListIdRegistry registry = new Jbord0001SentListIdRegistry();
        registry.open(file);

        registry.register("G0002");

        Jbord0001SentListIdRegistry after = new Jbord0001SentListIdRegistry();
        after.open(file);
        assertThat(after.isSent("G0001")).isTrue();
        assertThat(after.isSent("G0002")).isTrue();
        assertThat(after.isSent("G0001G0002")).isFalse();
    }

    @Test
    @DisplayName("P-06 同じ組番号を2回登録してもファイルには1行だけ書く")
    void register_duplicate_writtenOnce() throws IOException {
        Path file = tmp.resolve("sent_listid.txt");
        Jbord0001SentListIdRegistry registry = new Jbord0001SentListIdRegistry();
        registry.open(file);

        registry.register("G0001");
        registry.register("G0001");

        assertThat(Files.readAllLines(file, StandardCharsets.UTF_8)).containsExactly("G0001");
    }

    @Test
    @DisplayName("P-06 ファイルへ書けなくてもメモリには登録し、例外で知らせる（同一プロセス内の二重送信は防ぐ）")
    void register_writeFails_keptInMemory() throws IOException {
        // 親ディレクトリの位置に通常ファイルがあるため、書き込み時に失敗する
        Path blocker = Files.write(tmp.resolve("blocker"), new byte[0]);
        Jbord0001SentListIdRegistry registry = new Jbord0001SentListIdRegistry();
        registry.open(blocker.resolve("sent_listid.txt"));

        assertThatThrownBy(() -> registry.register("G0001")).isInstanceOf(IOException.class);
        assertThat(registry.isSent("G0001")).isTrue();
    }

    @Test
    @DisplayName("P-06 保存ファイルは基準日ごと（組番号の重複チェック範囲＝基準日）")
    void fileFor_namesByBaseDate() {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2026, Calendar.NOVEMBER, 19);

        Path file = Jbord0001SentListIdRegistry.fileFor(tmp, cal.getTime());

        assertThat(file).isEqualTo(tmp.resolve("jbord0001_sent_listid_20261119.txt"));
    }

    @Test
    @DisplayName("P-06 基準日が取れない場合は例外")
    void fileFor_nullBaseDate_throws() {
        assertThatThrownBy(() -> Jbord0001SentListIdRegistry.fileFor(tmp, null))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    @DisplayName("P-06 open 前の利用はプログラム誤りとして拒否する（保存されないまま動くのを防ぐ）")
    void notOpened_throws() {
        Jbord0001SentListIdRegistry registry = new Jbord0001SentListIdRegistry();

        assertThatThrownBy(() -> registry.isSent("G0001")).isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> registry.register("G0001")).isInstanceOf(IllegalStateException.class);
    }
}
