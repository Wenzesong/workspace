package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001ErrorBackoffTest {

    @Test
    @DisplayName("P-11 連続失敗ごとに待ち時間を倍にし、上限で止める")
    void delayDoublesUpToMax() {
        Jbord0001ErrorBackoff backoff = new Jbord0001ErrorBackoff(200, 1_000, 0);

        assertThat(backoff.onFailure()).isEqualTo(200);
        assertThat(backoff.onFailure()).isEqualTo(400);
        assertThat(backoff.onFailure()).isEqualTo(800);
        assertThat(backoff.onFailure()).isEqualTo(1_000);
        assertThat(backoff.onFailure()).isEqualTo(1_000);
        assertThat(backoff.getConsecutiveFailures()).isEqualTo(5);
    }

    @Test
    @DisplayName("P-11 成功したら最初の待ち時間に戻る")
    void successResets() {
        Jbord0001ErrorBackoff backoff = new Jbord0001ErrorBackoff(200, 1_000, 0);
        backoff.onFailure();
        backoff.onFailure();

        backoff.onSuccess();

        assertThat(backoff.getConsecutiveFailures()).isZero();
        assertThat(backoff.onFailure()).isEqualTo(200);
    }

    @Test
    @DisplayName("P-11 連続失敗の上限に達したら知らせる（0 は無制限）")
    void limitReached() {
        Jbord0001ErrorBackoff limited = new Jbord0001ErrorBackoff(200, 1_000, 3);
        limited.onFailure();
        limited.onFailure();
        assertThat(limited.isLimitReached()).isFalse();
        limited.onFailure();
        assertThat(limited.isLimitReached()).isTrue();

        Jbord0001ErrorBackoff unlimited = new Jbord0001ErrorBackoff(200, 1_000, 0);
        for (int i = 0; i < 100; i++) {
            unlimited.onFailure();
        }
        assertThat(unlimited.isLimitReached()).isFalse();
    }

    @Test
    @DisplayName("P-11 長く失敗が続いても待ち時間が桁あふれしない")
    void noOverflow() {
        Jbord0001ErrorBackoff backoff = new Jbord0001ErrorBackoff(200, 30_000, 0);
        long last = 0;
        for (int i = 0; i < 200; i++) {
            last = backoff.onFailure();
        }
        assertThat(last).isEqualTo(30_000);
    }

    @Test
    @DisplayName("P-11 設定値の不正はコンストラクタで拒否する")
    void invalidSettings() {
        assertThatThrownBy(() -> new Jbord0001ErrorBackoff(0, 1_000, 0)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new Jbord0001ErrorBackoff(200, 100, 0)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new Jbord0001ErrorBackoff(200, 1_000, -1)).isInstanceOf(IllegalArgumentException.class);
    }
}
