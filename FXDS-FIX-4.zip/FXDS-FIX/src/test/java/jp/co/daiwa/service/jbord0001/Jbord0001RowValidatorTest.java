package jp.co.daiwa.service.jbord0001;

import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.EXPIRE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.cancelLine;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.line;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.newLine;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.row;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class Jbord0001RowValidatorTest {

    private final Jbord0001RowValidator validator = new Jbord0001RowValidator(Jbord0001OrderFixtures.defaultRules());

    private List<Jbord0001ValidationError> validate(String line) {
        return validator.validate(row(1, line));
    }

    private static Jbord0001ValidationError err(Jbord0001ErrorCode code, int itemId) {
        return new Jbord0001ValidationError(1, code, itemId);
    }

    @Nested
    @DisplayName("正常系（§9.1）")
    class Valid {
        @Test
        @DisplayName("T01 スタンダード / T02 リーブ / T04 成行 / T05 損切り / T06 利確")
        void validOrders_noErrors() {
            assertThat(validate(newLine("2", "155.20", "4", "", ""))).isEmpty();
            assertThat(validate(newLine("2", "154.80", "6", EXPIRE, ""))).isEmpty();
            assertThat(validate(newLine("1", "", "4", "", ""))).isEmpty();
            assertThat(validate(newLine("3", "", "6", EXPIRE, "154.50"))).isEmpty();
            assertThat(validate(newLine("2", "156.00", "6", EXPIRE, ""))).isEmpty();
        }

        @Test
        @DisplayName("キャンセル行は項目7〜9・14の組み合わせチェックをしない（§4）")
        void cancelRow_skipsCombinationChecks() {
            assertThat(validate(cancelLine("DAIWA_D-C-100", "2", "2", "DAIWA_D-1-099"))).isEmpty();
        }

        @Test
        @DisplayName("キャンセル行の売買金額0は数量チェックの対象外（取消電文に38を載せないため）")
        void cancelRow_zeroQty_noError() {
            String cancel = cancelLine("DAIWA_D-C-100", "2", "2", "DAIWA_D-1-099").replace("1000000.00", "0");

            assertThat(validate(cancel)).isEmpty();
        }
    }

    @Nested
    @DisplayName("E1xx")
    class Basic {
        @Test
        @DisplayName("E101 必須項目が空")
        void required() {
            String noUser = newLine("2", "155.20", "4", "", "").replace("RA00230", "");

            assertThat(validate(noUser)).containsExactly(err(Jbord0001ErrorCode.E101, Jbord0001OrderRow.USER_ID));
        }

        @Test
        @DisplayName("E101 キャンセル行で訂正対象発注番号が空（41 OrigClOrdID が空の取消を送らない）")
        void cancelWithoutOrigClOrdId() {
            assertThat(validate(cancelLine("DAIWA_D-C-100", "2", "2", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E101, Jbord0001OrderRow.ORIG_CL_ORD_ID));
        }

        @Test
        @DisplayName("E103 新規行の売買金額が0")
        void zeroOrderQty() {
            assertThat(validate(newLine("2", "155.20", "4", "", "").replace("1000000.00", "0.00")))
                    .containsExactly(err(Jbord0001ErrorCode.E103, Jbord0001OrderRow.ORDER_QTY));
        }

        @Test
        @DisplayName("E103 指値の為替レートが0（E203 にはならない）")
        void zeroPrice() {
            assertThat(validate(newLine("2", "0", "4", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E103, Jbord0001OrderRow.PRICE));
        }

        @Test
        @DisplayName("0 かつ桁あふれは E102 のみ（二重に報告しない）")
        void zeroAndTooLong_onlyE102() {
            String line = newLine("2", "155.20", "4", "", "").replace("1000000.00", "00000000000000000.00");

            assertThat(validate(line)).containsExactly(err(Jbord0001ErrorCode.E102, Jbord0001OrderRow.ORDER_QTY));
        }

        @Test
        @DisplayName("T12 発注番号23桁はE102（上限は設定値、既定22）")
        void clOrdIdTooLong() {
            String id23 = "DAIWA_D-1-1234567890123";

            assertThat(id23).hasSize(23);
            assertThat(validate(line(id23, "2", "2", "155.20", "4", "", "0", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E102, Jbord0001OrderRow.CL_ORD_ID));
        }

        @Test
        @DisplayName("E102 数字の桁あふれ（売買金額 16,2）")
        void decimalTooLong() {
            String line = newLine("2", "155.20", "4", "", "").replace("1000000.00", "12345678901234.567");

            assertThat(validate(line)).containsExactly(err(Jbord0001ErrorCode.E102, Jbord0001OrderRow.ORDER_QTY));
        }

        @Test
        @DisplayName("E103 日時・数字の形式、コード値が不正")
        void invalidFormatOrCode() {
            assertThat(validate(newLine("2", "155.20", "6", "20261332-21:00:00.000", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E103, Jbord0001OrderRow.EXPIRE_TIME));
            assertThat(validate(newLine("2", "abc", "4", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E103, Jbord0001OrderRow.PRICE));
            assertThat(validate(line("DAIWA_D-1-100", "3", "2", "155.20", "4", "", "0", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E103, Jbord0001OrderRow.SIDE));
            assertThat(validate(line("DAIWA_D-1-100", "2", "2", "155.20", "4", "", "1", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E103, Jbord0001OrderRow.SEND_TYPE));
            assertThat(validate(newLine("2", "155.20", "5", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E103, Jbord0001OrderRow.TIME_IN_FORCE));
        }

        @Test
        @DisplayName("組番号が英数字以外はE103（TBD-04）")
        void invalidListId() {
            assertThat(validate(line("DAIWA_D-1-100", "2", "2", "156.00", "6", EXPIRE, "0", "", "G-001")))
                    .containsExactly(err(Jbord0001ErrorCode.E103, Jbord0001OrderRow.LIST_ID));
        }
    }

    @Nested
    @DisplayName("E2xx（§9.2）")
    class Combination {
        @Test
        @DisplayName("T10 損切りで逆指値価格なし → E201")
        void stopWithoutStopPx() {
            assertThat(validate(newLine("3", "", "6", EXPIRE, "")))
                    .containsExactly(err(Jbord0001ErrorCode.E201, Jbord0001OrderRow.STOP_PX));
        }

        @Test
        @DisplayName("E202 注文区分3以外で逆指値価格あり")
        void stopPxOnNonStop() {
            assertThat(validate(newLine("2", "156.00", "6", EXPIRE, "154.50")))
                    .containsExactly(err(Jbord0001ErrorCode.E202, Jbord0001OrderRow.STOP_PX));
        }

        @Test
        @DisplayName("E203 指値で為替レートなし")
        void limitWithoutPrice() {
            assertThat(validate(newLine("2", "", "4", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E203, Jbord0001OrderRow.PRICE));
        }

        @Test
        @DisplayName("T11 成行で為替レートあり → E204")
        void marketWithPrice() {
            assertThat(validate(newLine("1", "155.20", "4", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E204, Jbord0001OrderRow.PRICE));
        }

        @Test
        @DisplayName("T11 設定「無視」なら E202・E204 はエラーにしない（TBD-08）")
        void extraPriceIgnored() {
            Jbord0001RowValidator ignoring = new Jbord0001RowValidator(Jbord0001OrderFixtures.rules(false));

            assertThat(ignoring.validate(row(1, newLine("1", "155.20", "4", "", "")))).isEmpty();
            assertThat(ignoring.validate(row(1, newLine("2", "156.00", "6", EXPIRE, "154.50")))).isEmpty();
        }

        @Test
        @DisplayName("T18 有効期間区分6で有効期間なし → E205")
        void gtdWithoutExpire() {
            assertThat(validate(newLine("2", "154.80", "6", "", "")))
                    .containsExactly(err(Jbord0001ErrorCode.E205, Jbord0001OrderRow.EXPIRE_TIME));
        }

        @Test
        @DisplayName("E206 損切りの有効期間区分が6以外")
        void stopWithFok() {
            assertThat(validate(newLine("3", "", "4", "", "154.50")))
                    .containsExactly(err(Jbord0001ErrorCode.E206, Jbord0001OrderRow.TIME_IN_FORCE));
        }

        @Test
        @DisplayName("E207 逆指値価格が0以下、または通貨ペアの小数桁数を超える")
        void invalidStopPx() {
            assertThat(validate(newLine("3", "", "6", EXPIRE, "0")))
                    .containsExactly(err(Jbord0001ErrorCode.E207, Jbord0001OrderRow.STOP_PX));
            // USD/JPY の小数桁数は3（テスト用の設定）
            assertThat(validate(newLine("3", "", "6", EXPIRE, "154.5001")))
                    .containsExactly(err(Jbord0001ErrorCode.E207, Jbord0001OrderRow.STOP_PX));
        }
    }
}
