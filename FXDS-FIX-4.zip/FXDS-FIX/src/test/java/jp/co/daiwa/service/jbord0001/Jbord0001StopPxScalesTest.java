package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.function.Function;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001StopPxScalesTest {

    @Test
    @DisplayName("P-19 「通貨ペア:小数桁数」をカンマ区切りで読む（前後の空白は無視）")
    void parse() {
        Function<String, Integer> scales = Jbord0001StopPxScales.parse(" USD/JPY:3, EUR/USD:5 ");

        assertThat(scales.apply("USD/JPY")).isEqualTo(3);
        assertThat(scales.apply("EUR/USD")).isEqualTo(5);
        assertThat(scales.apply("GBP/JPY")).isNull();
    }

    @Test
    @DisplayName("P-19 未設定（空）なら全通貨ペアが不明（項目定義の上限でチェック）")
    void empty() {
        assertThat(Jbord0001StopPxScales.parse("").apply("USD/JPY")).isNull();
        assertThat(Jbord0001StopPxScales.parse(null).apply("USD/JPY")).isNull();
    }

    @Test
    @DisplayName("P-19 形式不正・負の桁数・重複は起動時エラーにする")
    void invalid() {
        assertThatThrownBy(() -> Jbord0001StopPxScales.parse("USD/JPY")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Jbord0001StopPxScales.parse("USD/JPY:a")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Jbord0001StopPxScales.parse("USD/JPY:-1")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Jbord0001StopPxScales.parse("USD/JPY:3,USD/JPY:2"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("P-19 設定した桁数を超える逆指値価格は E207 になる")
    void appliedToValidation() {
        Jbord0001ValidationRules rules = new Jbord0001ValidationRules("0",
                new java.util.HashSet<>(java.util.Collections.singletonList("2")), 22, 20, "^[A-Za-z0-9]+$", "4", true,
                Jbord0001StopPxScales.parse("USD/JPY:3"));
        Jbord0001RowValidator validator = new Jbord0001RowValidator(rules);
        String stop = Jbord0001OrderFixtures.newLine("3", "", "6", Jbord0001OrderFixtures.EXPIRE, "154.5001");

        assertThat(validator.validate(Jbord0001OrderFixtures.row(1, stop))).containsExactly(
                new Jbord0001ValidationError(1, Jbord0001ErrorCode.E207, Jbord0001OrderRow.STOP_PX));
    }
}
