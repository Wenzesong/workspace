package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001NoreplyDelayTest {

    private static final long NOW = 1_000_000L;
    private final Jbord0001NoreplyDelay delay = new Jbord0001NoreplyDelay(10);

    @Test
    @DisplayName("P-01 送信日時から noreply 秒後までの残り時間（受信側の境界より 1ms 後に判定する）")
    void remaining_fromSentAt() {
        assertThat(delay.remainingMillis(new Date(NOW - 3_000), NOW)).isEqualTo(7_001);
    }

    @Test
    @DisplayName("P-01 送信日時が不明なら noreply 秒（＋1ms）")
    void remaining_unknownSentAt() {
        assertThat(delay.remainingMillis(null, NOW)).isEqualTo(10_001);
    }

    @Test
    @DisplayName("P-01 既に noreply 秒を過ぎていれば即時（0）")
    void remaining_alreadyElapsed() {
        assertThat(delay.remainingMillis(new Date(NOW - 20_000), NOW)).isZero();
    }

    @Test
    @DisplayName("P-01 送信日時が未来（時計のずれ）でも noreply 秒（＋1ms）を超えて待たない")
    void remaining_futureSentAt_capped() {
        assertThat(delay.remainingMillis(new Date(NOW + 5_000), NOW)).isEqualTo(10_001);
    }

    @Test
    @DisplayName("noreply 秒が負ならコンストラクタで拒否する")
    void constructor_negative_throws() {
        assertThatThrownBy(() -> new Jbord0001NoreplyDelay(-1)).isInstanceOf(IllegalArgumentException.class);
    }
}
