package jp.co.daiwa.service.jbord0001;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * 無応答判定を行うまでの残り時間の計算（P-01）。
 *
 * <p>受信側（FixEventHandler）は「送信から noreply 秒以上経過した応答」を判定後の応答として扱う。
 * 判定がその境界より早いと、境界直前に届いた応答が受信側では時間内・送信側では無応答と食い違うため、
 * 境界より {@link #MARGIN_MILLIS} 後に判定する。</p>
 */
public final class Jbord0001NoreplyDelay {

    /** 受信側の境界（diff &gt;= noreply）より確実に後にするための余裕 */
    static final long MARGIN_MILLIS = 1L;

    private final long noreplyMillis;

    /**
     * @param noreplySeconds 無応答とみなす秒数（0 以上）
     */
    public Jbord0001NoreplyDelay(int noreplySeconds) {
        if (noreplySeconds < 0) {
            throw new IllegalArgumentException("noreplySeconds must not be negative: " + noreplySeconds);
        }
        this.noreplyMillis = TimeUnit.SECONDS.toMillis(noreplySeconds);
    }

    /**
     * @param sentAt 送信日時（不明なら null）
     * @param nowMillis 現在日時（エポックミリ秒）
     * @return 判定までの残りミリ秒（0 以上、noreply 秒＋余裕 以下）
     */
    public long remainingMillis(Date sentAt, long nowMillis) {
        long full = noreplyMillis + MARGIN_MILLIS;
        if (sentAt == null) {
            return full;
        }
        long elapsed = Math.max(0L, nowMillis - sentAt.getTime());
        return Math.max(0L, full - elapsed);
    }
}
