package jp.co.daiwa.service.jbord0001;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Pattern;

/**
 * 入力チェックの設定値（仕様書 §11 の TBD を外出ししたもの）。
 */
public final class Jbord0001ValidationRules {

    /** 項目14の小数桁の上限（項目定義 15,8）。通貨ペア別の桁数が取れない場合に使う */
    public static final int DEFAULT_STOP_PX_SCALE = 8;

    private final String newSendType;
    private final Set<String> cancelSendTypes;
    private final int clOrdIdMaxLength;
    private final int listIdMaxLength;
    private final Pattern listIdPattern;
    private final Set<String> allowedTimeInForce;
    private final boolean extraPriceIsError;
    private final Function<String, Integer> symbolScaleResolver;

    /**
     * @param newSendType 新規の発注区分（§3.1：0）
     * @param cancelSendTypes キャンセルの発注区分（§3.1：2）
     * @param clOrdIdMaxLength 発注番号の上限桁数（TBD-03）
     * @param listIdMaxLength 組番号の上限桁数（TBD-04）
     * @param listIdPattern 組番号の形式（TBD-04）
     * @param marketTimeInForce 成行の有効期間区分（TBD-06）
     * @param extraPriceIsError E202・E204 をエラーにするか（TBD-08。false なら値を無視して送信）
     * @param symbolScaleResolver 通貨ペア→小数桁数。不明なら null を返す（E207）
     */
    public Jbord0001ValidationRules(String newSendType, Set<String> cancelSendTypes, int clOrdIdMaxLength,
            int listIdMaxLength, String listIdPattern, String marketTimeInForce, boolean extraPriceIsError,
            Function<String, Integer> symbolScaleResolver) {
        this.newSendType = Objects.requireNonNull(newSendType, "newSendType");
        this.cancelSendTypes = Collections.unmodifiableSet(new LinkedHashSet<>(cancelSendTypes));
        this.clOrdIdMaxLength = clOrdIdMaxLength;
        this.listIdMaxLength = listIdMaxLength;
        this.listIdPattern = Pattern.compile(listIdPattern);
        Set<String> tif = new LinkedHashSet<>();
        tif.add("4");
        tif.add("6");
        tif.add(marketTimeInForce);
        this.allowedTimeInForce = Collections.unmodifiableSet(tif);
        this.extraPriceIsError = extraPriceIsError;
        this.symbolScaleResolver = Objects.requireNonNull(symbolScaleResolver, "symbolScaleResolver");
    }

    public boolean isNew(Jbord0001OrderRow row) {
        return newSendType.equals(row.get(Jbord0001OrderRow.SEND_TYPE));
    }

    public boolean isCancel(Jbord0001OrderRow row) {
        return cancelSendTypes.contains(row.get(Jbord0001OrderRow.SEND_TYPE));
    }

    public boolean isKnownSendType(String sendType) {
        return newSendType.equals(sendType) || cancelSendTypes.contains(sendType);
    }

    public int getClOrdIdMaxLength() {
        return clOrdIdMaxLength;
    }

    public int getListIdMaxLength() {
        return listIdMaxLength;
    }

    public Pattern getListIdPattern() {
        return listIdPattern;
    }

    public Set<String> getAllowedTimeInForce() {
        return allowedTimeInForce;
    }

    public boolean isExtraPriceError() {
        return extraPriceIsError;
    }

    /** 通貨ペアの小数桁数（不明な場合は項目定義の上限） */
    public int stopPxScaleOf(String symbol) {
        Integer scale = symbolScaleResolver.apply(symbol);
        return scale != null ? scale : DEFAULT_STOP_PX_SCALE;
    }
}
