package jp.co.daiwa.service.jbord0001;

import java.util.HashMap;
import java.util.Map;

/**
 * 同じ対象で繰り返す失敗のログを間引く（P-21・P-22）。
 *
 * <p>1回目と、以降 interval 回ごとにだけ報告する。回復したら {@link #clear} で数え直す。
 * 監視スレッド1本から使う。</p>
 *
 * @param <K> 対象（ファイル・ディレクトリ等）
 */
public final class Jbord0001RepeatSuppressor<K> {

    private final int interval;
    private final Map<K, Integer> counts = new HashMap<>();

    /**
     * @param interval 2回目以降の報告間隔（回数、1 以上）
     */
    public Jbord0001RepeatSuppressor(int interval) {
        if (interval < 1) {
            throw new IllegalArgumentException("interval must be positive: " + interval);
        }
        this.interval = interval;
    }

    /**
     * 失敗を記録する。
     *
     * @return 報告すべき場合 true
     */
    public boolean shouldReport(K key) {
        int count = counts.merge(key, 1, (a, b) -> a == Integer.MAX_VALUE ? a : a + b);
        return (count - 1) % interval == 0;
    }

    /** 連続失敗回数 */
    public int countOf(K key) {
        return counts.getOrDefault(key, 0);
    }

    /**
     * 回復を記録する。
     *
     * @return 失敗中だった場合 true（回復ログ用）
     */
    public boolean clear(K key) {
        return counts.remove(key) != null;
    }
}
