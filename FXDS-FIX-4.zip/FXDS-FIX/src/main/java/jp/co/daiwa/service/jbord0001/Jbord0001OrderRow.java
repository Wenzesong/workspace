package jp.co.daiwa.service.jbord0001;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 発注要求TSVの1行（発注TSVインタフェース仕様書 §3）。
 *
 * <p>13列の行は項目14・15を空として保持する（§2.1）。</p>
 */
public final class Jbord0001OrderRow {

    public static final int CL_ORD_ID = 1;
    public static final int SYMBOL = 2;
    public static final int SIDE = 3;
    public static final int TRANSACT_TIME = 4;
    public static final int ORDER_QTY = 5;
    public static final int ORD_TYPE = 6;
    public static final int PRICE = 7;
    public static final int TIME_IN_FORCE = 8;
    public static final int EXPIRE_TIME = 9;
    public static final int SEND_TYPE = 10;
    public static final int USER_ID = 11;
    public static final int ORIG_CL_ORD_ID = 12;
    public static final int CURRENCY = 13;
    public static final int STOP_PX = 14;
    public static final int LIST_ID = 15;

    /** 項目数 */
    public static final int ITEM_COUNT = 15;

    /** 注文区分：成行 */
    public static final String ORD_TYPE_MARKET = "1";
    /** 注文区分：指値（指値・リーブ・利確） */
    public static final String ORD_TYPE_LIMIT = "2";
    /** 注文区分：逆指値（損切り） */
    public static final String ORD_TYPE_STOP = "3";

    private static final String[] ITEM_NAMES = {
        "－", "発注番号", "通貨ペア", "売買区分", "約定日時", "売買金額", "注文区分", "為替レート",
        "有効期間区分", "有効期間", "発注区分", "ユーザID", "訂正対象発注番号", "発注通貨", "逆指値価格", "組番号",
    };

    private final int lineNo;
    private final List<String> values;

    private Jbord0001OrderRow(int lineNo, List<String> values) {
        this.lineNo = lineNo;
        this.values = values;
    }

    /**
     * @param lineNo ファイル内の行番号（1始まり）
     * @param columns 列（ITEM_COUNT 以下。不足分は空とする）
     */
    public static Jbord0001OrderRow of(int lineNo, List<String> columns) {
        if (columns.size() > ITEM_COUNT) {
            throw new IllegalArgumentException("columns > " + ITEM_COUNT + ": " + columns.size());
        }
        List<String> padded = new ArrayList<>(columns);
        while (padded.size() < ITEM_COUNT) {
            padded.add("");
        }
        return new Jbord0001OrderRow(lineNo, Collections.unmodifiableList(padded));
    }

    /** 項目名（0 は該当項目なし） */
    public static String itemName(int itemId) {
        return itemId >= 0 && itemId < ITEM_NAMES.length ? ITEM_NAMES[itemId] : ITEM_NAMES[0];
    }

    public int getLineNo() {
        return lineNo;
    }

    /**
     * @param itemId 項目ID（1〜15）
     * @return 値（null にはならない）
     */
    public String get(int itemId) {
        return values.get(itemId - 1);
    }

    public boolean isBlank(int itemId) {
        return get(itemId).trim().isEmpty();
    }

    public boolean hasListId() {
        return !isBlank(LIST_ID);
    }
}
