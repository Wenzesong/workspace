package jp.co.daiwa.service.jbord0000;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.bean.TradeMng;
import jp.co.daiwa.bean.TradeOpeHistory;
import jp.co.daiwa.common.FixDateUtils;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.config.FixTagConfig;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dao.TradeMngRepository;
import jp.co.daiwa.dao.TradeOpeHistoryRepository;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.UserNotificationDto;
import jp.co.daiwa.enums.FixDealDivisionEnum;
import jp.co.daiwa.enums.FixEnums.WriterResult;
import jp.co.daiwa.enums.FixOrderDivisionEnum;
import jp.co.daiwa.enums.FixUserNotificationEnum.NotificationType;

/**
 *
 * Callableインタフェース
 *
 */

public class Jbord0000NoreplyThread implements Callable<WriterResult> {

    private TradeMngRepository tTradeMngRepository;
    private TradeOpeHistoryRepository tTradeOpeHistoryDao;
    private FixJobStatusInfoDto fixJobStatusInfo;
    private String fixMsg;
    private Integer noreplySeconds;
    private String usernotificationPath;
    private String clientPath;
    private String clientFile;
    private Map<String, String> fixTagMap;
    private static final String NOREPLY_CODE = "W";
    private static final String NOREPLY_FILE = "unknown_";
    private static final FixLogger logger = FixLogger.getLogger(Jbord0000NoreplyThread.class);
    private PlatformTransactionManager transactionManager;
    private DefaultTransactionDefinition definition;

    /**
     * コンストラクタ
     *
     */
    public Jbord0000NoreplyThread(String orderMsg, Integer noreplySeconds, String usernotificationPath, String clientPath,
            String clientFile, Map<String, String> fixTagMap, FixJobStatusInfoDto fixJobStatusInfo1) {
        this.fixMsg = orderMsg;
        this.noreplySeconds = noreplySeconds;
        this.usernotificationPath = usernotificationPath;
        this.clientPath = clientPath;
        this.clientFile = clientFile;
        this.fixTagMap = fixTagMap;
        this.fixJobStatusInfo = fixJobStatusInfo1;
    }

    @Override
    public WriterResult call() throws Exception {
        try {
            String clOrdId = FixFileUtils.getTagValue(fixMsg, fixTagMap.get(FixTagConfig.getClOrdId()) + "=", FixConstants.KEY_TAB);
            String ordNumStr = clOrdId.split(FixConstants.HYPHEN)[2];
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", noreplySeconds + "秒後無応答注文判定を行います。", clOrdId);
            TimeUnit.SECONDS.sleep(noreplySeconds);
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", clOrdId, fixJobStatusInfo.getReqOrdMap().containsKey(clOrdId) ? "無応答" : "応答済");
            if (fixJobStatusInfo.getReqOrdMap().containsKey(clOrdId)) {
                logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", clOrdId, FixDateUtils.convertDateToStrYmdHms(fixJobStatusInfo.getReqOrdMap().get(clOrdId)));
                TradeMng tradeMng = tTradeMngRepository.findMaxRevision(new BigDecimal(ordNumStr));
                // 取引操作履歴登録
                registTradeOpeHistory(tradeMng);
                // ファイル連携
                transferFile(clOrdId, ordNumStr, tradeMng);
            }
            return WriterResult.SUCCESS;
        } catch (Exception e) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "無応答判定処理", e);
            return WriterResult.FAILED;
        }
    }

    /**
     * ファイル連携処理
     *
     * @param clOrdId
     * @param ordNumStr
     * @param tradeMng
     * @throws IOException
     */
    private void transferFile(String clOrdId, String ordNumStr, TradeMng tradeMng) throws IOException {
        BigDecimal amount = tradeMng.getOrderCurrency().equals(tradeMng.getDealCurrency()) ? tradeMng.getDealAmount() : tradeMng.getSettleAmount();
        String msg = MessageFormat.format(NotificationType.TWENTYSEVEN.getName(),
                ordNumStr, clOrdId,
                FixOrderDivisionEnum.getNameByCode(clOrdId.split(FixConstants.HYPHEN)[1]),
                ordNumStr,
                tradeMng.getDealCurrency() + "/" + tradeMng.getSettleCurrency(),
                FixDealDivisionEnum.getByCode(tradeMng.getDealDivision()).getName(),
                amount != null ? amount : 0,
                FixDateUtils.convertDateToStrYmdSlash(tradeMng.getDeliveryDate()),
                tradeMng.getFxRate() != null ? tradeMng.getFxRate() : 0);
        // ユーザ通知ログファイル出力
        UserNotificationDto userNotificationDto = new UserNotificationDto();
        userNotificationDto.setText(msg);
        userNotificationDto.setType(NotificationType.TWENTYSEVEN.value());
        FixFileUtils.writeUserNotificationLogFile(usernotificationPath, userNotificationDto);
        // クライアント連携用ファイル出力
        List<List<String>> fileData = new ArrayList<>();
        List<String> lineData = new ArrayList<>();
        fileData.add(lineData);
        lineData.add(clOrdId + FixConstants.KEY_TAB + NOREPLY_CODE);
        String outputPath = Paths.get(clientPath + File.separatorChar + clientFile + NOREPLY_FILE + ordNumStr + ".tsv").toString();
        FixFileUtils.writeTsvFile(outputPath, fileData);
    }

    /**
     * 取引操作履歴登録
     *
     * @param tradeMng
     */
    private void registTradeOpeHistory(TradeMng tradeMng) {
        TransactionStatus tStatus = null;
        try {
            TradeOpeHistory bean = new TradeOpeHistory();
            bean.setOrderNumber(tradeMng.getOrderNumber());
            bean.setRevisionNumber(tradeMng.getRevisionNumber());
            bean.setExchangeDivision(tradeMng.getExchangeDivision());
            bean.setHistoryNumber(tTradeOpeHistoryDao.findMaxHistoryNumber(bean));
            bean.setOperation("無応答注文");
            bean.setOperationUser(FixConstants.Jbord0000);
            // トランザクション開始
            tStatus = transactionManager.getTransaction(definition);
            // [取引管理]の更新処理
            tTradeOpeHistoryDao.registTradeOpeHistory(bean);
            // トランザクションをコミット
            transactionManager.commit(tStatus);
        } catch (Exception e) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
            if (tStatus != null) {
                // トランザクションをロールバック
                transactionManager.rollback(tStatus);
            }
        }
    }

    /**
     * @param tTradeMngRepository セットする tTradeMngRepository
     */
    public void setTradeMngRepository(TradeMngRepository tTradeMngRepository) {
        this.tTradeMngRepository = tTradeMngRepository;
    }

    /**
     * @param tTradeOpeHistoryDao セットする tTradeOpeHistoryDao
     */
    public void setTradeOpeHistoryDao(TradeOpeHistoryRepository tTradeOpeHistoryDao) {
        this.tTradeOpeHistoryDao = tTradeOpeHistoryDao;
    }

    /**
     * @param transactionManager セットする transactionManager
     */
    public void setTransactionManager(PlatformTransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }

    /**
     * @param definition セットする definition
     */
    public void setDefinition(DefaultTransactionDefinition definition) {
        this.definition = definition;
    }
}
