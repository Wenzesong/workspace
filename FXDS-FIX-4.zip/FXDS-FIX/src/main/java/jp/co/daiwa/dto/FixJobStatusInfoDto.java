package jp.co.daiwa.dto;

import java.util.Date;
import java.util.HashMap;

/**
 * FIXジョブ状態管理
 *
 * @author MatsuFumizawa
 *
 */
public class FixJobStatusInfoDto {
    private boolean isWarn = false;
    /** key:CID注文番号 value:FIX送信日時 */
    private HashMap<String, Date> reqOrdMap = new HashMap<>();

    public FixJobStatusInfoDto(Boolean isWarn) {
        this.isWarn = isWarn;
    }

    /**
     * @return isWarn
     */
    public boolean isWarn() {
        return isWarn;
    }

    /**
     * @param isWarn セットする isWarn
     */
    public void setWarn(boolean isWarn) {
        this.isWarn = isWarn;
    }

    /**
     * @return reqOrdMap
     */
    public HashMap<String, Date> getReqOrdMap() {
        return reqOrdMap;
    }

    /**
     * @param reqOrdMap セットする reqOrdMap
     */
    public void setReqOrdMap(HashMap<String, Date> reqOrdMap) {
        this.reqOrdMap = reqOrdMap;
    }
}
