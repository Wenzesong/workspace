package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * 送信済みの組番号（E304 の重複チェック用）。
 *
 * <p>再起動しても忘れないよう、基準日ごとのファイルに1行1組番号で追記する（P-06）。
 * 重複チェックの範囲は基準日（組番号が日ごとに採番し直される場合に、前日分と誤って重複しないため）。
 * TODO(S10) 対象範囲・保存先は仕様書で未確定。範囲を変える場合は {@link #fileFor} を変える。</p>
 *
 * <p>発注処理（監視スレッド）からのみ使う想定だが、念のため全メソッドを同期する。</p>
 */
public class Jbord0001SentListIdRegistry {

    private static final String FILE_PREFIX = "jbord0001_sent_listid_";
    private static final String FILE_SUFFIX = ".txt";
    private static final String BASE_DATE_FORMAT = "yyyyMMdd";
    private static final String LINE_SEPARATOR = System.lineSeparator();

    private final Set<String> sent = new HashSet<>();
    private Path file;

    /**
     * 基準日の保存ファイル。
     *
     * @param dir 保存ディレクトリ
     * @param baseDate 基準日
     * @return 保存ファイル
     */
    public static Path fileFor(Path dir, Date baseDate) {
        if (baseDate == null) {
            throw new IllegalStateException("基準日が取得できません（送信済み組番号の保存先を決められない）");
        }
        return dir.resolve(FILE_PREFIX + new SimpleDateFormat(BASE_DATE_FORMAT).format(baseDate) + FILE_SUFFIX);
    }

    /**
     * 保存ファイルを開き、送信済みの組番号を読み込む。ファイルが無ければ空とする。
     *
     * @param file 保存ファイル
     * @throws IOException 読み込めない場合
     */
    public synchronized void open(Path file) throws IOException {
        Set<String> loaded = new HashSet<>();
        if (Files.exists(file)) {
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                String listId = line.trim();
                if (!listId.isEmpty()) {
                    loaded.add(listId);
                }
            }
        }
        sent.clear();
        sent.addAll(loaded);
        this.file = file;
    }

    /** 読み込んだ件数（起動ログ用） */
    public synchronized int size() {
        requireOpened();
        return sent.size();
    }

    public synchronized boolean isSent(String listId) {
        requireOpened();
        return sent.contains(listId);
    }

    /**
     * 送信済みとして登録し、ファイルへ追記する。
     *
     * <p>ファイルへの書き込みに失敗してもメモリには登録する（同一プロセス内の二重送信は防ぐ）。</p>
     *
     * @param listId 組番号
     * @throws IOException ファイルへ書き込めない場合（再起動後は重複チェックされない）
     */
    public synchronized void register(String listId) throws IOException {
        requireOpened();
        if (!sent.add(listId)) {
            return;
        }
        Path parent = file.toAbsolutePath().getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        // 前回が行の途中で止まっていた場合に、組番号がつながって別の値にならないようにする
        String line = (endsWithoutNewline(file) ? LINE_SEPARATOR : "") + listId + LINE_SEPARATOR;
        Files.write(file, line.getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND, StandardOpenOption.WRITE,
                StandardOpenOption.SYNC);
    }

    private static boolean endsWithoutNewline(Path file) throws IOException {
        if (!Files.exists(file)) {
            return false;
        }
        try (SeekableByteChannel ch = Files.newByteChannel(file, StandardOpenOption.READ)) {
            long size = ch.size();
            if (size == 0) {
                return false;
            }
            ByteBuffer last = ByteBuffer.allocate(1);
            ch.position(size - 1);
            ch.read(last);
            return last.get(0) != '\n';
        }
    }

    /** 保存先の無いまま動く（再起動で忘れる）のを防ぐ */
    private void requireOpened() {
        if (file == null) {
            throw new IllegalStateException("open() されていません");
        }
    }
}
