package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ScheduledExecutorService;

import javax.inject.Provider;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.OrdSendDto;
import jp.co.daiwa.service.FixSendStateUnknownException;

/**
 * 発注要求ファイル1つを処理する（仕様書 §5.1）。
 *
 * <ol>
 *   <li>req_ → prc_ へ移す（二重送信防止）</li>
 *   <li>全行を解析・チェック。1件でもエラーなら全行送信せず err_ へ移し、エラー内容はログに出力する</li>
 *   <li>送信単位ごとに送信。途中で失敗した場合、未送信なら err_、一部送信済みなら prc_ のまま警告</li>
 * </ol>
 */
public class Jbord0001OrderFileProcessor {

    private static final FixLogger logger = FixLogger.getLogger(Jbord0001OrderFileProcessor.class);
    /** claim の連続失敗ログの間隔（ポーリング 200ms で約1分） */
    private static final int CLAIM_FAILURE_LOG_INTERVAL = 300;
    private static final String NOTE_STATE_PARTIAL = "一部のみ送信済み";
    private static final String NOTE_STATE_UNKNOWN = "送信状態不明";
    private static final String NOTE_DATE_FORMAT = "yyyy/MM/dd HH:mm:ss.SSS";

    private final Jbord0001OrderFiles orderFiles;
    private final Jbord0001OrderPlanner planner;
    private final Jbord0001FixMessageBuilder builder;
    private final Jbord0001FixMessageBuilder.OcoFormat ocoFormat;
    private final Jbord0001Processor processor;
    private final Provider<OrdSendDto> ordSendDtoProvider;
    private final Jbord0001NoreplyChecker noreplyChecker;
    private final Jbord0001ResourceSuffixCreator suffixCreator;
    private final Jbord0001SentListIdRegistry sentListIds;
    private final FixJobStatusInfoDto fixJobStatusInfo;
    private final Charset tsvCharset;
    private final String outputPath;
    private final String outputFileName;
    /** claim に失敗し続けているファイル（ログの間引き用、P-22） */
    private final Jbord0001RepeatSuppressor<Path> claimFailures = new Jbord0001RepeatSuppressor<>(CLAIM_FAILURE_LOG_INTERVAL);

    public Jbord0001OrderFileProcessor(Jbord0001OrderFiles orderFiles, Jbord0001OrderPlanner planner,
            Jbord0001FixMessageBuilder builder, Jbord0001FixMessageBuilder.OcoFormat ocoFormat,
            Jbord0001Processor processor, Provider<OrdSendDto> ordSendDtoProvider,
            Jbord0001NoreplyChecker noreplyChecker, Jbord0001ResourceSuffixCreator suffixCreator,
            Jbord0001SentListIdRegistry sentListIds,
            FixJobStatusInfoDto fixJobStatusInfo, Charset tsvCharset, String outputPath, String outputFileName) {
        this.orderFiles = orderFiles;
        this.planner = planner;
        this.builder = builder;
        this.ocoFormat = ocoFormat;
        this.processor = processor;
        this.ordSendDtoProvider = ordSendDtoProvider;
        this.noreplyChecker = noreplyChecker;
        this.suffixCreator = suffixCreator;
        this.sentListIds = sentListIds;
        this.fixJobStatusInfo = fixJobStatusInfo;
        this.tsvCharset = tsvCharset;
        this.outputPath = outputPath;
        this.outputFileName = outputFileName;
    }

    /**
     * @param request req_ ファイル
     * @param noreplyPool 無応答判定のスレッドプール
     * @return 取得（claim）できた場合 true。false の場合、送信順を守るため呼び出し側は以降のファイルを次回に回す
     */
    public boolean process(Path request, ScheduledExecutorService noreplyPool) {
        Path claimed;
        try {
            claimed = orderFiles.claim(request);
        } catch (IOException e) {
            // 作成元が書き込み中等。次回ポーリングで再試行する（同じファイルの連続失敗はログを間引く）
            if (claimFailures.shouldReport(request)) {
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002",
                        "発注要求ファイル取得（連続" + claimFailures.countOf(request) + "回目）：" + request, e);
            }
            return false;
        }
        claimFailures.clear(request);
        handleClaimed(claimed, noreplyPool);
        return true;
    }

    /** 取得（claim）に連続で失敗している回数 */
    public int claimFailureCount(Path request) {
        return claimFailures.countOf(request);
    }

    private void handleClaimed(Path claimed, ScheduledExecutorService noreplyPool) {
        Jbord0001OrderPlanner.Plan plan;
        try {
            plan = planner.plan(Files.readAllLines(claimed, tsvCharset));
        } catch (IOException | RuntimeException e) {
            fixJobStatusInfo.setWarn(true);
            moveToError(claimed, "発注要求読込：" + e.getMessage(), Collections.<Jbord0001ValidationError>emptyList());
            return;
        }
        if (plan.hasErrors()) {
            fixJobStatusInfo.setWarn(true);
            moveToError(claimed, "入力チェックエラー " + plan.getErrors().size() + "件", plan.getErrors());
            return;
        }
        sendAll(claimed, plan.getUnits(), noreplyPool);
    }

    private void sendAll(Path claimed, List<Jbord0001SendUnit> units, ScheduledExecutorService noreplyPool) {
        List<String> allClOrdIds = clOrdIdsOf(units);
        List<String> sentClOrdIds = new ArrayList<>();
        for (Jbord0001SendUnit unit : units) {
            List<OutgoingMessage> messages;
            try {
                messages = toMessages(unit);
            } catch (RuntimeException e) {
                failBeforeSend(claimed, allClOrdIds, sentClOrdIds, "電文組立：" + e.getMessage());
                return;
            }
            for (OutgoingMessage m : messages) {
                Optional<String> output;
                try {
                    output = processor.process(m.fixStr);
                } catch (FixSendStateUnknownException e) {
                    // FIXエンジンへ渡った可能性があるため err_ にせず prc_ のまま残す
                    if (unit.getKind() == Jbord0001SendUnit.Kind.OCO) {
                        // P-06 送信済みかもしれないため登録する（再投入による二重送信を E304 で止める側に倒す）
                        registerSentListId(unit.getListId());
                    }
                    // P-15 送信されていた場合に備えて無応答判定する（応答が無ければ無応答として通知される）
                    scheduleNoreplyChecks(m.clOrdIds, noreplyPool);
                    fixJobStatusInfo.setWarn(true);
                    logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002",
                            "送信状態不明（再送しません。要確認）：" + claimed + " 送信済み=" + sentClOrdIds, e);
                    leaveNote(claimed, NOTE_STATE_UNKNOWN, "送信中の想定外エラー：" + e, allClOrdIds, sentClOrdIds, m.clOrdIds);
                    return;
                } catch (RuntimeException e) {
                    // M-5 書き込み前の失敗（電文変換など）は確実に未送信
                    failBeforeSend(claimed, allClOrdIds, sentClOrdIds, "送信前の想定外エラー：" + e);
                    return;
                }
                if (!output.isPresent()) {
                    failBeforeSend(claimed, allClOrdIds, sentClOrdIds, "発注要求未送信：" + m.fixStr);
                    return;
                }
                afterSent(m, output.get(), noreplyPool);
                sentClOrdIds.addAll(m.clOrdIds);
                if (unit.getKind() == Jbord0001SendUnit.Kind.OCO) {
                    // P-06 1通目を送った時点で登録する（2通目で失敗したファイルの再投入による二重送信を E304 で防ぐ）
                    registerSentListId(unit.getListId());
                }
            }
        }
        complete(claimed);
    }

    /** 送信単位 → 電文。既存の注文種類は既存の組立（OrdSendDto）をそのまま使う */
    private List<OutgoingMessage> toMessages(Jbord0001SendUnit unit) {
        switch (unit.getKind()) {
            case NEW_EXISTING:
                return single(unit.getRow(), toOrdSendDto(unit.getRow()).toNewOrderSingle());
            case CANCEL:
                return single(unit.getRow(), toOrdSendDto(unit.getRow()).toOrderCancelRequest());
            case NEW_EXTENDED:
                return single(unit.getRow(), builder.newOrderSingle(unit.getRow()));
            case OCO:
                return ocoMessages(unit);
            default:
                throw new IllegalStateException("unknown kind: " + unit.getKind());
        }
    }

    private List<OutgoingMessage> ocoMessages(Jbord0001SendUnit unit) {
        List<String> fixStrs = builder.oco(unit, ocoFormat);
        List<String> clOrdIds = new ArrayList<>();
        for (Jbord0001OrderRow row : unit.getRows()) {
            clOrdIds.add(row.get(Jbord0001OrderRow.CL_ORD_ID));
        }
        List<OutgoingMessage> messages = new ArrayList<>();
        if (fixStrs.size() == 1) {
            // パターンA：1通に2注文
            messages.add(new OutgoingMessage(clOrdIds, fixStrs.get(0)));
        } else {
            // パターンB：1注文1通（1通目＝損切り）
            for (int i = 0; i < fixStrs.size(); i++) {
                messages.add(new OutgoingMessage(Collections.singletonList(clOrdIds.get(i)), fixStrs.get(i)));
            }
        }
        return messages;
    }

    private static List<OutgoingMessage> single(Jbord0001OrderRow row, String fixStr) {
        return Collections.singletonList(
                new OutgoingMessage(Collections.singletonList(row.get(Jbord0001OrderRow.CL_ORD_ID)), fixStr));
    }

    private OrdSendDto toOrdSendDto(Jbord0001OrderRow row) {
        OrdSendDto dto = ordSendDtoProvider.get();
        dto.setClOrdID(row.get(Jbord0001OrderRow.CL_ORD_ID));
        dto.setSymbol(row.get(Jbord0001OrderRow.SYMBOL));
        dto.setSide(row.get(Jbord0001OrderRow.SIDE));
        dto.setTransactTime(row.get(Jbord0001OrderRow.TRANSACT_TIME));
        dto.setOrderQty(row.get(Jbord0001OrderRow.ORDER_QTY));
        dto.setOrdType(row.get(Jbord0001OrderRow.ORD_TYPE));
        dto.setPrice(row.get(Jbord0001OrderRow.PRICE));
        dto.setTimeInForce(row.get(Jbord0001OrderRow.TIME_IN_FORCE));
        dto.setExpireTime(row.get(Jbord0001OrderRow.EXPIRE_TIME));
        dto.setSendType(row.get(Jbord0001OrderRow.SEND_TYPE));
        dto.setUserId(row.get(Jbord0001OrderRow.USER_ID));
        dto.setClOrdIDChange(row.get(Jbord0001OrderRow.ORIG_CL_ORD_ID));
        dto.setCurrency(row.get(Jbord0001OrderRow.CURRENCY));
        return dto;
    }

    /** 送信済みの組番号を登録する。保存に失敗しても送信済みのため処理は続ける */
    private void registerSentListId(String listId) {
        try {
            sentListIds.register(listId);
        } catch (IOException | RuntimeException e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002",
                    "送信済み組番号の保存失敗（このプロセス内は重複チェックされますが、再起動後はされません）：" + listId, e);
        }
    }

    /** 送信済み後処理。どれが失敗しても再送・エラー扱いにはしない */
    private void afterSent(OutgoingMessage m, String output, ScheduledExecutorService noreplyPool) {
        scheduleNoreplyChecks(m.clOrdIds, noreplyPool);
        try {
            new FixFileUtils().writeFixMsgFile(outputPath, null, outputFileName, output, suffixCreator.getSuffixIndex());
        } catch (Exception e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "送信済み電文の出力失敗：" + output, e);
        }
    }

    /** ディーラー注文以外の無応答判定を予約する。予約の失敗は警告のみ */
    private void scheduleNoreplyChecks(List<String> clOrdIds, ScheduledExecutorService noreplyPool) {
        for (String clOrdId : clOrdIds) {
            if (clOrdId.contains(FixConstants.CLORD_DEALER)) {
                continue;
            }
            try {
                noreplyChecker.schedule(noreplyPool, clOrdId);
            } catch (RuntimeException e) {
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "無応答判定の登録失敗：" + clOrdId, e);
            }
        }
    }

    /** 送信できなかった場合。1通も送っていなければ err_、送信済みがあれば prc_ のまま警告 */
    private void failBeforeSend(Path claimed, List<String> allClOrdIds, List<String> sentClOrdIds, String reason) {
        fixJobStatusInfo.setWarn(true);
        if (sentClOrdIds.isEmpty()) {
            moveToError(claimed, reason, Collections.<Jbord0001ValidationError>emptyList());
            return;
        }
        // TODO(S09) 一部送信済み（OCOパターンBの2通目失敗など）の扱いは仕様書で未確定。自動取消はせず手動対応とする
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                "一部のみ送信済み（要手動対応）：" + claimed + " 送信済み=" + sentClOrdIds + " " + reason);
        leaveNote(claimed, NOTE_STATE_PARTIAL, reason, allClOrdIds, sentClOrdIds, Collections.<String>emptyList());
    }

    /**
     * P-07 手動対応に必要な内容を prc_ ファイルの横にメモとして残す（起動時の残存チェックでもログに出す）。
     * メモを書けなくてもログには同じ内容が出ている。
     */
    private void leaveNote(Path claimed, String state, String reason, List<String> allClOrdIds,
            List<String> sentClOrdIds, List<String> unknownClOrdIds) {
        List<String> unsent = new ArrayList<>(allClOrdIds);
        unsent.removeAll(sentClOrdIds);
        unsent.removeAll(unknownClOrdIds);
        List<String> lines = new ArrayList<>();
        lines.add("日時=" + new SimpleDateFormat(NOTE_DATE_FORMAT).format(new Date()));
        lines.add("状態=" + state);
        lines.add("理由=" + reason);
        lines.add("送信済み=" + sentClOrdIds);
        lines.add("送信状態不明=" + unknownClOrdIds);
        lines.add("未送信=" + unsent);
        lines.add("対応=送信済み・送信状態不明の注文を約定照会等で確認し、未送信分は新しい発注要求で再投入する。"
                + "このファイルを req_ に戻すと送信済み分も再送されるため戻さないこと");
        try {
            Path note = orderFiles.writeNote(claimed, lines);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", "手動対応メモを出力：" + note);
        } catch (IOException e) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "手動対応メモの出力失敗：" + claimed + " " + lines, e);
        }
    }

    private static List<String> clOrdIdsOf(List<Jbord0001SendUnit> units) {
        List<String> ids = new ArrayList<>();
        for (Jbord0001SendUnit unit : units) {
            for (Jbord0001OrderRow row : unit.getRows()) {
                ids.add(row.get(Jbord0001OrderRow.CL_ORD_ID));
            }
        }
        return ids;
    }

    private void complete(Path claimed) {
        try {
            orderFiles.complete(claimed);
        } catch (IOException e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "送信済みファイル削除失敗（再送はされません）：" + claimed, e);
        }
    }

    /** エラー内容はログにだけ残すため、移動に失敗しても失わないよう移動の前に出力する */
    private void moveToError(Path claimed, String reason, List<Jbord0001ValidationError> errors) {
        String fileName = String.valueOf(claimed.getFileName());
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                fileName + " " + reason + "（エラー" + errors.size() + "件）");
        for (Jbord0001ValidationError e : errors) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", fileName + " " + e.toLogText());
        }
        try {
            Path error = orderFiles.markError(claimed);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", fileName + " → " + error.getFileName());
        } catch (IOException e) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "エラーファイル移動失敗：" + claimed + " " + reason, e);
        }
    }

    /** 送信する電文1通と、含まれる発注番号 */
    private static final class OutgoingMessage {
        private final List<String> clOrdIds;
        private final String fixStr;

        private OutgoingMessage(List<String> clOrdIds, String fixStr) {
            this.clOrdIds = clOrdIds;
            this.fixStr = fixStr;
        }
    }
}
