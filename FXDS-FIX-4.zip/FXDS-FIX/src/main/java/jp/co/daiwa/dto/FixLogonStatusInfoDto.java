package jp.co.daiwa.dto;

import java.util.Date;

import com.fujitsu.fxsvc.FXParam;
import com.fujitsu.fxsvc.FXReason;

public class FixLogonStatusInfoDto {
    /** FIXエンジンのイベントスレッドで更新し、監視スレッドで参照するため volatile */
    private volatile boolean isLogonStatus;
    /** ログオン状態が変わるたびに新しい値になる（接続要求後のログオン確認に使うため volatile） */
    private volatile Date lastLogonDate;
    private Date lastLogoutDate;
    private FXParam logonParam;
    private FXParam logoutParam;
    private FXReason logoutReason;

    public FixLogonStatusInfoDto(Boolean isLogonStatus) {
        this.isLogonStatus = isLogonStatus;
    }

    public boolean isLogonStatus() {
        return isLogonStatus;
    }

    public void setLogonStatus(boolean isLogonStatus) {
        this.isLogonStatus = isLogonStatus;
    }

    public Date getLastLogonDate() {
        return lastLogonDate;
    }

    public void setLastLogonDate(Date lastLogonDate) {
        this.lastLogonDate = lastLogonDate;
    }

    public Date getLastLogoutDate() {
        return lastLogoutDate;
    }

    public void setLastLogoutDate(Date lastLogoutDate) {
        this.lastLogoutDate = lastLogoutDate;
    }

    public FXParam getLogonParam() {
        return logonParam;
    }

    public void setLogonParam(FXParam logonParam) {
        this.logonParam = logonParam;
    }

    public FXParam getLogoutParam() {
        return logoutParam;
    }

    public void setLogoutParam(FXParam logoutParam) {
        this.logoutParam = logoutParam;
    }

    public FXReason getLogoutReason() {
        return logoutReason;
    }

    public void setLogoutReason(FXReason logoutReason) {
        this.logoutReason = logoutReason;
    }

}
