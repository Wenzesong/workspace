package jp.co.daiwa.service.jbord0001;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dto.FixJobStatusInfoDto;

/**
 * 終了ステータスの決定（異常 &gt; 警告 &gt; 正常）。
 */
@Component
public class Jbord0001JobListener implements JobExecutionListener {

    private static final String WARN = "WARN";
    private static final FixLogger logger = FixLogger.getLogger(Jbord0001JobListener.class);

    private final FixJobStatusInfoDto fixJobStatusInfo;

    @Inject
    public Jbord0001JobListener(@Named("fixjobstatus_order") FixJobStatusInfoDto fixJobStatusInfo) {
        this.fixJobStatusInfo = fixJobStatusInfo;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I030");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        boolean failed = false;
        for (StepExecution stepExecution : jobExecution.getStepExecutions()) {
            if (ExitStatus.FAILED.getExitCode().equals(stepExecution.getExitStatus().getExitCode())) {
                logger.error(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_E001", FixConstants.Jbord0000_Name, stepExecution);
                failed = true;
            }
        }
        if (failed) {
            jobExecution.setExitStatus(ExitStatus.FAILED);
        } else if (fixJobStatusInfo.isWarn()) {
            jobExecution.setExitStatus(new ExitStatus(WARN));
        }
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I002",
                jobExecution.getExitStatus().getExitCode(), jobExecution);
    }
}
