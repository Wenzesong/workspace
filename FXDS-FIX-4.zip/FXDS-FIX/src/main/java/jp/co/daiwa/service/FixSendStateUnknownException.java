package jp.co.daiwa.service;

/**
 * FIXエンジンへの書き込み（FXServiceCB.write）中に想定外の例外が起き、送信されたか分からないことを表す。
 *
 * <p>書き込み前の例外（電文変換の失敗など）は確実に未送信のため、この例外にしない（M-5）。
 * RuntimeException のサブクラスのため、従来 RuntimeException を捕まえていた呼び出し元（jbord0000）の動作は変わらない。</p>
 */
public class FixSendStateUnknownException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public FixSendStateUnknownException(String message, Throwable cause) {
        super(message, cause);
    }
}
