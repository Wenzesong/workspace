package jp.co.daiwa.dto;

import java.util.Map;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.batch.item.ItemCountAware;
import org.springframework.beans.factory.annotation.Value;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.config.FixTagConfig;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.enums.FixEnums;
import jp.co.daiwa.enums.FixEnums.MsgType;

public class OrdSendDto implements ItemCountAware {

    private int count;

    /** 発注番号 */
    @NotBlank
    @Size(min = 9, max = 26)
    private String clOrdID;

    /** 通貨ペア */
    @NotBlank
    @Size(min = 7, max = 7)
    private String symbol;

    /** 売買区分 */
    @NotBlank
    @Size(min = 1, max = 1)
    private String side;

    /** 約定日時 */
    @NotBlank
    private String transactTime;

    /** 売買金額 */
    @NotBlank
    private String orderQty;

    /** 注文区分 */
    @NotBlank
    @Size(min = 1, max = 1)
    private String ordType;

    /** 為替レート */
    private String price;

    /** 有効期間区分 */
    @Size(min = 1, max = 1)
    private String timeInForce;

    /** 有効期間 */
    private String expireTime;

    /** 発注区分 */
    @Size(min = 1, max = 1)
    private String sendType;

    /** ユーザID */
    @NotBlank
    @Size(min = 7, max = 7)
    private String userId;

    /** 訂正対象発注番号 */
    @Size(min = 0, max = 26)
    private String clOrdIDChange;

    /** 発注通貨 */
    @Size(min = 0, max = 3)
    private String currency;

    @Value("#{${fix.tag}}")
    private Map<String, String> fixTagMap;

    /** Logger */
    private static final FixLogger logger = FixLogger.getLogger(OrdSendDto.class);

    /**
     * @return count
     */
    public int getCount() {
        return count;
    }

    /**
     * @param count セットする count
     */
    public void setCount(int count) {
        this.count = count;
    }

    /**
     * @return clOrdID
     */
    public String getClOrdID() {
        return clOrdID;
    }

    /**
     * @param clOrdID セットする clOrdID
     */
    public void setClOrdID(String clOrdID) {
        this.clOrdID = clOrdID;
    }

    /**
     * @return symbol
     */
    public String getSymbol() {
        return symbol;
    }

    /**
     * @param symbol セットする symbol
     */
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    /**
     * @return side
     */
    public String getSide() {
        return side;
    }

    /**
     * @param side セットする side
     */
    public void setSide(String side) {
        this.side = side;
    }

    /**
     * @return transactTime
     */
    public String getTransactTime() {
        return transactTime;
    }

    /**
     * @param transactTime セットする transactTime
     */
    public void setTransactTime(String transactTime) {
        this.transactTime = transactTime;
    }

    /**
     * @return orderQty
     */
    public String getOrderQty() {
        return orderQty;
    }

    /**
     * @param orderQty セットする orderQty
     */
    public void setOrderQty(String orderQty) {
        this.orderQty = orderQty;
    }

    /**
     * @return ordType
     */
    public String getOrdType() {
        return ordType;
    }

    /**
     * @param ordType セットする ordType
     */
    public void setOrdType(String ordType) {
        this.ordType = ordType;
    }

    /**
     * @return price
     */
    public String getPrice() {
        return price;
    }

    /**
     * @param price セットする price
     */
    public void setPrice(String price) {
        this.price = price;
    }

    /**
     * @return timeInForce
     */
    public String getTimeInForce() {
        return timeInForce;
    }

    /**
     * @param timeInForce セットする timeInForce
     */
    public void setTimeInForce(String timeInForce) {
        this.timeInForce = timeInForce;
    }

    /**
     * @return expireTime
     */
    public String getExpireTime() {
        return expireTime;
    }

    /**
     * @param expireTime セットする expireTime
     */
    public void setExpireTime(String expireTime) {
        this.expireTime = expireTime;
    }

    /**
     * @return sendType
     */
    public String getSendType() {
        return sendType;
    }

    /**
     * @param sendType セットする sendType
     */
    public void setSendType(String sendType) {
        this.sendType = sendType;
    }

    /**
     * @return userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId セットする userId
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return clOrdIDChange
     */
    public String getClOrdIDChange() {
        return clOrdIDChange;
    }

    /**
     * @param clOrdIDChange セットする clOrdIDChange
     */
    public void setClOrdIDChange(String clOrdIDChange) {
        this.clOrdIDChange = clOrdIDChange;
    }

    /**
     * @return currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @param currency セットする currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public void setItemCount(int count) {
        this.count = count;

    }

    /**
     * クライアント注文要求電文からDTO変換処理
     *
     * @param str
     */
    public void toOrdSendDtoFromTsvStr(String str) {
        try {
            String[] readItem = new String[] {};
            readItem = str.split(FixConstants.KEY_TAB, -1);
            this.clOrdID = readItem[0];
            this.symbol = readItem[1];
            this.side = readItem[2];
            this.transactTime = readItem[3];
            this.orderQty = readItem[4];
            this.ordType = readItem[5];
            this.price = readItem[6];
            this.timeInForce = readItem[7];
            this.expireTime = readItem[8];
            this.sendType = readItem[9];
            this.userId = readItem[10];
            this.clOrdIDChange = readItem[11];
            this.currency = readItem[12];
        } catch (Exception e) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", Thread.currentThread().getName() + " input:" + str, e);
        }
    }

    /**
     * OrderCancelRequest電文変換処理
     *
     * @return
     */
    public String toOrderCancelRequest() {
        return fixTagMap.get(FixTagConfig.getMsgType()) + "=" + MsgType.F.value() //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getClOrdId()) + "=" + clOrdID //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getOrigClOrdId()) + "=" + clOrdIDChange //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getSymbol()) + "=" + FixFileUtils.convertCnyToCnh(symbol) //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getTransactTime()) + "=" + transactTime;
    }

    /**
     * NewOrderSingle電文変換処理
     *
     * @return
     */
    public String toNewOrderSingle() {
        return fixTagMap.get(FixTagConfig.getMsgType()) + "=" + MsgType.D.value() //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getClOrdId()) + "=" + clOrdID //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getOrigClOrdId()) + "=" + clOrdIDChange //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getSymbol()) + "=" + FixFileUtils.convertCnyToCnh(symbol) //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getSide()) + "=" + side //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getTransactTime()) + "=" + transactTime //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getOrderQty()) + "=" + orderQty //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getSettlType3()) + "=" + FixEnums.SettleType.SPOT //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getOrdType()) + "=" + ordType //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getPrice()) + "=" + price //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getTimeInforce()) + "=" + timeInForce //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getCurrency()) + "=" + currency //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getExpireTime()) + "=" + expireTime //
                + FixConstants.KEY_TAB + fixTagMap.get(FixTagConfig.getMinQty()) + "=" + orderQty;
    }

    /**
     *
     */
    @Override
    public String toString() {
        return "OrdSendDto [count=" + count + ", clOrdID=" + clOrdID + ", symbol=" + symbol + ", side=" + side + ", transactTime=" + transactTime + ", orderQty=" + orderQty + ", ordType=" + ordType
                + ", price=" + price + ", timeInForce=" + timeInForce + ", expireTime=" + expireTime + ", sendType=" + sendType + ", userId=" + userId + ", clOrdIDChange=" + clOrdIDChange
                + ", currency=" + currency + ", fixTagMap=" + fixTagMap + "]";
    }

}
