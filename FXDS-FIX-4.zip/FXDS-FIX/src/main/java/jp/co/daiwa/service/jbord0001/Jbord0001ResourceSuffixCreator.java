package jp.co.daiwa.service.jbord0001;

import java.util.concurrent.atomic.AtomicLong;

/**
 * 出力電文ファイルの連番採番（プロセス内で一意）。
 */
public class Jbord0001ResourceSuffixCreator {

    private static final AtomicLong INDEX = new AtomicLong();

    /**
     * @return 次の連番（1始まり）
     */
    public long getSuffixIndex() {
        return INDEX.incrementAndGet();
    }
}
