package jp.co.daiwa.service.jbord0001;

import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.CL_ORD_ID;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.CURRENCY;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.EXPIRE_TIME;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.LIST_ID;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORDER_QTY;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORD_TYPE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORD_TYPE_LIMIT;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORD_TYPE_MARKET;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORD_TYPE_STOP;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORIG_CL_ORD_ID;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.PRICE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.SEND_TYPE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.SIDE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.STOP_PX;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.SYMBOL;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.TIME_IN_FORCE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.TRANSACT_TIME;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.USER_ID;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 行単位チェック（仕様書 §5.2：E101〜E103、E201〜E207）。
 */
public class Jbord0001RowValidator {

    /** 新規行の必須項目（§3 の ○） */
    private static final List<Integer> REQUIRED_NEW = Arrays.asList(
            CL_ORD_ID, SYMBOL, SIDE, TRANSACT_TIME, ORDER_QTY, ORD_TYPE, TIME_IN_FORCE, SEND_TYPE, USER_ID);
    /**
     * キャンセル行の必須項目。§4 でキャンセル行の項目8は「－」のため除く。
     * 項目12（訂正対象発注番号）は取消電文の 41 OrigClOrdID になり、空だと取消対象を特定できないため必須とする。
     * TODO(S04) キャンセル行への適用範囲は仕様書で未確定。
     */
    private static final List<Integer> REQUIRED_CANCEL = Arrays.asList(
            CL_ORD_ID, SYMBOL, SIDE, TRANSACT_TIME, ORDER_QTY, ORD_TYPE, SEND_TYPE, USER_ID, ORIG_CL_ORD_ID);

    private static final Pattern DECIMAL = Pattern.compile("^\\d+(\\.\\d+)?$");
    private static final Pattern DATE_TIME = Pattern.compile("^\\d{8}-\\d{2}:\\d{2}:\\d{2}(\\.\\d{3})?$");
    private static final DateTimeFormatter DATE_TIME_SEC =
            DateTimeFormatter.ofPattern("uuuuMMdd-HH:mm:ss").withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter DATE_TIME_MILLI =
            DateTimeFormatter.ofPattern("uuuuMMdd-HH:mm:ss.SSS").withResolverStyle(ResolverStyle.STRICT);

    private final Jbord0001ValidationRules rules;
    private final Map<Integer, Integer> maxLengths;

    public Jbord0001RowValidator(Jbord0001ValidationRules rules) {
        this.rules = rules;
        Map<Integer, Integer> m = new LinkedHashMap<>();
        m.put(CL_ORD_ID, rules.getClOrdIdMaxLength());
        m.put(SYMBOL, 7);
        m.put(SIDE, 1);
        m.put(ORD_TYPE, 1);
        m.put(TIME_IN_FORCE, 1);
        m.put(SEND_TYPE, 1);
        m.put(USER_ID, 7);
        m.put(ORIG_CL_ORD_ID, rules.getClOrdIdMaxLength());
        m.put(CURRENCY, 3);
        m.put(LIST_ID, rules.getListIdMaxLength());
        this.maxLengths = Collections.unmodifiableMap(m);
    }

    /**
     * @param row 行
     * @return エラー（無ければ空）
     */
    public List<Jbord0001ValidationError> validate(Jbord0001OrderRow row) {
        List<Jbord0001ValidationError> errors = new ArrayList<>();
        Checker c = new Checker(row, errors);
        boolean isCancel = rules.isCancel(row);
        for (int id : isCancel ? REQUIRED_CANCEL : REQUIRED_NEW) {
            c.required(id);
        }
        for (Map.Entry<Integer, Integer> e : maxLengths.entrySet()) {
            c.maxLength(e.getKey(), e.getValue());
        }
        // 新規行の売買金額・為替レートは 0 を不可とする（逆指値価格の 0 以下は E207 で扱う）
        boolean isNewRow = rules.isNew(row);
        c.decimal(ORDER_QTY, 16, 2, isNewRow);
        c.decimal(PRICE, 15, 8, isNewRow);
        c.decimal(STOP_PX, 15, 8, false);
        c.dateTime(TRANSACT_TIME);
        c.dateTime(EXPIRE_TIME);
        c.code(SIDE, Arrays.asList("1", "2"));
        c.code(ORD_TYPE, Arrays.asList(ORD_TYPE_MARKET, ORD_TYPE_LIMIT, ORD_TYPE_STOP));
        c.code(TIME_IN_FORCE, rules.getAllowedTimeInForce());
        if (!row.isBlank(SEND_TYPE) && !rules.isKnownSendType(row.get(SEND_TYPE))) {
            c.add(Jbord0001ErrorCode.E103, SEND_TYPE);
        }
        if (row.hasListId() && !rules.getListIdPattern().matcher(row.get(LIST_ID)).matches()) {
            c.add(Jbord0001ErrorCode.E103, LIST_ID);
        }
        if (isNewRow) {
            validateOrderCombination(row, c);
        }
        return Collections.unmodifiableList(errors);
    }

    /** E201〜E207（新規行のみ。§4 でキャンセル行の項目7〜9・14は「－」） */
    private void validateOrderCombination(Jbord0001OrderRow row, Checker c) {
        String ordType = row.get(ORD_TYPE);
        boolean isStop = ORD_TYPE_STOP.equals(ordType);
        if (isStop && row.isBlank(STOP_PX)) {
            c.add(Jbord0001ErrorCode.E201, STOP_PX);
        }
        if (!isStop && !row.isBlank(STOP_PX) && rules.isExtraPriceError()) {
            c.add(Jbord0001ErrorCode.E202, STOP_PX);
        }
        if (ORD_TYPE_LIMIT.equals(ordType) && row.isBlank(PRICE)) {
            c.add(Jbord0001ErrorCode.E203, PRICE);
        }
        boolean isMarketOrStop = ORD_TYPE_MARKET.equals(ordType) || isStop;
        if (isMarketOrStop && !row.isBlank(PRICE) && rules.isExtraPriceError()) {
            c.add(Jbord0001ErrorCode.E204, PRICE);
        }
        if ("6".equals(row.get(TIME_IN_FORCE)) && row.isBlank(EXPIRE_TIME)) {
            c.add(Jbord0001ErrorCode.E205, EXPIRE_TIME);
        }
        if (isStop && !"6".equals(row.get(TIME_IN_FORCE))) {
            c.add(Jbord0001ErrorCode.E206, TIME_IN_FORCE);
        }
        if (isStop && !row.isBlank(STOP_PX) && DECIMAL.matcher(row.get(STOP_PX)).matches()) {
            // TODO(S11) 通貨ペアの小数桁数の取得元は仕様書で未確定
            BigDecimal stopPx = new BigDecimal(row.get(STOP_PX));
            if (stopPx.signum() <= 0 || stopPx.scale() > rules.stopPxScaleOf(row.get(SYMBOL))) {
                c.add(Jbord0001ErrorCode.E207, STOP_PX);
            }
        }
    }

    /** 1行分のチェックとエラー蓄積 */
    private static final class Checker {
        private final Jbord0001OrderRow row;
        private final List<Jbord0001ValidationError> errors;

        private Checker(Jbord0001OrderRow row, List<Jbord0001ValidationError> errors) {
            this.row = row;
            this.errors = errors;
        }

        void add(Jbord0001ErrorCode code, int itemId) {
            errors.add(new Jbord0001ValidationError(row.getLineNo(), code, itemId));
        }

        void required(int id) {
            if (row.isBlank(id)) {
                add(Jbord0001ErrorCode.E101, id);
            }
        }

        void maxLength(int id, int max) {
            if (row.get(id).length() > max) {
                add(Jbord0001ErrorCode.E102, id);
            }
        }

        /**
         * 数字（precision 桁、うち小数 scale 桁）。形式不正は E103、桁あふれは E102。
         * mustBePositive の場合、0 も E103 とする（形式上は正しいが注文として不正な値。仕様書 §5.2 に無い追加チェック）。
         */
        void decimal(int id, int precision, int scale, boolean mustBePositive) {
            if (row.isBlank(id)) {
                return;
            }
            String v = row.get(id);
            if (!DECIMAL.matcher(v).matches()) {
                add(Jbord0001ErrorCode.E103, id);
                return;
            }
            int dot = v.indexOf('.');
            int intDigits = dot < 0 ? v.length() : dot;
            int fracDigits = dot < 0 ? 0 : v.length() - dot - 1;
            if (intDigits > precision - scale || fracDigits > scale) {
                add(Jbord0001ErrorCode.E102, id);
            } else if (mustBePositive && new BigDecimal(v).signum() == 0) {
                // DECIMAL は負数を受け付けないため、0 だけを判定すればよい
                add(Jbord0001ErrorCode.E103, id);
            }
        }

        /** 日時（yyyyMMdd-HH:mm:ss、ミリ秒付きも可）。TODO(S12) 項目別の書式は仕様書で未確定 */
        void dateTime(int id) {
            if (row.isBlank(id)) {
                return;
            }
            String v = row.get(id);
            if (!DATE_TIME.matcher(v).matches()) {
                add(Jbord0001ErrorCode.E103, id);
                return;
            }
            try {
                LocalDateTime.parse(v, v.length() > 17 ? DATE_TIME_MILLI : DATE_TIME_SEC);
            } catch (DateTimeParseException e) {
                add(Jbord0001ErrorCode.E103, id);
            }
        }

        void code(int id, java.util.Collection<String> allowed) {
            if (!row.isBlank(id) && !allowed.contains(row.get(id))) {
                add(Jbord0001ErrorCode.E103, id);
            }
        }
    }
}
