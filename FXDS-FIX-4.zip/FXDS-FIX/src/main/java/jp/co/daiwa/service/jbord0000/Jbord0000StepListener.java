package jp.co.daiwa.service.jbord0000;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.constant.FixConstants;

@Component
public class Jbord0000StepListener implements StepExecutionListener {

    /** Logger */
    private static final FixLogger logger = FixLogger.getLogger(Jbord0000StepListener.class);

    @Override
    public void beforeStep(StepExecution stepExecution) {
        // TODO 自動生成されたメソッド・スタブ

    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        if ("FAILED".equals(stepExecution.getExitStatus().getExitCode())) {
            logger.error(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_E001", FixConstants.Jbord0000_Name,
                    stepExecution);
        }
        if ("WARN".equals(stepExecution.getExitStatus().getExitCode())) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W001", FixConstants.Jbord0000_Name,
                    stepExecution);
        }
        ExitStatus exitStatus = stepExecution.getExitStatus();
        return exitStatus;
    }
}
