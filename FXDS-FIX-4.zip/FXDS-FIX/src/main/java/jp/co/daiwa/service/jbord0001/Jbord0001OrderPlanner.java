package jp.co.daiwa.service.jbord0001;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 発注要求ファイル1つを解析・チェックし、送信単位に分ける（仕様書 §5.1）。
 *
 * <p>1件でもエラーがあれば送信単位を返さない（ファイル全体を送信しない）。</p>
 */
public class Jbord0001OrderPlanner {

    private final Jbord0001ValidationRules rules;
    private final Jbord0001RowValidator rowValidator;
    private final Jbord0001GroupValidator groupValidator;
    private final boolean allow14Columns;

    public Jbord0001OrderPlanner(Jbord0001ValidationRules rules, Jbord0001GroupValidator groupValidator,
            boolean allow14Columns) {
        this.rules = rules;
        this.rowValidator = new Jbord0001RowValidator(rules);
        this.groupValidator = groupValidator;
        this.allow14Columns = allow14Columns;
    }

    /**
     * @param lines ファイルの全行
     * @return 計画（エラーがあれば送信単位は空）
     */
    public Plan plan(List<String> lines) {
        Jbord0001TsvSupport.ParseResult parsed = Jbord0001TsvSupport.parseOrderFile(lines, allow14Columns);
        List<Jbord0001ValidationError> errors = new ArrayList<>(parsed.getErrors());
        for (Jbord0001OrderRow row : parsed.getRows()) {
            errors.addAll(rowValidator.validate(row));
        }
        errors.addAll(groupValidator.validate(parsed.getRows()));
        if (!errors.isEmpty()) {
            errors.sort(Comparator.comparingInt(Jbord0001ValidationError::getLineNo));
            return new Plan(Collections.<Jbord0001SendUnit>emptyList(), errors);
        }
        return new Plan(toUnits(parsed.getRows()), Collections.<Jbord0001ValidationError>emptyList());
    }

    /** 送信単位に分ける（ファイル内の出現順。OCO は1行目の位置） */
    private List<Jbord0001SendUnit> toUnits(List<Jbord0001OrderRow> rows) {
        Map<String, List<Jbord0001OrderRow>> groups = Jbord0001GroupValidator.groupByListId(rows);
        Set<String> emitted = new HashSet<>();
        List<Jbord0001SendUnit> units = new ArrayList<>();
        for (Jbord0001OrderRow row : rows) {
            if (row.hasListId()) {
                String listId = row.get(Jbord0001OrderRow.LIST_ID);
                if (emitted.add(listId)) {
                    units.add(toOco(groups.get(listId)));
                }
            } else if (rules.isCancel(row)) {
                units.add(Jbord0001SendUnit.single(Jbord0001SendUnit.Kind.CANCEL, row));
            } else if (Jbord0001OrderRow.ORD_TYPE_LIMIT.equals(row.get(Jbord0001OrderRow.ORD_TYPE))) {
                units.add(Jbord0001SendUnit.single(Jbord0001SendUnit.Kind.NEW_EXISTING, row));
            } else {
                units.add(Jbord0001SendUnit.single(Jbord0001SendUnit.Kind.NEW_EXTENDED, row));
            }
        }
        return units;
    }

    /** 行の順序に関係なく、1注文目を損切り行にする（§6.3、T09） */
    private static Jbord0001SendUnit toOco(List<Jbord0001OrderRow> pair) {
        Jbord0001OrderRow first = pair.get(0);
        Jbord0001OrderRow second = pair.get(1);
        boolean isFirstStop = Jbord0001OrderRow.ORD_TYPE_STOP.equals(first.get(Jbord0001OrderRow.ORD_TYPE));
        return isFirstStop ? Jbord0001SendUnit.oco(first, second) : Jbord0001SendUnit.oco(second, first);
    }

    /** 計画結果 */
    public static final class Plan {
        private final List<Jbord0001SendUnit> units;
        private final List<Jbord0001ValidationError> errors;

        private Plan(List<Jbord0001SendUnit> units, List<Jbord0001ValidationError> errors) {
            this.units = Collections.unmodifiableList(units);
            this.errors = Collections.unmodifiableList(errors);
        }

        public List<Jbord0001SendUnit> getUnits() {
            return units;
        }

        public List<Jbord0001ValidationError> getErrors() {
            return errors;
        }

        public boolean hasErrors() {
            return !errors.isEmpty();
        }
    }
}
