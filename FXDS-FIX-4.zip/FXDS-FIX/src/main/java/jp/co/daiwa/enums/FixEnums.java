package jp.co.daiwa.enums;

public class FixEnums {
    /**
     * 送受信区分
     *
     */
    public static enum ReqResDivision implements FixEnum {
        SEND("1"), ACCPET("2");

        private String value;

        private ReqResDivision(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    /**
     * FIX電文ステータス区分 1:正常、2:異常
     *
     */
    public static enum StatusDivision implements FixEnum {
        NORMAL("1"), ANOMALY("2");

        private String value;

        private StatusDivision(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum OnOffFlg implements FixEnum {
        ON("1"), OFF("0");

        private String value;

        private OnOffFlg(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum PartyIdKeys implements FixEnum {
        PartyIdCnt("453"), PartyId("448"), PartyIdSource("447"), PartyRole("452"), PartyRoleQualifier("2376");

        private String value;

        private PartyIdKeys(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum OrderInfoKeys implements FixEnum {
        OrderId("37"), TradeId("1003");

        private String value;

        private OrderInfoKeys(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum MarketDataEntryKeys implements FixEnum {
        MDEntryType("269"), MDEntryID("278");

        private String value;

        private MarketDataEntryKeys(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum MsgName implements FixEnum {
        Logon("Logon"), MarketDataRequest("MarketDataRequest"), NewOrderSingle("NewOrderSingle"),
        OrderCancelReplaceRequest("OrderCancelReplaceRequest"), OrderCancelRequest("OrderCancelRequest");

        private String value;

        private MsgName(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum SettleType implements FixEnum {
        /** スポット */
        SPOT("SPOT"),
        /** アウトライト */
        OUTRIGHT("FX Outright"),
        /** スワップ */
        SWAP("FX Swap");

        private String value;

        private SettleType(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum ReceiverResult implements FixEnum {
        SUCCESS("0"), IO_EXECTION("1"), FX_SERVICE_EXECTION("2"),
        /** 想定外の例外（受信電文の解析エラー等） */
        UNEXPECTED_EXCEPTION("3");

        private String value;

        private ReceiverResult(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum WriterResult implements FixEnum {
        SUCCESS("0"), FAILED("1");

        private String value;

        private WriterResult(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }

    public static enum MsgType implements FixEnum {
        /** MarketDataRequest (Type V) */
        V("V"),
        /** MarketDataRequestReject (Type Y) */
        Y("Y"),
        /** MarketDataSnapshotFullRefresh (Type W) */
        W("W"),
        /** MarketDataIncrementalRefresh (Type X) */
        X("X"),
        /** QuoteRequest (Type R) */
        R("R"),
        /** Quote (Type S) */
        S("S"),
        /** QuoteAcknowledgement (Type b) */
        B("B"),
        /** MassQuote (Type i) */
        I("I"),
        /** QuoteCancel (Type Z) */
        Z("Z"),
        /** TradingSessionStatus (Type h) */
        H("H"),
        /** NewOrderSingle (Type D) */
        D("D"),
        /** NewOrderMLeg (Type AB) */
        AB("AB"),
        /** OrderCancelRequest (Type F) */
        F("F"),
        /** OrderCancelReject (Type 9) */
        TYPE_9("9"),
        /** OrderCancelReplaceRequest (Type G) */
        G("G"),
        /** ExecutionReport (Type 8) */
        TYPE_8("8"),
        /** NewOrderList (Type E) */
        E("E"),
        /** ListCancelRequest (Type K) */
        K("K"),
        /** ListStatus (Type N) */
        N("N"),
        /** Logon (Type A) */
        A("A"),
        /** Logout (Type 5) */
        TYPE_5("5"),
        /** ResendRequest (Type 2) */
        TYPE_2("2"),
        /** SequenceReset (Type 4) */
        TYPE_4("4"),
        /** Reject (Type 3) */
        TYPE_3("3"),
        /** TestRequest (Type 1) */
        TYPE_1("1"),
        /** Heartbeat (Type 0) */
        TYPE_0("0");

        private String value;

        private MsgType(String value) {
            this.value = value;
        }

        @Override
        public String value() {
            return value;
        }
    }
}
