package jp.co.daiwa.service.jbord0001;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.parser.FixSessionMsgParser;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dto.ExecutionReportDto;
import jp.co.daiwa.enums.FixEnums.MsgType;
import jp.co.daiwa.enums.FixSessionEnum.FixSession;
import jp.co.daiwa.service.FixEngineService;
import jp.co.daiwa.service.FixEngineService.MessageBean;
import jp.co.daiwa.service.jbord0001.Jbord0001FixMessages.NewOrderSingle;
import jp.co.daiwa.service.jbord0001.Jbord0001FixMessages.OrderCancelReplaceRequestBody;
import jp.co.daiwa.service.jbord0001.Jbord0001FixMessages.OrderCancelRequest;

/**
 * FIX電文（タブ区切り）をFIXエンジンへ送信する。
 */
public class Jbord0001Processor {

    private static final String TAB = "\t";
    private static final String MSG_TYPE_NEW_ORDER_LIST = "E";
    private static final FixLogger logger = FixLogger.getLogger(Jbord0001Processor.class);

    private final FixEngineService fixEngineService;
    private final Map<String, String> fixTagMap;
    private final String delimiter;

    public Jbord0001Processor(FixEngineService fixEngineService, Map<String, String> fixTagMap, String delimiter) {
        this.fixEngineService = fixEngineService;
        this.fixTagMap = fixTagMap;
        this.delimiter = delimiter;
    }

    /**
     * 電文を送信する。
     *
     * @param msg タブ区切りFIX電文
     * @return 送信できた場合は出力用電文（区切り文字変換済み）、送信できなかった場合は empty
     */
    public Optional<String> process(final String msg) {
        FixSessionMsgParser parser = new FixSessionMsgParser(TAB, fixTagMap);
        parser.parse(msg);
        ExecutionReportDto header = parser.extractData(ExecutionReportDto.class);
        String msgType = header.getMsgType();
        boolean sent;
        if (MsgType.D.value().equals(msgType)) {
            NewOrderSingle bean = parser.extractData(NewOrderSingle.class);
            List<String> dropped = Jbord0001TagDefinitions.missingInBean(msg, bean);
            if (dropped.isEmpty()) {
                // 電文→Bean に加え、送信時と同じ Bean→送信用電文 の変換でも値が残るか確認する
                MessageBean converted = fixEngineService.toMessageBean(bean);
                dropped = Jbord0001TagDefinitions.missingValues(msg, tag -> converted.getBodyValue(Integer.valueOf(tag)));
            }
            if (dropped.isEmpty()) {
                sent = fixEngineService.sendMsg(bean, FixSession.ORDER, header.getClOrdID());
            } else {
                // P-04 タグ定義の不備で値が落ちた電文（StopPx なしの逆指値など）は送らない
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                        "タグの値が電文変換で失われたため送信しません（fix.tag の定義を確認）: タグ=" + dropped + " " + header.getClOrdID());
                sent = false;
            }
        } else if (MsgType.G.value().equals(msgType)) {
            sent = fixEngineService.sendMsg(parser.extractData(OrderCancelReplaceRequestBody.class), FixSession.ORDER, header.getClOrdID());
        } else if (MsgType.F.value().equals(msgType)) {
            sent = fixEngineService.sendMsg(parser.extractData(OrderCancelRequest.class), FixSession.ORDER, header.getClOrdID());
        } else if (MSG_TYPE_NEW_ORDER_LIST.equals(msgType)) {
            // TODO(TBD-10) NewOrderList（繰り返しグループ）を FixEngineService で送れるか未確認（修正一覧 F02）。
            // 確認できるまでは送信せず、未送信（err_）とする。
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                    "OCOパターンA（35=E）は未対応のため送信しません。oco.message_format=B を検討してください: " + header.getClOrdID());
            sent = false;
        } else {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", "未対応のMsgType: " + msgType);
            sent = false;
        }
        return sent ? Optional.of(Jbord0001TsvSupport.toDelimited(msg, delimiter)) : Optional.empty();
    }
}
