package jp.co.daiwa.service.jbord0001;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * 改修で追加したタグ（99・66・1385）の定義チェック（P-04）。
 *
 * <p>送信電文は「タブ区切り電文 → Bean（FixSessionMsgParser）→ 送信用 MessageBean（FixBeanUtils）」と
 * fix-tag.properties のタグ定義（名前→番号）を介して変換される。定義が無い、または名前が Bean の
 * プロパティ名と一致しないと値が黙って落ち、逆指値が StopPx なしで送信される。</p>
 */
public final class Jbord0001TagDefinitions {

    /** 逆指値で必須（プロパティ名 → タグ番号） */
    private static final Map<String, String> STOP_TAGS;
    /** OCO パターンB で必須 */
    private static final Map<String, String> OCO_TAGS;
    /** 送信直前チェックの対象（タグ番号 → Bean の値） */
    private static final Map<String, Function<Jbord0001FixMessages.NewOrderSingle, String>> BEAN_VALUES;
    /** 送信直前チェックの対象タグ番号 */
    private static final List<String> CHECKED_TAGS = Collections.unmodifiableList(Arrays.asList("99", "66", "1385"));

    static {
        Map<String, String> stop = new LinkedHashMap<>();
        stop.put("stopPx", "99");
        STOP_TAGS = Collections.unmodifiableMap(stop);
        Map<String, String> oco = new LinkedHashMap<>();
        oco.put("listID", "66");
        oco.put("contingencyType", "1385");
        OCO_TAGS = Collections.unmodifiableMap(oco);
        Map<String, Function<Jbord0001FixMessages.NewOrderSingle, String>> values = new LinkedHashMap<>();
        values.put("99", Jbord0001FixMessages.NewOrderSingle::getStopPx);
        values.put("66", Jbord0001FixMessages.NewOrderSingle::getListID);
        values.put("1385", Jbord0001FixMessages.NewOrderSingle::getContingencyType);
        BEAN_VALUES = Collections.unmodifiableMap(values);
    }

    private static final String TAB = "\t";
    private static final char EQUAL = '=';

    private Jbord0001TagDefinitions() {
    }

    /**
     * タグ定義（fix.tag）の不足を返す。
     *
     * @param fixTagMap タグ定義（名前 → タグ番号）
     * @param requireOcoTags OCO（パターンB）を送る設定か
     * @return 問題の説明（無ければ空）
     */
    public static List<String> findProblems(Map<String, String> fixTagMap, boolean requireOcoTags) {
        List<String> problems = new ArrayList<>();
        check(fixTagMap, STOP_TAGS, problems);
        if (requireOcoTags) {
            check(fixTagMap, OCO_TAGS, problems);
        }
        return Collections.unmodifiableList(problems);
    }

    /**
     * 電文に値があるのに Bean に入らなかったタグを返す（送信直前の安全確認）。
     *
     * @param tabSeparated タブ区切り電文
     * @param bean 電文から変換した Bean
     * @return 値が落ちたタグ番号（無ければ空）
     */
    public static List<String> missingInBean(String tabSeparated, Jbord0001FixMessages.NewOrderSingle bean) {
        return missingValues(tabSeparated, tag -> BEAN_VALUES.get(tag).apply(bean));
    }

    /**
     * 電文に値がある 99・66・1385 のうち、変換後に値が無いタグを返す。
     *
     * @param tabSeparated タブ区切り電文
     * @param convertedValueOf タグ番号 → 変換後の値（送信用 MessageBean の値など）
     * @return 値が落ちたタグ番号（無ければ空）
     */
    public static List<String> missingValues(String tabSeparated, Function<String, String> convertedValueOf) {
        List<String> missing = new ArrayList<>();
        for (String field : tabSeparated.split(TAB)) {
            int eq = field.indexOf(EQUAL);
            if (eq < 1 || eq == field.length() - 1) {
                continue;
            }
            String tag = field.substring(0, eq);
            if (CHECKED_TAGS.contains(tag) && isBlank(convertedValueOf.apply(tag))) {
                missing.add(tag);
            }
        }
        return Collections.unmodifiableList(missing);
    }

    private static void check(Map<String, String> fixTagMap, Map<String, String> required, List<String> problems) {
        for (Map.Entry<String, String> r : required.entrySet()) {
            List<String> names = namesOf(fixTagMap, r.getValue());
            if (names.isEmpty()) {
                problems.add("タグ " + r.getValue() + "（" + r.getKey() + "）が fix.tag に定義されていません");
            } else if (names.size() > 1) {
                // 電文→Bean の変換は後勝ち、Bean→送信は名前で引くため、どの名前が使われるか不定になる
                problems.add("タグ " + r.getValue() + " が重複して定義されています: " + names);
            } else if (!names.get(0).equalsIgnoreCase(r.getKey())) {
                problems.add("タグ " + r.getValue() + " の名前が " + names.get(0) + " です（" + r.getKey() + " にしてください）");
            }
        }
    }

    private static List<String> namesOf(Map<String, String> fixTagMap, String tagNumber) {
        List<String> names = new ArrayList<>();
        for (Map.Entry<String, String> e : fixTagMap.entrySet()) {
            if (e.getValue() != null && tagNumber.equals(e.getValue().trim())) {
                names.add(e.getKey());
            }
        }
        Collections.sort(names);
        return names;
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
