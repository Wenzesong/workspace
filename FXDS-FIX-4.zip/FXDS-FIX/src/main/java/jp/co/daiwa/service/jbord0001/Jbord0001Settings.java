package jp.co.daiwa.service.jbord0001;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * jbord0001 の設定値。
 *
 * <p>ファイルパス等は jbord0000 と同じプロパティキーを使う（FixEventHandler_order と共有しているため）。
 * jbord0001 で追加した項目のみ {@code job.jbord0001.*} キーとし、既定値を持たせている。
 * 発注TSVの入力チェック・電文形式に関する設定は {@link Jbord0001OrderSettings}。</p>
 */
@Component
@Scope("step")
public class Jbord0001Settings {

    private final String stopFile;
    private final String inputPath;
    private final String salesOrderPath;
    private final String dealerOrderPath;
    private final String connectFile;
    private final String disconnectFile;
    private final String connectResFile;
    private final String disconnectResFile;
    private final String resetConnectFile;
    private final Integer receiveMsgPoolSize;
    private final String outputPath;
    private final String outputFileName;
    private final int beforeStopWaitSeconds;
    private final int noreplyPoolSize;
    private final int noreplySeconds;
    private final String usernotificationPath;
    private final String clientPath;
    private final String clientFile;
    private final Map<String, String> fixTagMap;
    private final long pollIntervalMillis;
    private final int shutdownMarginSeconds;
    private final long requestSettleMillis;
    private final String sentListIdDir;
    private final boolean reconnectDiscardPending;
    private final long errorBackoffMaxMillis;
    private final int errorMaxConsecutive;
    private final int logonWaitSeconds;
    private final long requestHoldMaxMillis;

    @javax.inject.Inject
    public Jbord0001Settings(
            @Value("${job.jbord0000.stop.file}") String stopFile,
            @Value("${job.jbord0000.input.path}") String inputPath,
            @Value("${sales.order.input.path}") String salesOrderPath,
            @Value("${dealer.order.input.path}") String dealerOrderPath,
            @Value("${job.jbord0000.connect.file}") String connectFile,
            @Value("${job.jbord0000.disconnect.file}") String disconnectFile,
            @Value("${job.jbord0000.connect.res.file}") String connectResFile,
            @Value("${job.jbord0000.disconnect.res.file}") String disconnectResFile,
            @Value("${job.jbord0000.connect.reset.file}") String resetConnectFile,
            @Value("#{jobParameters['receiveMsgPoolSize']}") Integer receiveMsgPoolSize,
            @Value("${job.jbord0000.output.path}") String outputPath,
            @Value("${job.jbord0000.output.file.name}") String outputFileName,
            @Value("${before.stop.wait.seconds}") int beforeStopWaitSeconds,
            @Value("${order.noreply.thread.pool.size}") int noreplyPoolSize,
            @Value("${order.noreply.seconds}") int noreplySeconds,
            @Value("${usernotification.file.path}") String usernotificationPath,
            @Value("${resorder.client.file.path}") String clientPath,
            @Value("${resorder.client.file}") String clientFile,
            @Value("#{${fix.tag}}") Map<String, String> fixTagMap,
            @Value("${job.jbord0001.poll.interval.millis:200}") long pollIntervalMillis,
            @Value("${job.jbord0001.shutdown.margin.seconds:10}") int shutdownMarginSeconds,
            @Value("${job.jbord0001.request.settle.millis:500}") long requestSettleMillis,
            @Value("${job.jbord0001.sent.listid.dir}") String sentListIdDir,
            @Value("${job.jbord0001.reconnect.discard.pending:false}") boolean reconnectDiscardPending,
            @Value("${job.jbord0001.error.backoff.max.millis:30000}") long errorBackoffMaxMillis,
            @Value("${job.jbord0001.error.max.consecutive:0}") int errorMaxConsecutive,
            @Value("${job.jbord0001.logon.wait.seconds:10}") int logonWaitSeconds,
            @Value("${job.jbord0001.request.hold.max.millis:10000}") long requestHoldMaxMillis) {
        requirePositive("order.noreply.thread.pool.size", noreplyPoolSize);
        requirePositive("job.jbord0001.poll.interval.millis", pollIntervalMillis);
        requireNotNegative("order.noreply.seconds", noreplySeconds);
        requireNotNegative("before.stop.wait.seconds", beforeStopWaitSeconds);
        requireNotNegative("job.jbord0001.shutdown.margin.seconds", shutdownMarginSeconds);
        requireNotNegative("job.jbord0001.request.settle.millis", requestSettleMillis);
        requireNotNegative("job.jbord0001.error.max.consecutive", errorMaxConsecutive);
        // ログオンは非同期のため 0 秒では必ず確認できない
        requirePositive("job.jbord0001.logon.wait.seconds", logonWaitSeconds);
        requireNotNegative("job.jbord0001.request.hold.max.millis", requestHoldMaxMillis);
        if (errorBackoffMaxMillis < pollIntervalMillis) {
            throw new IllegalArgumentException("job.jbord0001.error.backoff.max.millis must be >= poll.interval.millis: "
                    + errorBackoffMaxMillis);
        }
        if (sentListIdDir == null || sentListIdDir.trim().isEmpty()) {
            throw new IllegalArgumentException("job.jbord0001.sent.listid.dir must not be empty");
        }
        this.stopFile = stopFile;
        this.inputPath = inputPath;
        this.salesOrderPath = salesOrderPath;
        this.dealerOrderPath = dealerOrderPath;
        this.connectFile = connectFile;
        this.disconnectFile = disconnectFile;
        this.connectResFile = connectResFile;
        this.disconnectResFile = disconnectResFile;
        this.resetConnectFile = resetConnectFile;
        this.receiveMsgPoolSize = receiveMsgPoolSize;
        this.outputPath = outputPath;
        this.outputFileName = outputFileName;
        this.beforeStopWaitSeconds = beforeStopWaitSeconds;
        this.noreplyPoolSize = noreplyPoolSize;
        this.noreplySeconds = noreplySeconds;
        this.usernotificationPath = usernotificationPath;
        this.clientPath = clientPath;
        this.clientFile = clientFile;
        this.fixTagMap = Collections.unmodifiableMap(new HashMap<>(fixTagMap));
        this.pollIntervalMillis = pollIntervalMillis;
        this.shutdownMarginSeconds = shutdownMarginSeconds;
        this.requestSettleMillis = requestSettleMillis;
        this.sentListIdDir = sentListIdDir.trim();
        this.reconnectDiscardPending = reconnectDiscardPending;
        this.errorBackoffMaxMillis = errorBackoffMaxMillis;
        this.errorMaxConsecutive = errorMaxConsecutive;
        this.logonWaitSeconds = logonWaitSeconds;
        this.requestHoldMaxMillis = requestHoldMaxMillis;
    }

    private static void requirePositive(String key, long value) {
        if (value <= 0) {
            throw new IllegalArgumentException(key + " must be positive: " + value);
        }
    }

    private static void requireNotNegative(String key, long value) {
        if (value < 0) {
            throw new IllegalArgumentException(key + " must not be negative: " + value);
        }
    }

    public String getStopFile() {
        return stopFile;
    }

    public String getInputPath() {
        return inputPath;
    }

    public String getSalesOrderPath() {
        return salesOrderPath;
    }

    public String getDealerOrderPath() {
        return dealerOrderPath;
    }

    public String getConnectFile() {
        return connectFile;
    }

    public String getDisconnectFile() {
        return disconnectFile;
    }

    public String getConnectResFile() {
        return connectResFile;
    }

    public String getDisconnectResFile() {
        return disconnectResFile;
    }

    public String getResetConnectFile() {
        return resetConnectFile;
    }

    public Integer getReceiveMsgPoolSize() {
        return receiveMsgPoolSize;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public String getOutputFileName() {
        return outputFileName;
    }

    public int getBeforeStopWaitSeconds() {
        return beforeStopWaitSeconds;
    }

    public int getNoreplyPoolSize() {
        return noreplyPoolSize;
    }

    public int getNoreplySeconds() {
        return noreplySeconds;
    }

    public String getUsernotificationPath() {
        return usernotificationPath;
    }

    public String getClientPath() {
        return clientPath;
    }

    public String getClientFile() {
        return clientFile;
    }

    public Map<String, String> getFixTagMap() {
        return fixTagMap;
    }

    public long getPollIntervalMillis() {
        return pollIntervalMillis;
    }

    public int getShutdownMarginSeconds() {
        return shutdownMarginSeconds;
    }

    /** 発注要求ファイルの安定待ち時間（P-08） */
    public long getRequestSettleMillis() {
        return requestSettleMillis;
    }

    /** 送信済み組番号の保存ディレクトリ（P-06） */
    public String getSentListIdDir() {
        return sentListIdDir;
    }

    /** 再接続時に未処理の発注要求を err_ へ移すか（P-09。既定 false＝再接続後に送信する） */
    public boolean isReconnectDiscardPending() {
        return reconnectDiscardPending;
    }

    /** 例外が続く場合の待ち時間の上限（P-11） */
    public long getErrorBackoffMaxMillis() {
        return errorBackoffMaxMillis;
    }

    /** 連続例外の上限。超えたら異常終了（P-11。0 は無制限） */
    public int getErrorMaxConsecutive() {
        return errorMaxConsecutive;
    }

    /** 接続要求後、ログオン完了を待つ秒数（P-20） */
    public int getLogonWaitSeconds() {
        return logonWaitSeconds;
    }

    /** 書き込み中の発注要求ファイルが、後から置かれたファイルを保留できる時間（H-2） */
    public long getRequestHoldMaxMillis() {
        return requestHoldMaxMillis;
    }
}
