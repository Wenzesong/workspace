package jp.co.daiwa.service.jbord0001;

/**
 * FixSessionMsgParser#extractData のマッピング先（送信電文ボディ）。
 *
 * <p>リフレクションでプロパティを設定するため JavaBeans 形式とする。項目は jbord0000 と同一。</p>
 */
public final class Jbord0001FixMessages {

    private Jbord0001FixMessages() {
    }

    /** NewOrderSingle (MsgType=D) */
    public static class NewOrderSingle {
        private String msgType;
        private String clOrdID;
        private String symbol;
        private String side;
        private String transactTime;
        private String orderQty;
        private String settlType8;
        private String ordType;
        private String currency;
        private String price;
        private String timeInForce;
        private String expireTime;
        private String minQty;
        /** 99 StopPx（改修2）。TODO(F19) fix-tag.properties にタグ定義を追加し、FixEngineService が送るか確認 */
        private String stopPx;
        /** 66 ListID（改修3 パターンB） */
        private String listID;
        /** 1385 ContingencyType（改修3 パターンB） */
        private String contingencyType;

        public String getMsgType() {
            return msgType;
        }

        public void setMsgType(String msgType) {
            this.msgType = msgType;
        }

        public String getClOrdID() {
            return clOrdID;
        }

        public void setClOrdID(String clOrdID) {
            this.clOrdID = clOrdID;
        }

        public String getSymbol() {
            return symbol;
        }

        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }

        public String getSide() {
            return side;
        }

        public void setSide(String side) {
            this.side = side;
        }

        public String getTransactTime() {
            return transactTime;
        }

        public void setTransactTime(String transactTime) {
            this.transactTime = transactTime;
        }

        public String getOrderQty() {
            return orderQty;
        }

        public void setOrderQty(String orderQty) {
            this.orderQty = orderQty;
        }

        public String getSettlType8() {
            return settlType8;
        }

        public void setSettlType8(String settlType) {
            this.settlType8 = settlType;
        }

        public String getOrdType() {
            return ordType;
        }

        public void setOrdType(String ordType) {
            this.ordType = ordType;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getTimeInForce() {
            return timeInForce;
        }

        public void setTimeInForce(String timeInForce) {
            this.timeInForce = timeInForce;
        }

        public String getExpireTime() {
            return expireTime;
        }

        public void setExpireTime(String expireTime) {
            this.expireTime = expireTime;
        }

        public String getMinQty() {
            return minQty;
        }

        public void setMinQty(String minQty) {
            this.minQty = minQty;
        }

        public String getStopPx() {
            return stopPx;
        }

        public void setStopPx(String stopPx) {
            this.stopPx = stopPx;
        }

        public String getListID() {
            return listID;
        }

        public void setListID(String listID) {
            this.listID = listID;
        }

        public String getContingencyType() {
            return contingencyType;
        }

        public void setContingencyType(String contingencyType) {
            this.contingencyType = contingencyType;
        }
    }

    /** OrderCancelRequest (MsgType=F) */
    public static class OrderCancelRequest {
        private String msgType;
        private String clOrdID;
        private String origClOrdID;
        private String symbol;
        private String transactTime;

        public String getMsgType() {
            return msgType;
        }

        public void setMsgType(String msgType) {
            this.msgType = msgType;
        }

        public String getClOrdID() {
            return clOrdID;
        }

        public void setClOrdID(String clOrdID) {
            this.clOrdID = clOrdID;
        }

        public String getOrigClOrdID() {
            return origClOrdID;
        }

        public void setOrigClOrdID(String origClOrdID) {
            this.origClOrdID = origClOrdID;
        }

        public String getSymbol() {
            return symbol;
        }

        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }

        public String getTransactTime() {
            return transactTime;
        }

        public void setTransactTime(String transactTime) {
            this.transactTime = transactTime;
        }
    }

    /** OrderCancelReplaceRequest (MsgType=G) */
    public static class OrderCancelReplaceRequestBody {
        private String msgType;
        private String origClOrdID;
        private String clOrdID;
        private String symbol;
        private String transactTime;
        private String orderQty;
        private String price;
        private String expireTime;

        public String getMsgType() {
            return msgType;
        }

        public void setMsgType(String msgType) {
            this.msgType = msgType;
        }

        public String getOrigClOrdID() {
            return origClOrdID;
        }

        public void setOrigClOrdID(String origClOrdID) {
            this.origClOrdID = origClOrdID;
        }

        public String getClOrdID() {
            return clOrdID;
        }

        public void setClOrdID(String clOrdID) {
            this.clOrdID = clOrdID;
        }

        public String getSymbol() {
            return symbol;
        }

        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }

        public String getTransactTime() {
            return transactTime;
        }

        public void setTransactTime(String transactTime) {
            this.transactTime = transactTime;
        }

        public String getOrderQty() {
            return orderQty;
        }

        public void setOrderQty(String orderQty) {
            this.orderQty = orderQty;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getExpireTime() {
            return expireTime;
        }

        public void setExpireTime(String expireTime) {
            this.expireTime = expireTime;
        }
    }
}
