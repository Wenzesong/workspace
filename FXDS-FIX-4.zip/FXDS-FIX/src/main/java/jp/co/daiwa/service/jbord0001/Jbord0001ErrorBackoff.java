package jp.co.daiwa.service.jbord0001;

/**
 * 監視ループで例外が続く場合の待ち時間（P-11）。
 *
 * <p>連続失敗ごとに待ち時間を倍にし（上限あり）、ログの洪水と無駄な再試行を防ぐ。
 * 連続失敗の上限に達したかも判定する（0 は無制限）。監視スレッド1本から使う。</p>
 */
public final class Jbord0001ErrorBackoff {

    private final long baseMillis;
    private final long maxMillis;
    private final int maxConsecutive;
    private int consecutiveFailures;

    /**
     * @param baseMillis 最初の待ち時間（1 以上）
     * @param maxMillis 待ち時間の上限（baseMillis 以上）
     * @param maxConsecutive 連続失敗の上限（0 は無制限）
     */
    public Jbord0001ErrorBackoff(long baseMillis, long maxMillis, int maxConsecutive) {
        if (baseMillis < 1) {
            throw new IllegalArgumentException("baseMillis must be positive: " + baseMillis);
        }
        if (maxMillis < baseMillis) {
            throw new IllegalArgumentException("maxMillis must be >= baseMillis: " + maxMillis);
        }
        if (maxConsecutive < 0) {
            throw new IllegalArgumentException("maxConsecutive must not be negative: " + maxConsecutive);
        }
        this.baseMillis = baseMillis;
        this.maxMillis = maxMillis;
        this.maxConsecutive = maxConsecutive;
    }

    /**
     * 失敗を記録する。
     *
     * @return 次の試行までの待ち時間（ミリ秒）
     */
    public long onFailure() {
        if (consecutiveFailures < Integer.MAX_VALUE) {
            consecutiveFailures++;
        }
        long delay = baseMillis;
        for (int i = 1; i < consecutiveFailures && delay < maxMillis; i++) {
            delay *= 2;
        }
        return Math.min(delay, maxMillis);
    }

    /** 成功を記録する（待ち時間を最初に戻す） */
    public void onSuccess() {
        consecutiveFailures = 0;
    }

    public int getConsecutiveFailures() {
        return consecutiveFailures;
    }

    /** 連続失敗の上限に達したか */
    public boolean isLimitReached() {
        return maxConsecutive > 0 && consecutiveFailures >= maxConsecutive;
    }
}
