package jp.co.daiwa.enums;

import java.util.Arrays;

public class FixSessionEnum {
    /**
     * FIXセッション接続の列挙型クラス
     *
     */
    public enum FixSession {
        RATE("1", "ストリーミングレートセッション"), //
        ORDER("2", "発注要求セッション"), //
        TRADE("3", "ST約定セッション");

        private String code;
        private String name;

        /**
         * コンストラクタ
         *
         */
        private FixSession(String code, String name) {
            this.code = code;
            this.name = name;
        }

        /**
         * コードを取得する。
         *
         * @return コード
         */
        public String getCode() {
            return this.code;
        }

        /**
         * 名称を取得する。
         *
         * @return 名称
         */
        public String getName() {
            return this.name;
        }

        /**
         * コード値より取得
         *
         * @param code
         * @return
         */
        public static FixSession getByCode(String code) {
            return Arrays.stream(FixSession.values()).filter(data -> data.getCode().equals(code)).findFirst()
                    .orElse(null);
        }
    }
}
