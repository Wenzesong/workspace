package jp.co.daiwa.service.jbord0000;

import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Value;

import jp.co.daiwa.common.parser.FixSessionMsgParser;
import jp.co.daiwa.dto.ExecutionReportDto;
import jp.co.daiwa.enums.FixEnums.MsgType;
import jp.co.daiwa.enums.FixSessionEnum.FixSession;
import jp.co.daiwa.service.FixEngineService;


public class Jbord0000Processor {
    @Inject
    @Named("fixEngineService")
    private FixEngineService fixEngineService;

    @Value("#{${fix.tag}}")
    private Map<String, String> fixTagMap;

    @Value("${fix.msg.delimitr}")
    private String delimitr;

    public String process(final String msg) {
        boolean sendFlag = false;
        FixSessionMsgParser parser = new FixSessionMsgParser("\t", fixTagMap);
        parser.parse(msg);
        ExecutionReportDto fixMsg = parser.extractData(ExecutionReportDto.class);
        if (MsgType.D.value().equals(fixMsg.getMsgType())) {
            sendFlag = fixEngineService.sendMsg(parser.extractData(NewOrderSingle.class), FixSession.ORDER, fixMsg.getClOrdID());
        } else if (MsgType.G.value().equals(fixMsg.getMsgType())) {
            sendFlag = fixEngineService.sendMsg(parser.extractData(OrderCancelReplaceRequestBody.class), FixSession.ORDER, fixMsg.getClOrdID());
        } else if (MsgType.F.value().equals(fixMsg.getMsgType())) {
            sendFlag = fixEngineService.sendMsg(parser.extractData(OrderCancelRequest.class), FixSession.ORDER, fixMsg.getClOrdID());
        }
        // MSG構成しなおし
        // 「有効期限：126」を取り除く
        String[] msgs = msg.split("\t");
        StringBuilder sb = new StringBuilder();
        for (String m : msgs) {
            sb.append(m);
            sb.append(delimitr);
        }
        int lastPoint = sb.lastIndexOf(delimitr);
        return sendFlag ? sb.substring(0, lastPoint) : null;
    }

    public static class NewOrderSingle {
        private String msgType;
        private String clOrdID;
        private String symbol;
        private String side;
        private String transactTime;
        private String orderQty;
        private String settlType8;
        private String ordType;
        private String currency;
        private String price;
        private String timeInForce;
        private String expireTime;
        private String minQty;

        public String getMsgType() {
            return msgType;
        }

        public void setMsgType(String msgType) {
            this.msgType = msgType;
        }

        public String getClOrdID() {
            return clOrdID;
        }

        public void setClOrdID(String clOrdID) {
            this.clOrdID = clOrdID;
        }

        public String getSymbol() {
            return symbol;
        }

        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }

        public String getSide() {
            return side;
        }

        public void setSide(String side) {
            this.side = side;
        }

        public String getTransactTime() {
            return transactTime;
        }

        public void setTransactTime(String transactTime) {
            this.transactTime = transactTime;
        }

        public String getOrderQty() {
            return orderQty;
        }

        public void setOrderQty(String orderQty) {
            this.orderQty = orderQty;
        }

        public String getSettlType8() {
            return settlType8;
        }

        public void setSettlType8(String settlType) {
            this.settlType8 = settlType;
        }

        public String getOrdType() {
            return ordType;
        }

        public void setOrdType(String ordType) {
            this.ordType = ordType;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getTimeInForce() {
            return timeInForce;
        }

        public void setTimeInForce(String timeInForce) {
            this.timeInForce = timeInForce;
        }

        public String getExpireTime() {
            return expireTime;
        }

        public void setExpireTime(String expireTime) {
            this.expireTime = expireTime;
        }

        public String getMinQty() {
            return minQty;
        }

        public void setMinQty(String minQty) {
            this.minQty = minQty;
        }
    }

    public static class OrderCancelRequest {
        private String msgType;
        private String clOrdID;
        private String origClOrdID;
        private String symbol;
        private String transactTime;

        public String getMsgType() {
            return msgType;
        }

        public void setMsgType(String msgType) {
            this.msgType = msgType;
        }

        public String getClOrdID() {
            return clOrdID;
        }

        public void setClOrdID(String clOrdID) {
            this.clOrdID = clOrdID;
        }

        public String getOrigClOrdID() {
            return origClOrdID;
        }

        public void setOrigClOrdID(String origClOrdID) {
            this.origClOrdID = origClOrdID;
        }

        public String getSymbol() {
            return symbol;
        }

        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }

        public String getTransactTime() {
            return transactTime;
        }

        public void setTransactTime(String transactTime) {
            this.transactTime = transactTime;
        }
    }

    public static class OrderCancelReplaceRequestBody {
        private String msgType;
        private String origClOrdID;
        private String clOrdID;
        private String symbol;
        private String transactTime;
        private String orderQty;
        private String price;
        private String expireTime;

        public String getMsgType() {
            return msgType;
        }

        public void setMsgType(String msgType) {
            this.msgType = msgType;
        }

        public String getOrigClOrdID() {
            return origClOrdID;
        }

        public void setOrigClOrdID(String origClOrdID) {
            this.origClOrdID = origClOrdID;
        }

        public String getClOrdID() {
            return clOrdID;
        }

        public void setClOrdID(String clOrdID) {
            this.clOrdID = clOrdID;
        }

        public String getSymbol() {
            return symbol;
        }

        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }

        public String getTransactTime() {
            return transactTime;
        }

        public void setTransactTime(String transactTime) {
            this.transactTime = transactTime;
        }

        public String getOrderQty() {
            return orderQty;
        }

        public void setOrderQty(String orderQty) {
            this.orderQty = orderQty;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getExpireTime() {
            return expireTime;
        }

        public void setExpireTime(String expireTime) {
            this.expireTime = expireTime;
        }
    }

    public FixEngineService getFixEngineService() {
        return fixEngineService;
    }

    public void setFixEngineService(FixEngineService fixEngineService) {
        this.fixEngineService = fixEngineService;
    }

    public Map<String, String> getFixTagMap() {
        return fixTagMap;
    }

    public void setFixTagMap(Map<String, String> fixTagMap) {
        this.fixTagMap = fixTagMap;
    }

    public String getDelimitr() {
        return delimitr;
    }

    public void setDelimitr(String delimitr) {
        this.delimitr = delimitr;
    }
}
