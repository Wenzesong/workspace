package jp.co.daiwa.service.jbord0001;

import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.EXPIRE_TIME;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.LIST_ID;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORDER_QTY;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORD_TYPE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORD_TYPE_LIMIT;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORD_TYPE_STOP;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.SIDE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.SYMBOL;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.TIME_IN_FORCE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * 組チェック（仕様書 §5.3：E301〜E304）。エラーの場合は組の全行をエラー行にする。
 */
public class Jbord0001GroupValidator {

    /** 組の2行で一致すべき項目（E302） */
    private static final List<Integer> MUST_MATCH = Arrays.asList(SYMBOL, SIDE, ORDER_QTY, TIME_IN_FORCE, EXPIRE_TIME);
    private static final int GROUP_SIZE = 2;

    private final Jbord0001ValidationRules rules;
    private final Predicate<String> isSentListId;
    private final boolean isOcoSendable;

    /**
     * @param rules 設定値
     * @param isSentListId 送信済みの組番号か（E304）
     * @param isOcoSendable 設定された OCO 電文形式を送信できるか（できなければ E305）
     */
    public Jbord0001GroupValidator(Jbord0001ValidationRules rules, Predicate<String> isSentListId,
            boolean isOcoSendable) {
        this.rules = rules;
        this.isSentListId = isSentListId;
        this.isOcoSendable = isOcoSendable;
    }

    /**
     * @param rows ファイル内の全行
     * @return エラー（無ければ空）
     */
    public List<Jbord0001ValidationError> validate(List<Jbord0001OrderRow> rows) {
        List<Jbord0001ValidationError> errors = new ArrayList<>();
        for (Map.Entry<String, List<Jbord0001OrderRow>> group : groupByListId(rows).entrySet()) {
            validateGroup(group.getKey(), group.getValue(), errors);
        }
        return Collections.unmodifiableList(errors);
    }

    /** 組番号ごとの行（ファイル内の出現順） */
    public static Map<String, List<Jbord0001OrderRow>> groupByListId(List<Jbord0001OrderRow> rows) {
        Map<String, List<Jbord0001OrderRow>> groups = new LinkedHashMap<>();
        for (Jbord0001OrderRow row : rows) {
            if (row.hasListId()) {
                groups.computeIfAbsent(row.get(LIST_ID), k -> new ArrayList<>()).add(row);
            }
        }
        return groups;
    }

    private void validateGroup(String listId, List<Jbord0001OrderRow> group, List<Jbord0001ValidationError> errors) {
        if (!isOcoSendable) {
            // P-05 送信段階で失敗すると、同じファイルの先行注文だけが送信済みになるため、ここで止める
            addAll(errors, group, Jbord0001ErrorCode.E305, LIST_ID);
            return;
        }
        if (group.stream().anyMatch(rules::isCancel)) {
            // TODO(TBD-07) OCOキャンセルのTSVの書き方・電文が未確定のため受け付けない
            addAll(errors, group, Jbord0001ErrorCode.E103, LIST_ID);
            return;
        }
        if (group.size() != GROUP_SIZE) {
            addAll(errors, group, Jbord0001ErrorCode.E301, LIST_ID);
            return;
        }
        Jbord0001OrderRow a = group.get(0);
        Jbord0001OrderRow b = group.get(1);
        for (int id : MUST_MATCH) {
            if (!a.get(id).equals(b.get(id))) {
                addAll(errors, group, Jbord0001ErrorCode.E302, id);
                break;
            }
        }
        boolean isStopAndLimit = (ORD_TYPE_STOP.equals(a.get(ORD_TYPE)) && ORD_TYPE_LIMIT.equals(b.get(ORD_TYPE)))
                || (ORD_TYPE_LIMIT.equals(a.get(ORD_TYPE)) && ORD_TYPE_STOP.equals(b.get(ORD_TYPE)));
        if (!isStopAndLimit) {
            addAll(errors, group, Jbord0001ErrorCode.E303, ORD_TYPE);
        }
        if (isSentListId.test(listId)) {
            addAll(errors, group, Jbord0001ErrorCode.E304, LIST_ID);
        }
    }

    private static void addAll(List<Jbord0001ValidationError> errors, List<Jbord0001OrderRow> group,
            Jbord0001ErrorCode code, int itemId) {
        for (Jbord0001OrderRow row : group) {
            errors.add(new Jbord0001ValidationError(row.getLineNo(), code, itemId));
        }
    }
}
