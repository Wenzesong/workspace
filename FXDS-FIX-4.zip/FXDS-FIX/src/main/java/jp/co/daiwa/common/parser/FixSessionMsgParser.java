package jp.co.daiwa.common.parser;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.micrometer.core.instrument.util.StringUtils;
import jp.co.daiwa.common.FixBeanUtils;
import jp.co.daiwa.constant.FixConstants;

/**
 * FIXエンジンの電文をbeanに変換するパーサークラス。
 *
 * @author kensei.kyu
 *
 */
public class FixSessionMsgParser {
    // 電文区切り文字
    private String delimitr;
    // タグマップ：key:名、value:ID
    private Map<String, String> fixTagMapNameId;
    // タグマップ：key:ID、value:名
    private Map<String, String> fixTagMapIdName;

    // 電文テキスト
    private String fixMsg;
    // 電文アイテム情報 name：タグ名、value：タグ値
    private Map<String, String> fixMap;
    // 解析された電文アイテム情報 id:タグID、name：タグ名、value：タグ値
    private List<FixMsgEntity> fixMsgItemList;

    /**
     * コンストラクタ：インスタンスを生成する。
     *
     * @param delimitr  項目セパレーター
     * @param fixTagMap FIXタグマップ（名、ID）
     */
    public FixSessionMsgParser(String delimitr, Map<String, String> fixTagMap) {

        if (StringUtils.isEmpty(delimitr)) {
            throw new IllegalArgumentException("Argument delimitr is empty.");
        }
        if (fixTagMap == null || fixTagMap.size() == 0) {
            throw new IllegalArgumentException("Argument fixTagMap is empty.");
        }

        this.delimitr = delimitr;
        this.fixTagMapNameId = fixTagMap;
        this.fixTagMapIdName = new HashMap<>();

        // タグマップ（key:名、value:ID）からタグマップ（key:ID、value:名）を作成
        this.fixTagMapNameId.entrySet().forEach(v -> fixTagMapIdName.put(v.getValue().toUpperCase(), v.getKey()));
    }

    /**
     * 電文パース処理を行う。
     *
     * @param fixMsg 電文テキスト
     */
    public void parse(String fixMsg) {

        if (StringUtils.isEmpty(fixMsg)) {
            throw new IllegalArgumentException("Argument fixMsg is empty.");
        }

        this.fixMsg = fixMsg;
        this.fixMap = new HashMap<String, String>();
        this.fixMsgItemList = new ArrayList<>();

        // 電文テキストから電文アイテムを解析
        for (String str : this.fixMsg.split(delimitr)) {
            int keyIndex = str.indexOf(FixConstants.EQUAL);
            if (1 <= keyIndex) {
                String tagId = str.substring(0, keyIndex);

                if (fixTagMapIdName.containsKey(tagId)) {
                    String tagName = fixTagMapIdName.get(tagId).toUpperCase();
                    String tagValue = str.substring(keyIndex + 1);

                    fixMsgItemList.add(new FixMsgEntity(tagId, tagName, tagValue));

                    fixMap.put(tagName, tagValue);
                }
            }
        }
    }

    /**
     * パース処理後の電文情報からデータを抽出。
     *
     * @param <T> パース結果を格納するbean
     * @param clz パース結果を格納するbeanのクラスを設定
     * @return パース結果を格納する新しいインスタンスを返す。
     */
    public <T> T extractData(Class<T> clz) {

        if (clz == null) {
            throw new IllegalArgumentException("Need set bean type for return.");
        }
        T bean = null;

        try {
            bean = clz.getDeclaredConstructor().newInstance();
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
                | NoSuchMethodException | SecurityException e) {
            throw new IllegalArgumentException("Invalid bean type by " + clz.getClass());
        }

        if (StringUtils.isEmpty(fixMap.get("msgContent"))) {
            fixMap.put("msgContent", this.fixMsg);
        }
        FixBeanUtils.copy(fixMap, bean);

        return bean;
    }

    /**
     * パース処理後の電文情報からサブアイテムデータを抽出。
     *
     * @param <T>        パース結果を格納するbean
     * @param clz        パース結果を格納するbeanのクラスを設定
     * @param itemStratId サブアイテム開始のタグIDを設定
     * @return パース結果を格納するインスタンスのリストを返す。
     */
    public <T> List<T> extractSubItems(Class<T> clz, String itemStratId) {

        if (clz == null) {
            throw new IllegalArgumentException("Need set bean type for return.");
        }
        if (fixMsgItemList == null || fixMsgItemList.size() == 0) {
            return null;
        }

        List<T> beanList = new ArrayList<>();

        T bean = null;
        Map<String, String> subItemMap = null;
        for (int idx = 0; idx < fixMsgItemList.size(); idx++) {
            FixMsgEntity msgItem = fixMsgItemList.get(idx);
            if (itemStratId.equals(msgItem.getId())) {
                if (subItemMap != null && bean != null) {
                    // beanにリフレクションで値を設定
                    FixBeanUtils.copy(subItemMap, bean);
                }

                subItemMap = new HashMap<String, String>();
                try {
                    bean = clz.getDeclaredConstructor().newInstance();
                    // ※ 写真は154行目で終了。以降は未撮影
