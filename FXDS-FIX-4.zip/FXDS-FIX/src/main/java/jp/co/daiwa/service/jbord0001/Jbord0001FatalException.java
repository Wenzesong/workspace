package jp.co.daiwa.service.jbord0001;

/**
 * 監視を続けると被害が広がるため、ジョブを異常終了させる例外（P-10・P-11）。
 *
 * <p>監視ループは通常の例外を警告として継続するが、この例外は捕まえずにステップを FAILED にする。</p>
 */
public class Jbord0001FatalException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public Jbord0001FatalException(String message, Throwable cause) {
        super(message, cause);
    }
}
