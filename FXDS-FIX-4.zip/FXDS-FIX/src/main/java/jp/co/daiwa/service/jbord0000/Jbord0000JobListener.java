package jp.co.daiwa.service.jbord0000;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dto.FixJobStatusInfoDto;

@Component
public class Jbord0000JobListener implements JobExecutionListener {

    @Inject
    @Named("fixjobstatus_order")
    private FixJobStatusInfoDto fixJobStatusInfo;

    /** Logger */
    private static final FixLogger logger = FixLogger.getLogger(Jbord0000JobListener.class);

    @Override
    public void beforeJob(JobExecution jobExecution) {
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I030");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        // 警告終了確認
        if (fixJobStatusInfo.isWarn()) {
            jobExecution.setExitStatus(new ExitStatus("WARN"));
        }
        // 異常終了確認
        jobExecution.getStepExecutions().forEach(stepExecution -> {
            if (ExitStatus.FAILED.getExitCode().equals(stepExecution.getExitStatus().getExitCode())) {
                logger.error(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_E001", FixConstants.Jbord0000_Name, stepExecution);
                jobExecution.setExitStatus(ExitStatus.FAILED);
            }
        });
        // ジョブ終了ステータスと詳細を出力する
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I002",
                jobExecution.getExitStatus().getExitCode(), jobExecution);

    }
}
