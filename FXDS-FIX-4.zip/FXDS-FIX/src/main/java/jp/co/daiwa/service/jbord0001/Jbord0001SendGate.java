package jp.co.daiwa.service.jbord0001;

import java.util.Date;

/**
 * 発注を送ってよいかの判定（ORDER セッションの接続／切断要求に応じた送信可否）。
 *
 * <ul>
 *   <li>H-1 接続要求後は、新しいセッションのログオンイベントが届く（ログオン状態の更新日時が変わる）まで、
 *       古いセッションの「ログオン中」を信用しない。</li>
 *   <li>P-26 切断要求後は、次の接続要求まで送らない。切断（ログアウト要求）してもログオン状態は
 *       ログアウトイベント受信まで true のままのため、ログオン状態だけでは切断中のセッションへ送ってしまう。</li>
 * </ul>
 *
 * <p>監視ループのスレッドからのみ使う（スレッドセーフではない）。</p>
 */
class Jbord0001SendGate {

    /** 接続要求を受けてから新しいセッションのログオンを確認できていない */
    private boolean awaitingLogon;
    /** 接続要求の直前のログオン状態の更新日時（awaitingLogon の間だけ意味を持つ） */
    private Date staleLogonMarker;
    /** 切断要求を受けた（次の接続要求まで送らない） */
    private boolean disconnected;

    /**
     * 接続／リセット接続要求を受けた。切断状態を解除し、新しいセッションのログオンを待つ。
     *
     * @param currentLogonDate 接続前のログオン状態の更新日時
     */
    void onConnectRequested(Date currentLogonDate) {
        disconnected = false;
        awaitingLogon = true;
        staleLogonMarker = currentLogonDate;
    }

    /** 切断要求を受けた。次の接続要求まで送らない */
    void onDisconnectRequested() {
        disconnected = true;
    }

    /**
     * 発注を送ってよいか。
     *
     * @param isLogon        ログオン状態
     * @param lastLogonDate  ログオン状態の更新日時（ログオン状態より先に読んだ値）
     * @return 送ってよい場合 true
     */
    boolean isOpen(boolean isLogon, Date lastLogonDate) {
        if (disconnected || !isLogon) {
            return false;
        }
        // 同一インスタンスかで判定する（ログオンイベントごとに新しい Date が設定される）
        if (awaitingLogon && lastLogonDate == staleLogonMarker) {
            return false;
        }
        awaitingLogon = false;
        staleLogonMarker = null;
        return true;
    }
}
