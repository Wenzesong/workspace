package jp.co.daiwa.service.jbord0001;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 送信の単位（単独注文1行、キャンセル1行、またはOCOの2行）。
 */
public final class Jbord0001SendUnit {

    /** 送信単位の種類 */
    public enum Kind {
        /** 既存の新規注文（注文区分2：スタンダード・リーブ・利確）。既存の電文組立をそのまま使う */
        NEW_EXISTING,
        /** 改修で追加した新規注文（注文区分1：成行、3：損切り） */
        NEW_EXTENDED,
        /** 単独キャンセル（既存） */
        CANCEL,
        /** OCO（1行目＝損切り、2行目＝利確） */
        OCO
    }

    private final Kind kind;
    private final List<Jbord0001OrderRow> rows;

    private Jbord0001SendUnit(Kind kind, List<Jbord0001OrderRow> rows) {
        this.kind = kind;
        this.rows = Collections.unmodifiableList(rows);
    }

    public static Jbord0001SendUnit single(Kind kind, Jbord0001OrderRow row) {
        if (kind == Kind.OCO) {
            throw new IllegalArgumentException("use oco()");
        }
        return new Jbord0001SendUnit(kind, Collections.singletonList(row));
    }

    /** @param stop 損切り行（注文区分3） @param profit 利確行（注文区分2） */
    public static Jbord0001SendUnit oco(Jbord0001OrderRow stop, Jbord0001OrderRow profit) {
        return new Jbord0001SendUnit(Kind.OCO, Arrays.asList(stop, profit));
    }

    public Kind getKind() {
        return kind;
    }

    public List<Jbord0001OrderRow> getRows() {
        return rows;
    }

    /** 単独注文・キャンセルの行 */
    public Jbord0001OrderRow getRow() {
        return rows.get(0);
    }

    /** OCO の組番号（OCO 以外は null） */
    public String getListId() {
        return kind == Kind.OCO ? rows.get(0).get(Jbord0001OrderRow.LIST_ID) : null;
    }
}
