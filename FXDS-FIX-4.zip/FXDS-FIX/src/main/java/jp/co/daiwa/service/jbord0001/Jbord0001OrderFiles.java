package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.LongSupplier;

/**
 * 発注要求ファイルの収集・状態遷移を扱う。
 *
 * <p>ファイルは次の状態を遷移する（いずれも同一ディレクトリ内のリネーム）。</p>
 * <pre>
 *   req_xxx ──claim──▶ prc_req_xxx ──complete──▶ (削除)
 *                           │
 *                           ├──markError──▶ err_req_xxx
 *                           └──（一部送信・送信状態不明）prc_ のまま ＋ note_prc_req_xxx（P-07）
 * </pre>
 * <p>送信前に {@code req_} 以外の名前へ移すため、送信後にファイル操作が失敗しても
 * 次回ポーリングで同じ注文が再送されることはない。</p>
 *
 * <p>書き込み途中のファイルを処理しないよう、サイズと更新日時が安定待ち時間のあいだ変わらなかった
 * ファイルだけを処理対象にする（P-08）。作成元が一時名で書き込んでから {@code req_} へリネームしていれば
 * 安定待ちは不要（0 にできる）。</p>
 *
 * <p>状態（観測結果）を持つため、監視スレッド1本からのみ使うこと。</p>
 */
public class Jbord0001OrderFiles {

    /** 発注要求ファイルのプレフィックス */
    public static final String REQUEST_PREFIX = "req_";

    /** 処理中ファイルのプレフィックス */
    public static final String PROCESSING_PREFIX = "prc_";

    /** 処理中ファイルのメモ（一部送信・送信状態不明の内容）のプレフィックス */
    public static final String NOTE_PREFIX = "note_";

    /**
     * 送信順：最初に見えたときの更新日時 → ディレクトリの優先順（ディーラー→営業、jbord0000 と同じ）→ ファイル名。
     * 最初に見えたときの更新日時を使うのは、書き込み中に更新日時が進んだファイルが後回しにならないようにするため。
     */
    private static final Comparator<Observation> SEND_ORDER = Comparator
            .comparing((Observation o) -> o.firstModified)
            .thenComparingInt(o -> o.dirIndex)
            .thenComparing(o -> o.path.getFileName().toString());

    /** 書き込み中のファイルが後続のファイルを保留できる時間の既定値 */
    public static final long DEFAULT_HOLD_MAX_MILLIS = 10_000L;

    private final List<Path> orderDirectories;
    private final String errorPrefix;
    private final long settleNanos;
    private final long holdMaxNanos;
    private final LongSupplier nanoClock;
    /** 未処理ファイルの最終観測結果 */
    private final Map<Path, Observation> observations = new HashMap<>();
    /** 直近の収集で、保留上限を過ぎても書き込みが続いていたファイル */
    private List<Path> stalledRequests = Collections.emptyList();

    /**
     * 安定待ちなし（見つけたファイルをすぐ処理対象にする）。
     *
     * @param orderDirectories 発注要求ファイルを監視するディレクトリ（優先順）
     * @param errorPrefix エラーファイルのプレフィックス
     */
    public Jbord0001OrderFiles(List<Path> orderDirectories, String errorPrefix) {
        this(orderDirectories, errorPrefix, 0, System::nanoTime);
    }

    /**
     * @param orderDirectories 発注要求ファイルを監視するディレクトリ（優先順）
     * @param errorPrefix エラーファイルのプレフィックス
     * @param settleMillis 安定待ち時間（ミリ秒）。0 なら待たない
     * @param nanoClock 経過時間の計測に使う時計（{@link System#nanoTime()} 相当）
     */
    public Jbord0001OrderFiles(List<Path> orderDirectories, String errorPrefix, long settleMillis,
            LongSupplier nanoClock) {
        this(orderDirectories, errorPrefix, settleMillis, DEFAULT_HOLD_MAX_MILLIS, nanoClock);
    }

    /**
     * @param orderDirectories 発注要求ファイルを監視するディレクトリ（優先順）
     * @param errorPrefix エラーファイルのプレフィックス
     * @param settleMillis 安定待ち時間（ミリ秒）。0 なら待たない
     * @param holdMaxMillis 書き込み中のファイルが、後から見つかったファイルを保留できる時間（ミリ秒）
     * @param nanoClock 経過時間の計測に使う時計（{@link System#nanoTime()} 相当）
     */
    public Jbord0001OrderFiles(List<Path> orderDirectories, String errorPrefix, long settleMillis, long holdMaxMillis,
            LongSupplier nanoClock) {
        Objects.requireNonNull(orderDirectories, "orderDirectories");
        Objects.requireNonNull(nanoClock, "nanoClock");
        if (errorPrefix == null || errorPrefix.isEmpty()) {
            throw new IllegalArgumentException("errorPrefix must not be empty");
        }
        if (settleMillis < 0) {
            throw new IllegalArgumentException("settleMillis must not be negative: " + settleMillis);
        }
        if (holdMaxMillis < 0) {
            throw new IllegalArgumentException("holdMaxMillis must not be negative: " + holdMaxMillis);
        }
        this.orderDirectories = Collections.unmodifiableList(new ArrayList<>(orderDirectories));
        this.errorPrefix = errorPrefix;
        this.settleNanos = TimeUnit.MILLISECONDS.toNanos(settleMillis);
        this.holdMaxNanos = TimeUnit.MILLISECONDS.toNanos(holdMaxMillis);
        this.nanoClock = nanoClock;
    }

    /**
     * 存在しない監視ディレクトリを返す。
     *
     * @return 存在しないディレクトリ（全て存在すれば空）
     */
    public List<Path> findMissingDirectories() {
        List<Path> missing = new ArrayList<>();
        for (Path dir : orderDirectories) {
            if (!Files.isDirectory(dir)) {
                missing.add(dir);
            }
        }
        return Collections.unmodifiableList(missing);
    }

    /**
     * 処理してよい発注要求ファイルを送信順に返す。ディレクトリを1つでも読めなければ例外。
     *
     * @return 発注要求ファイル
     * @throws IOException ディレクトリを読めない場合
     */
    public List<Path> collectRequests() throws IOException {
        Collected c = collect();
        if (!c.failures.isEmpty()) {
            throw c.failures.values().iterator().next();
        }
        return c.ready;
    }

    /**
     * 処理してよい発注要求ファイルを送信順に返す。読めないディレクトリがあっても他は処理する（P-21）。
     *
     * <p>処理してよいのは、安定待ちが済み、かつ自分より先に見つかったファイルが全て安定済みのもの
     * （書き込み中の新規より後から置かれた取消が先に送られないようにする）。ただし保留は保留上限まで
     * （書き込みが止まらないファイルで後続が止まり続けないようにする。該当ファイルは {@link #getStalledRequests}）。</p>
     *
     * @param onDirectoryError 読めなかったディレクトリ・ファイルの通知先
     * @return 発注要求ファイル
     * @throws IOException 全てのディレクトリを読めない場合
     */
    public List<Path> collectRequests(BiConsumer<Path, IOException> onDirectoryError) throws IOException {
        Collected c = collect();
        if (!orderDirectories.isEmpty() && c.failures.size() == orderDirectories.size()) {
            throw c.failures.values().iterator().next();
        }
        c.failures.forEach(onDirectoryError);
        c.fileFailures.forEach(onDirectoryError);
        return c.ready;
    }

    private Collected collect() {
        long now = nanoClock.getAsLong();
        Map<Path, Observation> seen = new HashMap<>();
        Map<Path, Observation> carried = new HashMap<>();
        Map<Path, IOException> failures = new LinkedHashMap<>();
        Map<Path, IOException> fileFailures = new LinkedHashMap<>();
        for (int i = 0; i < orderDirectories.size(); i++) {
            Path dir = orderDirectories.get(i);
            List<Path> files;
            try {
                files = listByPrefix(dir, REQUEST_PREFIX);
            } catch (IOException e) {
                failures.put(dir, e);
                carryObservationsOf(dir, carried);
                continue;
            }
            for (Path file : files) {
                try {
                    Observation current = observeOrNull(file, i, now);
                    if (current != null) {
                        seen.put(file, settle(observations.get(file), current));
                    }
                } catch (IOException e) {
                    // M-2 読めないファイルだけを飛ばす（ディレクトリ全体を止めない）
                    fileFailures.put(file, e);
                    carried.putAll(observationOf(file));
                }
            }
        }
        // 消えたファイル（claim 済み・削除済み）の記録は捨てる。読めなかったものは次回のために残すが処理対象にはしない
        observations.clear();
        observations.putAll(carried);
        observations.putAll(seen);
        List<Path> ready = readyInSendOrder(seen.values(), now);
        return new Collected(ready, failures, fileFailures);
    }

    /** 読めなかったディレクトリのファイルは、前回の観測結果を引き継ぐ（回復後に待ち直さない） */
    private void carryObservationsOf(Path dir, Map<Path, Observation> carried) {
        for (Map.Entry<Path, Observation> e : observations.entrySet()) {
            if (dir.equals(e.getKey().getParent())) {
                carried.put(e.getKey(), e.getValue());
            }
        }
    }

    private Map<Path, Observation> observationOf(Path file) {
        Observation o = observations.get(file);
        return o == null ? Collections.<Path, Observation>emptyMap() : Collections.singletonMap(file, o);
    }

    /** 直近の収集で、保留上限を過ぎても書き込み（サイズ・更新日時の変化）が続いていたファイル */
    public List<Path> getStalledRequests() {
        return stalledRequests;
    }

    private List<Path> readyInSendOrder(java.util.Collection<Observation> all, long now) {
        List<Observation> settled = new ArrayList<>();
        List<Observation> unsettled = new ArrayList<>();
        List<Path> stalled = new ArrayList<>();
        for (Observation o : all) {
            if (now - o.since >= settleNanos) {
                settled.add(o);
            } else if (now - o.firstSeen >= holdMaxNanos) {
                // H-2 保留上限を過ぎても書き込みが続くファイルは、後続を保留しない
                stalled.add(o.path);
            } else {
                unsettled.add(o);
            }
        }
        Collections.sort(stalled);
        stalledRequests = Collections.unmodifiableList(stalled);
        settled.sort(SEND_ORDER);
        List<Path> result = new ArrayList<>(settled.size());
        for (Observation f : settled) {
            if (!isPrecededByUnsettled(f, unsettled)) {
                result.add(f.path);
            }
        }
        return Collections.unmodifiableList(result);
    }

    private static boolean isPrecededByUnsettled(Observation f, List<Observation> unsettled) {
        for (Observation u : unsettled) {
            if (u.firstSeen - f.firstSeen < 0 || (u.firstSeen == f.firstSeen && SEND_ORDER.compare(u, f) < 0)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 前回実行で処理中のまま残ったファイルを返す（送信済みか不明なため再送しない）。
     *
     * @return 処理中ファイル
     * @throws IOException ディレクトリを読めない場合
     */
    public List<Path> findLeftoverClaims() throws IOException {
        List<Path> result = new ArrayList<>();
        for (Path dir : orderDirectories) {
            result.addAll(listByPrefix(dir, PROCESSING_PREFIX));
        }
        return Collections.unmodifiableList(result);
    }

    /**
     * 監視ディレクトリの未処理（req_）ファイル数。
     *
     * @return 件数
     * @throws IOException ディレクトリを読めない場合
     */
    public int countPendingRequests() throws IOException {
        int count = 0;
        for (Path dir : orderDirectories) {
            count += listByPrefix(dir, REQUEST_PREFIX).size();
        }
        return count;
    }

    /**
     * 監視ディレクトリの未処理（req_）ファイルを全てエラーファイルへ移す（再接続時に古い注文を送らない設定用、P-09）。
     * 削除はせず、内容を確認・再投入できるようにする。
     *
     * @param onError 読めなかったディレクトリ・移動できなかったファイルの通知先（他は処理を続ける）
     * @return 移動後のエラーファイル
     */
    public List<Path> discardPendingRequests(BiConsumer<Path, IOException> onError) {
        List<Path> moved = new ArrayList<>();
        for (Path dir : orderDirectories) {
            List<Path> files;
            try {
                files = listByPrefix(dir, REQUEST_PREFIX);
            } catch (IOException e) {
                onError.accept(dir, e);
                continue;
            }
            for (Path file : files) {
                try {
                    moved.add(Files.move(file, uniqueSibling(file, errorPrefix + file.getFileName())));
                    observations.remove(file);
                } catch (IOException e) {
                    onError.accept(file, e);
                }
            }
        }
        return Collections.unmodifiableList(moved);
    }

    /**
     * 発注要求ファイルを処理中状態へ移す。
     *
     * <p>作成元がまだ書き込み中でロックされている場合は失敗し、次回ポーリングで再試行される。</p>
     *
     * @param request {@code req_} ファイル
     * @return 処理中ファイル
     * @throws IOException リネームに失敗した場合
     */
    public Path claim(Path request) throws IOException {
        String name = request.getFileName().toString();
        if (!name.startsWith(REQUEST_PREFIX)) {
            throw new IllegalArgumentException("not a request file: " + request);
        }
        Path claimed = uniqueSibling(request, PROCESSING_PREFIX + name);
        return Files.move(request, claimed, StandardCopyOption.ATOMIC_MOVE);
    }

    /**
     * 処理済みファイルを削除する。
     *
     * @param claimed 処理中ファイル
     * @throws IOException 削除に失敗した場合
     */
    public void complete(Path claimed) throws IOException {
        Files.delete(claimed);
    }

    /**
     * 処理中ファイルをエラーファイルへ移す。元の {@code req_} 名に errorPrefix を付けた名前になる。
     *
     * @param claimed 処理中ファイル
     * @return エラーファイル
     * @throws IOException リネームに失敗した場合
     */
    public Path markError(Path claimed) throws IOException {
        String name = claimed.getFileName().toString();
        String original = name.startsWith(PROCESSING_PREFIX) ? name.substring(PROCESSING_PREFIX.length()) : name;
        Path error = uniqueSibling(claimed, errorPrefix + original);
        return Files.move(claimed, error);
    }

    /**
     * 処理中ファイルの横にメモを書く（一部送信・送信状態不明の内容。運用者の手動対応用、P-07）。
     *
     * @param claimed 処理中ファイル
     * @param lines メモの内容
     * @return メモファイル
     * @throws IOException 書き込めない場合
     */
    public Path writeNote(Path claimed, List<String> lines) throws IOException {
        return Files.write(noteOf(claimed), lines, StandardCharsets.UTF_8);
    }

    /**
     * 処理中ファイルのメモを読む。
     *
     * @param claimed 処理中ファイル
     * @return メモの内容（無ければ empty）
     * @throws IOException 読めない場合
     */
    public Optional<List<String>> readNote(Path claimed) throws IOException {
        Path note = noteOf(claimed);
        if (!Files.exists(note)) {
            return Optional.empty();
        }
        return Optional.of(Collections.unmodifiableList(Files.readAllLines(note, StandardCharsets.UTF_8)));
    }

    private static Path noteOf(Path claimed) {
        return claimed.resolveSibling(NOTE_PREFIX + claimed.getFileName());
    }

    /**
     * 指定ディレクトリの {@code req_} ファイルを削除する（再接続時の古い電文破棄）。
     *
     * @param dir 対象ディレクトリ
     * @return 削除件数
     * @throws IOException ディレクトリを読めない、または削除に失敗した場合
     */
    public static int deleteRequests(Path dir) throws IOException {
        int count = 0;
        for (Path file : listByPrefix(dir, REQUEST_PREFIX)) {
            if (Files.deleteIfExists(file)) {
                count++;
            }
        }
        return count;
    }

    /**
     * 同名ファイルが既にある場合（前回の prc_/err_ が残っている等）は上書きせず、連番を付けた名前にする。
     */
    private static Path uniqueSibling(Path base, String name) {
        Path candidate = base.resolveSibling(name);
        for (int i = 1; Files.exists(candidate); i++) {
            candidate = base.resolveSibling(name + "." + i);
        }
        return candidate;
    }

    private static List<Path> listByPrefix(Path dir, String prefix) throws IOException {
        List<Path> result = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, prefix + "*")) {
            for (Path p : stream) {
                if (Files.isRegularFile(p)) {
                    result.add(p);
                }
            }
        }
        return result;
    }

    /**
     * サイズ・更新日時が前回と同じなら前回の観測結果を引き継ぐ。変わっていれば今から待ち直す
     * （最初に見えた時刻・更新日時は引き継ぐ）。
     */
    private static Observation settle(Observation previous, Observation current) {
        if (previous == null) {
            return current;
        }
        if (previous.isSameContent(current)) {
            return previous;
        }
        return current.changedAfter(previous);
    }

    private static Observation observeOrNull(Path file, int dirIndex, long now) throws IOException {
        try {
            FileTime modified = Files.getLastModifiedTime(file);
            return new Observation(file, dirIndex, Files.size(file), modified, now, now, modified);
        } catch (NoSuchFileException e) {
            // 一覧取得後に消えたファイルは対象外
            return null;
        }
    }

    /** ファイルの観測結果 */
    private static final class Observation {
        private final Path path;
        private final int dirIndex;
        private final long size;
        private final FileTime modified;
        /** 現在のサイズ・更新日時を最初に見た時刻 */
        private final long since;
        /** ファイルを最初に見つけた時刻 */
        private final long firstSeen;
        /** ファイルを最初に見つけたときの更新日時 */
        private final FileTime firstModified;

        private Observation(Path path, int dirIndex, long size, FileTime modified, long since, long firstSeen,
                FileTime firstModified) {
            this.path = path;
            this.dirIndex = dirIndex;
            this.size = size;
            this.modified = modified;
            this.since = since;
            this.firstSeen = firstSeen;
            this.firstModified = firstModified;
        }

        private boolean isSameContent(Observation other) {
            return size == other.size && modified.equals(other.modified);
        }

        private Observation changedAfter(Observation previous) {
            return new Observation(path, dirIndex, size, modified, since, previous.firstSeen, previous.firstModified);
        }
    }

    private static final class Collected {
        private final List<Path> ready;
        private final Map<Path, IOException> failures;
        private final Map<Path, IOException> fileFailures;

        private Collected(List<Path> ready, Map<Path, IOException> failures, Map<Path, IOException> fileFailures) {
            this.ready = ready;
            this.failures = failures;
            this.fileFailures = fileFailures;
        }
    }
}
