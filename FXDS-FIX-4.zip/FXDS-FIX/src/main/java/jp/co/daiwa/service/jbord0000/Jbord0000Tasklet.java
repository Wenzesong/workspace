package jp.co.daiwa.service.jbord0000;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.validator.Validator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.fujitsu.fxsvc.FXServiceException;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.common.FixTargetFileFilter;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dao.BatchExecBaseDateRepository;
import jp.co.daiwa.dao.TradeMngRepository;
import jp.co.daiwa.dao.TradeOpeHistoryRepository;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.FixLogonStatusInfoDto;
import jp.co.daiwa.dto.OrdSendDto;
import jp.co.daiwa.enums.FixSessionEnum.FixSession;
import jp.co.daiwa.service.FixEngineService;

@Component
@Scope("step")
public class Jbord0000Tasklet implements Tasklet {
    @Value("${job.jbord0000.stop.file}")
    private String stopFile;

    @Value("${job.jbord0000.input.path}")
    private String inputPath;

    @Value("${sales.order.input.path}")
    private String salesOrderPath;

    @Value("${dealer.order.input.path}")
    private String dealerOrderPath;

    @Value("${job.jbord0000.work.filename}")
    private String renameFile;

    @Value("${job.jbord0000.connect.file}")
    private String connectFile;

    @Value("${job.jbord0000.disconnect.file}")
    private String disconnectFile;

    @Value("${job.jbord0000.connect.res.file}")
    private String connectResFile;

    @Value("${job.jbord0000.disconnect.res.file}")
    private String disconnectResFile;

    @Value("${job.jbord0000.connect.reset.file}")
    private String resetConnectFile;

    @Value("#{jobParameters['receiveMsgPoolSize']}")
    private Integer receiveMsgPoolSize;

    @Value("${job.jbord0000.output.path}")
    private String outputPath;

    /** ジョブ終了前一時停止（秒） */
    @Value("#{new Integer('${before.stop.wait.seconds}')}")
    private Integer beforeStopSleepSeconds;

    @Value("${order.noreply.thread.pool.size}")
    private Integer noreplyPoolSize;

    @Value("#{new Integer('${order.noreply.seconds}')}")
    private Integer noreplySeconds;

    @Value("${usernotification.file.path}")
    private String usernotificationPath;

    @Value("${resorder.client.file.path}")
    private String clientPath;

    @Value("${resorder.client.file}")
    private String clientFile;

    @Value("#{${fix.tag}}")
    private Map<String, String> fixTagMap;

    @Inject
    @Named("logonstatus_order")
    private FixLogonStatusInfoDto orderLogonStatus;

    @Inject
    @Named("processer")
    private Jbord0000Processor processer;

    @Inject
    @Named("ordSendDto")
    private OrdSendDto ordSendDto;

    @Inject
    @Named("fixEngineService")
    private FixEngineService fixEngineService;

    @Value("${job.jbord0000.output.file.name}")
    private String outputFileFix;

    @Inject
    @Named("suffixCreator")
    private Jbord0000ResourceSuffixCreator suffixCreator;

    @Inject
    @Named("fixjobstatus_order")
    private FixJobStatusInfoDto fixJobStatusInfo;

    @Inject
    TradeMngRepository tTradeMngRepository;

    @Inject
    TradeOpeHistoryRepository tTradeOpeHistoryDao;

    @Inject
    BatchExecBaseDateRepository tBatchExecBaseDateRepository;

    @Inject
    @Named("jobTransactionManager")
    PlatformTransactionManager transactionManager;

    /** 共通チェック */
    @Inject
    Validator<OrdSendDto> validator;

    /** Logger */
    private static final FixLogger logger = FixLogger.getLogger(Jbord0000Tasklet.class);

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        // 無応答リーブオーダー取得
        getLvNoReplyOrd();
        while (true) {
            try {
                // バッチ終了監視
                if (isStopJob()) {
                    return RepeatStatus.FINISHED;
                }
                // セッション接続切断監視
                monitorSessionOnOff();
                // 発注要求監視
                if (orderLogonStatus.isLogonStatus()) {
                    monitorOrderFile();
                }
            } catch (Exception e) {
                // 警告終了設定
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "送信電文作成処理。例外エラー", e);
            }
        }
    }

    /**
     * バッチ終了監視
     *
     * @return
     */
    private boolean isStopJob() {
        Path stop = Paths.get(stopFile);
        try {
            if (Files.exists(stop)) {
                logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I001", stopFile);
                fixEngineService.closeConnect(FixSession.ORDER);
                // プロセス停止前に、Logoutメソッド結果受信結果処理完了待ち
                TimeUnit.SECONDS.sleep(beforeStopSleepSeconds);
                Files.deleteIfExists(stop);
                return true;
            }
        } catch (Exception e) {
            // 警告終了設定
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "バッチ終了監視", e);
            return true;
        }
        return false;
    }

    /**
     * セッション接続切断要求監視
     */
    private void monitorSessionOnOff() {
        Path resetConnect = Paths.get(resetConnectFile);
        Path connect = Paths.get(connectFile);
        Path connectRes = Paths.get(connectResFile);
        Path ditconnect = Paths.get(disconnectFile);
        Path ditconnectRes = Paths.get(disconnectResFile);
        try {
            if (Files.exists(resetConnect)) {
                logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I012", FixSession.ORDER.getName(), resetConnect);
                // 古い電文を削除する
                deleteOldReqFile();
                // SEQリセットで接続
                fixEngineService.init(FixSession.ORDER, receiveMsgPoolSize, true);
                // 接続要求ファイル削除
                Files.deleteIfExists(resetConnect);
            } else if (Files.exists(connect)) {
                logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I012", FixSession.ORDER.getName(), connect);
                // 古い電文を削除する
                deleteOldReqFile();
                // SEQリセットなしで接続
                fixEngineService.init(FixSession.ORDER, receiveMsgPoolSize, false);
                // 接続要求⇒応答ファイル
                Files.move(connect, connectRes, StandardCopyOption.REPLACE_EXISTING);
            } else if (Files.exists(ditconnect)) {
                logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I013", FixSession.ORDER.getName(), ditconnect);
                // ログアウト
                fixEngineService.closeConnect(FixSession.ORDER);
                // 切断要求⇒応答ファイル
                Files.move(ditconnect, ditconnectRes, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            // 警告終了設定
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "セッション接続切断要求監視", e);
        }
    }

    /**
     * 発注要求監視
     *
     * @throws IOException
     */
    private void monitorOrderFile() throws IOException {
        // スレッドプールの作成、引数に生成するスレッド数を渡す
        ExecutorService orderPool = Executors.newFixedThreadPool(!ObjectUtils.isEmpty(noreplyPoolSize) ? noreplyPoolSize : FixConstants.DEFAULT_THREAD_POOL_SIZE);
        // トランザクション設定
        DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
        File fileArray[] = combineOrderFiles();
        for (File f : fileArray) {
            try {
                FixFileUtils fileUtil = new FixFileUtils();
                // クライアント設定値
                String clStr = fileUtil.loadLineString(f);
                // クライアント設定値⇒FIX用変換
                ordSendDto.toOrdSendDtoFromTsvStr(clStr);
                // チェック処理
                validator.validate(ordSendDto);
                // クライアント設定値⇒FIX用変換
                String fixStr = "0".equals(ordSendDto.getSendType()) ? ordSendDto.toNewOrderSingle() : ordSendDto.toOrderCancelRequest();
                String result = processer.process(fixStr);
                if (result == null) {
                    // 発注要求未送信
                    creatErrFile(f, fixStr, "発注要求未送信：");
                    continue;
                }
                fileUtil.writeFixMsgFile(outputPath, null, outputFileFix, result, suffixCreator.getSuffixIndex());
                if (!ordSendDto.getClOrdID().contains(FixConstants.CLORD_DEALER)) {
                    Jbord0000NoreplyThread thread = new Jbord0000NoreplyThread(fixStr, noreplySeconds, usernotificationPath, clientPath, clientFile, fixTagMap, fixJobStatusInfo);
                    thread.setTradeMngRepository(tTradeMngRepository);
                    thread.setTradeOpeHistoryDao(tTradeOpeHistoryDao);
                    thread.setDefinition(definition);
                    thread.setTransactionManager(transactionManager);
                    orderPool.submit(thread);
                }
                // 処理済みファイル削除
                f.delete();
            } catch (Exception e) {
                // 警告終了設定
                fixJobStatusInfo.setWarn(true);
                // 発注要求後送信
                creatErrFile(f, e.getMessage(), "発注要求監視：");
            }
        }
        // シャットダウン
        orderPool.shutdown();
    }

    /**
     * 処理失敗時にinputファイルリネーム処理
     * @param f
     * @param fixStr
     * @param wkStep
     * @throws IOException
     */
    private void creatErrFile(File f, String fixStr, String wkStep) throws IOException {
        Path fSrc = f.toPath();
        Path fDes = Paths.get(f.toString().replace(f.getName(), FixConstants.ERR_PREFIX + f.getName()));
        Files.move(fSrc, fDes, StandardCopyOption.REPLACE_EXISTING);
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", wkStep + fDes.getFileName() + fixStr);
    }

    /**
     * 無応答リーブオーダー取得
     */
    private void getLvNoReplyOrd() {
        List<String> ordList = tTradeOpeHistoryDao.findLvNoRplyOrdNum(tBatchExecBaseDateRepository.getExecBaseDate());
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", "起動時無応答注文", ordList);
        if (!CollectionUtils.isEmpty(ordList)) {
            ordList.forEach(d -> {
                fixJobStatusInfo.getReqOrdMap().put(d, null);
            });
        }
    }

    /**
     * 送信電文ファイル削除処理
     */
    private void deleteOldReqFile() {
        FileFilter filter = new FixTargetFileFilter("req_", ".*");
        File fileArray[] = new File(inputPath).listFiles(filter);
        if (!ObjectUtils.isEmpty(fileArray)) {
            for (File f : fileArray) {
                f.delete();
            }
        }
    }

    /**
     * 発注要求ファイル集計
     *
     * @return
     */
    private File[] combineOrderFiles() {
        int offset = 0;
        FileFilter filter = new FixTargetFileFilter("req_", ".*");
        // ディーラー注文
        File array1[] = new File(dealerOrderPath).listFiles(filter);
        // セールス注文
        File array2[] = new File(salesOrderPath).listFiles(filter);

        File[] combinedArray = new File[array1.length + array2.length];
        System.arraycopy(array1, 0, combinedArray, offset, array1.length);
        offset += array1.length;
        System.arraycopy(array2, 0, combinedArray, offset, array2.length);
        return combinedArray;
    }

    public FixEngineService getFixEngineService() {
        return fixEngineService;
    }

    public void setFixEngineService(FixEngineService fixEngineService) {
        this.fixEngineService = fixEngineService;
    }

    public void closeFixEngineConnect() throws FXServiceException {
        if (fixEngineService != null) {
            fixEngineService.closeConnect(FixSession.ORDER);
        }
    }
}
