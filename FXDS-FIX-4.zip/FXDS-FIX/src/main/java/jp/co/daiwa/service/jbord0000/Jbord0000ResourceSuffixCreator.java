package jp.co.daiwa.service.jbord0000;

public class Jbord0000ResourceSuffixCreator {
    private static long INDEX = 0;

    public long getSuffixIndex() {
        addIndex();
        return INDEX;
    }

    synchronized private static long addIndex() {
        INDEX += 1;
        return INDEX;
    }
}
