package jp.co.daiwa.service.jbord0001;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * 通貨ペア別の逆指値価格の小数桁数（E207、P-19）。
 *
 * <p>設定値 {@code job.jbord0001.stoppx.scale} の「通貨ペア:桁数」をカンマ区切りで読む（例 {@code USD/JPY:3,EUR/USD:5}）。
 * 設定の無い通貨ペアは null（項目定義の上限 8 桁でチェック）。
 * TODO(S11) 取得元（マスタ等）が決まったら差し替える。</p>
 */
public final class Jbord0001StopPxScales {

    private static final String ENTRY_SEPARATOR = ",";
    private static final String PAIR_SEPARATOR = ":";

    private Jbord0001StopPxScales() {
    }

    /**
     * @param setting 設定値（空・null 可）
     * @return 通貨ペア → 小数桁数（不明なら null）
     * @throws IllegalArgumentException 形式不正
     */
    public static Function<String, Integer> parse(String setting) {
        Map<String, Integer> scales = new HashMap<>();
        if (setting != null) {
            for (String entry : setting.split(ENTRY_SEPARATOR)) {
                if (!entry.trim().isEmpty()) {
                    put(scales, entry.trim());
                }
            }
        }
        Map<String, Integer> fixed = Collections.unmodifiableMap(scales);
        return fixed::get;
    }

    private static void put(Map<String, Integer> scales, String entry) {
        int sep = entry.lastIndexOf(PAIR_SEPARATOR);
        if (sep < 1 || sep == entry.length() - 1) {
            throw new IllegalArgumentException("job.jbord0001.stoppx.scale の形式不正（通貨ペア:桁数）: " + entry);
        }
        String symbol = entry.substring(0, sep).trim();
        int scale;
        try {
            scale = Integer.parseInt(entry.substring(sep + 1).trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("job.jbord0001.stoppx.scale の桁数が数字ではありません: " + entry, e);
        }
        if (scale < 0) {
            throw new IllegalArgumentException("job.jbord0001.stoppx.scale の桁数が負です: " + entry);
        }
        if (scales.put(symbol, scale) != null) {
            throw new IllegalArgumentException("job.jbord0001.stoppx.scale の通貨ペアが重複しています: " + symbol);
        }
    }
}
