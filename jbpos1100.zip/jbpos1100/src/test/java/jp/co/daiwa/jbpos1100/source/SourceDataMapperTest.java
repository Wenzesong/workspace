package jp.co.daiwa.jbpos1100.source;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;

/**
 * {@link SourceDataMapper} の単体テスト。検証ガード（必須項目欠落の除外）を中心に確認する。
 */
class SourceDataMapperTest {

    private SourceDataMapper mapper;
    private Date targetDate;

    @BeforeEach
    void setUp() {
        mapper = new SourceDataMapper(mock(JobWarningReporter.class));
        targetDate = new Date();
    }

    @Test
    @DisplayName("約定日が欠落したデータは除外される")
    void map_tradeDateNull_excluded() {
        PosSumSourceDto invalid = dto(null, "BOOK1", new Date());
        PosSumSourceDto valid = dto(new Date(), "BOOK1", new Date());

        List<TPosSumSourceDataBean> result = mapper.map(targetDate, Arrays.asList(invalid, valid));

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getDealerBook()).isEqualTo("BOOK1");
    }

    @Test
    @DisplayName("ディーラブック欠落・受渡日欠落も除外される")
    void map_missingDealerBookOrDelivery_excluded() {
        PosSumSourceDto noDealerBook = dto(new Date(), null, new Date());
        PosSumSourceDto noDelivery = dto(new Date(), "BOOK1", null);

        List<TPosSumSourceDataBean> result = mapper.map(targetDate, Arrays.asList(noDealerBook, noDelivery));

        assertThat(result).isEmpty();
    }

    @Test
    @DisplayName("有効データは処理基準日が設定され変換される")
    void map_valid_setsProcessBaseDate() {
        PosSumSourceDto valid = dto(new Date(), "BOOK1", new Date());

        List<TPosSumSourceDataBean> result = mapper.map(targetDate, Arrays.asList(valid));

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getProcessBaseDate()).isEqualTo(targetDate);
    }

    private PosSumSourceDto dto(Date tradeDate, String dealerBook, Date deliveryDate) {
        PosSumSourceDto dto = new PosSumSourceDto();
        dto.setTradeDate(tradeDate);
        dto.setDealerBook(dealerBook);
        dto.setDeliveryDate(deliveryDate);
        dto.setInputDataSource("FXDS");
        dto.setCurrencyPair("USDJPY");
        return dto;
    }
}
