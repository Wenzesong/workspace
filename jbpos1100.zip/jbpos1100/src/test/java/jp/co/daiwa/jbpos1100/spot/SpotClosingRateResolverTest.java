package jp.co.daiwa.jbpos1100.spot;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.CloseRateDto;

/**
 * {@link SpotClosingRateResolver} の単体テスト。
 *
 * <p>原本破損から標準パターンで復元した引値レート／引値円転レートの選択分岐を検証する。</p>
 */
class SpotClosingRateResolverTest {

    private SpotClosingRateResolver resolver;
    private Date targetDate;
    private String baseDate;

    @BeforeEach
    void setUp() throws Exception {
        resolver = new SpotClosingRateResolver();
        targetDate = new SimpleDateFormat("yyyy/MM/dd").parse("2026/06/28");
        baseDate = "2026/06/28";
    }

    @Test
    @DisplayName("決済通貨がJPYなら引値円転レートは1.0")
    void resolve_settleJpy_yenRateIsOne() {
        TPosSumSourceDataBean item = item("USD", "JPY");
        item.setClosingRate(new BigDecimal("150"));

        List<TPosSumSourceDataBean> result = resolver.resolve(targetDate,
                Collections.singletonList(item), Collections.<CloseRateDto>emptyList());

        assertThat(result.get(0).getClosingYenRate()).isEqualByComparingTo("1");
    }

    @Test
    @DisplayName("決済通貨が外貨なら引値円転レートはファイルの(決済通貨,JPY)から取得")
    void resolve_settleForeign_yenRateFromFile() {
        TPosSumSourceDataBean item = item("EUR", "USD");
        item.setClosingRate(new BigDecimal("1.1"));

        CloseRateDto usdJpy = closeRate(baseDate, "USD", "JPY", new BigDecimal("150"));

        List<TPosSumSourceDataBean> result = resolver.resolve(targetDate,
                Collections.singletonList(item), Collections.singletonList(usdJpy));

        assertThat(result.get(0).getClosingYenRate()).isEqualByComparingTo("150");
    }

    @Test
    @DisplayName("引値レートNULLかつ売買/決済ともJPYなら1.0")
    void resolve_closingRateNullAndBothJpy_isOne() {
        TPosSumSourceDataBean item = item("JPY", "JPY");
        item.setClosingRate(null);

        List<TPosSumSourceDataBean> result = resolver.resolve(targetDate,
                Collections.singletonList(item), Collections.<CloseRateDto>emptyList());

        assertThat(result.get(0).getClosingRate()).isEqualByComparingTo("1");
    }

    @Test
    @DisplayName("引値レートNULLなら(売買通貨,決済通貨)ペアをファイルから取得")
    void resolve_closingRateNull_fromFile() {
        TPosSumSourceDataBean item = item("EUR", "USD");
        item.setClosingRate(null);

        CloseRateDto eurUsd = closeRate(baseDate, "EUR", "USD", new BigDecimal("1.08"));

        List<TPosSumSourceDataBean> result = resolver.resolve(targetDate,
                Collections.singletonList(item), Collections.singletonList(eurUsd));

        assertThat(result.get(0).getClosingRate()).isEqualByComparingTo("1.08");
    }

    @Test
    @DisplayName("既存の引値円転レートは保持される")
    void resolve_existingYenRate_isKept() {
        TPosSumSourceDataBean item = item("EUR", "USD");
        item.setClosingRate(new BigDecimal("1.1"));
        item.setClosingYenRate(new BigDecimal("999"));

        List<TPosSumSourceDataBean> result = resolver.resolve(targetDate,
                Collections.singletonList(item), Collections.<CloseRateDto>emptyList());

        assertThat(result.get(0).getClosingYenRate()).isEqualByComparingTo("999");
    }

    private TPosSumSourceDataBean item(String dealCcy, String settleCcy) {
        TPosSumSourceDataBean bean = new TPosSumSourceDataBean();
        bean.setDealCurrency(dealCcy);
        bean.setSettleCurrency(settleCcy);
        return bean;
    }

    private CloseRateDto closeRate(String baseDate, String dealCcy, String settleCcy, BigDecimal rate) {
        CloseRateDto dto = new CloseRateDto();
        dto.setBaseDate(baseDate);
        dto.setDealCurrency(dealCcy);
        dto.setSettleCurrency(settleCcy);
        dto.setCloseRate(rate);
        return dto;
    }
}
