package jp.co.daiwa.jbpos1100.tasklet;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.source.ClosingSpotSourceLoader;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplitter;

/**
 * {@link ClosingEvaluationService} の結線テスト。
 * スポット＝プレ引値結果＋PLデルタ、スワップ＝引値ウィンドウ抽出、引値区分での委譲を検証する。
 */
class ClosingEvaluationServiceTest {

    private ClosingSpotSourceLoader loader;
    private SourcePositionSplitter splitter;
    private PositionEvaluationService evaluationService;
    private ClosingEvaluationService service;

    @BeforeEach
    void setUp() {
        loader = mock(ClosingSpotSourceLoader.class);
        splitter = mock(SourcePositionSplitter.class);
        evaluationService = mock(PositionEvaluationService.class);
        service = new ClosingEvaluationService(loader, splitter, evaluationService);
    }

    @Test
    @DisplayName("スポット=プレ引値+PLデルタ、スワップ=引値ウィンドウを引値区分で委譲する")
    void evaluate_combinesSpotAndDelegates() throws Exception {
        StepContribution contribution = mock(StepContribution.class);
        Date targetDate = new Date();
        Date busiDaysBefore = new Date();

        TPosSumSourceDataBean preSpot = bean("preSpot");
        TPosSumSourceDataBean delta = bean("delta");
        TPosSumSourceDataBean swap = bean("swap");

        when(loader.loadPreClosingSpotAsSource(targetDate)).thenReturn(Collections.singletonList(preSpot));
        when(loader.loadDeltaAsSource(targetDate)).thenReturn(Collections.singletonList(delta));
        when(splitter.splitForClosingSwap(any(), any(), any()))
                .thenReturn(new SourcePositionSplit(Collections.<TPosSumSourceDataBean>emptyList(),
                        Collections.singletonList(swap)));

        service.evaluate(contribution, targetDate, busiDaysBefore,
                Collections.<TPosSumSourceDataBean>emptyList(),
                Collections.emptyList(), Collections.emptyList(),
                Collections.<TPositionSpotSumDataBean>emptyList());

        ArgumentCaptor<SourcePositionSplit> captor = ArgumentCaptor.forClass(SourcePositionSplit.class);
        verify(evaluationService).evaluate(any(), any(), captor.capture(), any(), any(), any(),
                eq(EvaluationRateKbn.CLOSING_PRICE.getCode()), any());

        List<TPosSumSourceDataBean> spot = captor.getValue().getSpotList();
        assertThat(spot).containsExactly(preSpot, delta);
        assertThat(captor.getValue().getSwapList()).containsExactly(swap);
    }

    private TPosSumSourceDataBean bean(String dealerBook) {
        TPosSumSourceDataBean bean = new TPosSumSourceDataBean();
        bean.setDealerBook(dealerBook);
        return bean;
    }
}
