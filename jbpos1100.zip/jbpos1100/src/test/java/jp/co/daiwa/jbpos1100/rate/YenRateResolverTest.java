package jp.co.daiwa.jbpos1100.rate;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfarmBbgRateBean;
import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.dto.PosBaseRateDto;

/**
 * {@link YenRateResolver} の単体テスト。Real円転（マニュアル/ST/BBGの優先順位）と
 * 引値円転（マニュアルTTM/ファイル）の選択を検証する。
 */
class YenRateResolverTest {

    private YenRateResolver resolver;

    @BeforeEach
    void setUp() {
        resolver = new YenRateResolver();
    }

    @Test
    @DisplayName("決済通貨がJPYならReal円転レートは1.0")
    void realYenRate_settleJpy_isOne() {
        TPosSumSourceDataBean data = data("0", "USD", "JPY");

        BigDecimal rate = resolver.resolveRealYenRate(Collections.<PosBaseRateDto>emptyList(), data,
                Collections.<TPosSumManualRateBean>emptyList(), Collections.<TDfarmBbgRateBean>emptyList(),
                Collections.<TCurrencyMstBean>emptyList());

        assertThat(rate).isEqualByComparingTo("1");
    }

    @Test
    @DisplayName("マニュアル日中時価があれば最優先")
    void realYenRate_manualDaily_takesPriority() {
        TPosSumSourceDataBean data = data("0", "EUR", "USD");
        TPosSumManualRateBean manual = manual("USD", new BigDecimal("149"), null);

        BigDecimal rate = resolver.resolveRealYenRate(Collections.<PosBaseRateDto>emptyList(), data,
                Collections.singletonList(manual), Collections.<TDfarmBbgRateBean>emptyList(),
                Collections.<TCurrencyMstBean>emptyList());

        assertThat(rate).isEqualByComparingTo("149");
    }

    @Test
    @DisplayName("レート取得先がSTならベースレートの仲値")
    void realYenRate_smart_usesMid() {
        TPosSumSourceDataBean data = data("0", "EUR", "USD");
        TCurrencyMstBean mst = currencyMst("USD", "1"); // RATE_SOURCE_SMART
        PosBaseRateDto base = baseRate("USDJPY", "150", "152");

        BigDecimal rate = resolver.resolveRealYenRate(Collections.singletonList(base), data,
                Collections.<TPosSumManualRateBean>emptyList(), Collections.<TDfarmBbgRateBean>emptyList(),
                Collections.singletonList(mst));

        assertThat(rate).isEqualByComparingTo("151");
    }

    @Test
    @DisplayName("レート取得先がBBGならBBGレート")
    void realYenRate_bbg_usesBbg() {
        TPosSumSourceDataBean data = data("0", "EUR", "USD");
        TCurrencyMstBean mst = currencyMst("USD", "0"); // RATE_SOURCE_BBG
        TDfarmBbgRateBean bbg = bbg("USDJPY", new BigDecimal("153"));

        BigDecimal rate = resolver.resolveRealYenRate(Collections.<PosBaseRateDto>emptyList(), data,
                Collections.<TPosSumManualRateBean>emptyList(), Collections.singletonList(bbg),
                Collections.singletonList(mst));

        assertThat(rate).isEqualByComparingTo("153");
    }

    @Test
    @DisplayName("引値円転: マニュアルTTM優先、なければファイル")
    void closingYenRate_manualTtmThenFile() {
        TPosSumSourceDataBean data = data("0", "EUR", "USD");
        TPosSumManualRateBean manual = manual("USD", null, new BigDecimal("148"));

        BigDecimal withManual = resolver.resolveClosingYenRate(Collections.<CloseRateDto>emptyList(), data,
                "2026/06/28", Collections.singletonList(manual));
        assertThat(withManual).isEqualByComparingTo("148");

        CloseRateDto file = closeRate("2026/06/28", "USD", "JPY", new BigDecimal("150"));
        BigDecimal withFile = resolver.resolveClosingYenRate(Collections.singletonList(file), data,
                "2026/06/28", Collections.<TPosSumManualRateBean>emptyList());
        assertThat(withFile).isEqualByComparingTo("150");
    }

    private TPosSumSourceDataBean data(String exchangeDivision, String dealCcy, String settleCcy) {
        TPosSumSourceDataBean bean = new TPosSumSourceDataBean();
        bean.setExchangeDivision(exchangeDivision);
        bean.setDealCurrency(dealCcy);
        bean.setSettleCurrency(settleCcy);
        return bean;
    }

    private TPosSumManualRateBean manual(String dealCcy, BigDecimal daily, BigDecimal closingTtm) {
        TPosSumManualRateBean bean = new TPosSumManualRateBean();
        bean.setDealCurrency(dealCcy);
        bean.setSettleCurrency("JPY");
        bean.setManualDailyRate(daily);
        bean.setManualClosingTtmRate(closingTtm);
        return bean;
    }

    private TCurrencyMstBean currencyMst(String dealCcy, String rateSource) {
        TCurrencyMstBean bean = new TCurrencyMstBean();
        bean.setDealCurrency(dealCcy);
        bean.setRateSource(rateSource);
        return bean;
    }

    private PosBaseRateDto baseRate(String currencyPair, String bid, String ask) {
        PosBaseRateDto dto = new PosBaseRateDto();
        dto.setCurrencyPair(currencyPair);
        dto.setBidRate(bid);
        dto.setAskRate(ask);
        return dto;
    }

    private TDfarmBbgRateBean bbg(String currencyPair, BigDecimal rate) {
        TDfarmBbgRateBean bean = new TDfarmBbgRateBean();
        bean.setCurrencyPair(currencyPair);
        bean.setRate(rate);
        return bean;
    }

    private CloseRateDto closeRate(String baseDate, String dealCcy, String settleCcy, BigDecimal rate) {
        CloseRateDto dto = new CloseRateDto();
        dto.setBaseDate(baseDate);
        dto.setDealCurrency(dealCcy);
        dto.setSettleCurrency(settleCcy);
        dto.setCloseRate(rate);
        return dto;
    }
}
