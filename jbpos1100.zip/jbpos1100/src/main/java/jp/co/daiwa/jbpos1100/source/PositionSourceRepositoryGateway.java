package jp.co.daiwa.jbpos1100.source;

import java.util.Date;
import java.util.List;

import jp.co.daiwa.common.DateUtil;
import jp.co.daiwa.dao.Jbpos1001Repository;
import jp.co.daiwa.dao.TBatchExecBaseDateRepository;
import jp.co.daiwa.dao.TDfitCustomerMstRepository;
import jp.co.daiwa.dao.bean.TB86BET0Bean;
import jp.co.daiwa.dao.bean.TB86BYG0Bean;
import jp.co.daiwa.dao.bean.TB86BYS0Bean;
import jp.co.daiwa.dao.bean.TDfitCustomerMstBean;
import jp.co.daiwa.dao.bean.TTradeMngBean;
import jp.co.daiwa.daobid.Tb86bet0Repository;
import jp.co.daiwa.daodfit.TDfitTradeExchangeRepository;
import jp.co.daiwa.dto.PosSumSourceDto;

/**
 * ポジション集計元情報の「読み取り（取得）」を担うリポジトリゲートウェイ。
 *
 * <p>旧 {@code JbPositionDbOperation}（ファイル名は {@code JbPostionDbOperation} の typo）を
 * 役割が一目で分かる名前に刷新したもの。紛らわしい接頭辞 {@code Jb}/{@code Jp} を廃止し、
 * 「データ取得＝Gateway」「データ突合＝Matcher（{@link PositionSourceMatcher}）」と責務で命名する。</p>
 *
 * <p>本クラスは「取得系」のみを担い、登録/削除/更新は
 * {@code jp.co.daiwa.jbpos1100.source.*Store} 側へ分離する（単一責務）。</p>
 *
 * <p>依存はフィールドインジェクションではなくコンストラクタインジェクションで受け取り、
 * 各リポジトリをモック化して JUnit で検証可能にする。</p>
 *
 * @author MatsuFumizawa（原本）, jbpos1100 移行
 */
public class PositionSourceRepositoryGateway {

    private static final String FXDS = "FXDS";
    private static final String FOREIGN_EXCHANGE_DEPARTMENT = "外国為替課";

    private final Tb86bet0Repository businessDayRepository;
    private final TBatchExecBaseDateRepository batchExecBaseDateRepository;
    private final Jbpos1001Repository tradeMngRepository;
    private final TDfitTradeExchangeRepository dfitTradeExchangeRepository;
    private final TDfitCustomerMstRepository dfitCustomerMstRepository;

    /**
     * 取得系で必要な依存だけを受け取る（旧クラスが抱えていた 17 個の Repository から
     * 取得処理に不要なものを除外）。
     *
     * @param businessDayRepository       営業日マスタ（TB86BET0）
     * @param batchExecBaseDateRepository バッチ実行基準日
     * @param tradeMngRepository          取引管理（jbpos1001）
     * @param dfitTradeExchangeRepository DFIT 為替トレード
     * @param dfitCustomerMstRepository   DFIT 部課別顧客マスタ
     */
    public PositionSourceRepositoryGateway(
            Tb86bet0Repository businessDayRepository,
            TBatchExecBaseDateRepository batchExecBaseDateRepository,
            Jbpos1001Repository tradeMngRepository,
            TDfitTradeExchangeRepository dfitTradeExchangeRepository,
            TDfitCustomerMstRepository dfitCustomerMstRepository) {
        this.businessDayRepository = businessDayRepository;
        this.batchExecBaseDateRepository = batchExecBaseDateRepository;
        this.tradeMngRepository = tradeMngRepository;
        this.dfitTradeExchangeRepository = dfitTradeExchangeRepository;
        this.dfitCustomerMstRepository = dfitCustomerMstRepository;
    }

    /**
     * 営業日判定処理。
     *
     * @return 営業日の場合バッチ実行基準日、非営業日または基準日未取得の場合 null
     */
    public Date resolveBusinessDate() {
        Date targetDate = batchExecBaseDateRepository.getExecBaseDate();
        // [Fixed P1] 基準日が取得できない場合は convertDateToStrYmd(null) で NPE になり得るためガード
        if (targetDate == null) {
            return null;
        }
        TB86BET0Bean condition = new TB86BET0Bean();
        condition.setRekiymd(DateUtil.convertDateToStrYmd(targetDate));
        TB86BET0Bean businessDay = businessDayRepository.getBusinessDay(condition);
        TB86BET0Bean lastBusinessDay = businessDayRepository.getLastBusinessDay(condition);
        if (businessDay != null || lastBusinessDay != null) {
            return targetDate;
        }
        return null;
    }

    /**
     * 前営業日取得。
     *
     * @param targetDate 基準日
     * @return 前営業日
     */
    public Date getPreviousBusinessDay(Date targetDate) {
        TB86BET0Bean prev = businessDayRepository.getWorkingDayPlus(DateUtil.convertDateToStrYmd(targetDate), -1);
        return DateUtil.parsDate(prev.getRekiymd());
    }

    /**
     * ポジション集計元情報取得処理（取引管理）。
     *
     * @param previousBusinessDate 前営業日
     * @param endTime              終了時刻
     * @return ポジション集計元情報リスト
     */
    public List<PosSumSourceDto> getTradeMngSourceData(Date previousBusinessDate, String endTime) {
        TTradeMngBean condition = new TTradeMngBean();
        condition.setTradeDatetime(previousBusinessDate);
        condition.setNote(endTime);
        return tradeMngRepository.getTradeMngFxAll(condition);
    }

    /**
     * 【DFIT】部課別顧客マスタ取得。
     *
     * @return DFIT 部課別顧客マスタリスト
     */
    public List<TDfitCustomerMstBean> getDfitCustomerData() {
        TDfitCustomerMstBean condition = new TDfitCustomerMstBean();
        condition.setReferAuthSection(FOREIGN_EXCHANGE_DEPARTMENT);
        return dfitCustomerMstRepository.getDfitCustomerMstData(condition);
    }

    /**
     * 【DFIT】ポジション集計元フォーマットの為替トレードデータ取得。
     *
     * @param previousBusinessDate 前営業日（yyyyMMdd）
     * @return DFIT ポジション集計元情報リスト
     */
    public List<PosSumSourceDto> getDfitTradeExchange(String previousBusinessDate) {
        return dfitTradeExchangeRepository.getTDfitTradeExchange(previousBusinessDate);
    }

    /**
     * 【BID】ポジション集計元フォーマットの対顧客為替約定（リアル）。
     *
     * @param targetDate           基準日
     * @param previousBusinessDate 前営業日
     * @return BID 為替トレードデータリスト
     */
    public List<PosSumSourceDto> getBidTradeInfo(Date targetDate, Date previousBusinessDate) {
        TB86BYG0Bean condition = new TB86BYG0Bean();
        condition.setSgymd1(DateUtil.convertDateToStrYmd(targetDate));
        condition.setYakymd1(DateUtil.convertDateToStrYmd(previousBusinessDate));
        return tradeMngRepository.getBidTrade(condition);
    }

    /**
     * 【BID】ポジション集計元フォーマットの外 M データ仕分け。
     *
     * @param targetDate           基準日
     * @param previousBusinessDate 前営業日
     * @return BID 外 M データ仕分けリスト
     */
    public List<PosSumSourceDto> getBidOutsideMInfo(Date targetDate, Date previousBusinessDate) {
        TB86BYS0Bean condition = new TB86BYS0Bean();
        condition.setYakymd1(DateUtil.convertDateToStrYmd(targetDate));
        condition.setChuymd(DateUtil.convertDateToStrYmd(previousBusinessDate));
        return tradeMngRepository.getBidOutsideM(condition);
    }
}
