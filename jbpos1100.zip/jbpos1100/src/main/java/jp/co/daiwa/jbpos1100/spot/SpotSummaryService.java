package jp.co.daiwa.jbpos1100.spot;

import java.util.Date;
import java.util.List;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;

/**
 * スポット集計（算出＋永続化）を 1 評価レート区分単位でまとめるサービス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setSpotSumDate} のうち、集計本体を
 * {@link SpotPositionAggregator} へ、中間コミット永続化を {@link SpotSumStore} へ委譲して結線したもの
 * （継承ではなくコンポジション）。集計と永続化の責務をこのサービスが束ねる。</p>
 *
 * <p><b>未移植のため本サービスでは扱わないもの</b>（旧コードでは実施）:
 * ファイル出力（{@code Jbpos1000PositionSumDateFileUtil}）、日締めデータ複製
 * （{@code setClosingData}）、既存有無の事前 SELECT による削除要否判定。これらは
 * 別途移植のうえオーケストレータ側で実施する。</p>
 */
public class SpotSummaryService {

    private final SpotPositionAggregator aggregator;
    private final SpotSumStore spotSumStore;

    /**
     * @param aggregator   スポット集計本体
     * @param spotSumStore スポット集計結果の永続化（中間コミット）
     */
    public SpotSummaryService(SpotPositionAggregator aggregator, SpotSumStore spotSumStore) {
        this.aggregator = aggregator;
        this.spotSumStore = spotSumStore;
    }

    /**
     * スポット集計を実行し、結果を中間コミットで永続化する。
     *
     * @param targetDate        基準日
     * @param spotSourceList    スポット対象の集計元データ
     * @param evaluationRateKbn 評価レート区分コード
     * @param preClosingPlList  プレ引値の確定PL参照用リスト（引値で参照・プレ引値/引値で追記する共有状態）
     * @return 各グループ最終行のスポット集計結果
     * @throws Exception DB 切断由来の例外
     */
    public List<TPositionSpotSumDataBean> aggregateAndStore(Date targetDate,
            List<TPosSumSourceDataBean> spotSourceList, String evaluationRateKbn,
            List<TPositionSpotSumDataBean> preClosingPlList) throws Exception {

        List<TPositionSpotSumDataBean> spotSumList =
                aggregator.aggregate(targetDate, spotSourceList, evaluationRateKbn, preClosingPlList);

        // 既存（基準日・評価レート区分）を削除してから登録（中間コミット）
        TPositionSpotSumDataBean deleteCondition = new TPositionSpotSumDataBean();
        deleteCondition.setProcessBaseDate(targetDate);
        deleteCondition.setEvaluationRateDivision(evaluationRateKbn);
        spotSumStore.delete(deleteCondition);

        if (!spotSumList.isEmpty()) {
            spotSumStore.insert(spotSumList);
        }
        return spotSumList;
    }
}
