package jp.co.daiwa.jbpos1100.common;

/**
 * ポジション集計バッチ（jbpos1100）で共有する定数定義。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet} / {@code Jbpos1000SwapSummary} で
 * クラスごとに二重定義されていた定数（{@code JPY} / {@code RATESOURCESMART} 等）を
 * 単一の定数クラスに集約し、継承による定数の隠蔽（shadowing）を排除する。</p>
 *
 * <p>すべて {@code private static final} ＋ SCREAMING_SNAKE_CASE で統一する。</p>
 */
public final class BatchConstants {

    private BatchConstants() {
        // ユーティリティクラスのためインスタンス化禁止
    }

    /** 売買区分（買い）。 */
    public static final String DEAL_DIVISION_BUY = "1";
    /** 売買区分（売り）。 */
    public static final String DEAL_DIVISION_SELL = "2";

    /** レート取得先（SMART）。旧名: RATESOURCESMART。 */
    public static final String RATE_SOURCE_SMART = "1";
    /** レート取得先（BBG）。旧名: RATESOURCEBBG。 */
    public static final String RATE_SOURCE_BBG = "0";

    /** 対円通貨コード。 */
    public static final String CURRENCY_JPY = "JPY";

    /** データ取得元（BID リアル）。旧名: DATA_SOURCE_BIDR。 */
    public static final String DATA_SOURCE_BID_REAL = "BID_R";
    /** データ取得元（DFIT）。 */
    public static final String DATA_SOURCE_DFIT = "DFIT";

    /** AC フラグ（インタイム）。旧名: NONAC。 */
    public static final String AC_FLAG_IN_TIME = "0";
    /** AC フラグ（アフタークローズ）。旧名: AC。 */
    public static final String AC_FLAG_AFTER_CLOSE = "1";

    /** 為替区分（約定済 CF）。旧名: TRADEDCF。 */
    public static final String EXCHANGE_DIVISION_TRADED_CF = "4";

    /** 日付フォーマット（yyyyMMdd）。 */
    public static final String DATE_PATTERN_YMD = "yyyyMMdd";
    /** 日付フォーマット（yyyyMMddHHmmss）。 */
    public static final String DATE_PATTERN_YMD_HMS = "yyyyMMddHHmmss";
    /** 日付フォーマット（yyyy/MM/dd）。 */
    public static final String DATE_PATTERN_SLASH = "yyyy/MM/dd";
}
