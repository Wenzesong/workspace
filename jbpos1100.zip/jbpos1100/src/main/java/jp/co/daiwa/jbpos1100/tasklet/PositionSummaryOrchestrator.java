package jp.co.daiwa.jbpos1100.tasklet;

import java.util.Date;
import java.util.List;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;
import jp.co.daiwa.jbpos1100.common.TransactionalBatchExecutor;
import jp.co.daiwa.jbpos1100.source.PositionSourceMatcher;
import jp.co.daiwa.jbpos1100.source.PositionSourceRepositoryGateway;
import jp.co.daiwa.jbpos1100.source.PositionSourceStore;

/**
 * ポジション集計 1 サイクルのオーケストレーション（旧 {@code posSumTask} の薄い置き換え）。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet} は 1 クラスで全工程を抱えていたが、本クラスは
 * 「どのサービスを、どの順で呼ぶか」というワークフロー定義に責務を限定し、実処理は
 * 各専門クラス（{@link PositionSourceRepositoryGateway} / {@link PositionSourceMatcher} /
 * {@link PositionSourceStore} / 集計クラス群）へ委譲する。</p>
 *
 * <p>1 サイクルで状態が変わる協調オブジェクト（{@link JobWarningReporter} /
 * {@link TransactionalBatchExecutor} / {@link PositionSourceMatcher}）は
 * {@link #runOnce} 内で生成する。これにより旧コードの可変 static フィールド共有を排除する。</p>
 *
 * <h2>移行ステータス</h2>
 * <ul>
 *   <li><b>復元済み（本パッケージで実装）:</b> 基準日解決、集計元の削除→取得→突合→中間コミット登録、
 *       レートファイル読込、通貨別デルタ・キャッシュ残集計（{@code delta} パッケージ）。</li>
 *   <li><b>要・原本確認（FIXME）:</b> Real/プレ引値/引値/引値以降のスポット・スワップ集計本体は
 *       原本ソースの破損（{@code setClosingRate}/{@code setSourceData}/{@code posSumSourceDataMapping}/
 *       {@code mkSwapPlSumDate} の型不整合・制御構造崩壊・文字化け）により金融計算ロジックを
 *       忠実に復元できない。推測実装は「静かな誤計算」を招くため行わず、原本（非破損版）と
 *       突き合わせて {@code SpotPositionAggregator} / {@code SwapPositionAggregator} へ移植すること。</li>
 * </ul>
 */
public class PositionSummaryOrchestrator implements PositionSummaryCycle {

    private final PositionSourceRepositoryGateway gateway;
    private final PositionSourcePipelineFactory pipelineFactory;

    /**
     * @param gateway         集計元データの取得ゲートウェイ
     * @param pipelineFactory 1 サイクル分の協調オブジェクトを生成するファクトリ
     */
    public PositionSummaryOrchestrator(PositionSourceRepositoryGateway gateway,
            PositionSourcePipelineFactory pipelineFactory) {
        this.gateway = gateway;
        this.pipelineFactory = pipelineFactory;
    }

    @Override
    public Date resolveTargetDate() {
        return gateway.resolveBusinessDate();
    }

    @Override
    public void runOnce(StepContribution contribution, Date targetDate) throws Exception {
        // --- 1 サイクル分の協調オブジェクトを生成（状態リーク防止のため毎回新規） ---
        JobWarningReporter reporter = new JobWarningReporter(contribution);
        TransactionalBatchExecutor executor = pipelineFactory.createExecutor(reporter);
        PositionSourceStore sourceStore = pipelineFactory.createSourceStore(executor);

        Date previousBusinessDate = gateway.getPreviousBusinessDay(targetDate);

        // --- 集計元の収集（取得系は Gateway、突合は Matcher に委譲） ---
        List<PosSumSourceDto> collected = collectSourceData(targetDate, previousBusinessDate);

        // --- 集計元の中間コミット登録（重複していた delete/insert トランザクションは Store へ集約） ---
        persistCollectedSource(sourceStore, collected);

        // --- 評価レート区分ごとの集計（Real/プレ引値/引値/引値以降） ---
        // スポット・スワップ集計はいずれも移植済みで、1 評価レート区分分を
        // tasklet.PositionEvaluationService に集約済み:
        //   - source.SourcePositionSplitter で集計元をスポット／スワップに振り分け、
        //   - spot.SpotSummaryService（SpotPositionAggregator + SpotSumStore）でスポット集計＋永続化、
        //   - swap.SwapSummaryService（SwapCashSumAssembler → SwapCurrencyAggregator
        //       → CurrencyDeltaCashCalculator → SwapPlSumCalculator）でスワップ計算、
        //   - SwapSumStore / CurrencyDeltaCashStore / SwapPlSumStore で中間コミット永続化。
        //   集計元のレート割当は source.PositionSourceRateMapper + rate.YenRateResolver、
        //   引値レート再設定は spot.SpotClosingRateResolver。
        //
        // 呼び出し例（Real 集計）:
        //   SourcePositionSplit split = splitter.splitForReal(allSource, targetDate, previousBusinessDate);
        //   evaluationService.evaluate(contribution, targetDate, split, allSource,
        //           dfCalcResult, dfHistory, EvaluationRateKbn.REAL.getCode(), preClosingPlList);
        //
        // 残ギャップ（当初6メソッドの範囲外）:
        //   - プレ引値/引値/引値以降の振り分け（SourcePositionSplitter の Pre/Closing/After 版）、
        //   - ファイル出力（Jbpos1000PositionSumDateFileUtil 相当）・日締めデータ複製、
        //   - 上記に必要な DF/履歴/全集計元の取得は PositionSourcePipelineFactory へ追加する。
    }

    /**
     * 各データソース（FXDS/DFIT/BID）から集計元候補を突合・収集する。
     *
     * @param targetDate           基準日
     * @param previousBusinessDate 前営業日
     * @return 突合済みの集計元 DTO リスト
     */
    private List<PosSumSourceDto> collectSourceData(Date targetDate, Date previousBusinessDate) {
        PositionSourceMatcher matcher = pipelineFactory.createMatcher(gateway, targetDate, previousBusinessDate);
        List<PosSumSourceDto> result = matcher.matchTradeMngDataForDfit(false);
        result.addAll(matcher.matchTradeMngDataForDfit(true));
        result.addAll(matcher.matchDfitTradeExchangeDataForFxds());
        result.addAll(matcher.matchBidTradeForFxds(true));
        result.addAll(matcher.matchBidTradeForFxds(false));
        result.addAll(matcher.matchBidOutsideMForFxds());
        return result;
    }

    /**
     * 収集した集計元を変換し中間コミットで登録する。
     *
     * <p>変換（{@code PosSumSourceDto} → {@link TPosSumSourceDataBean}）は
     * {@code SourceDataMapper}（要・原本確認）へ委譲する想定。</p>
     *
     * @param sourceStore 集計元ストア
     * @param collected   収集済み DTO
     * @throws Exception DB 切断由来の例外
     */
    private void persistCollectedSource(PositionSourceStore sourceStore, List<PosSumSourceDto> collected)
            throws Exception {
        List<TPosSumSourceDataBean> beans = pipelineFactory.mapToSourceBeans(collected);
        if (beans != null && !beans.isEmpty()) {
            sourceStore.insert(beans);
        }
    }
}
