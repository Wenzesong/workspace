package jp.co.daiwa.jbpos1100.tasklet;

import java.util.Date;
import java.util.List;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashStore;
import jp.co.daiwa.jbpos1100.file.PositionSumFileWriter;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.spot.SpotSummaryService;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSummaryResult;
import jp.co.daiwa.jbpos1100.swap.SwapSummaryService;

/**
 * 1 評価レート区分（Real／プレ引値／引値／引値以降）のスポット・スワップ集計を実行・永続化するサービス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setPosRealData}（および Pre/Closing/After 系）の
 * 「スポット集計＋スワップ集計」の呼び出しを、移植済みサービスへ委譲して結線したもの。</p>
 *
 * <p>スポットは {@link SpotSummaryService}（集計＋永続化）、スワップは {@link SwapSummaryService}
 * （計算）＋各 Store（中間コミット永続化）で構成する。</p>
 */
public class PositionEvaluationService {

    private final SpotSummaryService spotSummaryService;
    private final SwapSummaryService swapSummaryService;
    private final SwapSumStore swapSumStore;
    private final CurrencyDeltaCashStore deltaCashStore;
    private final SwapPlSumStore swapPlSumStore;
    private final PositionSumFileWriter fileWriter;
    private final String outputFilePath;

    /**
     * @param spotSummaryService スポット集計＋永続化
     * @param swapSummaryService スワップ集計（計算）
     * @param swapSumStore       スワップ集計結果ストア
     * @param deltaCashStore     通貨別デルタ・キャッシュ残ストア
     * @param swapPlSumStore     スワップPL合計ストア
     * @param fileWriter         集計結果ファイル出力
     * @param outputFilePath     出力先パス
     */
    public PositionEvaluationService(SpotSummaryService spotSummaryService, SwapSummaryService swapSummaryService,
            SwapSumStore swapSumStore, CurrencyDeltaCashStore deltaCashStore, SwapPlSumStore swapPlSumStore,
            PositionSumFileWriter fileWriter, String outputFilePath) {
        this.spotSummaryService = spotSummaryService;
        this.swapSummaryService = swapSummaryService;
        this.swapSumStore = swapSumStore;
        this.deltaCashStore = deltaCashStore;
        this.swapPlSumStore = swapPlSumStore;
        this.fileWriter = fileWriter;
        this.outputFilePath = outputFilePath;
    }

    /**
     * 1 評価レート区分のスポット・スワップ集計を実行し永続化する。
     *
     * @param contribution      ステップ実行コンテキスト
     * @param targetDate        基準日
     * @param split             スポット／スワップ振り分け済みの集計元
     * @param allSourceList     当該基準日の全集計元（デルタ集計のスタートポジション抽出に使用）
     * @param dfCalcResult      DF 算出結果
     * @param dfHistory         DF 履歴情報
     * @param evaluationRateKbn 評価レート区分コード
     * @param preClosingPlList  プレ引値の確定PL参照用リスト（スポット集計の共有状態）
     * @throws Exception DB 切断由来の例外
     */
    public void evaluate(StepContribution contribution, Date targetDate, SourcePositionSplit split,
            List<TPosSumSourceDataBean> allSourceList, List<TDfCalcResultBean> dfCalcResult,
            List<TDfHistoryDateBean> dfHistory, String evaluationRateKbn,
            List<TPositionSpotSumDataBean> preClosingPlList) throws Exception {

        // スポット集計＋永続化
        List<TPositionSpotSumDataBean> spotSumList =
                spotSummaryService.aggregateAndStore(targetDate, split.getSpotList(), evaluationRateKbn, preClosingPlList);
        // スポット集計結果ファイル出力（プレ引値以外。旧 setSpotSumDate のガードを踏襲）
        if (!EvaluationRateKbn.PRE_CLOSING.getCode().equals(evaluationRateKbn)) {
            fileWriter.writeSpotSumFile(contribution, outputFilePath, evaluationRateKbn, spotSumList);
        }

        // スワップ集計（計算）
        SwapSummaryResult swap = swapSummaryService.aggregate(contribution, targetDate, split.getSwapList(),
                allSourceList, dfCalcResult, dfHistory, evaluationRateKbn);

        // スワップ各成果物の永続化（既存削除→登録の中間コミット）
        persistSwap(targetDate, evaluationRateKbn, swap);

        // スワップ集計結果ファイル出力（スワップが処理された場合のみ＝旧 mkPositionSwapSumData 相当）
        if (!swap.getCurrencySumList().isEmpty()) {
            fileWriter.writeSwapSumFile(contribution, outputFilePath, evaluationRateKbn,
                    swap.getPlSumList(), swap.getDeltaCashList(), swap.getCurrencySumList());
        }
    }

    /**
     * スワップ集計結果（通貨纏め・デルタ／キャッシュ残・PL合計）を永続化する。
     */
    private void persistSwap(Date targetDate, String evaluationRateKbn, SwapSummaryResult swap) throws Exception {
        TPositionSwapSumDataBean swapCondition = new TPositionSwapSumDataBean();
        swapCondition.setProcessBaseDate(targetDate);
        swapCondition.setEvaluationRateDivision(evaluationRateKbn);
        swapSumStore.delete(swapCondition);
        swapSumStore.insert(swap.getCurrencySumList());

        TByCcyDeltaCashBalanceBean deltaCondition = new TByCcyDeltaCashBalanceBean();
        deltaCondition.setProcessBaseDate(targetDate);
        deltaCondition.setEvaluationRateDivision(evaluationRateKbn);
        deltaCashStore.delete(deltaCondition);
        deltaCashStore.insert(swap.getDeltaCashList());

        TSwapPlSumDateBean plCondition = new TSwapPlSumDateBean();
        plCondition.setProcessBaseDate(targetDate);
        plCondition.setEvaluationRateDivision(evaluationRateKbn);
        swapPlSumStore.delete(plCondition);
        swapPlSumStore.insert(swap.getPlSumList());
    }
}
