package jp.co.daiwa.jbpos1100.tasklet;

import java.util.Date;
import java.util.List;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;
import jp.co.daiwa.jbpos1100.common.TransactionalBatchExecutor;
import jp.co.daiwa.jbpos1100.source.PositionSourceMatcher;
import jp.co.daiwa.jbpos1100.source.PositionSourceRepositoryGateway;
import jp.co.daiwa.jbpos1100.source.PositionSourceStore;

/**
 * 1 サイクル分の協調オブジェクトを生成するファクトリ境界。
 *
 * <p>{@link PositionSummaryOrchestrator} を「ワークフロー定義」に専念させ、
 * リポジトリや設定値（bulkInsertUnit 等）に依存するインスタンス生成を本ファクトリへ隔離する。
 * オーケストレータの単体テストでは本ファクトリをモックに差し替える。</p>
 *
 * <p>実装クラス（Spring 設定側）は各 {@code *Repository} と設定値を保持し、
 * 取得したマスタ/トレードデータを {@link PositionSourceMatcher} へ注入して返す。</p>
 */
public interface PositionSourcePipelineFactory {

    /**
     * 当該サイクルの中間コミット実行テンプレートを生成する。
     *
     * @param reporter 当該サイクルの警告レポータ
     * @return 中間コミット実行テンプレート
     */
    TransactionalBatchExecutor createExecutor(JobWarningReporter reporter);

    /**
     * 集計元ストアを生成する。
     *
     * @param executor 中間コミット実行テンプレート
     * @return 集計元ストア
     */
    PositionSourceStore createSourceStore(TransactionalBatchExecutor executor);

    /**
     * 当該サイクルの集計元マッチャを生成する（必要なマスタ/トレードデータを取得し注入する）。
     *
     * @param gateway              取得ゲートウェイ
     * @param targetDate           基準日
     * @param previousBusinessDate 前営業日
     * @return 集計元マッチャ
     */
    PositionSourceMatcher createMatcher(PositionSourceRepositoryGateway gateway, Date targetDate,
            Date previousBusinessDate);

    /**
     * 突合済み DTO をポジション集計元 Bean へ変換する。
     *
     * <p>旧 {@code setSourceData} 相当。原本破損のため変換ロジックは原本確認後に移植すること。</p>
     *
     * @param collected 突合済み DTO
     * @return 集計元 Bean リスト
     */
    List<TPosSumSourceDataBean> mapToSourceBeans(List<PosSumSourceDto> collected);
}
