package jp.co.daiwa.jbpos1100.file;

import java.util.List;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.common.Jbpos1000PositionSumDateFileUtil;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;

/**
 * {@link PositionSumFileWriter} の既定実装。既存の出力ユーティリティ
 * {@code Jbpos1000PositionSumDateFileUtil}（外部）の static メソッドへ委譲する。
 *
 * <p>ファイル書き込みの実装そのものは外部ユーティリティに委ねつつ、呼び出しを
 * インスタンス境界に閉じ込めることで、集計サービス側を static 依存から解放しテスト容易にする。</p>
 */
public class DefaultPositionSumFileWriter implements PositionSumFileWriter {

    @Override
    public void writeSpotSumFile(StepContribution contribution, String outputFilePath, String evaluationRateKbn,
            List<TPositionSpotSumDataBean> spotSumList) {
        Jbpos1000PositionSumDateFileUtil.writePostSumDateFile(contribution, outputFilePath, evaluationRateKbn,
                spotSumList);
    }

    @Override
    public void writeSwapSumFile(StepContribution contribution, String outputFilePath, String evaluationRateKbn,
            List<TSwapPlSumDateBean> plSumList, List<TByCcyDeltaCashBalanceBean> deltaCashList,
            List<TPositionSwapSumDataBean> currencySumList) {
        Jbpos1000PositionSumDateFileUtil.writeSwapSumDateFile(contribution, outputFilePath, evaluationRateKbn,
                plSumList, deltaCashList, currencySumList);
    }
}
