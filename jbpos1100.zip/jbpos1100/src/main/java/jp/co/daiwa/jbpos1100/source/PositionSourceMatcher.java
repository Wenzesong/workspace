package jp.co.daiwa.jbpos1100.source;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.daiwa.common.constant.ExchangeKbnEnum.ExchangeKbn;
import jp.co.daiwa.common.constant.ProductEnum;
import jp.co.daiwa.common.constant.TradeKbnEnum.TradeKbn;
import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfitCustomerMstBean;
import jp.co.daiwa.dao.bean.TDfitTradeExchangeBean;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;

/**
 * ポジション集計元データの突合（マッチング）とディーラブック設定を担うクラス。
 *
 * <p>旧 {@code JpPositionDataOperation}（ファイル名は {@code JpPostionDataOperation} の typo、
 * かつ {@code Jb}/{@code Jp} の紛らわしい接頭辞）を責務ベースで刷新したもの。</p>
 *
 * <p>旧クラスは入力リストを setter で後から差し込む可変状態だったが、
 * 1 実行内で不変な入力としてコンストラクタインジェクションで受け取り、
 * テスト時に決まった入力で検証できるようにする。</p>
 */
public class PositionSourceMatcher {

    private static final String REMARKS_POSITION = "ポジション表示";

    /** 通貨マスタ。 */
    private final List<TCurrencyMstBean> currencyMstList;
    /** DFIT 部課別顧客マスタ（旧 {@code dfitCurrencyMstList} は実体が顧客マスタのため改名）。 */
    private final List<TDfitCustomerMstBean> dfitCustomerMstList;
    /** DFIT 為替トレードデータ。 */
    private final List<TDfitTradeExchangeBean> dfitTradeExchangeList;
    /** ポジション集計元: FXDS 取引管理データ。 */
    private final List<PosSumSourceDto> fxdsInfoList;
    /** ポジション集計元: DFIT データ。 */
    private final List<PosSumSourceDto> dfitInfoList;
    /** ポジション集計元: BID 為替トレードデータ。 */
    private final List<PosSumSourceDto> bidInfoList;
    /** ポジション集計元: BID 外 M データ仕分けデータ。 */
    private final List<PosSumSourceDto> bidOutsideMInfoList;

    /**
     * @param currencyMstList       通貨マスタ
     * @param dfitCustomerMstList   DFIT 部課別顧客マスタ
     * @param dfitTradeExchangeList DFIT 為替トレードデータ
     * @param fxdsInfoList          FXDS 取引管理データ
     * @param dfitInfoList          DFIT データ
     * @param bidInfoList           BID 為替トレードデータ
     * @param bidOutsideMInfoList   BID 外 M データ仕分けデータ
     */
    public PositionSourceMatcher(
            List<TCurrencyMstBean> currencyMstList,
            List<TDfitCustomerMstBean> dfitCustomerMstList,
            List<TDfitTradeExchangeBean> dfitTradeExchangeList,
            List<PosSumSourceDto> fxdsInfoList,
            List<PosSumSourceDto> dfitInfoList,
            List<PosSumSourceDto> bidInfoList,
            List<PosSumSourceDto> bidOutsideMInfoList) {
        this.currencyMstList = currencyMstList;
        this.dfitCustomerMstList = dfitCustomerMstList;
        this.dfitTradeExchangeList = dfitTradeExchangeList;
        this.fxdsInfoList = fxdsInfoList;
        this.dfitInfoList = dfitInfoList;
        this.bidInfoList = bidInfoList;
        this.bidOutsideMInfoList = bidOutsideMInfoList;
    }

    /**
     * FXDS 取引管理データ・DFIT データマッチング処理。
     *
     * @param bondFlg 外債売買フラグ（false: 単独/利金/償還為替、true: 外株/外投円決）
     * @return マッチング後のポジション集計元情報リスト
     */
    public List<PosSumSourceDto> matchTradeMngDataForDfit(boolean bondFlg) {
        List<PosSumSourceDto> result;
        if (!bondFlg) {
            result = fxdsInfoList.stream()
                    .filter(t -> !TradeKbn.SECURITY.getCode().equals(t.getTradeDivision()))
                    .filter(t -> !ProductEnum.FBOND_TRADE.getCode().equals(t.getProduct())
                            || t.getTradeDivision() == null)
                    .collect(Collectors.toList());
            List<String> inputIdList = dfitTradeExchangeList.stream()
                    .map(TDfitTradeExchangeBean::getInputDataId)
                    .distinct()
                    .collect(Collectors.toList());
            Iterator<PosSumSourceDto> it = result.iterator();
            while (it.hasNext()) {
                PosSumSourceDto item = it.next();
                String key = item.getOrderNumber().toString() + "_"
                        + item.getRevisionNumber().toString() + "_"
                        + item.getExchangeDivision();
                if (inputIdList.contains(key)) {
                    it.remove();
                }
            }
        } else {
            result = fxdsInfoList.stream()
                    .filter(t -> TradeKbn.SECURITY.getCode().equals(t.getTradeDivision()))
                    .filter(t -> ProductEnum.FBOND_TRADE.getCode().equals(t.getProduct())
                            || t.getProduct() == null
                            || "1".equals(t.getCustomerDivision()))
                    .collect(Collectors.toList());
        }
        setDealerBook(result);
        return result;
    }

    /**
     * DFIT 為替トレードデータ・FXDS マッチング処理。
     *
     * @return マッチング後の DFIT ポジション集計元情報リスト
     */
    public List<PosSumSourceDto> matchDfitTradeExchangeDataForFxds() {
        List<String> currencyPairList = currencyMstList.stream()
                .map(c -> c.getDealCurrency() + c.getSettleCurrency())
                .collect(Collectors.toList());
        Iterator<PosSumSourceDto> it = dfitInfoList.iterator();
        while (it.hasNext()) {
            PosSumSourceDto item = it.next();
            if (!currencyPairList.contains(item.getDealCurrency() + item.getSettleCurrency())) {
                it.remove();
                // [Fixed P1] 対象外データは除外後に後続処理へ進ませない（除外後の cmst 参照による NPE 防止）
                continue;
            }
            TCurrencyMstBean currencyMst = currencyMstList.stream()
                    .filter(t -> t.getDealCurrency().equals(item.getDealCurrency()))
                    .filter(t -> t.getSettleCurrency().equals(item.getSettleCurrency()))
                    .findFirst().orElse(null);
            item.setDealAmount(new BigDecimal(item.getDealAmount().stripTrailingZeros().toPlainString()));
            item.setTradeRate(new BigDecimal(item.getTradeRate().stripTrailingZeros().toPlainString()));
            item.setSettleAmount(new BigDecimal(item.getSettleAmount().stripTrailingZeros().toPlainString()));
            // [Fixed P1] currencyMst が null の場合の NullPointerException を防止
            if (currencyMst != null
                    && ("1".equals(item.getInputDataSource()) || "2".equals(item.getInputDataSource()))) {
                item.setDeliveryDate(currencyMst.getSpotDate());
            }
            item.setInputDataSource(BatchConstants.DATA_SOURCE_DFIT);
        }
        return dfitInfoList;
    }

    /**
     * BID 為替トレードデータ・FXDS マッチング処理。
     *
     * @param autoFlg 自動約定フラグ（true: 営業店自動約定、false: インターナル伝票仕分け）
     * @return マッチング後の BID ポジション集計元情報リスト
     */
    public List<PosSumSourceDto> matchBidTradeForFxds(boolean autoFlg) {
        List<PosSumSourceDto> result;
        if (autoFlg) {
            result = bidInfoList.stream()
                    .filter(t -> "1".equals(t.getBidHonkbn()))
                    .collect(Collectors.toList());
        } else {
            result = bidInfoList.stream()
                    .filter(t -> !"1".equals(t.getBidHonkbn()) || t.getBidHonkbn() == null)
                    .filter(t -> "DD1".equals(t.getBidAtbutcd()))
                    .filter(t -> "911513".equals(t.getBidAkokcd1()))
                    .collect(Collectors.toList());
        }
        setDealerBook(result);
        return result;
    }

    /**
     * BID 外 M データ仕分けデータ・FXDS マッチング処理。
     *
     * @return BID 外 M データ仕分けリスト
     */
    public List<PosSumSourceDto> matchBidOutsideMForFxds() {
        setDealerBook(bidOutsideMInfoList);
        return bidOutsideMInfoList;
    }

    /**
     * 顧客名前（ディーラブック）設定処理。
     *
     * @param sourceList ポジション集計元情報データ
     */
    private void setDealerBook(List<PosSumSourceDto> sourceList) {
        for (PosSumSourceDto item : sourceList) {
            TDfitCustomerMstBean positionCust = findCustomer(item.getDepartmentCode(), item.getCustomerCode());
            TDfitCustomerMstBean spotCust = findCustomer(item.getDepartmentCodeSpot(), item.getCustomerCodeSpot());
            TDfitCustomerMstBean swapCust = findCustomer(item.getDepartmentCodeSwap(), item.getCustomerCodeSwap());

            if ("0".equals(item.getDealerBook())) {
                // フォワードから生成したスポット
                item.setExchangeDivision(ExchangeKbn.SPOT.getCode());
                applyDealerBook(item, positionCust, spotCust);
            }
            if ("1".equals(item.getDealerBook()) || "2".equals(item.getDealerBook())) {
                // フォワードから生成したスワップスタート・エンド
                if ("1".equals(item.getDealerBook())) {
                    item.setExchangeDivision(ExchangeKbn.SWAP_START.getCode());
                } else {
                    item.setExchangeDivision(ExchangeKbn.SWAP_END.getCode());
                }
                applyDealerBook(item, positionCust, swapCust);
            }
            if ("10".equals(item.getDealerBook())) {
                // スポット、スワップ
                TDfitCustomerMstBean fallbackCust =
                        ExchangeKbn.SPOT.getCode().equals(item.getExchangeDivision()) ? spotCust : swapCust;
                applyDealerBook(item, positionCust, fallbackCust);
            }
        }
    }

    /**
     * ディーラブック確定（ポジション表示顧客優先、なければフォールバック顧客）。
     *
     * @param item         対象データ
     * @param positionCust ポジション表示候補顧客
     * @param fallbackCust スポット/スワップのフォールバック顧客
     */
    private void applyDealerBook(PosSumSourceDto item, TDfitCustomerMstBean positionCust,
            TDfitCustomerMstBean fallbackCust) {
        if (isPositionCust(positionCust)) {
            item.setDealerBook(positionCust.getCustomerName());
        } else if (fallbackCust != null && fallbackCust.getCustomerName() != null) {
            item.setDealerBook(fallbackCust.getCustomerName());
        } else {
            item.setDealerBook(null);
        }
    }

    /**
     * 部課コード・顧客コードで顧客マスタを検索する。
     *
     * @param departmentCode 部課コード
     * @param customerCode   顧客コード
     * @return 該当顧客（なければ null）
     */
    private TDfitCustomerMstBean findCustomer(String departmentCode, String customerCode) {
        return dfitCustomerMstList.stream()
                .filter(t -> t.getDepartmentCode().equals(departmentCode))
                .filter(t -> t.getCustomerCode().equals(customerCode))
                .findFirst().orElse(null);
    }

    /**
     * ポジション表示対象の顧客マスタかどうか判定する（旧コードで 3 分岐に重複していた条件を共通化）。
     *
     * @param cust 顧客マスタ
     * @return ポジション表示対象なら true
     */
    private boolean isPositionCust(TDfitCustomerMstBean cust) {
        return cust != null
                && cust.getCustomerName() != null
                && cust.getRemarks() != null
                && cust.getRemarks().contains(REMARKS_POSITION);
    }
}
