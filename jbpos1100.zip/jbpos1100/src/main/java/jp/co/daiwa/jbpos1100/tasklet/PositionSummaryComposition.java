package jp.co.daiwa.jbpos1100.tasklet;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.batch.core.StepContribution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.TPosSumSourceDataRepository;
import jp.co.daiwa.dao.TPositionPlDeltaDataRepository;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.TPositionSwapSumDataRepository;
import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;
import jp.co.daiwa.jbpos1100.common.TransactionalBatchExecutor;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashCalculator;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashStore;
import jp.co.daiwa.jbpos1100.file.PositionSumFileWriter;
import jp.co.daiwa.jbpos1100.rate.RateLookupContext;
import jp.co.daiwa.jbpos1100.source.ClosingSpotSourceLoader;
import jp.co.daiwa.jbpos1100.source.PositionSourceMatcher;
import jp.co.daiwa.jbpos1100.source.PositionSourceRateMapper;
import jp.co.daiwa.jbpos1100.source.PositionSourceRepositoryGateway;
import jp.co.daiwa.jbpos1100.source.PositionSourceStore;
import jp.co.daiwa.jbpos1100.source.SourceDataMapper;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplitter;
import jp.co.daiwa.jbpos1100.spot.SpotCloseCostReplacer;
import jp.co.daiwa.jbpos1100.spot.SpotPositionAggregator;
import jp.co.daiwa.jbpos1100.spot.SpotSumStore;
import jp.co.daiwa.jbpos1100.spot.SpotSummaryService;
import jp.co.daiwa.jbpos1100.swap.SwapCashSumAssembler;
import jp.co.daiwa.jbpos1100.swap.SwapCurrencyAggregator;
import jp.co.daiwa.jbpos1100.swap.SwapItTradeUnitAggregator;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumCalculator;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSummaryService;
import jp.co.daiwa.jbpos1100.rate.YenRateResolver;

/**
 * ポジション集計 1 サイクルの合成ルート（旧 {@code posSumTask} に相当）。
 *
 * <p>{@link PositionSummaryCycle} を実装し、{@link PositionSummaryTasklet}（常駐ループ）から呼ばれる。
 * 1 サイクルで {@link StepContribution} に依存する協調オブジェクトを本クラスが構築し、集計元の収集・登録、
 * Real／プレ引値／引値／引値以降の各評価工程へ委譲する。</p>
 *
 * <p>配線層のため依存数が多く、ここではフィールドインジェクションを用いる（業務ロジック側は
 * すべてコンストラクタインジェクションでテスト容易にしてある）。{@code @Scope("step")} により
 * サイクルごとに新規生成され、可変 static を持たない。</p>
 *
 * <p>注: 一部の周辺工程（決済通貨外貨 PL デルタ生成＝旧 {@code setPosPlDeltaValueData}、
 * 引値レートファイル読込みの結果有無による分岐、引値スポットの DB 取得など）は別途整備が必要なため、
 * 本クラスでは委譲ポイントを明示し、未整備箇所は TODO として残す。</p>
 */
@Component
@Scope("step")
public class PositionSummaryComposition implements PositionSummaryCycle {

    @Inject
    @Named("jobTransactionManager")
    private PlatformTransactionManager transactionManager;

    @Inject
    private PositionSourceRepositoryGateway gateway;
    @Inject
    private TPosSumSourceDataRepository posSumSourceRepository;
    @Inject
    private TPositionSpotSumDataRepository spotSumRepository;
    @Inject
    private TPositionSwapSumDataRepository swapSumRepository;
    @Inject
    private TPositionPlDeltaDataRepository plDeltaRepository;
    @Inject
    private TByCcyDeltaCashBalanceRepository deltaCashRepository;
    @Inject
    private TSwapPlSumDateRepository swapPlSumRepository;

    @Inject
    private YenRateResolver yenRateResolver;
    @Inject
    private SourcePositionSplitter splitter;
    @Inject
    private ClosingSpotSourceLoader closingSpotSourceLoader;
    @Inject
    private SpotCloseCostReplacer spotCloseCostReplacer;
    @Inject
    private PositionSumFileWriter fileWriter;

    @Value("${bulk.insert.unit}")
    private int bulkInsertUnit;
    @Value("${job.jbpos1000.path}")
    private String outputFilePath;

    @Override
    public Date resolveTargetDate() {
        return gateway.resolveBusinessDate();
    }

    @Override
    public void runOnce(StepContribution contribution, Date targetDate) throws Exception {
        // --- 1 サイクル分の協調オブジェクトを構築（状態リーク防止のため毎回新規） ---
        JobWarningReporter reporter = new JobWarningReporter(contribution);
        TransactionalBatchExecutor executor = new TransactionalBatchExecutor(transactionManager, reporter);

        PositionSourceStore sourceStore = new PositionSourceStore(posSumSourceRepository, executor, bulkInsertUnit);
        PositionSourceRateMapper rateMapper = new PositionSourceRateMapper(yenRateResolver, reporter);
        SourceDataMapper sourceDataMapper = new SourceDataMapper(reporter);

        PositionEvaluationService evaluationService = buildEvaluationService(reporter, executor);
        ClosingEvaluationService closingService =
                new ClosingEvaluationService(closingSpotSourceLoader, splitter, evaluationService);
        AfterClosingEvaluationService afterService = new AfterClosingEvaluationService(
                splitter, new SwapItTradeUnitAggregator(reporter), spotCloseCostReplacer, rateMapper,
                evaluationService);

        Date previousBusinessDate = gateway.getPreviousBusinessDay(targetDate);

        // --- 集計元の収集 → 検証/変換 → レート割当 → 中間コミット登録 ---
        List<PosSumSourceDto> collected = collectSource(targetDate, previousBusinessDate);
        List<TPosSumSourceDataBean> sourceBeans = sourceDataMapper.map(targetDate, collected);
        // TODO: RateLookupContext（ベース/引値/通貨マスタ/マニュアル/BBG）の取得を整備し rateMapper.map を適用
        sourceStore.insert(sourceBeans);

        // --- 当該基準日の全集計元を再取得 ---
        TPosSumSourceDataBean condition = new TPosSumSourceDataBean();
        condition.setProcessBaseDate(targetDate);
        List<TPosSumSourceDataBean> allSource = posSumSourceRepository.getPosSumSourceDataAll(condition);

        // --- DF 算出結果 / DF 履歴の取得（スワップ集計の入力） ---
        List<TDfCalcResultBean> dfCalcResult = new ArrayList<>();   // TODO: dfCalcResultRepository から取得
        List<TDfHistoryDateBean> dfHistory = new ArrayList<>();     // TODO: dfHistoryRepository から取得

        // --- スポット集計のプレ引値→引値の橋渡し用共有リスト ---
        List<TPositionSpotSumDataBean> preClosingPlList = new ArrayList<>();

        // 1. Real 集計
        SourcePositionSplit realSplit = splitter.splitForReal(allSource, targetDate, previousBusinessDate);
        evaluationService.evaluate(contribution, targetDate, realSplit, allSource, dfCalcResult, dfHistory,
                EvaluationRateKbn.REAL.getCode(), preClosingPlList);

        // 2. プレ引値集計（スポットのみ）
        SourcePositionSplit preSplit = splitter.splitForPreClosing(allSource, targetDate, previousBusinessDate);
        evaluationService.evaluate(contribution, targetDate, preSplit, allSource, dfCalcResult, dfHistory,
                EvaluationRateKbn.PRE_CLOSING.getCode(), preClosingPlList);

        // TODO: 決済通貨外貨 PL デルタ生成（旧 setPosPlDeltaValueData）の移植・適用

        // 3. 引値集計（スポット＝プレ引値結果＋PLデルタ、スワップ＝引値ウィンドウ）
        closingService.evaluate(contribution, targetDate, previousBusinessDate, allSource, dfCalcResult, dfHistory,
                preClosingPlList);

        // 4. 引値以降集計
        List<TPositionSpotSumDataBean> spotClosingFromDb = closingSpotSourceLoader.loadClosingSpotResults(targetDate);
        RateLookupContext rateContext = null; // TODO: 引値以降の再マッピング用 RateLookupContext を整備
        afterService.evaluate(contribution, targetDate, previousBusinessDate, allSource, spotClosingFromDb,
                rateContext, dfCalcResult, dfHistory, preClosingPlList);

        // TODO: 日締めデータ複製（EndOfDayClosingDuplicator + 各 Store）の適用条件分岐
    }

    /** スワップ計算パイプライン＋永続化＋ファイル出力を束ねる評価サービスをサイクル単位で構築する。 */
    private PositionEvaluationService buildEvaluationService(JobWarningReporter reporter,
            TransactionalBatchExecutor executor) {
        SpotPositionAggregator spotAggregator = new SpotPositionAggregator(reporter);
        SpotSumStore spotSumStore = new SpotSumStore(spotSumRepository, executor, bulkInsertUnit);
        SpotSummaryService spotSummaryService = new SpotSummaryService(spotAggregator, spotSumStore);

        SwapSummaryService swapSummaryService = new SwapSummaryService(
                new SwapCashSumAssembler(reporter),
                new SwapCurrencyAggregator(reporter),
                new CurrencyDeltaCashCalculator(reporter),
                new SwapPlSumCalculator(reporter));

        SwapSumStore swapSumStore = new SwapSumStore(swapSumRepository, executor, bulkInsertUnit);
        CurrencyDeltaCashStore deltaCashStore = new CurrencyDeltaCashStore(deltaCashRepository, executor, bulkInsertUnit);
        SwapPlSumStore swapPlSumStore = new SwapPlSumStore(swapPlSumRepository, executor, bulkInsertUnit);

        return new PositionEvaluationService(spotSummaryService, swapSummaryService,
                swapSumStore, deltaCashStore, swapPlSumStore, fileWriter, outputFilePath);
    }

    /** 各データソース（FXDS/DFIT/BID）から集計元候補を突合・収集する。 */
    private List<PosSumSourceDto> collectSource(Date targetDate, Date previousBusinessDate) {
        // TODO: gateway からマスタ/トレードデータを取得し PositionSourceMatcher を構築する。
        //       （ここでは突合の呼び出し構造のみ示す。取得メソッドの整備後に有効化する。）
        PositionSourceMatcher matcher = buildMatcher(targetDate, previousBusinessDate);
        List<PosSumSourceDto> result = matcher.matchTradeMngDataForDfit(false);
        result.addAll(matcher.matchTradeMngDataForDfit(true));
        result.addAll(matcher.matchDfitTradeExchangeDataForFxds());
        result.addAll(matcher.matchBidTradeForFxds(true));
        result.addAll(matcher.matchBidTradeForFxds(false));
        result.addAll(matcher.matchBidOutsideMForFxds());
        return result;
    }

    /**
     * 当該サイクルの集計元マッチャを構築する。
     *
     * <p>TODO: 通貨マスタ・DFIT 顧客マスタ・DFIT トレード・FXDS/DFIT/BID 各情報を gateway 経由で取得して注入する。
     * 取得 API の整備までは空リストで構築する。</p>
     */
    private PositionSourceMatcher buildMatcher(Date targetDate, Date previousBusinessDate) {
        return new PositionSourceMatcher(
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
    }
}
