# jbpos1000 → jbpos1100 移行対応表

旧パッケージ `jp.co.daiwa.jbpos1000`（変更禁止・参照のみ）から、新パッケージ
`jp.co.daiwa.jbpos1100` への対応関係を示す。既存コードは一切変更していない。

---

## 1. クラス名の対応（④クラス名刷新）

| 旧クラス（jbpos1000） | 新クラス（jbpos1100） | 責務 |
|---|---|---|
| `Jbpos1000PosSumTasklet`（常駐ループ部） | `tasklet.PositionSummaryTasklet` | 常駐ループのオーケストレーションのみ |
| `Jbpos1000PosSumTasklet`（posSumTask 部） | `tasklet.PositionSummaryOrchestrator` | 1 サイクルのワークフロー定義 |
| `Jbpos1000JobListener` | `tasklet.PositionSummaryJobListener` | ジョブ終了ステータス判定 |
| `JbPositionDbOperation`（取得系） | `source.PositionSourceRepositoryGateway` | 集計元データの取得 |
| `JpPositionDataOperation` | `source.PositionSourceMatcher` | 集計元データの突合・ディーラブック設定 |
| `Jbpos1000PosSumTasklet`（集計元 delete/insert/update） | `source.PositionSourceStore` | 集計元の中間コミット永続化 |
| `Jbpos1000PosSumTasklet`（getBaseRateInfo） | `rate.BaseRateFileReader` | ベースレートファイル読込 |
| `Jbpos1000PosSumTasklet`（getCloseRateInfo） | `rate.CloseRateFileReader` | 当日引けレートファイル読込 |
| `Jbpos1000PosSumTasklet`（spot delete/insert） | `spot.SpotSumStore` | スポット集計結果の中間コミット永続化 |
| `Jbpos1000PosSumTasklet`（swap delete/insert） | `swap.SwapSumStore` | スワップ集計結果の中間コミット永続化 |
| `Jbpos1000PosSumTasklet`（plDelta delete/insert） | `delta.PlDeltaStore` | PL デルタの中間コミット永続化 |
| `Jbpos1000SwapSummary#mkByCcyDeltaCashBalance` | `delta.CurrencyDeltaCashCalculator` | 通貨別デルタ・キャッシュ残の集計（**P0 バグ修正**） |
| `Jbpos1000PosSumTasklet`（byCcyDeltaCash delete/insert） | `delta.CurrencyDeltaCashStore` | 通貨別デルタ・キャッシュ残の永続化 |
| `Jbpos1000PosSumTasklet`（swapPlSumDate delete/insert） | `swap.SwapPlSumStore` | スワップ PL 合計の永続化 |
| `Jbpos1000PosSumTasklet#setSpotSumDate` | `spot.SpotPositionAggregator` | スポット集計本体（健全・逐次状態を保持しつつ段階分割。BigDecimal==/equals(null) バグ修正反映） |
| `Jbpos1000PosSumTasklet#setClosingRate` | `spot.SpotClosingRateResolver` | 引値/引値円転レート再設定（**P0破損を修正のうえ移植**） |
| `Jbpos1000PosSumTasklet#setSourceData` | `source.SourceDataMapper` | 集計元DTO→Bean変換＋検証（**P0破損を修正のうえ移植**） |
| `Jbpos1000SwapSummary#mkSwapPlSumDate` | `swap.SwapPlSumCalculator` | スワップPL合計集計（**型不整合を修正のうえ移植**） |
| `Jbpos1000SwapSummary#getTPosCashSumData` | `swap.SwapCashSumAssembler` | スワップCF単位のPV組立（破損なし・段階分割／ロジック不変） |
| `Jbpos1000SwapSummary#sumPositionSwapData` | `swap.SwapCurrencyAggregator` | スワップ通貨単位纏め（破損なし・冗長Map除去／挙動不変） |
| `Jbpos1000PosSumTasklet#sumBigDecimal` | `common.BigDecimalSummer` | BigDecimal 合計ユーティリティ |
| （新規・中間コミット共通化） | `common.TransactionalBatchExecutor` | 中間コミット＋1 件リトライのテンプレート |
| （新規・警告状態の共通化） | `common.JobWarningReporter` | ジョブ警告状態の設定＋警告ログ |
| （新規・DB 切断判定の共通化） | `common.DbConnectionFailures` | DB 切断由来例外の判定 |
| （旧 `DBUtil#divideList` 依存） | `common.ListPartitioner` | リスト分割（テスト容易化のため内製） |
| （定数の二重定義） | `common.BatchConstants` | 共有定数の集約 |

---

## 2. 変数・フィールド名の対応（③変数名適切化）

### 2.1 不適切な綴り・大文字小文字・"0"/"O" 混在

| 旧名 | 新名 | 種別・理由 |
|---|---|---|
| `tPosSoptSumDataDao` | `spot` 関連は `SpotSumStore` 経由（`spotSumRepository`） | `Sopt`→`Spot` の綴り誤り |
| `geTPositionSpotSumDataBeanAll`（呼出側） | （外部 Repository メソッドのため改名不可。呼出は維持） | `ge`→`get` の綴り崩れ。外部 IF のため対応表に明記のみ |
| `Tb86bet0` / `TB86BET0` / `Tb86betO` | `businessDayRepository` / `TB86BET0Bean`（型は外部のため維持） | "0"/"O" 混在・大文字小文字不統一を、用途名（営業日）で吸収 |
| `closingDataLsit` | `closingDataList` | `Lsit`→`List` の綴り誤り |
| `tPosSwapItDataLsit` | `swapItDataList` | 同上 |
| `JbPositionDbOperation` / `JpPositionDataOperation` | `PositionSourceRepositoryGateway` / `PositionSourceMatcher` | `Jb`/`Jp` の紛らわしい接頭辞を責務名へ |
| `posdata` | `swapPositionData` 等 | ローカル変数の大文字小文字・意味不明瞭を解消 |
| `SwapSumData`（ローカル変数） | `swapSumCondition` / `swapSumData` | 変数なのに型風 PascalCase だったものを camelCase へ |
| `Delta`（ローカル変数） | `delta` | 変数なのに PascalCase |
| `dfitCurrencyMstList` | `dfitCustomerMstList` | 実体は「顧客マスタ」であり "Currency" は誤り |
| `tPosSumSourceSumDataList`（参照崩れ） | `sourceBeans` 等、宣言名に統一 | 宣言名と参照名の不一致を解消 |

### 2.2 定数（`private static final` ＋ SCREAMING_SNAKE_CASE へ統一）

| 旧名 | 新名（`common.BatchConstants`） |
|---|---|
| `BUY = "1"` | `DEAL_DIVISION_BUY` |
| `SELL = "2"` | `DEAL_DIVISION_SELL` |
| `RATESOURCESMART = "1"` | `RATE_SOURCE_SMART` |
| `RATESOURCEBBG = "0"` | `RATE_SOURCE_BBG` |
| `JPY = "JPY"` | `CURRENCY_JPY` |
| `DATA_SOURCE_BIDR = "BID_R"` | `DATA_SOURCE_BID_REAL` |
| `NONAC = "0"` | `AC_FLAG_IN_TIME` |
| `AC = "1"` | `AC_FLAG_AFTER_CLOSE` |
| `TRADEDCF = "4"` | `EXCHANGE_DIVISION_TRADED_CF` |
| `public static SimpleDateFormat fmt`（共有可変・スレッド非安全） | 使用箇所でローカル `SimpleDateFormat` 生成、または定数パターン `DATE_PATTERN_*` |

> 注: 旧コードは `Jbpos1000PosSumTasklet` と `Jbpos1000SwapSummary` の双方で
> `JPY` / `RATESOURCESMART` / `fmt` などを**二重定義**（継承による隠蔽）していた。
> `BatchConstants` へ一本化し隠蔽を解消した。

---

## 3. メソッド単位の主な対応

| 旧メソッド | 新クラス.メソッド |
|---|---|
| `posSumSourceDataDelete` | `PositionSourceStore.delete` |
| `posSumSourceDataInsert`（一括＋1 件リトライ） | `PositionSourceStore.insert` → `TransactionalBatchExecutor.bulkInsertWithRetry` |
| `posSumSourceDataUpdate` | `PositionSourceStore.update` |
| `isBizDate` | `PositionSourceRepositoryGateway.resolveBusinessDate` |
| `getPrevBizDay` | `PositionSourceRepositoryGateway.getPreviousBusinessDay` |
| `getPosSumSourceData` | `PositionSourceRepositoryGateway.getTradeMngSourceData` |
| `matchTradeMngDataForDfit` 他 match 系 | `PositionSourceMatcher.*`（同名、ロジック整理） |
| `setDealerBook`（3 分岐の重複条件） | `PositionSourceMatcher.applyDealerBook` ＋ `isPositionCust` に共通化 |
| `getBaseRateInfo` | `BaseRateFileReader.read` |
| `getCloseRateInfo` | `CloseRateFileReader.read` |
| `mkByCcyDeltaCashBalance` | `CurrencyDeltaCashCalculator.calculate` / `calculateForKey` / `resolveDelta` |
| `sumBigDecimal` | `BigDecimalSummer.sum` / `sumNullSafe` |
