package jp.co.daiwa.jbord4100;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import io.grpc.Server;
import io.grpc.ServerBuilder;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.jbord4100.grpc.FileEventServiceImpl;

/**
 * 応答電文取込処理 Tasklet（JBORD4100）
 *
 * <p>JBORD4000EX のリファクタリング版。業務ロジックは変えず、
 * 電文の取込とスレッド制御の構造のみを作り替えている。
 *
 * <h3>全体フロー</h3>
 * <pre>
 *   gRPC サーバ起動
 *   DB更新スレッド（既定 4 本）・ファイル更新スレッド（既定 6 本）を起動 ← ジョブ中ずっと常駐
 *   while (ストップファイルなし) {
 *       1. 受信電文ディレクトリを走査
 *       2. 空き枠がある分だけ読み込み、注文番号ごとのチェーンへ投入
 *          （※完了は待たない。空き枠が尽きたら残りはディスクに置いたまま次サイクルへ）
 *       3. スリープ
 *   }
 *   未着手電文をファイルへ書き戻し → 両段のスレッドを停止 → gRPC サーバ停止
 * </pre>
 *
 * <h3>JBORD4000EX からの主な変更点</h3>
 * <ol>
 * <li><b>サイクル内の完了待ちを全廃</b><br>
 * 旧版はサイクルごとに (a) 全 {@code Future} の完了待ち、(b) Poison Pill 投入後の
 * 通知ワーカー終了待ち、という 2 つの待ちを持っていた。このため 1 電文の処理時間が
 * そのまま次の電文の取込間隔になり、先行電文が長引くと後続電文の処理開始が同じだけ遅延した。
 * 本版はどちらの待ちもサイクルから除去している。</li>
 *
 * <li><b>スレッドを常駐化</b><br>
 * 旧版はサイクルごとに 2 つのスレッドプールを生成・破棄していた。
 * 本版はジョブ開始時に 1 度だけ生成し、ジョブ終了時に破棄する。
 * スレッド数は外部設定から変更できる（既定：DB更新 4 本、ファイル更新 6 本）。</li>
 *
 * <li><b>同一注文の直列化</b><br>
 * 旧版は同一注文の電文が並列実行され得たため、取引管理の read-modify-write が競合する
 * 可能性があった。本版は同一注文を到着順に直列処理する。</li>
 *
 * <li><b>流量制御とメモリ上限</b><br>
 * 旧版は走査で見つかった全ファイルを一括で読み込むため、取込件数に上限がなかった。
 * 本版は未処理件数に上限を設け、超過分はディスクに残す。</li>
 *
 * <li><b>停止時の電文保全</b><br>
 * 未着手電文をファイルへ書き戻してから停止する。</li>
 *
 * <li><b>例外の握り潰しを是正</b><br>
 * 旧版はメインループの catch で、DB接続例外以外の例外をログも出さずに捨てていた
 * （コメントには「WARNログを出力して」とあるが実装が無かった）。本版は必ず記録する。</li>
 * </ol>
 *
 * <h3>スレッド構成</h3>
 * <table border="1">
 * <tr><th>スレッド</th><th>本数</th><th>設定キー</th><th>役割</th></tr>
 * <tr><td>Tasklet実行スレッド</td><td>1</td><td>—</td><td>走査・読込・解析・投入（完了は待たない）</td></tr>
 * <tr><td>jbord4100-db-*</td><td>既定 4</td><td>job.jbord4100.db.thread.max</td><td>DB更新</td></tr>
 * <tr><td>jbord4100-file-*</td><td>既定 6</td><td>job.jbord4100.file.thread.max</td><td>ファイル更新（gRPC 配信）</td></tr>
 * </table>
 *
 * @see Jbord4100OrderedDispatcher スレッド制御・順序保証・流量制御の実体
 */
@Component("jbord4100Tasklet")
@Scope("step")
public class Jbord4100Tasklet implements Tasklet {

    /** DB更新スレッド数の既定値。 */
    private static final int DEFAULT_DB_THREAD_MAX = 4;

    /** ファイル更新スレッド数の既定値。 */
    private static final int DEFAULT_FILE_THREAD_MAX = 6;

    /** 未処理電文の上限係数の既定値（上限 = (DB本数 + ファイル本数) × 本値）。 */
    private static final int DEFAULT_QUEUE_FACTOR = 4;

    /** 停止時に各段の完了を待つ既定秒数。 */
    private static final int DEFAULT_SHUTDOWN_WAIT_SEC = 180;

    /** gRPC サーバの停止を待つ秒数。 */
    private static final int GRPC_SHUTDOWN_WAIT_SEC = 10;

    /** 特定の電文に紐付かないログの識別子欄。 */
    private static final String LOG_NO_KEY = "-";

    // ── ジョブ制御パラメータ ───────────────────────────────────────────────────

    /** ジョブ停止ファイルパス（このファイルが存在するとジョブを正常終了） */
    @Value("${job.jbord4100.stop.file}")
    private String defStopFile;

    /** ポーリング間隔（ミリ秒） */
    @Value("${job.jbord4100.sleep.ms}")
    private Integer sleepMs;

    /** DB更新スレッド数（常駐） */
    @Value("${job.jbord4100.db.thread.max:" + DEFAULT_DB_THREAD_MAX + "}")
    private Integer dbThreadMax;

    /** ファイル更新スレッド数（常駐） */
    @Value("${job.jbord4100.file.thread.max:" + DEFAULT_FILE_THREAD_MAX + "}")
    private Integer fileThreadMax;

    /** 未処理電文の上限係数（スレッド総数の何倍まで先読みするか） */
    @Value("${job.jbord4100.queue.factor:" + DEFAULT_QUEUE_FACTOR + "}")
    private Integer queueFactor;

    /** ジョブ停止時に各段の完了を待つ秒数 */
    @Value("${job.jbord4100.shutdown.wait.sec:" + DEFAULT_SHUTDOWN_WAIT_SEC + "}")
    private Integer shutdownWaitSec;

    /** gRPC サーバのリッスンポート */
    @Value("${job.jbord4100.grpc.port:50051}")
    private int grpcPort;

    // ── DI ───────────────────────────────────────────────────────────────────

    /** 受電文ファイル読込・FIX電文解析・書き戻し */
    @Inject
    private Jbord4100FileReader fileReader;

    /** DB更新段の業務処理 */
    @Inject
    private Jbord4100DbWorker dbWorker;

    // ── 実行時の状態 ──────────────────────────────────────────────────────────

    private FileEventServiceImpl grpcService;
    private Server grpcServer;
    private Jbord4100OrderedDispatcher dispatcher;

    /** 取込抑制中かどうか（ログの重複出力を防ぐための状態保持）。 */
    private boolean throttled = false;

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4100Tasklet.class);

    // ════════════════════════════════════════════════════════════════════════
    // メインループ
    // ════════════════════════════════════════════════════════════════════════

    @Override
    public RepeatStatus execute(StepContribution contribution,
                                 ChunkContext chunkContext) throws Exception {
        Path stopFilePath = Paths.get(defStopFile);

        // gRPC サーバ起動
        grpcService = new FileEventServiceImpl();
        grpcServer = ServerBuilder.forPort(grpcPort).addService(grpcService).build().start();
        logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_I028",
            "gRPC サーバ起動: port=" + grpcPort, LOG_NO_KEY);

        // 両段のスレッドを起動（以降ジョブ終了まで常駐する）
        dispatcher = new Jbord4100OrderedDispatcher(
            resolve(dbThreadMax, DEFAULT_DB_THREAD_MAX),
            resolve(fileThreadMax, DEFAULT_FILE_THREAD_MAX),
            resolve(queueFactor, DEFAULT_QUEUE_FACTOR),
            resolve(shutdownWaitSec, DEFAULT_SHUTDOWN_WAIT_SEC),
            dbWorker, fileReader);
        dispatcher.start(grpcService);

        try {
            while (true) {
                // ワーカー側で DB 切断を検知していた場合は処理終了
                if (dispatcher.isDbErrorDetected()) {
                    logger.error(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_E001", "DB接続",
                        new IllegalStateException("DB更新段が DB 切断を検知したため処理を終了します"));
                    break;
                }
                // ストップファイルが存在する場合、削除してジョブ終了
                if (Files.exists(stopFilePath)) {
                    deleteStopFile(stopFilePath, contribution);
                    break;
                }
                // ワーカーの失敗をジョブステータスへ反映（ExecutionContext への書き込みは本スレッドのみ）
                if (dispatcher.drainWorkerFailed()) {
                    setWarnStatus(contribution);
                }
                try {
                    // 到着済み電文のディスパッチ（完了は待たない）
                    dispatchArrivedMessages(contribution);
                } catch (Exception e) {
                    if (Jbord4100OrderedDispatcher.isDbIoException(e)) {
                        // DB接続例外はジョブループを停止する
                        logger.error(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                            "MSG_J_E001", "DB接続", e);
                        break;
                    }
                    // 旧版はここでログを出さずに握り潰していた
                    logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                        "MSG_J_W001", "電文ファイル取込処理", e);
                    setWarnStatus(contribution);
                }
                Thread.sleep(sleepMs);
            }
        } finally {
            // 例外・停止いずれの経路でも、未着手電文を保全してからスレッドを解放する
            dispatcher.shutdown(contribution);
            if (dispatcher.drainWorkerFailed()) {
                setWarnStatus(contribution);
            }
            shutdownGrpcServer();
        }
        return RepeatStatus.FINISHED;
    }

    // ════════════════════════════════════════════════════════════════════════
    // 1サイクルの電文ディスパッチ
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 到着済み電文をパイプラインへ投入する。
     *
     * <p>ワーカーの完了は待たないため、本メソッドの所要時間は
     * 「ファイル読込＋FIX解析」の時間のみで決まる。
     * 未処理電文が上限に達した場合、残りのファイルは読まずにディスクへ残し、次サイクルへ回す。</p>
     *
     * @param contribution Step実行状態
     */
    private void dispatchArrivedMessages(StepContribution contribution) {
        List<File> files = fileReader.listTargetFiles(contribution);
        if (files.isEmpty()) {
            // 滞留が解消された状態。抑制中だった場合はここで解除を記録する
            notifyThrottleCleared();
            return;
        }

        for (File file : files) {
            // 空き枠が無い場合、残りはディスクに置いたまま次サイクルへ回す
            if (!dispatcher.tryAcquire()) {
                notifyThrottled(files.size());
                return;
            }
            Jbord4100PendingMessage message = null;
            boolean dispatched = false;
            try {
                message = fileReader.readOne(file, contribution);
                if (message != null) {
                    dispatcher.submit(message);
                    dispatched = true;
                }
            } finally {
                if (!dispatched) {
                    dispatcher.releaseUnused(message);
                }
            }
        }
        notifyThrottleCleared();
    }

    // ════════════════════════════════════════════════════════════════════════
    // プライベートメソッド
    // ════════════════════════════════════════════════════════════════════════

    /**
     * gRPC サーバを停止する。
     *
     * <p>ファイル更新段が配信に使用するため、必ずディスパッチャの停止後に呼ぶこと。</p>
     */
    private void shutdownGrpcServer() {
        if (grpcServer == null) {
            return;
        }
        grpcServer.shutdown();
        try {
            if (!grpcServer.awaitTermination(GRPC_SHUTDOWN_WAIT_SEC, TimeUnit.SECONDS)) {
                grpcServer.shutdownNow();
            }
        } catch (InterruptedException e) {
            grpcServer.shutdownNow();
            Thread.currentThread().interrupt();
        }
        logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_I028",
            "gRPC サーバ停止", LOG_NO_KEY);
    }

    /**
     * ストップファイルを削除してジョブ正常終了を記録する。
     *
     * @param path ストップファイルパス
     * @param contribution Step実行状態
     */
    private void deleteStopFile(Path path, StepContribution contribution) {
        try {
            Files.deleteIfExists(path);
            logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_I001", defStopFile);
        } catch (IOException e) {
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "ストップファイル削除失敗", e);
            setWarnStatus(contribution);
        }
    }

    /**
     * 取込抑制の開始通知（状態が変化したときのみ出力）。
     *
     * @param backlogCount 走査時点の滞留ファイル数
     */
    private void notifyThrottled(int backlogCount) {
        if (throttled) {
            return;
        }
        throttled = true;
        logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_I028",
            String.format("【取込抑制開始】未処理電文が上限（%d件）に達しました。滞留ファイル数=%d",
                dispatcher.getMaxInFlight(), backlogCount), LOG_NO_KEY);
    }

    /** 取込抑制の解除通知（状態が変化したときのみ出力）。 */
    private void notifyThrottleCleared() {
        if (!throttled) {
            return;
        }
        throttled = false;
        logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_I028",
            "【取込抑制解除】", LOG_NO_KEY);
    }

    /**
     * 設定値を解決する（未設定・不正値の場合は既定値）。
     *
     * @param value 設定値
     * @param defaultValue 既定値
     * @return 解決後の値
     */
    private static int resolve(Integer value, int defaultValue) {
        return value != null && value > 0 ? value : defaultValue;
    }

    /** Job実行コンテキストにWARNステータスを設定する */
    private void setWarnStatus(StepContribution contribution) {
        contribution.getStepExecution().getJobExecution()
            .getExecutionContext()
            .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}
