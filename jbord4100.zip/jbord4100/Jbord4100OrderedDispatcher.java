package jp.co.daiwa.jbord4100;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.jbord4100.grpc.FileEventServiceImpl;

/**
 * 電文ディスパッチャ（DB更新段 ＋ ファイル更新段の 2 段パイプライン）
 *
 * <p>本クラスが jbord4100 のリファクタリングの中核であり、
 * スレッドの生成・常駐・破棄、注文単位の順序保証、流量制御、停止時の電文保全を一手に担う。
 *
 * <h3>パイプライン構成</h3>
 * <pre>
 *   受信電文ディレクトリ（ディスク）
 *       │ tryAcquire()  ← 未処理電文が上限に達したら取り込まない（背圧の起点）
 *       ▼
 *   注文番号ごとの直列チェーン（pendingByOrder）
 *       │
 *       ▼
 *   [DB更新段]   常駐 job.jbord4100.db.thread.max 本（既定 4）
 *       │ 有界キュー（容量 = 未処理電文の上限）
 *       ▼
 *   [ファイル更新段] 常駐 job.jbord4100.file.thread.max 本（既定 6）
 *       │
 *       └→ release()  ← ここまで完了して初めて permit を返す
 * </pre>
 *
 * <h3>設計上の要点</h3>
 * <ol>
 * <li><b>スレッドは常駐、サイクルごとに作り直さない</b><br>
 * 両プールとも {@link #start} で 1 度だけ生成し、{@link #shutdown} で破棄する。
 * DB更新段は {@code prestartAllCoreThreads()} で、ファイル更新段は常駐ループの投入で、
 * いずれも電文の有無によらずジョブ開始時から所定本数が起動している。</li>
 *
 * <li><b>完了待ちをサイクル内に持たない</b><br>
 * 呼び出し元（Tasklet）は投入するだけで完了を待たない。
 * jbord4000ex にあった「全 Future の完了待ち」と「Poison Pill によるワーカー終了待ち」を
 * どちらもサイクルから除去したため、電文の取込間隔が処理時間に左右されない。</li>
 *
 * <li><b>permit が 2 段にまたがる</b><br>
 * 流量制御の permit は「ファイル更新まで完了して初めて」返す。
 * これによりファイル更新段が詰まると permit が返らず、取込が自動的に止まる。
 * 段間キューが溢れて DB スレッドがブロックすることも、メモリが際限なく増えることもなく、
 * 背圧は最終的にディスク（受信電文ディレクトリの滞留）に吸収される。</li>
 *
 * <li><b>順序保証も 2 段にまたがる</b><br>
 * 同一注文の次電文は、先行電文が<b>ファイル更新まで完了してから</b> DB更新段へ進む。
 * DB更新の完了時点で次へ進めてしまうと、同一注文の出力順が入れ替わり得るため。
 * チェーンはスレッドを占有せず、完了イベントで駆動する。</li>
 *
 * <li><b>停止時に未着手電文を失わない</b><br>
 * 未着手（チェーン待ち・DB更新段のキュー待ち）の電文はファイルへ書き戻す。
 * 一方、<b>段間キューにある電文は書き戻さない</b>。DB更新が既にコミット済みのため、
 * 書き戻すと再処理により取引操作履歴などが二重登録されてしまう。
 * これらは配信し切ってから終了する。</li>
 * </ol>
 *
 * <h3>スレッド安全性</h3>
 * <p>{@link #pendingByOrder} と {@link #stopping} は {@link #lock} で保護する。
 * {@code ExecutionContext}（WARNステータス）への書き込みは Tasklet 実行スレッドからのみ行い、
 * ワーカースレッドはフラグを立てるだけとする。</p>
 */
public class Jbord4100OrderedDispatcher {

    /** DB更新スレッド名の接頭辞。 */
    private static final String DB_THREAD_PREFIX = "jbord4100-db-";

    /** ファイル更新スレッド名の接頭辞。 */
    private static final String FILE_THREAD_PREFIX = "jbord4100-file-";

    /** DB 切断判定で辿る cause の最大段数（循環 cause への保険）。 */
    private static final int MAX_CAUSE_DEPTH = 10;

    /** ログへ列挙する電文の最大件数。 */
    private static final int LOG_ID_LIMIT = 20;

    /** 特定の電文に紐付かないログの識別子欄。 */
    private static final String LOG_NO_KEY = "-";

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4100OrderedDispatcher.class);

    // ── 構成値 ───────────────────────────────────────────────────────────────

    private final int dbThreads;
    private final int fileThreads;
    private final int maxInFlight;
    private final int shutdownWaitSec;

    private final Jbord4100DbWorker dbWorker;
    private final Jbord4100FileReader fileReader;

    // ── 実行資源 ─────────────────────────────────────────────────────────────

    /** DB更新段の常駐スレッドプール。 */
    private ThreadPoolExecutor dbPool;

    /** ファイル更新段の常駐スレッドプール。 */
    private ThreadPoolExecutor filePool;

    /** 段間キュー（容量は未処理電文の上限と同じため、投入がブロックすることはない）。 */
    private BlockingQueue<Jbord4100PendingMessage> fileQueue;

    /** 未処理電文数（両段の合計）の上限を制御するセマフォ。 */
    private Semaphore capacity;

    // ── 状態 ─────────────────────────────────────────────────────────────────

    /**
     * 注文番号ごとの待機電文。
     *
     * <p>キーが存在すること自体が「当該注文が処理中」を意味する（値は後続の待機電文）。</p>
     */
    private final Map<String, Deque<Jbord4100PendingMessage>> pendingByOrder = new HashMap<>();

    /** {@link #pendingByOrder} と {@link #stopping} の排他制御。 */
    private final Object lock = new Object();

    /** 停止処理中か。true の間、チェーンは後続電文を引き取らない（書き戻し対象とするため）。 */
    private boolean stopping;

    /** ファイル更新段の停止指示。DB更新段の終了確認後に立てる。 */
    private volatile boolean fileStageStopping;

    /** 処理中（いずれかの段を通過中）の電文。停止時の記録に使用する。 */
    private final Set<Jbord4100PendingMessage> inFlight = ConcurrentHashMap.newKeySet();

    /** ワーカーが失敗したことを示すフラグ。Tasklet 実行スレッドが回収する。 */
    private final AtomicBoolean workerFailed = new AtomicBoolean(false);

    /** DB 切断を検知したことを示すフラグ。Tasklet 実行スレッドが回収する。 */
    private final AtomicBoolean dbErrorDetected = new AtomicBoolean(false);

    /**
     * @param dbThreads DB更新スレッド数
     * @param fileThreads ファイル更新スレッド数
     * @param queueFactor 未処理電文の上限係数（上限 = (dbThreads + fileThreads) × 本値）
     * @param shutdownWaitSec 停止時に各段の完了を待つ秒数
     * @param dbWorker DB更新段の業務処理
     * @param fileReader 電文の読込・書き戻し
     */
    public Jbord4100OrderedDispatcher(int dbThreads, int fileThreads, int queueFactor,
                                       int shutdownWaitSec,
                                       Jbord4100DbWorker dbWorker,
                                       Jbord4100FileReader fileReader) {
        this.dbThreads = dbThreads;
        this.fileThreads = fileThreads;
        this.maxInFlight = (dbThreads + fileThreads) * queueFactor;
        this.shutdownWaitSec = shutdownWaitSec;
        this.dbWorker = dbWorker;
        this.fileReader = fileReader;
    }

    // ════════════════════════════════════════════════════════════════════════
    // ライフサイクル
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 両段のスレッドを起動する。
     *
     * <p>電文の有無によらず、ここで所定本数のスレッドが常駐状態になる。</p>
     *
     * @param grpcService 配信先の gRPC サービス
     */
    public void start(FileEventServiceImpl grpcService) {
        capacity = new Semaphore(maxInFlight);
        fileQueue = new LinkedBlockingQueue<>(maxInFlight);

        AtomicInteger dbNo = new AtomicInteger();
        dbPool = new ThreadPoolExecutor(dbThreads, dbThreads, 0L, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(),
            runnable -> new Thread(runnable, DB_THREAD_PREFIX + dbNo.getAndIncrement()));
        // 電文が 1 件も無くても所定本数を起動しておく
        dbPool.prestartAllCoreThreads();

        AtomicInteger fileNo = new AtomicInteger();
        filePool = new ThreadPoolExecutor(fileThreads, fileThreads, 0L, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(),
            runnable -> new Thread(runnable, FILE_THREAD_PREFIX + fileNo.getAndIncrement()));
        // 常駐ループを本数分投入する（各スレッドはキュー待ちのまま常駐する）
        for (int i = 0; i < fileThreads; i++) {
            filePool.execute(new Jbord4100FileWorker(fileQueue, grpcService, this));
        }

        logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_I028",
            String.format("【スレッド起動】DB更新=%d本, ファイル更新=%d本, 未処理電文上限=%d件",
                dbThreads, fileThreads, maxInFlight), LOG_NO_KEY);
    }

    /**
     * 両段のスレッドを停止する。
     *
     * <p>停止順序が重要である。
     * <ol>
     * <li>未着手電文をファイルへ書き戻す（以降チェーンは後続を引き取らない）</li>
     * <li>DB更新段を締め切り、実行中の DB 更新の完了を待つ</li>
     * <li>DB更新段の終了を確認してからファイル更新段を締め切る<br>
     *     （先に締め切ると、その後に DB 更新を終えた電文の配信先が無くなるため）</li>
     * <li>段間キューを配信し切るまでファイル更新段の終了を待つ</li>
     * </ol>
     *
     * @param contribution ステップ実行情報
     */
    public void shutdown(StepContribution contribution) {
        if (dbPool == null) {
            return;
        }
        // ① 未着手電文の回収と書き戻し
        restoreNotStarted(contribution);

        long deadlineNanos = System.nanoTime() + TimeUnit.SECONDS.toNanos(shutdownWaitSec);

        // ② DB更新段の締め切りと完了待ち
        dbPool.shutdown();
        if (!awaitUntil(dbPool, deadlineNanos)) {
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_W001", "DB更新段の終了待ち",
                new IllegalStateException("待ち時間内に完了を確認できませんでした（中断はしません）: waitSec="
                    + shutdownWaitSec + ", 処理中電文=" + describeInFlight()));
            setWarnStatus(contribution);
        }

        // ③ ここで初めてファイル更新段を締め切る（以降キューへの追加は発生しない）
        fileStageStopping = true;
        filePool.shutdown();

        // ④ 段間キューを配信し切るまで待つ
        if (!awaitUntil(filePool, deadlineNanos)) {
            int undelivered = fileQueue.size();
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_W001", "ファイル更新段の終了待ち",
                new IllegalStateException("配信し切れませんでした（DB更新は確定済みのため失われるのは通知のみ）: 未配信="
                    + undelivered + "件, 処理中電文=" + describeInFlight()));
            setWarnStatus(contribution);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // 投入
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 未処理電文の枠を 1 件分確保する。
     *
     * <p>非ブロッキング。確保できない場合、呼び出し元は電文ファイルを読まずに残すこと。</p>
     *
     * @return 確保できた場合 true
     */
    public boolean tryAcquire() {
        return capacity.tryAcquire();
    }

    /**
     * 確保した枠を、電文を投入せずに返却する。
     *
     * @param message 対象電文（読込失敗時は null）
     */
    public void releaseUnused(Jbord4100PendingMessage message) {
        if (message == null || message.settle()) {
            capacity.release();
        }
    }

    /**
     * 電文をパイプラインへ投入する。
     *
     * <p>同一注文が処理中であれば待機キューへ積み、そうでなければ DB更新段へ投入する。</p>
     *
     * @param message 電文
     */
    public void submit(Jbord4100PendingMessage message) {
        String orderKey = message.getOrderKey();
        synchronized (lock) {
            Deque<Jbord4100PendingMessage> waiting = pendingByOrder.get(orderKey);
            if (waiting != null) {
                // 同一注文が処理中。到着順を守るため待機キューの末尾へ積む
                waiting.addLast(message);
                return;
            }
            // 空のキューを登録することが「処理中」のマークになる
            pendingByOrder.put(orderKey, new ArrayDeque<>());
        }
        submitToDbPool(message);
    }

    /**
     * DB更新段へ投入する。
     *
     * <p>投入できなかった場合（通常はジョブ停止時のみ）は、処理中マークを外し電文を書き戻す。</p>
     *
     * @param message 電文
     */
    private void submitToDbPool(Jbord4100PendingMessage message) {
        try {
            dbPool.execute(new DbStageTask(message));
        } catch (RuntimeException e) {
            synchronized (lock) {
                pendingByOrder.remove(message.getOrderKey());
            }
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_W001",
                "DB更新段への投入失敗: " + message.describe(), e);
            workerFailed.set(true);
            restoreOrReport(message);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // 各段の実行
    // ════════════════════════════════════════════════════════════════════════

    /**
     * DB更新段の起動タスク。
     *
     * <p>停止時にプールのキューへ未着手のまま残ったタスクから電文を取り出せるよう、
     * ラムダではなく名前付きクラスとして保持する。</p>
     */
    private final class DbStageTask implements Runnable {

        private final Jbord4100PendingMessage message;

        private DbStageTask(Jbord4100PendingMessage message) {
            this.message = message;
        }

        private Jbord4100PendingMessage getMessage() {
            return message;
        }

        @Override
        public void run() {
            runDbStage(message);
        }
    }

    /**
     * DB更新段の実行。
     *
     * <p>出力対象がある場合は段間キューへ引き渡し、この時点では permit を返さない。</p>
     *
     * @param message 電文
     */
    private void runDbStage(Jbord4100PendingMessage message) {
        inFlight.add(message);
        boolean handedOff = false;
        try {
            SambaWriteRequest request = dbWorker.process(message.getReport());
            message.setWriteRequest(request);
            if (request != null && request.hasAnyWriteRequest()) {
                // 容量は未処理電文の上限と同じため、ここでブロックすることはない
                fileQueue.put(message);
                handedOff = true;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_W001",
                "DB更新段の中断: " + message.describe(), e);
            workerFailed.set(true);
        } catch (Exception e) {
            if (isDbIoException(e)) {
                // DB切断は Tasklet 側へ通知してジョブを終了させる
                logger.error(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_E001", "DB接続", e);
                dbErrorDetected.set(true);
            } else {
                logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_W001",
                    "DB更新段: " + message.describe(), e);
                workerFailed.set(true);
            }
        } finally {
            if (!handedOff) {
                // 出力対象なし、または失敗。ここで完了扱いとする
                complete(message);
            }
        }
    }

    /**
     * ファイル更新段の完了通知（{@link Jbord4100FileWorker} から呼ばれる）。
     *
     * @param message 電文
     */
    public void completeFileStage(Jbord4100PendingMessage message) {
        complete(message);
    }

    /**
     * 電文 1 件の完了処理。
     *
     * <p>permit を返し、同一注文の次電文を DB更新段へ進める。</p>
     *
     * @param message 電文
     */
    private void complete(Jbord4100PendingMessage message) {
        inFlight.remove(message);
        if (message.settle()) {
            capacity.release();
        }
        advanceChain(message.getOrderKey());
    }

    /**
     * 同一注文の次電文を進める。
     *
     * <p>停止処理中は引き取らず、書き戻し側へ委ねる。</p>
     *
     * @param orderKey 注文番号
     */
    private void advanceChain(String orderKey) {
        Jbord4100PendingMessage next;
        synchronized (lock) {
            Deque<Jbord4100PendingMessage> waiting = pendingByOrder.get(orderKey);
            next = stopping || waiting == null ? null : waiting.pollFirst();
            if (next == null && (waiting == null || waiting.isEmpty())) {
                pendingByOrder.remove(orderKey);
            }
        }
        if (next != null) {
            submitToDbPool(next);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // 停止時の電文保全
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 未着手電文の回収と書き戻し。
     *
     * <p>回収対象は次の 2 か所。いずれも DB 更新に着手していないため、書き戻して再処理できる。</p>
     * <ol>
     * <li>{@link #pendingByOrder} … 同一注文の先行電文の完了待ち</li>
     * <li>DB更新段のキュー … 空きスレッド待ち</li>
     * </ol>
     *
     * <p>段間キューの電文は DB 更新がコミット済みのため<b>書き戻さない</b>（二重処理を防ぐため）。</p>
     *
     * @param contribution ステップ実行情報
     */
    private void restoreNotStarted(StepContribution contribution) {
        List<Jbord4100PendingMessage> targets = new ArrayList<>();
        synchronized (lock) {
            stopping = true;
            for (Deque<Jbord4100PendingMessage> waiting : pendingByOrder.values()) {
                targets.addAll(waiting);
                waiting.clear();
            }
        }
        // 空きスレッド待ちのまま起動していないタスクを回収する（drainTo は原子的）
        List<Runnable> notStarted = new ArrayList<>();
        dbPool.getQueue().drainTo(notStarted);
        for (Runnable runnable : notStarted) {
            if (runnable instanceof DbStageTask) {
                DbStageTask task = (DbStageTask) runnable;
                targets.add(task.getMessage());
                // このチェーンは起動しないため、処理中マークを解除する
                synchronized (lock) {
                    pendingByOrder.remove(task.getMessage().getOrderKey());
                }
            }
        }
        if (targets.isEmpty()) {
            return;
        }
        int restored = 0;
        for (Jbord4100PendingMessage message : targets) {
            if (restoreOrReport(message)) {
                restored++;
            }
        }
        logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_I028",
            String.format("【停止時書き戻し】未着手電文を受信電文パスへ戻しました。対象=%d件, 成功=%d件",
                targets.size(), restored), LOG_NO_KEY);
        if (restored < targets.size()) {
            setWarnStatus(contribution);
        }
    }

    /**
     * 電文をファイルへ書き戻す。失敗した場合は再送判断ができるよう記録する。
     *
     * @param message 電文
     * @return 書き戻せた場合 true
     */
    private boolean restoreOrReport(Jbord4100PendingMessage message) {
        if (!message.settle()) {
            // 既に完了済み。permit も返却済みのため何もしない
            return false;
        }
        try {
            fileReader.restore(message);
            return true;
        } catch (Exception e) {
            logger.error(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_E001",
                "電文書き戻し失敗（要再送）: " + message.describe(), e);
            workerFailed.set(true);
            return false;
        } finally {
            capacity.release();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // 状態参照・ユーティリティ
    // ════════════════════════════════════════════════════════════════════════

    /** @return ファイル更新段の停止指示が出ているか */
    public boolean isFileStageStopping() {
        return fileStageStopping;
    }

    /** @return DB 切断を検知しているか */
    public boolean isDbErrorDetected() {
        return dbErrorDetected.get();
    }

    /** ワーカー失敗を記録する（{@link Jbord4100FileWorker} から呼ばれる）。 */
    public void notifyWorkerFailed() {
        workerFailed.set(true);
    }

    /**
     * ワーカー失敗の有無を回収する（回収後はフラグをクリアする）。
     *
     * @return 前回の回収以降に失敗があった場合 true
     */
    public boolean drainWorkerFailed() {
        return workerFailed.compareAndSet(true, false);
    }

    /** @return 未処理電文の上限件数 */
    public int getMaxInFlight() {
        return maxInFlight;
    }

    /**
     * 指定期限までプールの終了を待つ。
     *
     * @param pool 対象プール
     * @param deadlineNanos 期限（{@code System.nanoTime()} 基準）
     * @return 期限内に終了した場合 true
     */
    private boolean awaitUntil(ThreadPoolExecutor pool, long deadlineNanos) {
        long remainNanos = deadlineNanos - System.nanoTime();
        if (remainNanos <= 0) {
            return pool.isTerminated();
        }
        try {
            return pool.awaitTermination(remainNanos, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return pool.isTerminated();
        }
    }

    /** @return 処理中電文の一覧（件数が多い場合は打ち切る） */
    private String describeInFlight() {
        List<Jbord4100PendingMessage> messages = new ArrayList<>(inFlight);
        String ids = messages.stream().limit(LOG_ID_LIMIT)
            .map(Jbord4100PendingMessage::describe).collect(Collectors.joining(", "));
        return messages.size() > LOG_ID_LIMIT ? ids + ", ...(全" + messages.size() + "件)" : ids;
    }

    /**
     * DB 切断由来の例外かを判定する。
     *
     * <p>jbord4000ex は最上位のメッセージのみを見ていたため、ラップされた例外を取りこぼす余地があった。</p>
     *
     * @param throwable 判定対象
     * @return DB 切断由来なら true
     */
    public static boolean isDbIoException(Throwable throwable) {
        Throwable current = throwable;
        for (int depth = 0; current != null && depth < MAX_CAUSE_DEPTH; depth++) {
            if (current.getMessage() != null && current.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                return true;
            }
            current = current.getCause();
        }
        return false;
    }

    /**
     * Job実行コンテキストにWARNステータスを設定する。
     *
     * <p>{@code ExecutionContext} はスレッドセーフではないため、Tasklet 実行スレッドからのみ呼ぶこと。</p>
     *
     * @param contribution ステップ実行情報
     */
    private void setWarnStatus(StepContribution contribution) {
        if (contribution == null) {
            return;
        }
        contribution.getStepExecution().getJobExecution()
            .getExecutionContext()
            .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}
