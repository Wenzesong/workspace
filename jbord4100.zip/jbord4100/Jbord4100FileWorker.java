package jp.co.daiwa.jbord4100;

import java.time.format.DateTimeFormatter;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TLeaveSttsMngBean;
import jp.co.daiwa.jbord4100.grpc.FileEvent;
import jp.co.daiwa.jbord4100.grpc.FileEventServiceImpl;
import jp.co.daiwa.jbord4100.grpc.LeaveFileEvent;
import jp.co.daiwa.jbord4100.grpc.ResponseFileEvent;
import jp.co.daiwa.jbord4100.grpc.TradeFileEvent;
import jp.co.daiwa.jbord4100.grpc.UserNotifyEvent;

/**
 * ファイル更新段の常駐ワーカー
 *
 * <p>キューから電文を取り出し、接続中の全 gRPC クライアントへイベントを配信する。
 * ジョブ開始時に {@code job.jbord4100.file.thread.max} 本（既定 6 本）が起動し、
 * ジョブ終了まで常駐する。
 *
 * <p>【jbord4000ex（Jbord4000ExGrpcNotifier）からの変更点】
 * <ol>
 * <li><b>Poison Pill を使わない</b><br>
 * 旧版は<b>サイクルごとに</b>ワーカーを起動し、サイクル末尾で Poison Pill を投入して
 * 終了させ、その終了を待っていた。この待ちが電文取込を止める原因の一つだった。<br>
 * 本版はワーカーを常駐させ、終了判定を
 * {@link Jbord4100OrderedDispatcher#isFileStageStopping()} で行う。
 * ジョブ停止時にキューを完全に飲み干してから終了するため、通知の取りこぼしがない。</li>
 *
 * <li><b>完了を通知する</b><br>
 * 配信完了時に {@link Jbord4100OrderedDispatcher#completeFileStage} を呼ぶ。
 * これにより、流量制御の permit がファイル更新まで完了して初めて返却され、
 * 同一注文の次電文もこの時点で初めて DB 更新段へ進む（＝出力順序が保証される）。</li>
 * </ol>
 */
public class Jbord4100FileWorker implements Runnable {

    /** キュー待ちのポーリング間隔（ミリ秒）。停止判定のためのみに使用する。 */
    private static final long POLL_INTERVAL_MS = 500L;

    private static final DateTimeFormatter FILE_DATE_FORMAT =
        DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4100FileWorker.class);

    /** 電文の受け渡しキュー */
    private final BlockingQueue<Jbord4100PendingMessage> queue;

    /** gRPC サービス（ブロードキャスト先） */
    private final FileEventServiceImpl grpcService;

    /** 完了通知先 */
    private final Jbord4100OrderedDispatcher dispatcher;

    public Jbord4100FileWorker(BlockingQueue<Jbord4100PendingMessage> queue,
                                FileEventServiceImpl grpcService,
                                Jbord4100OrderedDispatcher dispatcher) {
        this.queue = queue;
        this.grpcService = grpcService;
        this.dispatcher = dispatcher;
    }

    @Override
    public void run() {
        while (true) {
            Jbord4100PendingMessage message;
            try {
                message = queue.poll(POLL_INTERVAL_MS, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            if (message == null) {
                // キューが空。停止指示済みならここで終了する（＝残件は必ず処理し切ってから終わる）
                if (dispatcher.isFileStageStopping()) {
                    return;
                }
                continue;
            }
            try {
                publish(message.getWriteRequest());
            } catch (Exception e) {
                logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                    "MSG_J_W001", "ファイル更新段: " + message.describe(), e);
                dispatcher.notifyWorkerFailed();
            } finally {
                dispatcher.completeFileStage(message);
            }
        }
    }

    /**
     * 書込み要求の内容を種別ごとに gRPC イベントとして配信する。
     *
     * @param request 書込み要求
     */
    private void publish(SambaWriteRequest request) {
        if (request == null) {
            return;
        }

        // 応答ファイル → ResponseFileEvent
        if (request.isWriteResponseFile()) {
            grpcService.broadcast(FileEvent.newBuilder()
                .setResponseFile(ResponseFileEvent.newBuilder()
                    .setClordId(request.getClordId())
                    .setOrdStatus(request.getOrdStatus()))
                .build());
        }

        // リーブオーダー連携ファイル → LeaveFileEvent
        if (request.isWriteLeaveFile() && request.getLeaveSttsMngInfo() != null) {
            grpcService.broadcast(FileEvent.newBuilder()
                .setLeaveFile(buildLeaveFileEvent(request.getLeaveSttsMngInfo()))
                .build());
        }

        // 取引管理ファイル → TradeFileEvent
        // TODO: TTradeMngBean のフィールドが確定したら file_event.proto と併せて実装する
        if (request.isWriteTradeFile() && request.getTradeMngInfo() != null) {
            grpcService.broadcast(FileEvent.newBuilder()
                .setTradeFile(TradeFileEvent.newBuilder()
                    .setTradeId(request.getTradeMngInfo().toString())
                    .build())
                .build());
        }

        // ユーザ通知ファイル → UserNotifyEvent
        // TODO: UserNotificationDto のフィールドが確定したら file_event.proto と併せて実装する
        if (request.isWriteUserNotification() && request.getUserNotificationDto() != null) {
            grpcService.broadcast(FileEvent.newBuilder()
                .setUserNotify(UserNotifyEvent.newBuilder()
                    .setNotifyType("")
                    .setMessage("")
                    .build())
                .build());
        }
    }

    private LeaveFileEvent buildLeaveFileEvent(TLeaveSttsMngBean bean) {
        return LeaveFileEvent.newBuilder()
            .setOrderNumber(bean.getOrderNumber().toString())
            .setReservationStatus(bean.getReservationStatus())
            .setDeadlineDatetimeDiv(bean.getDeadlineDatetimeDivision())
            .setDeadlineDatetime(FILE_DATE_FORMAT.format(
                bean.getDeadlineDatetime().toLocalDateTime()))
            .setLimitRate(bean.getLimitRate().toString())
            .setDeliveryDateDiv(bean.getDeliveryDateDivision())
            .setOrderDatetime(FILE_DATE_FORMAT.format(
                bean.getOrderDatetime().toLocalDateTime()))
            .setRegisterUser(bean.getRegisterUser())
            .setRegisterDatetime(FILE_DATE_FORMAT.format(
                bean.getRegisterDatetime().toLocalDateTime()))
            .setUpdateUser(bean.getUpdateUser())
            .setUpdateDatetime(FILE_DATE_FORMAT.format(
                bean.getUpdateDatetime().toLocalDateTime()))
            .build();
    }
}
