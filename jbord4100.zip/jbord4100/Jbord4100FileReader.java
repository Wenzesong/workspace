package jp.co.daiwa.jbord4100;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.StepContribution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.TargetFileFilter;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.common.parser.FixMsgParserEx;
import jp.co.daiwa.dto.fix.ExecutionReport;

/**
 * FIX電文ファイル読込クラス
 *
 * <p>受信電文ディレクトリを走査し、1 件ずつ読み込んで FIX 電文を解析する。
 *
 * <p>【jbord4000ex からの変更点】
 * <ol>
 * <li><b>1 件ずつ読み込む API に変更</b><br>
 * 旧版の {@code readAll()} は走査で見つかった全ファイルを一括で読み込むため、
 * 大量到着時のメモリ使用量に上限がなかった。本版は
 * {@link #listTargetFiles} でファイル一覧のみを返し、
 * 呼び出し側が流量を見ながら {@link #readOne} を 1 件ずつ呼ぶ。</li>
 *
 * <li><b>元のバイト列を保持</b><br>
 * ジョブ停止時に未着手の電文をファイルへ復元できるよう、読み込んだバイト列を
 * {@link Jbord4100PendingMessage} に保持する。</li>
 *
 * <li><b>走査結果の null 対策</b><br>
 * ディレクトリ不在・I/O エラー時に {@code File#listFiles} が返す null を明示的に扱う。</li>
 * </ol>
 *
 * <p>【パフォーマンス】
 * FIX電文パーサー（{@link FixMsgParserEx}）はスレッドアンセーフのためファイルごとに新規生成する。
 * fixTagMap はインジェクション済みの Map を共有参照する（読み取り専用のため安全）。
 */
@Component
public class Jbord4100FileReader {

    /** 受電文ファイルディレクトリ */
    @Value("${job.jbord4000.output.path2}")
    private String inputFilePath;

    /** 受電文ファイル名プレフィックス（絞り込みに使用） */
    @Value("${job.jbord4000.res.output.file.name}")
    private String inputFileNamePrefix;

    /** FIX電文区切り文字 */
    @Value("${fix.msg.delimiter}")
    private String delimiter;

    /** FIX電文タグ情報（タグ番号→フィールド名マッピング） */
    @Value("#{${fix.tag}}")
    private Map<String, String> fixTagMap;

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4100FileReader.class);

    /**
     * 処理対象ファイルの一覧を、ファイル名昇順（＝到着順）で返す。
     *
     * <p>ファイルの読み込みは行わない。呼び出し側が流量制御を行いながら
     * {@link #readOne} を呼ぶことを想定する。</p>
     *
     * @param contribution Stepの実行状態（WARN設定に使用）
     * @return 処理対象ファイル（存在しない場合・走査できない場合は空リスト）
     */
    public List<File> listTargetFiles(StepContribution contribution) {
        FileFilter filter = new TargetFileFilter(inputFileNamePrefix, ".*");
        File[] files = new File(inputFilePath).listFiles(filter);

        if (files == null) {
            // ディレクトリ不在または I/O エラー（旧版は空リスト扱いで原因が埋もれていた）
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_W001", "受信電文パス走査",
                new IOException("受信電文パスを走査できません: " + inputFilePath));
            setWarnStatus(contribution);
            return Collections.emptyList();
        }
        if (files.length == 0) {
            return Collections.emptyList();
        }
        // ファイル名昇順ソート（電文の到着順序を保証）
        Arrays.sort(files);
        return Arrays.asList(files);
    }

    /**
     * 電文ファイル 1 件を読み込み・解析し、処理済みファイルを削除する。
     *
     * <p>解析に失敗した場合は ERR_ プレフィックスを付けて同ディレクトリへ退避し、null を返す。</p>
     *
     * @param file 電文ファイル
     * @param contribution Stepの実行状態
     * @return 解析成功時は電文、失敗時は null
     */
    public Jbord4100PendingMessage readOne(File file, StepContribution contribution) {
        Path filePath = file.toPath();
        Jbord4100PendingMessage message = parseOneFile(filePath, contribution);
        if (message == null) {
            return null;
        }
        // 解析済みファイルを削除（次サイクルで重複処理しないため）
        try {
            Files.deleteIfExists(filePath);
        } catch (Exception e) {
            // 削除失敗は次サイクルで再処理されるが業務継続は可能
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "ファイル削除失敗: " + file.getName(), e);
        }
        return message;
    }

    /**
     * 未着手の電文を元のファイル名で受信電文ディレクトリへ復元する。
     *
     * <p>同名ファイルが存在する場合は既存電文を壊さないため上書きしない。</p>
     *
     * @param message 復元する電文
     * @throws IOException 復元に失敗した場合
     */
    public void restore(Jbord4100PendingMessage message) throws IOException {
        Files.write(Paths.get(inputFilePath, message.getFileName()), message.getContent(),
            StandardOpenOption.CREATE_NEW);
    }

    /**
     * 電文ファイル1件を解析し {@link Jbord4100PendingMessage} に変換する。
     *
     * <p>TransactTime はFIXテキスト先頭17文字（UTCタイムスタンプ形式）で上書きする。
     * これはパーサーが17文字より長い形式で返す場合の補正処理。
     *
     * @param filePath 電文ファイルパス
     * @param contribution Stepの実行状態
     * @return 解析成功時は電文、失敗時は null
     */
    private Jbord4100PendingMessage parseOneFile(Path filePath, StepContribution contribution) {
        try {
            // 書き戻し用に元のバイト列を保持したうえで解析する
            byte[] content = Files.readAllBytes(filePath);
            String fixMsgText = decodeStrict(content);

            FixMsgParserEx parser = new FixMsgParserEx(delimiter, fixTagMap);
            parser.parse(fixMsgText);
            ExecutionReport report = parser.extractData(ExecutionReport.class);

            // TransactTimeはFIXテキスト先頭17文字（"yyyyMMdd-HH:mm:ss"形式）
            if (report.getTransactTime() != null && fixMsgText.length() >= 17) {
                report.setTransactTime(fixMsgText.substring(0, 17));
            }
            return new Jbord4100PendingMessage(filePath.getFileName().toString(), content, report);

        } catch (Exception e) {
            // パース失敗ファイルをエラーディレクトリへ退避
            moveToErrorDirectory(filePath);
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_W002", "parseOneFile",
                FxdConstants.ERR_PREFIX + filePath.getFileName(), e);
            setWarnStatus(contribution);
            return null;
        }
    }

    /**
     * パース失敗ファイルを ERR_ プレフィックス付きで同ディレクトリに退避する。
     *
     * @param filePath 退避対象ファイルパス
     */
    private void moveToErrorDirectory(Path filePath) {
        Path dest = Paths.get(inputFilePath, FxdConstants.ERR_PREFIX + filePath.getFileName());
        try {
            Files.move(filePath, dest, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            // 退避失敗は警告ログのみ（元ファイルは次サイクルで再処理）
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "エラーファイル退避失敗: " + filePath.getFileName(), e);
        }
    }

    /**
     * UTF-8 の厳密デコード
     *
     * <p>不正バイトを置換文字で黙って通さず例外とする（{@code Files#readString} と同じ挙動）。</p>
     *
     * @param content バイト列
     * @return 文字列
     * @throws CharacterCodingException 不正なバイト列の場合
     */
    private static String decodeStrict(byte[] content) throws CharacterCodingException {
        return StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(content))
            .toString();
    }

    /** Job実行コンテキストにWARNステータスを設定する */
    private void setWarnStatus(StepContribution contribution) {
        if (contribution == null) {
            return;
        }
        contribution.getStepExecution().getJobExecution()
            .getExecutionContext()
            .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}
