package jp.co.daiwa.jbord4100;

import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dto.fix.ExecutionReport;
import jp.co.daiwa.jbord4100.Jbord4100DbService.OrderContext;

/**
 * DB更新段の業務処理
 *
 * <p>電文 1 件に対する DB 更新を実行し、ファイル更新段へ渡す書込み要求を組み立てる。
 * 実際の業務ロジックは {@link Jbord4100DbService}・{@link Jbord4100Helper} に委譲し、
 * 本クラスは処理順序の制御・タイミング計測に専念する。
 *
 * <p>【jbord4000ex（Jbord4000ExProcessWorker）からの変更点】
 * <ol>
 * <li><b>電文ごとの {@code new} をやめ、状態を持たない Spring Bean にした</b><br>
 * 旧版は電文 1 件ごとに {@code Callable} インスタンスを生成し、依存を全てコンストラクタで
 * 受け取っていた。本版は依存を DI で受け取り、処理対象は引数で受け渡す。
 * これにより常駐スレッドプールから何度でも安全に呼び出せる。</li>
 *
 * <li><b>キューへの投入を行わない</b><br>
 * 旧版は自身で Samba キューへ {@code put} していたが、本版は書込み要求を戻り値として返し、
 * ファイル更新段への引き渡しは {@link Jbord4100OrderedDispatcher} が行う。
 * これにより、キューが詰まった場合に DB スレッドがブロックされることがなくなる。</li>
 *
 * <li><b>トランザクション定義をサイクルごとに生成しない</b><br>
 * 設定値のみを保持する読み取り専用オブジェクトのため、Bean 生成時に 1 度だけ作る。</li>
 * </ol>
 *
 * <p>【スレッド安全性】
 * インスタンス変数は全て不変または状態を持たないシングルトン Bean であり、
 * DB更新スレッド（既定 4 本）から同時に呼び出しても安全。
 */
@Component
public class Jbord4100DbWorker {

    /** DB更新サービス */
    @Inject
    private Jbord4100DbService dbService;

    /** 変換・補正・通知生成サービス */
    @Inject
    private Jbord4100Helper helper;

    /** トランザクションマネージャー */
    @Inject
    @Named("jobTransactionManager")
    private PlatformTransactionManager transactionManager;

    /**
     * 中間コミット用トランザクション定義。
     *
     * <p>設定値のみを保持する読み取り専用オブジェクトのため、全スレッドで共有する。</p>
     */
    private final DefaultTransactionDefinition definition = createDefinition();

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4100DbWorker.class);

    private static DefaultTransactionDefinition createDefinition() {
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        // 電文ごとに独立したトランザクション（1電文の失敗が他電文に影響しない）
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        return def;
    }

    /**
     * 電文 1 件の DB 更新を実行する。
     *
     * <p>処理フロー
     * <ol>
     * <li>初期化：注文存在確認・取引管理情報取得</li>
     * <li>取引管理DB更新</li>
     * <li>リーブオーダーDB更新</li>
     * <li>応答ファイル書込みフラグのセット</li>
     * </ol>
     *
     * @param report 処理対象 FIX 電文
     * @return ファイル更新段へ渡す書込み要求（出力対象が無い場合もある）
     * @throws Exception DB接続例外（呼び出し元でジョブ停止判定）
     */
    public SambaWriteRequest process(ExecutionReport report) throws Exception {
        long startTime = System.currentTimeMillis();
        SambaWriteRequest request = new SambaWriteRequest();

        // ── ① 初期化：注文存在確認・取引情報取得 ───────────────────────────
        Optional<OrderContext> ctxOpt = dbService.initialize(report, request, helper);
        if (ctxOpt.isEmpty()) {
            // 注文未存在時は通知のみを返して終了
            return request;
        }
        OrderContext ctx = ctxOpt.get();

        // ── ② 取引管理DB更新 ─────────────────────────────────────────────
        long tradeStart = System.currentTimeMillis();
        dbService.updateTrade(report, ctx, request, transactionManager, definition, helper);
        long tradeEnd = System.currentTimeMillis();

        // ── ③ リーブオーダーDB更新 ──────────────────────────────────────
        dbService.updateLeaveOrder(report, ctx, request, transactionManager, helper);
        long leaveEnd = System.currentTimeMillis();

        // ── ④ 応答ファイル書込みフラグをセット（init成功時は常に出力） ─────
        request.setClordId(report.getClordID());
        request.setOrdStatus(report.getOrdStatus());
        request.setWriteResponseFile(true);

        // 処理時間ログ（取引DB更新・リーブDB更新・合計）
        logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name, "MSG_J_I028",
            String.format("【DB更新段】trade=%dms, leave=%dms, total=%dms",
                tradeEnd - tradeStart,
                leaveEnd - tradeEnd,
                leaveEnd - startTime),
            report.getClordID());

        return request;
    }
}
