package jp.co.daiwa.jbord4100.grpc;

import io.grpc.stub.ServerCallStreamObserver;
import io.grpc.stub.StreamObserver;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.JobConstants;

/**
 * gRPC サービス実装 — 全接続クライアントへのブロードキャスト
 *
 * <p>C# クライアントが Subscribe すると {@link #subscribe} が呼ばれ、
 * そのストリームを {@link #clients} リストに登録する。
 * {@link #broadcast} を呼ぶと接続中の全クライアントにイベントが送信される。
 *
 * <p>クライアントが切断（アプリ終了・ネットワーク断）すると
 * {@code onCancelHandler} が発火してリストから自動除去される。
 *
 * <p>スレッド安全性：{@link CopyOnWriteArrayList} により
 * broadcast 中に別スレッドが接続・切断しても安全。
 */
public class FileEventServiceImpl
        extends FileEventServiceGrpc.FileEventServiceImplBase {

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(FileEventServiceImpl.class);

    private final List<ServerCallStreamObserver<FileEvent>> clients =
        new CopyOnWriteArrayList<>();

    /**
     * C# クライアントからの Subscribe 要求を受け付ける。
     *
     * <p>{@code onCompleted()} を呼ばないことでストリームを維持し続ける。
     * クライアント切断時は {@code setOnCancelHandler} で自動的にリストから除去する。
     */
    @Override
    public void subscribe(SubscribeRequest request,
                          StreamObserver<FileEvent> responseObserver) {

        ServerCallStreamObserver<FileEvent> serverObserver =
            (ServerCallStreamObserver<FileEvent>) responseObserver;

        clients.add(serverObserver);
        logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
            "MSG_J_1001", "gRPC クライアント接続: " + request.getClientId()
                + " (接続数: " + clients.size() + ")");

        serverObserver.setOnCancelHandler(() -> {
            clients.remove(serverObserver);
            logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_1001", "gRPC クライアント切断: " + request.getClientId()
                    + " (接続数: " + clients.size() + ")");
        });

        // onCompleted() を呼ばない → ストリームをオープンのまま維持
    }

    /**
     * 接続中の全クライアントにイベントを送信する。
     *
     * <p>送信失敗したクライアント（切断済みだが未除去）は
     * 例外キャッチ時にリストから除去する。
     *
     * @param event 送信するイベント
     */
    public void broadcast(FileEvent event) {
        for (ServerCallStreamObserver<FileEvent> client : clients) {
            try {
                client.onNext(event);
            } catch (Exception e) {
                clients.remove(client);
                logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                    "MSG_J_W001", "gRPC broadcast 送信失敗（クライアント除去）", e);
            }
        }
    }

    /** 現在の接続クライアント数を返す（監視・ログ用） */
    public int getClientCount() {
        return clients.size();
    }
}
