package jp.co.daiwa.jbord4100;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.DateUtil;
import jp.co.daiwa.common.constant.FxdEnum.MsgType;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.common.constant.OrdStatusEnum.OrdStatus;
import jp.co.daiwa.common.constant.ReservationStatusEnum.ResStatus;
import jp.co.daiwa.common.constant.UserNotificationEnum.NotificationType;
import jp.co.daiwa.dao.bean.TB86BET0Bean;
import jp.co.daiwa.dao.bean.TTradeMngBean;
import jp.co.daiwa.daobid.Tb86bet0Repository;
import jp.co.daiwa.dto.UserNotificationDto;
import jp.co.daiwa.dto.fix.ExecutionReport;

/**
 * 変換・補正・ユーザ通知生成クラス
 *
 * <p>以下の3機能を集約する。
 * <ol>
 *   <li>FIXステータス変換：OrdStatus / 予約ステータスへのマッピング</li>
 *   <li>約定日時補正：UTC→JST変換 + 取引時間外の営業日開始時刻補正</li>
 *   <li>ユーザ通知DTO生成：電文種別・注文ステータス・アメンドフラグの組合せで通知内容を決定</li>
 * </ol>
 *
 * <p>【スレッド安全性】
 * インスタンス変数は読み取り専用の設定値と {@link DateTimeFormatter}（不変）のみ。
 * 複数スレッドから安全に呼び出せる。
 *
 * <p>【パフォーマンス】
 * 取引開始・終了時刻の {@link LocalTime} は起動時に1回だけパースし
 * {@code @PostConstruct} でキャッシュする（毎呼び出しでのパース処理を排除）。
 */
@Component
public class Jbord4100Helper {

    /** 取引開始時刻文字列（例："09:00:00"） */
    @Value("${trade.start.time}")
    private String tradeStartTimeStr;

    /** 取引終了時刻文字列（例："15:30:00"） */
    @Value("${trade.end.time}")
    private String tradeEndTimeStr;

    @Inject
    private Tb86bet0Repository tb86bet0Repository;

    /** JSTタイムゾーン（UTC+9、夏時間なし） */
    private static final ZoneId JST = ZoneId.of("Asia/Tokyo");

    /** 営業日テーブル検索・約定日時組み立て用フォーマット（"yyyyMMddHH:mm:ss"） */
    private static final DateTimeFormatter TRADE_DATE_FORMAT =
        DateTimeFormatter.ofPattern("yyyyMMddHH:mm:ss");

    /** 取引時刻比較用フォーマット（"HH:mm:ss"） */
    private static final DateTimeFormatter TIME_FORMAT =
        DateTimeFormatter.ofPattern("HH:mm:ss");

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4100Helper.class);

    /** 【パフォーマンス】取引開始時刻（起動時にパースしてキャッシュ） */
    private LocalTime tradeStartTime;

    /** 【パフォーマンス】取引終了時刻（起動時にパースしてキャッシュ） */
    private LocalTime tradeEndTime;

    /** 起動時に取引時刻文字列をパースしてキャッシュする */
    @PostConstruct
    private void init() {
        this.tradeStartTime = LocalTime.parse(tradeStartTimeStr, TIME_FORMAT);
        this.tradeEndTime   = LocalTime.parse(tradeEndTimeStr,   TIME_FORMAT);
    }

    // ════════════════════════════════════════════════════════════════════════
    // FIXステータス変換
    // ════════════════════════════════════════════════════════════════════════

    /**
     * FIX OrdStatus を内部注文ステータスに変換する。
     *
     * <p>マッピング定義：
     * <ul>
     *   <li>"0" → {@link OrdStatus#ORDER}（注文受付）</li>
     *   <li>"2" → {@link OrdStatus#CONTRACTED}（約定）</li>
     *   <li>"3","4","8","C" → {@link OrdStatus#ORDER_CANCEL}（取消）</li>
     *   <li>その他 → null（DB更新不要）</li>
     * </ul>
     *
     * @param fixOrdStatus FIX OrdStatusコード
     * @return 内部注文ステータス、または null（更新不要）
     */
    public OrdStatus resolveOrderStatus(String fixOrdStatus) {
        if (fixOrdStatus == null) return null;
        return switch (fixOrdStatus) {
            case "0"                -> OrdStatus.ORDER;
            case "2"                -> OrdStatus.CONTRACTED;
            case "3", "4", "8", "C" -> OrdStatus.ORDER_CANCEL;
            default                 -> null;
        };
    }

    /**
     * FIX OrdStatus をリーブオーダー予約ステータスに変換する。
     *
     * <p>マッピング定義：
     * <ul>
     *   <li>"C" → {@link ResStatus#EXPIRED}（期限切れ）</li>
     *   <li>"2" → {@link ResStatus#DONE}（約定済み）</li>
     *   <li>"3","4","8" → {@link ResStatus#CANCEL}（取消）</li>
     *   <li>"0" およびその他 → null（予約ステータス変更不要）</li>
     * </ul>
     *
     * @param fixOrdStatus FIX OrdStatusコード
     * @return 予約ステータス値、または null（変更不要）
     */
    public String resolveReservationStatus(String fixOrdStatus) {
        if (fixOrdStatus == null) return null;
        return switch (fixOrdStatus) {
            case "C"           -> ResStatus.EXPIRED.getValue();
            case "2"           -> ResStatus.DONE.getValue();
            case "3", "4", "8" -> ResStatus.CANCEL.getValue();
            default            -> null; // "0"（注文受付）は予約ステータス変更なし
        };
    }

    // ════════════════════════════════════════════════════════════════════════
    // 約定日時補正
    // ════════════════════════════════════════════════════════════════════════

    /**
     * UTC約定日時をJSTに変換し、取引時間外の場合は補正する。
     *
     * <p>補正ルール（リーブオーダーのみ適用）：
     * <ol>
     *   <li>取引時間内 → そのまま返す</li>
     *   <li>取引開始前 → 当日取引開始時刻に補正</li>
     *   <li>取引終了後 → 翌営業日取引開始時刻に補正</li>
     * </ol>
     *
     * <p>営業日テーブル（TB86BET0）が取得できない場合は補正せず
     * UTC→JSTのみ変換して返す。
     *
     * @param utcTimestamp  UTC約定日時文字列（FIXテキスト先頭17文字）
     * @param applyAdjust   true=補正あり（リーブオーダー）、false=UTC→JST変換のみ
     * @return 補正後の約定日時
     */
    public Date adjustTradeDateTime(String utcTimestamp, boolean applyAdjust) {
        // UTC→JSTへの変換（ハードコードの +9h は廃止、タイムゾーン定義を使用）
        Date rawDate = DateUtil.parseTimestamp(utcTimestamp, 0);
        if (rawDate == null) return null;

        if (!applyAdjust) {
            // 通常注文はUTC→JST変換のみ（取引時間補正不要）
            return toJst(rawDate);
        }

        try {
            ZonedDateTime jst = rawDate.toInstant().atZone(JST);
            LocalTime tradeTime = jst.toLocalTime();
            String ymd = DateUtil.convertDateToStrYmd(Date.from(jst.toInstant()));

            TB86BET0Bean bizDay = tb86bet0Repository
                .getBusinessDay(new TB86BET0Bean(ymd));

            // 営業日テーブル取得不可 → 補正なし（UTC→JSTのみ）
            if (bizDay == null) return toJst(rawDate);

            if (!tradeTime.isBefore(tradeStartTime)
                    && !tradeTime.isAfter(tradeEndTime)) {
                // 取引時間内 → そのまま
                return toJst(rawDate);
            } else if (tradeTime.isBefore(tradeStartTime)) {
                // 取引開始前 → 当日の取引開始時刻に補正
                return toTimestamp(ymd, tradeStartTimeStr);
            } else {
                // 取引終了後 → 翌営業日の取引開始時刻に補正
                TB86BET0Bean nextBiz = tb86bet0Repository
                    .getNextOrPreBizDay(ymd, 1);
                return toTimestamp(nextBiz.getRekiymd(), tradeStartTimeStr);
            }
        } catch (Exception e) {
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "adjustTradeDateTime", e);
            return toJst(rawDate);
        }
    }

    /** UTC日時をJSTに変換する（ZoneId使用） */
    private Date toJst(Date utcDate) {
        ZonedDateTime jst = utcDate.toInstant().atZone(JST);
        return Date.from(jst.toInstant());
    }

    /** 営業日文字列と時刻文字列からTimestampを生成する */
    private Timestamp toTimestamp(String ymd, String timeStr) {
        return Timestamp.valueOf(
            LocalDateTime.parse(ymd + timeStr, TRADE_DATE_FORMAT));
    }

    // ════════════════════════════════════════════════════════════════════════
    // ユーザ通知DTO生成
    // ════════════════════════════════════════════════════════════════════════

    /**
     * リーブオーダー用ユーザ通知DTOを生成する。
     *
     * <p>通知パターン（MsgType=8）：
     * <table border="1">
     *   <tr><th>OrdStatus</th><th>isAmend</th><th>isAmendCancel</th><th>通知種別</th></tr>
     *   <tr><td>"0"（受付）</td><td>true</td><td>-</td><td>THIRTYSIX（アメンド完了）</td></tr>
     *   <tr><td>"0"（受付）</td><td>false</td><td>-</td><td>通知なし</td></tr>
     *   <tr><td>"C"（Expired）</td><td>-</td><td>-</td><td>SIX</td></tr>
     *   <tr><td>"2"（約定）</td><td>-</td><td>-</td><td>FIVE</td></tr>
     *   <tr><td>"4"（取消）</td><td>-</td><td>true</td><td>通知なし（アメンドキャンセルのため）</td></tr>
     *   <tr><td>"4"（取消）</td><td>-</td><td>false</td><td>SEVEN（キャンセル成功）</td></tr>
     * </table>
     *
     * <p>通知パターン（MsgType=9）：
     * <ul><li>FOUR（キャンセル失敗）</li></ul>
     *
     * @param report        FIX電文情報
     * @param tradeMngInfo  取引管理情報（注文番号・改版番号・ユーザグループID取得用）
     * @param isAmend       アメンド操作有無
     * @param isAmendCancel アメンドキャンセル操作有無
     * @return 通知DTO（通知不要の場合は {@link Optional#empty()}）
     */
    public Optional<UserNotificationDto> createLeaveOrderNotification(
            ExecutionReport report,
            TTradeMngBean tradeMngInfo,
            boolean isAmend,
            boolean isAmendCancel) {

        if (tradeMngInfo == null) return Optional.empty();

        String orderNum = tradeMngInfo.getOrderNumber().toString();
        UserNotificationDto dto = buildBaseDto(tradeMngInfo);

        if (MsgType.TYPE_8.value().equals(report.getMsgType())) {
            return buildType8Notification(
                report.getOrdStatus(), orderNum, dto, isAmend, isAmendCancel);

        } else if (MsgType.TYPE_9.value().equals(report.getMsgType())) {
            // MsgType=9：キャンセル失敗通知
            dto.setText("リーブオーダーのキャンセルが失敗しました。[" + orderNum + "]");
            dto.setType(NotificationType.FOUR.value());
            return Optional.of(dto);
        }

        return Optional.empty();
    }

    /**
     * MsgType=8 の通知内容を OrdStatus・アメンドフラグで分岐して生成する。
     */
    private Optional<UserNotificationDto> buildType8Notification(
            String ordStatus,
            String orderNum,
            UserNotificationDto dto,
            boolean isAmend,
            boolean isAmendCancel) {

        return switch (ordStatus) {
            case "0" -> {
                // アメンドによる注文受付のみ通知。通常の受付は通知不要
                if (!isAmend) yield Optional.empty();
                dto.setText("リーブオーダーのアメンドが完了しました。[" + orderNum + "]");
                dto.setType(NotificationType.THIRTYSIX.value());
                yield Optional.of(dto);
            }
            case "C" -> {
                dto.setText("リーブオーダーがExpiredしました。[" + orderNum + "]");
                dto.setType(NotificationType.SIX.value());
                yield Optional.of(dto);
            }
            case "2" -> {
                dto.setText("リーブオーダーが約定しました。[" + orderNum + "]");
                dto.setType(NotificationType.FIVE.value());
                yield Optional.of(dto);
            }
            case "4" -> {
                // アメンドキャンセルによる取消は通知不要（別途アメンド通知が送られるため）
                if (isAmendCancel) yield Optional.empty();
                dto.setText("リーブオーダーのキャンセルが成功しました。[" + orderNum + "]");
                dto.setType(NotificationType.SEVEN.value());
                yield Optional.of(dto);
            }
            default -> Optional.empty();
        };
    }

    /**
     * 注文未存在時の通知（通知種別28）を生成する。
     *
     * <p>応答電文の ClOrdID に対応する発注履歴が存在しない場合に呼び出す。
     *
     * @param clordId FIX ClOrdID
     * @param ordNm   注文番号
     * @return 通知DTO
     */
    public UserNotificationDto createOrderNotFoundNotification(
            String clordId, BigDecimal ordNm) {
        UserNotificationDto dto = new UserNotificationDto();
        dto.setText(String.format(
            NotificationType.TWENTYEIGHT.getName(),
            ordNm.toString(), clordId));
        dto.setType(NotificationType.TWENTYEIGHT.value());
        return dto;
    }

    /** 取引管理情報から通知DTOの共通フィールドを設定する */
    private UserNotificationDto buildBaseDto(TTradeMngBean tradeMngInfo) {
        UserNotificationDto dto = new UserNotificationDto();
        dto.setOrderNumber(tradeMngInfo.getOrderNumber().toString());
        dto.setRevisionNumber(tradeMngInfo.getRevisionNumber().toString());
        dto.setUserGroupId(tradeMngInfo.getUserGroupId());
        return dto;
    }
}
