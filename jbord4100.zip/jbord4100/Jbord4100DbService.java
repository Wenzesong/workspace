package jp.co.daiwa.jbord4100;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.CollectionUtils;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.ExchangeKbnEnum.ExchangeKbn;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.common.constant.OrdStatusEnum.OrdStatus;
import jp.co.daiwa.dao.TLeaveSttsMngRepository;
import jp.co.daiwa.dao.TTradeMngRepository;
import jp.co.daiwa.dao.TTradeopeHistoryRepository;
import jp.co.daiwa.dao.bean.TLeaveSttsMngBean;
import jp.co.daiwa.dao.bean.TTradeOpeHistoryBean;
import jp.co.daiwa.dao.bean.TTradeMngBean;
import jp.co.daiwa.dto.fix.ExecutionReport;

/**
 * DB更新サービス
 *
 * <p>FIX応答電文に対する全DB更新処理を集約する。
 * <ul>
 *   <li>{@link #initialize}：取引管理情報・リーブオーダー情報の取得と存在確認</li>
 *   <li>{@link #updateTrade}：取引管理テーブルの更新 + 操作履歴の登録</li>
 *   <li>{@link #updateLeaveOrder}：リーブオーダーステータス管理テーブルの更新</li>
 * </ul>
 *
 * <p>【スレッド安全性】
 * 本クラスはSpringのシングルトンBeanだが、
 * 処理状態を表すデータは {@link OrderContext} オブジェクトに格納して
 * メソッド引数で受け渡す設計とし、インスタンス変数に処理状態を持たない。
 * そのため複数スレッドから安全に呼び出せる。
 *
 * <p>【トランザクション】
 * 各更新処理は PROPAGATION_REQUIRES_NEW で独立したトランザクションを使用し、
 * 1電文内の更新失敗が他の電文に影響しないよう設計している。
 */
@Service
public class Jbord4100DbService {

    @Inject private TTradeMngRepository      tradeMngRepository;
    @Inject private TLeaveSttsMngRepository  leaveSttsMngRepository;
    @Inject private TTradeopeHistoryRepository tradeOpeHistoryRepository;

    /** 取引操作履歴：注文受付時の操作内容 */
    private static final String OPER_ACCEPT   = "注文受付による更新";

    /** 取引操作履歴：注文応答時の操作内容 */
    private static final String OPER_RESPONSE = "注文応答による更新";

    /** アメンド判定キーワード */
    private static final String KEYWORD_AMEND        = "画面.アメンド";

    /** アメンドキャンセル判定キーワード */
    private static final String KEYWORD_AMEND_CANCEL = "アメンドによる取消";

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4100DbService.class);

    // ════════════════════════════════════════════════════════════════════════
    // 初期化
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 取引管理情報・リーブオーダー情報を取得し、処理継続可否を判定する。
     *
     * <p>処理継続不可の判定条件：
     * <ol>
     *   <li>応答注文番号が発注履歴に存在しない → ユーザ通知をrequestに設定</li>
     *   <li>取引管理情報が存在しない → WARNログのみ</li>
     * </ol>
     *
     * @param report   FIX電文情報
     * @param request  Samba書込み要求（注文未存在時の通知設定に使用）
     * @param helper   ユーザ通知生成用
     * @return 処理継続可能な場合 {@link OrderContext}、不可の場合 {@link Optional#empty()}
     */
    public Optional<OrderContext> initialize(ExecutionReport report,
                                              SambaWriteRequest request,
                                              Jbord4100Helper helper) {
        BigDecimal ordNm = extractOrderNumber(report.getClordID());

        // ① 応答注文番号の存在確認（発注が先行していることの検証）
        String noRlyOrdNum = tradeOpeHistoryRepository.getRplyOrdNumber(ordNm);
        if (noRlyOrdNum == null) {
            // 応答に対応する発注が存在しない → ユーザへ通知して処理終了
            request.setUserNotificationDto(
                helper.createOrderNotFoundNotification(report.getClordID(), ordNm));
            request.setWriteUserNotification(true);
            return Optional.empty();
        }

        // ② 取引管理情報の取得（最新改版）
        TTradeMngBean tradeMngInfo = tradeMngRepository.findMaxRevision(ordNm);
        if (tradeMngInfo == null) {
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "取引管理情報取得",
                new RuntimeException("tradeMngInfo is null. orderNumber=" + ordNm));
            return Optional.empty();
        }

        // ③ リーブオーダーの場合は関連情報も取得
        TLeaveSttsMngBean leaveSttsMngInfo = null;
        if (isLeaveOrder(report.getClordID())) {
            TLeaveSttsMngBean key = new TLeaveSttsMngBean();
            key.setOrderNumber(ordNm);
            leaveSttsMngInfo = leaveSttsMngRepository.searchLeaveSttsInfo(key);
        }

        return Optional.of(new OrderContext(ordNm, tradeMngInfo, leaveSttsMngInfo));
    }

    // ════════════════════════════════════════════════════════════════════════
    // 取引管理DB更新
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 取引管理テーブルを更新し、取引操作履歴を登録する。
     *
     * <p>以下の場合は更新をスキップする：
     * <ul>
     *   <li>FIX OrdStatus が未知のコード（更新対象外）</li>
     *   <li>既に約定済みの注文に対して再度約定応答が来た場合（重複防止）</li>
     * </ul>
     *
     * <p>スポット取引が約定した場合は受渡日（SettlDate）も更新する。
     *
     * @param report     FIX電文情報
     * @param ctx        初期化済み注文コンテキスト
     * @param request    Samba書込み要求（更新後情報をセット）
     * @param txManager  トランザクションマネージャー
     * @param definition トランザクション定義
     * @param helper     ステータス変換・日時補正用
     */
    public void updateTrade(ExecutionReport report,
                             OrderContext ctx,
                             SambaWriteRequest request,
                             PlatformTransactionManager txManager,
                             DefaultTransactionDefinition definition,
                             Jbord4100Helper helper) {

        // FIXステータスを内部ステータスへ変換（null=更新不要）
        OrdStatus newStatus = helper.resolveOrderStatus(report.getOrdStatus());
        if (newStatus == null) return;

        // 約定済みへの重複更新防止
        if (OrdStatus.CONTRACTED.equals(newStatus)
                && OrdStatus.CONTRACTED.getCode().equals(
                    ctx.tradeMngInfo.getOrderStatus())) {
            return;
        }

        // スポット約定時：受渡日を SettlDate で更新
        // ClOrdID の第2セグメントが "1"（現物）または "C"（通貨）の場合のみ対象
        String ordType = report.getClordID().split(FxdConstants.HYPHEN)[1];
        if (("1".equals(ordType) || "C".equals(ordType))
                && ctx.leaveSttsMngInfo != null
                && ExchangeKbn.SPOT.getCode().equals(
                    ctx.leaveSttsMngInfo.getDeliveryDateDivision())
                && OrdStatus.CONTRACTED.equals(newStatus)) {
            ctx.tradeMngInfo.setDeliveryDate(
                jp.co.daiwa.common.DateUtil.parseDate(report.getSettlDate()));
        }

        // 取引管理情報の更新値をセット
        ctx.tradeMngInfo.setOrderStatus(newStatus.getCode());
        ctx.tradeMngInfo.setTradeDatetime(
            helper.adjustTradeDateTime(report.getTransactTime(),
                ctx.isLeaveOrder())); // リーブオーダーのみ取引時間補正
        ctx.tradeMngInfo.setSystemTradeDatetime(
            jp.co.daiwa.common.DateUtil.parseTimestamp(report.getTransactTime(), 0));
        ctx.tradeMngInfo.setUpdateUser(JobConstants.Jbord4000);
        ctx.tradeMngInfo.setUpdateDatetime(
            new Timestamp(System.currentTimeMillis()));

        // 取消ステータスの場合は論理削除フラグを立てる
        if (OrdStatus.ORDER_CANCEL.equals(newStatus)) {
            ctx.tradeMngInfo.setDeleteFlag(FxdConstants.DEL_FLG);
        }

        // トランザクション開始（REQUIRES_NEW：他電文の処理と独立）
        TransactionStatus txStatus = null;
        try {
            txStatus = txManager.getTransaction(definition);
            tradeMngRepository.updateStatus(ctx.tradeMngInfo);
            registerTradeOpeHistory(ctx.tradeMngInfo, report.getOrdStatus());
            txManager.commit(txStatus);

            // コミット成功後にSamba書込み要求をセット
            request.setTradeMngInfo(copyTradeMng(ctx.tradeMngInfo));
            request.setWriteTradeFile(true);

        } catch (Exception e) {
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "updateTrade", e);
            if (txStatus != null) txManager.rollback(txStatus);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // リーブオーダーDB更新
    // ════════════════════════════════════════════════════════════════════════

    /**
     * リーブオーダーステータス管理テーブルを更新する。
     *
     * <p>リーブオーダー対象外（leaveSttsMngInfo が null）の場合は何もしない。
     *
     * <p>予約ステータスが変化しない場合（OrdStatus="0" の注文受付など）でも、
     * アメンド操作があればユーザ通知を生成する。
     *
     * <p>アメンドフラグ判定：
     * <ul>
     *   <li>isAmend：操作履歴に "画面.アメンド" を含むレコードが存在する</li>
     *   <li>isAmendCancel：操作履歴に "アメンドによる取消" を含むレコードが存在する</li>
     * </ul>
     * 【バグ修正】旧実装では {@code !CollectionUtils.isNotEmpty(list)} を使用していたが、
     * これは {@code isEmpty()} と等価であり論理が逆転していた。正しくは {@code anyMatch} で判定する。
     *
     * @param report     FIX電文情報
     * @param ctx        初期化済み注文コンテキスト
     * @param request    Samba書込み要求（更新後情報・通知をセット）
     * @param txManager  トランザクションマネージャー
     * @param helper     ステータス変換・通知生成用
     */
    public void updateLeaveOrder(ExecutionReport report,
                                  OrderContext ctx,
                                  SambaWriteRequest request,
                                  PlatformTransactionManager txManager,
                                  Jbord4100Helper helper) {

        if (ctx.leaveSttsMngInfo == null) return;

        // アメンドフラグ判定（操作履歴を参照）
        List<TTradeOpeHistoryBean> history = tradeOpeHistoryRepository
            .getTradeOpeHistoryInfo(ctx.leaveSttsMngInfo.getOrderNumber());

        // 【パフォーマンス】anyMatch は条件合致後に短絡評価するため全件走査を回避
        boolean isAmend = !CollectionUtils.isEmpty(history)
            && history.stream().anyMatch(
                t -> t.getOperation().contains(KEYWORD_AMEND));
        boolean isAmendCancel = !CollectionUtils.isEmpty(history)
            && history.stream().anyMatch(
                t -> t.getOperation().contains(KEYWORD_AMEND_CANCEL));

        // 予約ステータス変換（null=変更不要）
        String reservationStatus = helper.resolveReservationStatus(
            report.getOrdStatus());

        if (reservationStatus == null) {
            // ステータス変更なし（OrdStatus="0" の注文受付など）
            // アメンド操作の場合のみユーザ通知が必要
            helper.createLeaveOrderNotification(
                    report, ctx.tradeMngInfo, isAmend, isAmendCancel)
                  .ifPresent(dto -> {
                      request.setUserNotificationDto(dto);
                      request.setWriteUserNotification(true);
                  });
            return;
        }

        // リーブオーダーDB更新（REQUIRES_NEW：他電文と独立したトランザクション）
        DefaultTransactionDefinition localDef = new DefaultTransactionDefinition();
        localDef.setPropagationBehavior(
            org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        TransactionStatus txStatus = null;

        try {
            ctx.leaveSttsMngInfo.setReservationStatus(reservationStatus);
            ctx.leaveSttsMngInfo.setUpdateUser(JobConstants.Jbord4000);

            txStatus = txManager.getTransaction(localDef);
            leaveSttsMngRepository.registLeaveSttsMng(ctx.leaveSttsMngInfo);
            txManager.commit(txStatus);

            // コミット成功後にSamba書込み要求をセット
            request.setLeaveSttsMngInfo(copyLeaveSttsMng(ctx.leaveSttsMngInfo));
            request.setWriteLeaveFile(true);

        } catch (Exception e) {
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "updateLeaveOrder", e);
            if (txStatus != null) txManager.rollback(txStatus);
        }

        // DB更新成否に関わらずユーザ通知は生成する
        helper.createLeaveOrderNotification(
                report, ctx.tradeMngInfo, isAmend, isAmendCancel)
              .ifPresent(dto -> {
                  request.setUserNotificationDto(dto);
                  request.setWriteUserNotification(true);
              });
    }

    // ════════════════════════════════════════════════════════════════════════
    // プライベートメソッド
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 取引操作履歴を登録する。
     *
     * <p>OrdStatus="0"（注文受付）は "注文受付による更新"、
     * それ以外は "注文応答による更新" として登録する。
     */
    private void registerTradeOpeHistory(TTradeMngBean tradeMng, String ordStatus) {
        TTradeOpeHistoryBean bean = new TTradeOpeHistoryBean();
        bean.setOrderNumber(tradeMng.getOrderNumber());
        bean.setRevisionNumber(tradeMng.getRevisionNumber());
        bean.setExchangeDivision(tradeMng.getExchangeDivision());
        bean.setHistoryNumber(
            tradeOpeHistoryRepository.findMaxHistoryNumber(bean));
        bean.setOperation("0".equals(ordStatus) ? OPER_ACCEPT : OPER_RESPONSE);
        bean.setOperationUser(JobConstants.Jbord4000);
        tradeOpeHistoryRepository.registTradeOpeHistory(bean);
    }

    /**
     * ClOrdID からハイフン区切り第3セグメントを注文番号として抽出する。
     * 例："ORDER-1-12345" → 12345
     */
    private BigDecimal extractOrderNumber(String clordId) {
        return new BigDecimal(clordId.split(FxdConstants.HYPHEN)[2]);
    }

    /**
     * ClOrdID がリーブオーダー系かどうかを判定する。
     * CLORD_LV または CLORD_LV_CANCEL を含む場合はリーブオーダー。
     */
    private boolean isLeaveOrder(String clordId) {
        return clordId.contains(FxdConstants.CLORD_LV)
            || clordId.contains(FxdConstants.CLORD_LV_CANCEL);
    }

    /** 取引管理情報をシャロウコピーする（Samba書込みキューへ渡す用） */
    private TTradeMngBean copyTradeMng(TTradeMngBean src) {
        TTradeMngBean dst = new TTradeMngBean();
        dst.setOrderNumber(src.getOrderNumber());
        dst.setRevisionNumber(src.getRevisionNumber());
        dst.setExchangeDivision(src.getExchangeDivision());
        dst.setOrderStatus(src.getOrderStatus());
        dst.setTradeDatetime(src.getTradeDatetime());
        dst.setSystemTradeDatetime(src.getSystemTradeDatetime());
        dst.setUpdateUser(src.getUpdateUser());
        dst.setUpdateDatetime(src.getUpdateDatetime());
        dst.setDeleteFlag(src.getDeleteFlag());
        dst.setDeliveryDate(src.getDeliveryDate());
        dst.setUserGroupId(src.getUserGroupId());
        return dst;
    }

    /** リーブオーダー情報をシャロウコピーする（Samba書込みキューへ渡す用） */
    private TLeaveSttsMngBean copyLeaveSttsMng(TLeaveSttsMngBean src) {
        TLeaveSttsMngBean dst = new TLeaveSttsMngBean();
        dst.setOrderNumber(src.getOrderNumber());
        dst.setReservationStatus(src.getReservationStatus());
        dst.setDeadlineDatetimeDivision(src.getDeadlineDatetimeDivision());
        dst.setDeadlineDatetime(src.getDeadlineDatetime());
        dst.setLimitRate(src.getLimitRate());
        dst.setDeliveryDateDivision(src.getDeliveryDateDivision());
        dst.setOrderDatetime(src.getOrderDatetime());
        dst.setRegisterUser(src.getRegisterUser());
        dst.setRegisterDatetime(src.getRegisterDatetime());
        dst.setUpdateUser(src.getUpdateUser());
        dst.setUpdateDatetime(src.getUpdateDatetime());
        return dst;
    }

    // ════════════════════════════════════════════════════════════════════════
    // 内部クラス：注文コンテキスト
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 1電文分の処理コンテキスト。
     *
     * <p>{@link #initialize} で生成し、{@link #updateTrade} / {@link #updateLeaveOrder}
     * に引き渡す。スレッドセーフな設計のため、フィールドへの書き込みは
     * initialize 内のみで行い、以降は読み取り専用で使用する。
     */
    public static class OrderContext {

        /** 注文番号 */
        public final BigDecimal ordNm;

        /** 取引管理情報（最新改版） */
        public final TTradeMngBean tradeMngInfo;

        /**
         * リーブオーダーステータス管理情報。
         * リーブオーダー以外は null。
         */
        public final TLeaveSttsMngBean leaveSttsMngInfo;

        public OrderContext(BigDecimal ordNm,
                            TTradeMngBean tradeMngInfo,
                            TLeaveSttsMngBean leaveSttsMngInfo) {
            this.ordNm            = ordNm;
            this.tradeMngInfo     = tradeMngInfo;
            this.leaveSttsMngInfo = leaveSttsMngInfo;
        }

        /** リーブオーダー電文か否かを返す */
        public boolean isLeaveOrder() {
            return leaveSttsMngInfo != null;
        }
    }
}
