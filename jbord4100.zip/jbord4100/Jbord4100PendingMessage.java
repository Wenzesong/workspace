package jp.co.daiwa.jbord4100;

import java.util.concurrent.atomic.AtomicBoolean;

import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.dto.fix.ExecutionReport;

/**
 * 取込済みで未完了の電文
 *
 * <p>1 件の電文が「DB更新段 → ファイル更新段」を通過し終えるまでの状態を保持する。
 *
 * <p>【元ファイルの保持】
 * 電文ファイルは取込時に削除されるため、ジョブ停止時に未着手の電文を復元できるよう
 * 元のファイル名とバイト列をそのまま保持する。
 *
 * <p>【スレッド安全性】
 * 生成はディスパッチスレッド、{@link #getWriteRequest()} の設定は DB更新ワーカー、
 * 参照はファイル更新ワーカーが行う。受け渡しは {@code BlockingQueue} を経由するため、
 * その happens-before 関係により可視性は保証される。
 * 二重解放を防ぐ {@link #settle()} のみ {@link AtomicBoolean} で保護する。
 */
public class Jbord4100PendingMessage {

    /** ClOrdID を分解したときの注文番号の位置。 */
    private static final int CLORD_ID_ORDER_NUMBER_INDEX = 2;

    /** 元の電文ファイル名。 */
    private final String fileName;

    /** 元の電文ファイルの内容（書き戻し時にバイト単位で復元する）。 */
    private final byte[] content;

    /** 解析済み電文情報。 */
    private final ExecutionReport report;

    /** 順序制御キー（注文番号）。 */
    private final String orderKey;

    /** 完了処理を 1 回だけ行うためのフラグ。 */
    private final AtomicBoolean settled = new AtomicBoolean(false);

    /** DB更新段が組み立て、ファイル更新段が消費する書込み要求。 */
    private SambaWriteRequest writeRequest;

    /**
     * @param fileName 元の電文ファイル名
     * @param content 元の電文ファイルの内容
     * @param report 解析済み電文情報
     */
    public Jbord4100PendingMessage(String fileName, byte[] content, ExecutionReport report) {
        this.fileName = fileName;
        this.content = content;
        this.report = report;
        this.orderKey = resolveOrderKey(report);
    }

    /**
     * 順序制御キーを決定する。
     *
     * <p>同一注文の電文を到着順に直列処理するためのキー。
     * ClOrdID の 3 要素目が注文番号（{@code Jbord4100DbService#extractOrderNumber} と同じ規則）。
     * 書式が想定外の場合は ClOrdID 全体をキーとし、安全側（より狭い並列度）に倒す。
     *
     * @param report 電文情報
     * @return 順序制御キー
     */
    private static String resolveOrderKey(ExecutionReport report) {
        String clordId = report == null ? null : report.getClordID();
        if (clordId == null) {
            // 注文を特定できない電文は 1 本のチェーンへ寄せる
            return "";
        }
        String[] parts = clordId.split(FxdConstants.HYPHEN);
        return parts.length > CLORD_ID_ORDER_NUMBER_INDEX ? parts[CLORD_ID_ORDER_NUMBER_INDEX] : clordId;
    }

    /**
     * 完了処理の権利を 1 度だけ取得する。
     *
     * <p>セマフォの二重解放を防ぐため、完了・書き戻しのいずれの経路でも本メソッドで排他する。
     *
     * @return 初めて呼ばれた場合のみ true
     */
    public boolean settle() {
        return settled.compareAndSet(false, true);
    }

    /** @return ログ用の識別子 */
    public String describe() {
        String clordId = report == null ? null : report.getClordID();
        return clordId + "(" + fileName + ")";
    }

    public String getFileName() {
        return fileName;
    }

    public byte[] getContent() {
        return content;
    }

    public ExecutionReport getReport() {
        return report;
    }

    public String getOrderKey() {
        return orderKey;
    }

    public SambaWriteRequest getWriteRequest() {
        return writeRequest;
    }

    public void setWriteRequest(SambaWriteRequest writeRequest) {
        this.writeRequest = writeRequest;
    }
}
