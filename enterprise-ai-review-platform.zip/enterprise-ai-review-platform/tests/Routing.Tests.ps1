# Routing.Tests.ps1
# Pester 3.x tests for scripts/lib/routing.ps1 and lib/common.ps1
# Run: Invoke-Pester -Path tests

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
. "$here\..\scripts\lib\common.ps1"
. "$here\..\scripts\lib\routing.ps1"

$repoRoot = Resolve-Path "$here\.."
$riskPatternsFile = Join-Path $repoRoot "ai-review\routing\risk_patterns.yaml"
$routingRulesFile = Join-Path $repoRoot "ai-review\routing\skill_routing_rules.yaml"

Describe "Test-PatternMatch" {

    It "matches an annotation pattern in source" {
        Test-PatternMatch -Source 'public class A { @Transactional void m() {} }' -Pattern '@Transactional' | Should Be $true
    }

    It "does not match Statement inside PreparedStatement (word boundary)" {
        Test-PatternMatch -Source 'PreparedStatement ps = conn.prepareStatement(sql);' -Pattern 'Statement' | Should Be $false
    }

    It "matches a standalone Statement" {
        Test-PatternMatch -Source 'Statement st = conn.createStatement();' -Pattern 'Statement' | Should Be $true
    }

    It "does not match COMMIT inside COMMITTED" {
        Test-PatternMatch -Source 'SET TRANSACTION ISOLATION LEVEL READ COMMITTED' -Pattern 'COMMIT' | Should Be $false
    }

    It "matches COMMIT as a standalone keyword" {
        Test-PatternMatch -Source 'UPDATE t SET x = 1; COMMIT;' -Pattern 'COMMIT' | Should Be $true
    }

    It "is case sensitive" {
        Test-PatternMatch -Source 'commit;' -Pattern 'COMMIT' | Should Be $false
    }

    It "handles non-word-edge patterns like .setId(" {
        Test-PatternMatch -Source 'dto.setId(entity.getId());' -Pattern '.setId(' | Should Be $true
    }

    It "returns false for empty pattern" {
        Test-PatternMatch -Source 'anything' -Pattern '' | Should Be $false
    }
}

Describe "Get-RiskPatternRules" {

    $rules = @(Get-RiskPatternRules -FilePath $riskPatternsFile)

    It "parses all rule blocks from risk_patterns.yaml" {
        $rules.Count | Should BeGreaterThan 10
    }

    It "parses the transaction rule with patterns, agents, skills and tier" {
        $tx = $rules | Where-Object { $_.Id -eq 'transaction' }
        $tx | Should Not BeNullOrEmpty
        $tx.Tier | Should Be 1
        $tx.Patterns -contains '@Transactional' | Should Be $true
        $tx.Agents -contains 'transaction_agent' | Should Be $true
        $tx.Skills -contains 'deadlock_skill' | Should Be $true
    }

    It "parses a tier 3 rule" {
        $sub = $rules | Where-Object { $_.Id -eq 'subquery' }
        $sub.Tier | Should Be 3
    }

    It "parses the VBA error handling rule" {
        $vba = $rules | Where-Object { $_.Id -eq 'vba_error_handling' }
        $vba | Should Not BeNullOrEmpty
        $vba.Tier | Should Be 1
        $vba.Patterns -contains 'On Error Resume Next' | Should Be $true
        $vba.Skills -contains 'vba_error_handling_skill' | Should Be $true
    }

    It "parses the VBA database rule with cross-language sql skills" {
        $db = $rules | Where-Object { $_.Id -eq 'vba_database' }
        $db.Tier | Should Be 1
        $db.Skills -contains 'sql_injection_skill' | Should Be $true
        $db.Agents -contains 'ado_database_agent' | Should Be $true
    }

    It "returns empty array for a missing file" {
        @(Get-RiskPatternRules -FilePath "$here\no_such_file.yaml").Count | Should Be 0
    }
}

Describe "Get-SkillTierMap" {

    $map = Get-SkillTierMap -FilePath $routingRulesFile

    It "maps tier1 sql skills" {
        $map['transaction_skill'] | Should Be 1
        $map['sql_injection_skill'] | Should Be 1
    }

    It "maps tier2 and tier3 skills" {
        $map['index_skill'] | Should Be 2
        $map['join_optimization_skill'] | Should Be 3
    }

    It "maps shared skill tiers from the second top-level block" {
        $map['security_skill'] | Should Be 1
        $map['clean_code_skill'] | Should Be 3
    }

    It "maps vba skill tiers" {
        $map['vba_skill'] | Should Be 1
        $map['excel_object_skill'] | Should Be 2
        $map['office_automation_skill'] | Should Be 3
    }

    It "returns empty map for a missing file" {
        (Get-SkillTierMap -FilePath "$here\no_such_file.yaml").Count | Should Be 0
    }
}

Describe "Select-SkillsByTier" {

    $tierMap = @{
        tier1_a = 1; tier1_b = 1
        tier2_a = 2; tier2_b = 2
        tier3_a = 3; tier3_b = 3
    }

    It "returns skills unchanged when under the limit" {
        $result = @(Select-SkillsByTier -Skills @('tier1_a','tier2_a') -TierMap $tierMap -MaxCount 5)
        $result.Count | Should Be 2
    }

    It "drops tier3 skills first when over the limit" {
        $skills = @('tier3_a','tier1_a','tier2_a','tier3_b','tier1_b')
        $result = @(Select-SkillsByTier -Skills $skills -TierMap $tierMap -MaxCount 3)
        $result.Count | Should Be 3
        $result -contains 'tier1_a' | Should Be $true
        $result -contains 'tier1_b' | Should Be $true
        $result -contains 'tier2_a' | Should Be $true
        $result -contains 'tier3_a' | Should Be $false
    }

    It "treats unknown skills as tier1 (never dropped first)" {
        $skills = @('java_skill','tier3_a','tier3_b')
        $result = @(Select-SkillsByTier -Skills $skills -TierMap $tierMap -MaxCount 2)
        $result -contains 'java_skill' | Should Be $true
    }

    It "preserves original relative order of the survivors" {
        $skills = @('tier1_b','tier1_a','tier3_a')
        $result = @(Select-SkillsByTier -Skills $skills -TierMap $tierMap -MaxCount 2)
        $result[0] | Should Be 'tier1_b'
        $result[1] | Should Be 'tier1_a'
    }
}

Describe "Read-SimpleYaml" {

    $tmp = Join-Path $env:TEMP "read_simple_yaml_test.yaml"
    @"
# comment line
key1: value1
quoted: "hello"
max_skill_count_tier1: 6
listKey:
  - item1
  - item2
after: done
"@ | Out-File -FilePath $tmp -Encoding UTF8

    $yaml = Read-SimpleYaml -FilePath $tmp

    It "parses flat key/value pairs" {
        $yaml['key1'] | Should Be 'value1'
    }

    It "strips quotes from values" {
        $yaml['quoted'] | Should Be 'hello'
    }

    It "parses numeric-looking values as strings castable to int" {
        [int]$yaml['max_skill_count_tier1'] | Should Be 6
    }

    It "parses simple lists" {
        @($yaml['listKey']).Count | Should Be 2
        @($yaml['listKey'])[0] | Should Be 'item1'
    }

    It "parses keys that appear after a list" {
        $yaml['after'] | Should Be 'done'
    }

    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}
