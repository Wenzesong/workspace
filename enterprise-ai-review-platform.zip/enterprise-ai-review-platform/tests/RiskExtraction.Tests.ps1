# RiskExtraction.Tests.ps1
# Pester 3.x tests for scripts/lib/risk_extraction.ps1
# Run: Invoke-Pester -Path tests

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
. "$here\..\scripts\lib\common.ps1"
. "$here\..\scripts\lib\risk_extraction.ps1"

Describe "Extract-Risks (JSON block)" {

    $reviewWithJson = @"
## Review Summary
Some analysis text here.

``````json
{
  "risks": [
    { "level": "P0", "title": "Multi-table update without transaction", "description": "desc0", "category": "transaction" },
    { "level": "P1", "title": "N+1 query in loop", "category": "performance", "fix": "use fetch join" },
    { "level": "P3", "title": "Minor naming issue" }
  ]
}
``````

More text after.
"@

    $risks = @(Extract-Risks -ReviewText $reviewWithJson)

    It "extracts all risks from the JSON block" {
        $risks.Count | Should Be 3
    }

    It "keeps level and title" {
        $risks[0].level | Should Be 'P0'
        $risks[0].title | Should Be 'Multi-table update without transaction'
    }

    It "fills optional fields with defaults when missing" {
        $risks[2].category | Should Be ''
        $risks[1].fix | Should Be 'use fetch join'
    }
}

Describe "Extract-Risks (regex fallback)" {

    $reviewPlainText = @"
Review result:

[P0-1] Transaction boundary missing
Category: transaction
Problem: updates two tables without a transaction

[P1] Slow query on large table
Category: performance

[P2-3] Missing index
"@

    $risks = @(Extract-Risks -ReviewText $reviewPlainText)

    It "extracts risks from [P0]-style lines" {
        $risks.Count | Should Be 3
    }

    It "parses numbered ids" {
        $risks[0].id | Should Be 'P0-1'
        $risks[0].level | Should Be 'P0'
    }

    It "captures category and problem lines" {
        $risks[0].category | Should Be 'transaction'
        $risks[0].description | Should Be 'updates two tables without a transaction'
    }

    It "handles un-numbered levels" {
        $risks[1].id | Should Be 'P1'
    }
}

Describe "Extract-Risks (malformed JSON falls back to regex)" {

    $broken = @"
``````json
{ this is not valid json
``````
[P1] Fallback risk detected
"@

    It "falls back to regex when the JSON block is invalid" {
        $risks = @(Extract-Risks -ReviewText $broken)
        $risks.Count | Should Be 1
        $risks[0].level | Should Be 'P1'
    }
}

Describe "Extract-Risks (zero findings)" {

    It "returns an empty array (not AutomationNull) when no risks are found" {
        $risks = @(Extract-Risks -ReviewText "This code looks great. No issues found.")
        $risks.Count | Should Be 0
    }

    It "treats a valid empty risks array in JSON as zero findings via the JSON path" {
        $review = @"
``````json
{ "risks": [] }
``````
"@
        $risks = @(Extract-Risks -ReviewText $review)
        $risks.Count | Should Be 0
    }

    It "survives the full zero-risk pipeline through Count-RiskLevels" {
        # Regression: an unwrapped empty array became @("") at the parameter
        # boundary and crashed on `$r.level` under StrictMode.
        $risks  = @(Extract-Risks -ReviewText "clean code, nothing to report")
        $counts = Count-RiskLevels -risks $risks
        $counts.P0 | Should Be 0
        @(Get-Categories -risks $risks).Count | Should Be 0
    }
}

Describe "Count-RiskLevels" {

    It "counts risks per level" {
        $risks = @(
            @{ level = 'P0' }, @{ level = 'P0' }, @{ level = 'P1' }, @{ level = 'P3' }
        )
        $counts = Count-RiskLevels -risks $risks
        $counts.P0 | Should Be 2
        $counts.P1 | Should Be 1
        $counts.P2 | Should Be 0
        $counts.P3 | Should Be 1
    }

    It "ignores unknown levels" {
        $counts = Count-RiskLevels -risks @(@{ level = 'P9' })
        $counts.P0 | Should Be 0
    }

    It "handles empty input" {
        $counts = Count-RiskLevels -risks @()
        $counts.P0 | Should Be 0
    }
}

Describe "Get-Categories" {

    It "returns distinct non-empty categories" {
        $risks = @(
            @{ category = 'transaction' },
            @{ category = 'transaction' },
            @{ category = 'performance' },
            @{ category = '' }
        )
        $cats = @(Get-Categories -risks $risks)
        $cats.Count | Should Be 2
        $cats -contains 'transaction' | Should Be $true
        $cats -contains 'performance' | Should Be $true
    }
}
