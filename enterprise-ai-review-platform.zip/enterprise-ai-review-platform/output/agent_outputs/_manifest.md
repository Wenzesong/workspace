﻿# Agent/Skill Manifest
Generated: 2026-07-11 22:09:00

## Loaded Agents
- vba_error_handling_agent
- security_architect_agent
- review_orchestrator_agent
- vba_architect_agent

## Loaded Skills
- performance_skill
- security_skill
- vba_error_handling_skill
- vba_skill

## Matched Rules

