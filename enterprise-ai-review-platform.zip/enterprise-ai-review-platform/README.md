# Enterprise AI Review Platform

本番障害を未然に防ぐための AI コードレビュー基盤。
単純なコードチェックではなく、**Runtime Failure Prediction** を目的とした Enterprise グレードのレビューシステム。

---

## コンセプト

### Risk-Based Dynamic Loading
コードの内容に応じて必要な Agent・Skill だけを動的にロードする。
Language-Based（言語ごとに固定ロード）ではなく、検出されたリスクパターンに基づく。

```
@Transactional 検出
  → transaction_agent + deadlock_skill + rollback_skill を自動ロード
```

### AIにゼロから考えさせない
毎回大きな Prompt を渡すのではなく、必要な知識だけを組み合わせて渡す。
Token 効率とレビュー品質の安定化を両立する。

### Review Memory（過去学習）
レビュー結果を蓄積し、繰り返し検出されるリスクを次回プロンプトへ自動注入する。
チーム・プロジェクト固有の弱点を AI が記憶し、見落とし防止と精度向上を図る。

```
過去レビュー結果
  → リスク抽出・構造化保存（memory/reviews/）
  → パターン分析（繰り返しリスク・トレンド検出）
  → 次回プロンプトへ自動注入（memory/memory_context.txt）
```

---

## フォルダ構成

```
enterprise-ai-review-platform/
│
├── README.md
│
├── ai-review/
│   ├── platform/        # AI の思考基盤（全レビューで必ずロード）
│   ├── agents/          # 役割別 AI エージェント定義
│   │   ├── shared/      # 言語共通エージェント
│   │   ├── java/        # Java 専用エージェント
│   │   ├── csharp/      # C# 専用エージェント
│   │   ├── linux/       # Linux/Shell 専用エージェント
│   │   ├── sql/         # SQL 専用エージェント
│   │   └── vba/         # VBA/Office マクロ専用エージェント
│   ├── skills/          # 専門知識ルール
│   │   ├── shared/      # 言語共通スキル（常時ロード）
│   │   ├── java/        # Java 専用スキル
│   │   ├── csharp/      # C# 専用スキル
│   │   ├── linux/       # Linux 専用スキル
│   │   ├── sql/         # SQL 専用スキル（Tier1〜3）
│   │   └── vba/         # VBA 専用スキル
│   ├── prompts/         # タスク定義
│   ├── templates/       # AI 出力フォーマット
│   └── routing/         # 動的ロードルール（YAML）
│
├── source-code/
│   ├── new/             # レビュー対象コード（必須）
│   └── old/             # 修正前コード（diff モード時）
│
├── output/              # 生成された Prompt・レポート
│   ├── agent_outputs/   # Agent 別出力（デバッグ用）
│   └── history/         # レビュー結果バックアップ（タイムスタンプ付き）
│
├── memory/              # レビュー履歴・パターン蓄積
│   ├── reviews/         # レビュー結果 JSON（1レビュー1ファイル）
│   ├── patterns/        # パターン分析結果
│   └── summary.json     # 累積統計（P0〜P3 合計・プロジェクト/開発者/言語別）
│
├── scripts/             # 実行スクリプト
│   ├── review.ps1           # エントリポイント（Windows）
│   ├── detect_context.ps1   # コンテキスト検出
│   ├── build_prompt.ps1     # Prompt 組み立て
│   ├── save_review_result.ps1  # レビュー結果の保存
│   ├── save_memory.ps1      # リスク抽出・メモリ書き込み
│   ├── analyze_patterns.ps1 # 過去履歴のパターン分析
│   ├── review.sh            # エントリポイント（Linux/Mac、pwsh 必須）
│   └── lib/                 # 共通ライブラリ
│       ├── common.ps1           # ログ・YAML リーダ等
│       ├── routing.ps1          # リスクパターン検出・Tier フィルタ
│       └── risk_extraction.ps1  # AI 出力からのリスク抽出
│
├── tests/               # Pester 単体テスト（Invoke-Pester -Path tests）
│
└── config/
    └── platform.yaml    # プラットフォーム設定（model・出力先・サイズ警告）
```

> **注意**: `scripts/*.ps1` は ASCII のみで記述する。Windows PowerShell 5.1 は
> BOM なしファイルを ANSI として解釈するため、非 ASCII 文字は文字化けする。

---

## 使い方

### 1. コードを配置する

```
# 新規レビューの場合
source-code/new/ にファイルを配置

# 差分レビューの場合
source-code/old/ に修正前、source-code/new/ に修正後を配置
```

### 2. スクリプトを実行する

```powershell
# Windows（-Language 省略時は拡張子から自動判定）
.\scripts\review.ps1 -Mode new-review
.\scripts\review.ps1 -Language java -Mode diff-review
.\scripts\review.ps1 -Language sql  -Mode new-review
.\scripts\review.ps1 -Language csharp -Mode diff-review

# Linux / Mac（PowerShell 7 = pwsh が必要）
bash scripts/review.sh -m diff-review
bash scripts/review.sh -l java -m diff-review
```

主なオプション:

| オプション | 説明 |
|---|---|
| `-Language` | `auto`（既定）/ `java` / `csharp` / `linux` / `sql` |
| `-ProjectName` / `-Developer` | メモリのフィルタキー |
| `-NoMemory` | 過去履歴のプロンプト注入を無効化 |
| `-AutoReview` | Claude CLI で自動レビュー実行（下記参照） |

### 3. 生成された Prompt を Claude に貼り付ける

```
output/final_review_prompt.txt を Claude に貼り付けてレビューを開始する
```

### 3'. 自動レビュー（Claude CLI がある場合）

```powershell
.\scripts\review.ps1 -Mode new-review -AutoReview
```

`claude` コマンドが PATH にあれば、生成した Prompt をそのまま Claude に送信し、
結果を `output/review_result.md` に保存してメモリ登録まで自動で行う。
使用モデルは `config/platform.yaml` の `model` で指定する。

---

## 対応言語・モード

| 言語 | -Language |
|---|---|
| Java / Spring Boot | `java` |
| C# / ASP.NET Core | `csharp` |
| Linux / Shell / Docker / K8s | `linux` |
| SQL | `sql` |
| VBA / Office マクロ | `vba` |

| モード | -Mode | 説明 |
|---|---|---|
| 新規レビュー | `new-review` | 新規コードのレビュー |
| 差分レビュー | `diff-review` | 修正前後の差分レビュー |
| 新規テスト | `new-test` | テストケース生成 |
| 差分テスト | `diff-test` | 回帰テストケース生成 |

---

## Skill Tier について

検出されたリスクの複雑度に応じて Tier（1〜3）が決まり、Tier ごとの Skill 数上限
（`ai-review/routing/skill_routing_rules.yaml` の `max_skill_count_tier*`）を超えた場合は
**Tier 数値が大きい Skill から順に切り捨てる**。Tier1 と言語ベースラインの Skill は
切り捨ての対象にならない。

| Tier | 意味 | 例 |
|---|---|---|
| Tier1 | 必須（切り捨て対象外） | transaction_skill, deadlock_skill, sql_injection_skill |
| Tier2 | コードで検出されたリスクに応じて | index_skill, slow_query_skill, migration_skill |
| Tier3 | 深度分析用（上限超過時に最初に削除） | join_optimization_skill, subquery_skill |

## テスト

コアロジック（パターン検出・Tier フィルタ・リスク抽出・YAML パース）は
Pester で単体テストされている。

```powershell
Invoke-Pester -Path tests
```

---

## メモリ機能

### 概要

レビュー結果を構造化 JSON として蓄積し、過去の傾向を次回レビューへフィードバックする機能。  
繰り返し発生するリスクや、チーム・プロジェクト固有の弱点を AI が記憶することで精度を向上させる。

### データフロー

```
Claude でレビュー実施
    ↓
save_review_result.ps1   ← 結果をクリップボードまたは手動ペーストで取得
    ↓
save_memory.ps1          ← P0〜P3 リスクを抽出・構造化して JSON 保存
    ↓
memory/reviews/          ← レビュー履歴を蓄積
    ↓
analyze_patterns.ps1     ← 過去データを分析（トレンド・繰り返しリスク）
    ↓
memory/memory_context.txt ← 次回レビュー時に build_prompt.ps1 がプロンプトへ注入
```

### 使い方

```powershell
# 1. レビュー結果を保存する（クリップボード自動取得 or 手動ペースト）
.\scripts\save_review_result.ps1 -Language java -Mode diff-review -ProjectName my-app -Developer ukben

# 2. 過去履歴を分析してメモリコンテキストを生成する
#    （review.ps1 実行時にも自動で行われるため、通常は省略可）
.\scripts\analyze_patterns.ps1 -Language java -ProjectName my-app

# 3. 次回レビュー時は通常通り実行（memory_context.txt が自動でプロンプトに含まれる）
.\scripts\review.ps1 -Language java -Mode diff-review
```

フィルタオプション：`-ProjectName`・`-Developer`・`-Language` で絞り込み可能。
`-AutoReview` を使う場合は手順 1〜2 も自動実行される。

### 保存形式

`memory/reviews/yyyyMMdd_HHmmss_{Project}_{Language}_{id}.json` に1レビュー1ファイルで保存。

```json
{
  "id": "a1b2c3d4",
  "date": "2026-06-02",
  "project": "my-app",
  "developer": "ukben",
  "language": "java",
  "risk_counts": { "P0": 1, "P1": 2, "P2": 3, "P3": 1 },
  "categories": ["transaction", "performance"],
  "risks": [
    { "level": "P0", "title": "トランザクション境界なしで複数テーブル更新", "description": "..." }
  ]
}
```

### パターン分析の内容

| 分析項目 | 説明 |
|---|---|
| P0/P1/P2 合計 | 累積リスク件数 |
| P0 発生率 | 1レビューあたりの平均 P0 件数 |
| トレンド | 直近3件 vs 前3件の比較（Improving / Stable / Worsening） |
| Top カテゴリ | 出現頻度が高いリスクカテゴリ Top5 |
| 繰り返しリスク | 2回以上検出されたリスクタイトル（要注意） |

### リスク抽出方式

AI 出力から P0〜P3 を2段階で自動抽出する。

| 優先度 | 方式 | 条件 |
|---|---|---|
| 1st | JSON ブロック抽出 | AI 出力に ` ```json ` ブロックがある場合 |
| 2nd | 正規表現フォールバック | JSON ブロックがない場合（`[P0]` 形式を解析） |

---

## リスクレベル

| Level | 意味 | 対応 |
|---|---|---|
| P0 | Critical: 本番障害・データ破壊 | 即時対応必須 |
| P1 | High: 高負荷時・特定条件で障害 | リリース前に対応 |
| P2 | Medium: 将来の保守・性能に影響 | 次スプリントで対応 |
| P3 | Suggestion: 改善推奨 | 任意対応 |
