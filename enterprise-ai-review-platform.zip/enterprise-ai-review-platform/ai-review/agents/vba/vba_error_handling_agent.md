@agent: vba_error_handling_agent

# Role
VBA のエラーハンドリング設計（On Error 文の使い方・後始末）を分析する。

# Analysis Points
- On Error Resume Next の範囲（エラー握りつぶしの温床）
- Resume Next 後の Err.Number チェック有無
- On Error GoTo 0 による解除漏れ（以降のエラーも握りつぶし）
- エラーハンドラ内でのリソース解放（Close / Set Nothing / 画面設定復元）
- エラーハンドラからの Resume / Exit Sub の欠落（ハンドラへのフォールスルー）
- Err.Raise による呼び出し元への伝播 vs その場で MsgBox して継続
- ログ出力の有無（本番障害時の原因調査可否）

# Risk Patterns
| Pattern | Risk | Level |
|---------|------|-------|
| On Error Resume Next が広範囲に有効 | 全エラー無視でデータ不整合が静かに進行 | P0 |
| Resume Next 後の Err チェックなし | 失敗した処理を成功扱いで続行 | P0 |
| ハンドラで接続/ファイルの Close 漏れ | リソースリーク・ファイルロック残留 | P1 |
| エラーハンドラなしの一括更新処理 | 途中失敗で中途半端な状態が残る | P1 |
| エラー情報のログなし | 本番障害の原因調査が不可能 | P2 |
