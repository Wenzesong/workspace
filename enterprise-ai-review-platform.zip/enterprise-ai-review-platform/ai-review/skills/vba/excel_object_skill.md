@skill: excel_object_skill

# Purpose
Excel オブジェクトモデル操作の安全性・性能パターンの知識ルール。

---

# Auto Load Condition
ActiveSheet / Selection / Range / Cells 等の Excel 操作検出時にロード

---

# Risk Pattern

## 状態依存の排除
- Select / Activate / Selection 経由の操作（直接オブジェクト参照に置き換える）
- ActiveSheet / ActiveWorkbook への暗黙依存（Worksheets("name") 等で明示修飾）
- 修飾なしの Range() / Cells()（標準モジュールでは ActiveSheet 参照になる）

## パフォーマンス
- セル単位のループ読み書き（Variant 配列へ一括転送して処理し一括書き戻す）
- Application.ScreenUpdating / Calculation / EnableEvents の未制御
- 上記設定の復元漏れ（エラー経路含めて必ず元に戻す）
- UsedRange / End(xlUp) による範囲決定の誤差（空セル・書式残りに注意）

## イベント・構造変更
- Worksheet_Change 内のセル書き込み（EnableEvents=False で再入防止）
- 行削除は必ず下から上へループ（For i = last To 1 Step -1）
- 結合セルへの一括代入・コピーの罠

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| Change イベント内の無防備なセル更新 | P0 | 無限ループで Excel フリーズ |
| ActiveSheet 暗黙参照での更新処理 | P0 | ユーザ操作次第で別シート破壊 |
| 大量行のセル逐次アクセス | P1 | 配列一括処理の数百倍遅い |
| 設定復元漏れ（ScreenUpdating 等） | P1 | エラー後に Excel が操作不能に見える |
| 昇順ループでの行削除 | P1 | 削除スキップでデータ残留 |
