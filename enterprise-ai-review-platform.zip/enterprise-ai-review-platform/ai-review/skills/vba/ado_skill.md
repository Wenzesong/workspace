@skill: ado_skill

# Purpose
VBA からの DB アクセス（ADO / DAO）の安全パターン知識ルール。

---

# Auto Load Condition
ADODB / DAO / Recordset 検出時にロード

---

# Risk Pattern

## SQL インジェクション
- セル値・InputBox の値を SQL に文字列連結
- ADODB.Command + CreateParameter によるパラメータ化が正解
- 動的 ORDER BY / テーブル名はホワイトリスト検証

## リソース管理
- Recordset / Connection の Close 漏れ（エラー経路含む）
- Close 後の Set Nothing 漏れ
- 接続をループ内で毎回 Open（接続は使い回す）

## トランザクション
- 複数更新に BeginTrans / CommitTrans がない
- エラーハンドラに RollbackTrans がない
- コミット前の長時間処理（ロック保持時間の増大）

## 資格情報
- 接続文字列のパスワード直書き（xlsm は zip 展開で読める）
- Windows 認証（Integrated Security）が使えるなら優先

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| SQL への文字列連結（外部入力） | P0 | SQL インジェクション |
| エラー時 Rollback なしの複数更新 | P0 | 中途半端なコミットでデータ不整合 |
| 接続文字列にパスワード直書き | P0 | 資格情報漏洩 |
| Close / Set Nothing 漏れ | P1 | 接続リーク・DB リソース枯渇 |
| ループ内の逐次 Execute | P1 | 大量データで実用不能 |
