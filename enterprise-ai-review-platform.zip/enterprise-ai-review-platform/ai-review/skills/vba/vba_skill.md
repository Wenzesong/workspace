@skill: vba_skill

# Purpose
VBA 言語コアの落とし穴と安全な記述パターンの知識ルール。

---

# Auto Load Condition
Language=vba の場合に常時ロード

---

# Risk Pattern

## 型と宣言
- Option Explicit 未宣言（タイポ変数が Variant として黙って生成される）
- Integer の使用（16bit・-32768〜32767 でオーバーフロー。原則 Long を使う）
- Variant の乱用（型チェックが実行時まで遅延）
- Dim a, b As Long（a は Variant になる複数宣言の罠）

## 制御フロー
- エラーハンドラ以外での GoTo 使用
- ByRef 既定を意識しない引数渡し（値を守るなら ByVal 明示）
- IIf は両辺を常に評価する（副作用・ゼロ除算に注意）

## 文字列・日付
- 文字列連結の & と + の混用（+ は Null 伝播で挙動が変わる）
- 日付の暗黙変換（地域設定依存。CDate よりも DateSerial を使う）
- Format$ / CStr の地域設定依存フォーマット

## その他
- ハードコードされたシート名・セル番地・ファイルパス
- マジックナンバー（Const 化する）
- DoEvents の乱用（再入・イベント順序の不整合）

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| Option Explicit なし | P1 | タイポが静かに Variant 変数化し誤動作 |
| Integer への大きい値代入 | P1 | 実行時エラー6（オーバーフロー）で停止 |
| Dim a, b As Long 形式 | P2 | 先頭変数が意図せず Variant |
| ハードコードパス/シート名 | P2 | 環境差異で動作しない |
