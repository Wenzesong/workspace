@skill: vba_error_handling_skill

# Purpose
VBA の On Error 構文に特化したエラーハンドリング知識ルール。

---

# Auto Load Condition
Language=vba の場合に常時ロード（On Error 検出時は必須）

---

# Risk Pattern

## On Error Resume Next
- 広い範囲で有効なまま（すべてのエラーを握りつぶす）
- Resume Next の直後に Err.Number チェックがない
- 解除（On Error GoTo 0）を忘れて以降の処理まで影響

## エラーハンドラ設計
- ハンドラ末尾の Exit Sub / Exit Function 欠落（正常経路がハンドラへフォールスルー）
- ハンドラ内でのリソース解放漏れ（Recordset/Connection Close、ファイル Close、
  Application.ScreenUpdating 等の復元）
- ハンドラ内で再度エラーが起きる可能性（二重障害で強制終了）
- Err.Raise で呼び出し元へ伝播すべき場面で MsgBox して継続

## 安全な定型
```vba
Sub Example()
    On Error GoTo ErrHandler
    ' ... main logic ...
CleanUp:
    On Error Resume Next   ' cleanup errors must not mask the original
    ' close/restore resources here
    Exit Sub
ErrHandler:
    ' log Err.Number / Err.Description / Erl
    Resume CleanUp
End Sub
```

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| プロシージャ全体に On Error Resume Next | P0 | 障害が無音で進行しデータ不整合 |
| Resume Next 後の Err チェックなし | P0 | 失敗を成功扱いで続行 |
| ハンドラでのリソース解放漏れ | P1 | 接続リーク・画面設定残留 |
| Exit Sub 欠落によるフォールスルー | P1 | 正常時にもハンドラが実行される |
