@skill: office_automation_skill

# Purpose
COM オートメーション・外部連携（他 Office / Shell / Win32 API）の知識ルール。

---

# Auto Load Condition
CreateObject / GetObject / Declare / Shell 検出時にロード

---

# Risk Pattern

## COM オブジェクト管理
- CreateObject で起動したアプリの Quit 漏れ（不可視プロセス残留）
- Quit 後の Set Nothing 漏れ
- 「2ドット以上」のチェーン参照（中間オブジェクトが解放不能になる。
  一時変数に受けて明示解放する）
- GetObject 失敗時（未起動）のフォールバック未実装

## バインディング
- 事前バインディング（参照設定）は配布先のバージョン差異で壊れる
- 配布マクロは遅延バインディング（Object + CreateObject）が安全
- 遅延バインディング時は定数を自前定義（組み込み定数が使えない）

## 外部プロセス・API
- Shell への未検証文字列連結（コマンドインジェクション）
- Shell は非同期（完了待ちが必要なら WScript.Shell の Run を使う）
- Declare に PtrSafe なし（64bit Office でコンパイル不能）
- ハンドル/ポインタは LongPtr で宣言
- SendKeys の使用（タイミング依存・フォーカス依存で不安定）

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| Shell への未検証文字列 | P0 | コマンドインジェクション |
| Quit / Set Nothing 漏れ | P1 | 不可視プロセス蓄積でメモリ枯渇 |
| SendKeys 依存の操作 | P1 | 誤送信・誤操作 |
| PtrSafe / LongPtr 未対応 | P2 | 64bit 環境で動作不能 |
