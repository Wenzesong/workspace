# analyze_patterns.ps1
# Extract and analyze patterns from past review history.
# Writes memory/patterns/latest_patterns.json and memory/memory_context.txt
# (the latter is injected into the next review prompt by build_prompt.ps1).

param(
    [Parameter(Mandatory = $false)][string]$RootDir     = "$PSScriptRoot\..",
    [Parameter(Mandatory = $false)][string]$ProjectName = "",
    [Parameter(Mandatory = $false)][string]$Developer   = "",
    [Parameter(Mandatory = $false)][string]$Language    = "",
    # How many of the most recent (matching) reviews to analyze.
    [Parameter(Mandatory = $false)][int]$MaxReviews     = 50
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

. "$PSScriptRoot\lib\common.ps1"

$MEMORY_DIR   = Join-Path $RootDir "memory"
$REVIEWS_DIR  = Join-Path $MEMORY_DIR "reviews"
$PATTERNS_DIR = Join-Path $MEMORY_DIR "patterns"

# ================================================================
# Load review history (filter first, then take the newest N so a
# project with a long tail of other-project reviews still gets data)
# ================================================================
function Load-Reviews {
    if (-not (Test-Path $REVIEWS_DIR)) { return @() }

    $files = Get-ChildItem $REVIEWS_DIR -Filter "*.json" |
             Sort-Object LastWriteTime -Descending

    $reviews = [System.Collections.Generic.List[object]]::new()
    foreach ($f in $files) {
        if ($reviews.Count -ge $MaxReviews) { break }
        try {
            $data = Get-Content $f.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($ProjectName -and $data.project  -ne $ProjectName) { continue }
            if ($Developer   -and $data.developer -ne $Developer)  { continue }
            if ($Language    -and $data.language  -ne $Language)   { continue }
            $reviews.Add($data)
        } catch {
            Write-Log "WARN" "Skipping unreadable review file: $($f.Name) ($_)"
        }
    }
    return $reviews.ToArray()
}

# ================================================================
# Pattern analysis
# ================================================================
function Analyze-Patterns {
    param($reviews)

    $reviews = @($reviews)  # normalize: never let a single review unwrap to a scalar
    if ($reviews.Count -eq 0) {
        # Return the full schema (not just a message) so downstream display/consumers
        # never hit a missing key under Set-StrictMode -Version Latest. This is the
        # first-run path when no review history exists yet.
        return @{
            review_count   = 0
            total_p0       = 0
            total_p1       = 0
            total_p2       = 0
            total_p3       = 0
            p0_per_review  = 0
            top_categories = @()
            trend          = "Insufficient data"
            last_review    = ""
            message        = "No review history found"
        }
    }

    $totalP0 = ($reviews | ForEach-Object { $_.risk_counts.P0 } | Measure-Object -Sum).Sum
    $totalP1 = ($reviews | ForEach-Object { $_.risk_counts.P1 } | Measure-Object -Sum).Sum
    $totalP2 = ($reviews | ForEach-Object { $_.risk_counts.P2 } | Measure-Object -Sum).Sum
    $totalP3 = ($reviews | ForEach-Object { $_.risk_counts.P3 } | Measure-Object -Sum).Sum

    # Category frequency
    $categoryCount = @{}
    foreach ($r in $reviews) {
        foreach ($cat in $r.categories) {
            if ($cat) {
                if (-not $categoryCount.ContainsKey($cat)) { $categoryCount[$cat] = 0 }
                $categoryCount[$cat]++
            }
        }
    }
    $topCategories = @($categoryCount.GetEnumerator() |
                     Sort-Object Value -Descending |
                     Select-Object -First 5 |
                     ForEach-Object { "$($_.Key)($($_.Value)x)" })

    $p0Rate = [math]::Round($totalP0 / $reviews.Count, 1)

    # Trend: recent 3 reviews vs the 3 before them (P0+P1 volume)
    $trend = "Insufficient data"
    if ($reviews.Count -ge 6) {
        $recent3 = ($reviews[0..2] | ForEach-Object { $_.risk_counts.P0 + $_.risk_counts.P1 } | Measure-Object -Sum).Sum
        $prev3   = ($reviews[3..5] | ForEach-Object { $_.risk_counts.P0 + $_.risk_counts.P1 } | Measure-Object -Sum).Sum
        $trend = if ($recent3 -lt $prev3) { "Improving" }
                 elseif ($recent3 -gt $prev3) { "Worsening" }
                 else { "Stable" }
    }

    return @{
        review_count   = $reviews.Count
        total_p0       = $totalP0
        total_p1       = $totalP1
        total_p2       = $totalP2
        total_p3       = $totalP3
        p0_per_review  = $p0Rate
        top_categories = $topCategories
        trend          = $trend
        last_review    = $reviews[0].timestamp
    }
}

# ================================================================
# Build the memory context text injected into the next prompt
# ================================================================
function Build-MemoryContext {
    param($reviews, $patterns)

    $reviews = @($reviews)  # normalize: never let a single review unwrap to a scalar
    if ($reviews.Count -eq 0) { return "" }

    $sb = [System.Text.StringBuilder]::new()
    $null = $sb.AppendLine("# Past Review History (Memory)")
    $null = $sb.AppendLine("")
    $null = $sb.AppendLine("## Statistics Summary")
    $null = $sb.AppendLine("- Reviews analyzed : $($patterns.review_count)")
    $null = $sb.AppendLine("- P0 total : $($patterns.total_p0) (avg $($patterns.p0_per_review) per review)")
    $null = $sb.AppendLine("- P1 total : $($patterns.total_p1) / P2 total : $($patterns.total_p2) / P3 total : $($patterns.total_p3)")
    $null = $sb.AppendLine("- Trend (recent 3 vs previous 3) : $($patterns.trend)")
    if (@($patterns.top_categories).Count -gt 0) {
        $null = $sb.AppendLine("- Top risk categories : $($patterns.top_categories -join ' / ')")
    }
    $null = $sb.AppendLine("")

    $null = $sb.AppendLine("## Recent Review Results")
    foreach ($r in ($reviews | Select-Object -First 3)) {
        $target = Get-Prop $r 'target_file' '(unspecified)'
        $null = $sb.AppendLine("- $($r.date) [$($r.language)] P0:$($r.risk_counts.P0) P1:$($r.risk_counts.P1) | $target")
    }
    $null = $sb.AppendLine("")

    # Risks detected in 2 or more past reviews
    $repeatRisks = [System.Collections.Generic.Dictionary[string,int]]::new()
    foreach ($r in $reviews) {
        foreach ($risk in $r.risks) {
            $title = Get-Prop $risk 'title'
            if ($title) {
                if (-not $repeatRisks.ContainsKey($title)) { $repeatRisks[$title] = 0 }
                $repeatRisks[$title]++
            }
        }
    }
    $repeated = @($repeatRisks.GetEnumerator() |
                Where-Object { $_.Value -ge 2 } |
                Sort-Object Value -Descending |
                Select-Object -First 5)

    if ($repeated.Count -gt 0) {
        $null = $sb.AppendLine("## Repeatedly Detected Risks (2+ occurrences - watch closely)")
        foreach ($item in $repeated) {
            $null = $sb.AppendLine("- $($item.Key) (detected $($item.Value) times)")
        }
        $null = $sb.AppendLine("")
    }

    $null = $sb.AppendLine("## Review Policy Based on History")
    $null = $sb.AppendLine("- Check the current code specifically for the repeated risks listed above; this team has a track record of reintroducing them.")
    $null = $sb.AppendLine("- Prioritize the top risk categories from the statistics when depth of analysis must be traded off.")

    return $sb.ToString()
}

# ================================================================
# Main
# ================================================================
Write-Log "INFO" "analyze_patterns.ps1 started"

# @(...) forces an array so a single review file is not unwrapped to a scalar
# (which would break .Count / indexing under Set-StrictMode -Version Latest).
$reviews  = @(Load-Reviews)
$patterns = Analyze-Patterns -reviews $reviews
$context  = Build-MemoryContext -reviews $reviews -patterns $patterns

Write-Log "OK" "Analysis complete: $($reviews.Count) reviews"

$null = New-Item -ItemType Directory -Path $PATTERNS_DIR -Force
$patternFile = Join-Path $PATTERNS_DIR "latest_patterns.json"
$patterns | ConvertTo-Json -Depth 10 | Out-File -FilePath $patternFile -Encoding UTF8

# Memory context file (read by build_prompt.ps1)
$contextFile = Join-Path $MEMORY_DIR "memory_context.txt"
$context | Out-File -FilePath $contextFile -Encoding UTF8
Write-Log "OK" "Memory context saved: $contextFile"

Write-Host ""
Write-Host "======================================" -ForegroundColor DarkGray
Write-Host " Pattern Analysis" -ForegroundColor White
Write-Host "======================================" -ForegroundColor DarkGray
Write-Host " Reviews  : $($patterns.review_count)"
Write-Host " P0 total : $($patterns.total_p0)"
Write-Host " Trend    : $($patterns.trend)"
if (@($patterns.top_categories).Count -gt 0) {
    Write-Host " Top cat. : $($patterns.top_categories -join ' / ')"
}
Write-Host "======================================" -ForegroundColor DarkGray
