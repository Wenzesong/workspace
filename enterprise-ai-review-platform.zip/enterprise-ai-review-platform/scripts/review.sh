#!/usr/bin/env bash
# review.sh
# Enterprise AI Review Platform - Linux/Mac entry point.
# Thin wrapper around review.ps1: the platform logic lives in PowerShell,
# so this requires PowerShell 7+ (pwsh). Install: https://aka.ms/powershell
#
# Usage:
#   bash scripts/review.sh -l java -m diff-review [-p project] [-d developer] [-n] [-a]
#     -l  language (auto|java|csharp|linux|sql|vba)  default: auto
#     -m  mode (new-review|diff-review|new-test|diff-test)  required
#     -p  project name       default: default
#     -d  developer name     default: unknown
#     -n  disable memory (-NoMemory)
#     -a  auto review via Claude CLI (-AutoReview)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

LANGUAGE="auto"
MODE=""
PROJECT="default"
DEVELOPER="unknown"
EXTRA_ARGS=()

while getopts "l:m:p:d:na" opt; do
  case "$opt" in
    l) LANGUAGE="$OPTARG" ;;
    m) MODE="$OPTARG" ;;
    p) PROJECT="$OPTARG" ;;
    d) DEVELOPER="$OPTARG" ;;
    n) EXTRA_ARGS+=("-NoMemory") ;;
    a) EXTRA_ARGS+=("-AutoReview") ;;
    *) echo "Unknown option: -$OPTARG" >&2; exit 1 ;;
  esac
done

if [ -z "$MODE" ]; then
  echo "ERROR: -m <mode> is required (new-review|diff-review|new-test|diff-test)" >&2
  exit 1
fi

if ! command -v pwsh >/dev/null 2>&1; then
  echo "ERROR: PowerShell 7 (pwsh) is required to run this platform on Linux/Mac." >&2
  echo "       Install instructions: https://aka.ms/powershell" >&2
  exit 1
fi

exec pwsh -NoProfile -File "$SCRIPT_DIR/review.ps1" \
  -Language "$LANGUAGE" \
  -Mode "$MODE" \
  -ProjectName "$PROJECT" \
  -Developer "$DEVELOPER" \
  ${EXTRA_ARGS[@]+"${EXTRA_ARGS[@]}"}
