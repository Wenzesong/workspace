# ============================================================
# detect_context.ps1
# Enterprise AI Review Platform - Context Detector
# Role: collect source code, match risk patterns from
#       routing/risk_patterns.yaml, decide Agents/Skills, and
#       write the resulting context JSON for build_prompt.ps1.
# ============================================================

param(
    [Parameter(Mandatory = $true)]
    [string]$Language,

    [Parameter(Mandatory = $true)]
    [string]$Mode,

    [Parameter(Mandatory = $true)]
    [string]$RootDir,

    # The detected context is written here as JSON.
    # review.ps1 consumes this file (file-based contract).
    [Parameter(Mandatory = $true)]
    [string]$OutputJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

. "$PSScriptRoot\lib\common.ps1"
. "$PSScriptRoot\lib\routing.ps1"

# ------------------------------------------------------------
# Constants
# ------------------------------------------------------------
$ROUTING_DIR       = Join-Path $RootDir "ai-review\routing"
$RISK_PATTERN_FILE = Join-Path $ROUTING_DIR "risk_patterns.yaml"
$ROUTING_RULE_FILE = Join-Path $ROUTING_DIR "skill_routing_rules.yaml"
$SOURCE_NEW        = Join-Path $RootDir "source-code\new"
$SOURCE_OLD        = Join-Path $RootDir "source-code\old"

# ------------------------------------------------------------
# Source code collection
# ------------------------------------------------------------
function Get-SourceContent {
    param([string]$Mode)

    $extensions = @("*.java", "*.cs", "*.sql", "*.sh", "*.bash",
                    "*.bas", "*.cls", "*.frm",
                    "*.xml", "*.yaml", "*.yml", "*.properties", "*.json")
    $content = [System.Text.StringBuilder]::new()

    function Collect-Dir {
        param([string]$Dir, [string]$Label)
        if (-not (Test-Path $Dir)) { return }
        foreach ($ext in $extensions) {
            Get-ChildItem -Path $Dir -Filter $ext -Recurse -ErrorAction SilentlyContinue |
            ForEach-Object {
                $rel = $_.FullName.Replace($Dir, $Label)
                $null = $content.AppendLine("### [$rel]")
                $null = $content.AppendLine((Get-Content $_.FullName -Raw -Encoding UTF8))
                $null = $content.AppendLine()
            }
        }
    }

    Collect-Dir $SOURCE_NEW "[NEW]"
    if ($Mode -in @("diff-review", "diff-test")) {
        Collect-Dir $SOURCE_OLD "[OLD]"
    }

    return $content.ToString()
}

# ------------------------------------------------------------
# Language baseline Agents/Skills (always loaded)
# ------------------------------------------------------------
function Get-BaseContext {
    param([string]$Language)

    $map = @{
        java = @{
            Agents = @("java_architect_agent", "review_orchestrator_agent",
                       "security_architect_agent", "performance_architect_agent")
            Skills = @("java_skill", "spring_boot_skill", "security_skill", "performance_skill")
        }
        csharp = @{
            Agents = @("csharp_architect_agent", "review_orchestrator_agent",
                       "security_architect_agent", "performance_architect_agent")
            Skills = @("csharp_skill", "aspnet_skill", "security_skill", "performance_skill")
        }
        sql = @{
            Agents = @("sql_runtime_agent", "review_orchestrator_agent",
                       "query_analysis_agent", "security_architect_agent")
            Skills = @("sql_skill", "transaction_skill", "sql_injection_skill", "performance_skill")
        }
        linux = @{
            Agents = @("bash_agent", "review_orchestrator_agent",
                       "shell_security_agent", "docker_agent")
            Skills = @("bash_skill", "shell_security_skill", "security_skill", "docker_skill")
        }
        vba = @{
            Agents = @("vba_architect_agent", "review_orchestrator_agent",
                       "security_architect_agent", "vba_error_handling_agent")
            Skills = @("vba_skill", "vba_error_handling_skill", "security_skill", "performance_skill")
        }
    }

    if ($map.ContainsKey($Language)) { return $map[$Language] }
    return @{ Agents = @(); Skills = @() }
}

# ------------------------------------------------------------
# Risk-based pattern detection using risk_patterns.yaml
# ------------------------------------------------------------
function Invoke-RiskPatternDetect {
    param([string]$SourceContent, [string]$Language)

    Write-Log "INFO" "Loading risk_patterns.yaml ..."
    $rules = @(Get-RiskPatternRules -FilePath $RISK_PATTERN_FILE)

    if ($rules.Count -eq 0) {
        Write-Log "WARN" "risk_patterns.yaml missing or empty. Using language baseline only."
    }

    $detectedAgents = [System.Collections.Generic.List[string]]::new()
    $detectedSkills = [System.Collections.Generic.List[string]]::new()
    $matchedRules   = [System.Collections.Generic.List[string]]::new()
    $maxTier        = 1

    foreach ($rule in $rules) {
        $matched = $false
        foreach ($p in $rule.Patterns) {
            if (Test-PatternMatch -Source $SourceContent -Pattern $p) {
                $matched = $true
                break
            }
        }
        if (-not $matched) { continue }

        Write-Log "INFO" "  Matched: [$($rule.Id)] (Tier $($rule.Tier))"
        $matchedRules.Add($rule.Id)
        foreach ($a in $rule.Agents) {
            if ($detectedAgents -notcontains $a) { $detectedAgents.Add($a) }
        }
        foreach ($s in $rule.Skills) {
            if ($detectedSkills -notcontains $s) { $detectedSkills.Add($s) }
        }
        if ($rule.Tier -gt $maxTier) { $maxTier = $rule.Tier }
    }

    # Always prepend the language baseline (Language-Based is the floor).
    $baseContext = Get-BaseContext -Language $Language
    foreach ($a in @($baseContext.Agents)) {
        if ($detectedAgents -notcontains $a) { $detectedAgents.Insert(0, $a) }
    }
    foreach ($s in @($baseContext.Skills)) {
        if ($detectedSkills -notcontains $s) { $detectedSkills.Insert(0, $s) }
    }

    Write-Log "OK" "Detection done: $($matchedRules.Count) rules matched, Tier=$maxTier"

    return @{
        Language     = $Language
        Mode         = $Mode
        Tier         = $maxTier
        MatchedRules = $matchedRules.ToArray()
        Agents       = $detectedAgents.ToArray()
        Skills       = $detectedSkills.ToArray()
    }
}

# ------------------------------------------------------------
# Tier filter: cap skill count per skill_routing_rules.yaml,
# dropping highest-tier (least essential) skills first.
# Tier 1 skills and language baseline skills survive truncation.
# ------------------------------------------------------------
function Invoke-TierFilter {
    param([hashtable]$Context)

    if (-not (Test-Path $ROUTING_RULE_FILE)) {
        Write-Log "WARN" "skill_routing_rules.yaml not found. Skipping tier filter."
        return $Context
    }

    $yaml = Read-SimpleYaml $ROUTING_RULE_FILE
    $maxCount = if ($yaml.ContainsKey("max_skill_count_tier$($Context.Tier)")) {
        [int]$yaml["max_skill_count_tier$($Context.Tier)"]
    } else { 99 }

    if (@($Context.Skills).Count -gt $maxCount) {
        $tierMap = Get-SkillTierMap -FilePath $ROUTING_RULE_FILE
        Write-Log "WARN" "Skill count $(@($Context.Skills).Count) exceeds limit $maxCount. Dropping highest-tier skills first."
        $Context.Skills = Select-SkillsByTier -Skills $Context.Skills -TierMap $tierMap -MaxCount $maxCount
    }

    return $Context
}

# ------------------------------------------------------------
# Main
# ------------------------------------------------------------
try {
    Write-Log "INFO" "detect_context.ps1 started"

    $source = Get-SourceContent -Mode $Mode
    $srcLen = $source.Length
    Write-Log "INFO" "Source collected: $([math]::Round($srcLen/1KB,1)) KB"

    if ($srcLen -eq 0) {
        Write-Log "ERROR" "No reviewable files found in source-code/new"
        exit 1
    }

    $context = Invoke-RiskPatternDetect -SourceContent $source -Language $Language
    $context = Invoke-TierFilter -Context $context
    $context["SourceContent"] = $source

    $jsonObj = [ordered]@{
        Language      = $context.Language
        Mode          = $context.Mode
        Tier          = $context.Tier
        MatchedRules  = @($context.MatchedRules)
        Agents        = @($context.Agents)
        Skills        = @($context.Skills)
        SourceContent = $context.SourceContent
    }
    $outDir = Split-Path $OutputJson
    if ($outDir -and -not (Test-Path $outDir)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }
    $jsonObj | ConvertTo-Json -Depth 10 -Compress | Out-File -FilePath $OutputJson -Encoding UTF8
    Write-Log "OK" "Context JSON saved: $OutputJson"
    Write-Log "OK" "detect_context.ps1 done"
    exit 0
}
catch {
    Write-Log "ERROR" "detect_context.ps1 failed: $_"
    Write-Log "ERROR" $_.ScriptStackTrace
    exit 1
}
