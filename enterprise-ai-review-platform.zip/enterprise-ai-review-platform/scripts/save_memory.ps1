# save_memory.ps1
# Review result -> structured JSON -> memory/reviews/
# Also maintains memory/summary.json (totals and per-project/developer/language counts).

param(
    [Parameter(Mandatory = $true)][string]$Language,
    [Parameter(Mandatory = $true)][string]$Mode,
    [Parameter(Mandatory = $false)][string]$ProjectName = "default",
    [Parameter(Mandatory = $false)][string]$Developer   = "unknown",
    [Parameter(Mandatory = $false)][string]$TargetFile  = "",
    [Parameter(Mandatory = $false)][string]$RootDir     = "$PSScriptRoot\..",
    [Parameter(Mandatory = $false)][string]$ReviewResult = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

. "$PSScriptRoot\lib\common.ps1"
. "$PSScriptRoot\lib\risk_extraction.ps1"

$MEMORY_DIR   = Join-Path $RootDir "memory"
$REVIEWS_DIR  = Join-Path $MEMORY_DIR "reviews"
$SUMMARY_FILE = Join-Path $MEMORY_DIR "summary.json"

# Ensure memory directories exist before any write (first-run safe).
foreach ($d in @($MEMORY_DIR, $REVIEWS_DIR)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

# ================================================================
# Summary maintenance
# ================================================================

# Convert a PSCustomObject loaded from JSON into a plain hashtable
# (one level deep) so keys can be added/incremented freely on PS 5.1.
function ConvertTo-CountHashtable {
    param($Obj)
    $ht = @{}
    if ($null -ne $Obj) {
        foreach ($p in $Obj.PSObject.Properties) { $ht[$p.Name] = [int]$p.Value }
    }
    return $ht
}

function Update-Summary {
    param($newRecord)

    $totals = @{
        total_reviews = 0
        total_p0      = 0
        total_p1      = 0
        total_p2      = 0
        total_p3      = 0
    }
    $projects   = @{}
    $developers = @{}
    $languages  = @{}

    if (Test-Path $SUMMARY_FILE) {
        try {
            $existing = Get-Content $SUMMARY_FILE -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($key in @($totals.Keys)) {
                $totals[$key] = [int](Get-Prop $existing $key 0)
            }
            $projects   = ConvertTo-CountHashtable (Get-Prop $existing 'projects'   $null)
            $developers = ConvertTo-CountHashtable (Get-Prop $existing 'developers' $null)
            $languages  = ConvertTo-CountHashtable (Get-Prop $existing 'languages'  $null)
        } catch {
            Write-Log "WARN" "summary.json unreadable. Rebuilding from this record. ($_)"
        }
    }

    $totals.total_reviews++
    $totals.total_p0 += $newRecord.risk_counts.P0
    $totals.total_p1 += $newRecord.risk_counts.P1
    $totals.total_p2 += $newRecord.risk_counts.P2
    $totals.total_p3 += $newRecord.risk_counts.P3

    foreach ($pair in @(
        @{ Map = $projects;   Key = $newRecord.project },
        @{ Map = $developers; Key = $newRecord.developer },
        @{ Map = $languages;  Key = $newRecord.language }
    )) {
        $map = $pair.Map; $key = $pair.Key
        if ($key) {
            if (-not $map.ContainsKey($key)) { $map[$key] = 0 }
            $map[$key]++
        }
    }

    $summary = [ordered]@{
        total_reviews = $totals.total_reviews
        total_p0      = $totals.total_p0
        total_p1      = $totals.total_p1
        total_p2      = $totals.total_p2
        total_p3      = $totals.total_p3
        projects      = $projects
        developers    = $developers
        languages     = $languages
        last_updated  = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    }

    $summary | ConvertTo-Json -Depth 10 | Out-File -FilePath $SUMMARY_FILE -Encoding UTF8
    Write-Log "INFO" "Summary updated: $SUMMARY_FILE"
}

# ================================================================
# Main
# ================================================================
try {

Write-Log "INFO" "save_memory.ps1 started"

# Load review result when not passed explicitly.
# Reads the dedicated review-result file written by save_review_result.ps1.
# NOTE: never fall back to final_report.md - that file holds the generated prompt
# metadata, not the AI review output, and would silently extract 0 risks.
if (-not $ReviewResult) {
    $resultFile = Join-Path $RootDir "output\review_result.md"
    if (Test-Path $resultFile) {
        $ReviewResult = Get-Content $resultFile -Raw -Encoding UTF8
        Write-Log "INFO" "Review result loaded from: $resultFile"
    } else {
        Write-Log "WARN" "Review result not found: $resultFile"
        $ReviewResult = ""
    }
}

# Guard: refuse to save an empty review (avoids polluting memory with 0-risk records).
if (-not $ReviewResult -or $ReviewResult.Trim().Length -lt 10) {
    Write-Log "ERROR" "No review result to save. Run save_review_result.ps1 to capture the AI review first."
    exit 1
}

# @(...) keeps a zero-finding result as an empty array (see Extract-Risks).
$risks      = @(Extract-Risks -ReviewText $ReviewResult)
$riskCounts = Count-RiskLevels -risks $risks
$categories = Get-Categories -risks $risks

Write-Log "INFO" "Risks detected: P0=$($riskCounts.P0) P1=$($riskCounts.P1) P2=$($riskCounts.P2) P3=$($riskCounts.P3)"

$record = [ordered]@{
    id           = [System.Guid]::NewGuid().ToString("N").Substring(0, 8)
    date         = Get-Date -Format "yyyy-MM-dd"
    timestamp    = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    project      = $ProjectName
    developer    = $Developer
    language     = $Language
    mode         = $Mode
    target_file  = $TargetFile
    risk_counts  = $riskCounts
    categories   = $categories
    risks        = $risks
    review_text  = $ReviewResult.Substring(0, [Math]::Min($ReviewResult.Length, 2000))
}

# Include the unique record id: two saves within the same second must not
# overwrite each other.
$fileName   = "$(Get-Date -Format 'yyyyMMdd_HHmmss')_${ProjectName}_${Language}_$($record.id).json"
$outputPath = Join-Path $REVIEWS_DIR $fileName
$record | ConvertTo-Json -Depth 10 | Out-File -FilePath $outputPath -Encoding UTF8

Write-Log "OK" "Saved: $outputPath"

Update-Summary -newRecord $record

Write-Host ""
Write-Host "======================================" -ForegroundColor DarkGray
Write-Host " Memory Saved" -ForegroundColor White
Write-Host "======================================" -ForegroundColor DarkGray
Write-Host " Project   : $ProjectName"
Write-Host " Developer : $Developer"
Write-Host " Language  : $Language"
Write-Host " Mode      : $Mode"
Write-Host " P0        : $($riskCounts.P0)"
Write-Host " P1        : $($riskCounts.P1)"
Write-Host " Saved to  : $outputPath"
Write-Host "======================================" -ForegroundColor DarkGray

}
catch {
    Write-Log "ERROR" "save_memory.ps1 failed: $_"
    Write-Log "ERROR" $_.ScriptStackTrace
    exit 1
}
