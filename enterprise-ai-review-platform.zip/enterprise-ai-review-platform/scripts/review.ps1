# review.ps1
# Enterprise AI Review Platform - Entry Point
#
# Flow:
#   Step0: analyze past reviews -> memory/memory_context.txt
#   Step1: detect_context.ps1  -> output/_context.json
#   Step2: build_prompt.ps1    -> output/final_review_prompt.txt
#   (optional) -AutoReview: run Claude CLI and save the result to memory
#
# After a manual (copy-paste) review, run save_review_result.ps1 to
# capture the AI output and feed the memory loop.

param(
    # "auto" detects the language from file extensions in source-code/new.
    [Parameter(Mandatory = $false)]
    [ValidateSet("auto", "java", "csharp", "linux", "sql", "vba")]
    [string]$Language = "auto",

    [Parameter(Mandatory = $true)]
    [ValidateSet("new-review", "diff-review", "new-test", "diff-test")]
    [string]$Mode,

    [Parameter(Mandatory = $false)][string]$ProjectName = "default",
    [Parameter(Mandatory = $false)][string]$Developer   = "unknown",
    [Parameter(Mandatory = $false)][switch]$NoMemory,

    # Run the review automatically via the Claude CLI instead of manual copy-paste.
    # Requires the "claude" command on PATH. The result is written to
    # output/review_result.md and saved to memory via save_memory.ps1.
    [Parameter(Mandatory = $false)][switch]$AutoReview,

    [Parameter(Mandatory = $false)][string]$ConfigPath = "$PSScriptRoot\..\config\platform.yaml"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

. "$PSScriptRoot\lib\common.ps1"

$SCRIPT_DIR = $PSScriptRoot
$ROOT_DIR   = Resolve-Path "$SCRIPT_DIR\.."
$MEMORY_DIR = Join-Path $ROOT_DIR "memory"
$SOURCE_NEW = Join-Path $ROOT_DIR "source-code\new"
$TIMESTAMP  = Get-Date -Format "yyyyMMdd_HHmmss"

# Stale-source warning threshold. Files older than this in source-code/new
# are probably leftovers from a previous review run.
$STALE_SOURCE_HOURS = 24

# ================================================================
# Config (config/platform.yaml)
# ================================================================
function Get-PlatformConfig {
    $defaults = @{
        model              = "claude-sonnet-5"
        output_dir         = "output"
        final_prompt_file  = "final_review_prompt.txt"
        max_prompt_size_kb = 400
    }
    $yaml = Read-SimpleYaml $ConfigPath
    foreach ($key in @($defaults.Keys)) {
        if ($yaml.ContainsKey($key)) { $defaults[$key] = $yaml[$key] }
    }
    return $defaults
}

function Invoke-PreCheck {
    Write-Log "INFO" "Pre-check started"
    if (-not (Test-Path $ConfigPath)) {
        Write-Log "WARN" "config/platform.yaml not found. Using defaults."
    }
    if (-not (Test-Path $SOURCE_NEW)) {
        Write-Log "ERROR" "Not found: source-code/new"
        exit 1
    }
    if ($Mode -in @("diff-review", "diff-test") -and -not (Test-Path (Join-Path $ROOT_DIR "source-code\old"))) {
        Write-Log "ERROR" "Not found: source-code/old (required for $Mode)"
        exit 1
    }
    foreach ($s in @("detect_context.ps1", "build_prompt.ps1")) {
        if (-not (Test-Path (Join-Path $SCRIPT_DIR $s))) {
            Write-Log "ERROR" "Not found: scripts/$s"
            exit 1
        }
    }

    # List review targets and warn about possibly stale leftovers.
    $files = @(Get-ChildItem $SOURCE_NEW -File -Recurse -ErrorAction SilentlyContinue)
    if ($files.Count -eq 0) {
        Write-Log "ERROR" "No files in source-code/new. Place the code to review first."
        exit 1
    }
    Write-Log "INFO" "Review targets ($($files.Count) files):"
    foreach ($f in $files) {
        $age = (Get-Date) - $f.LastWriteTime
        $mark = if ($age.TotalHours -gt $STALE_SOURCE_HOURS) { " <- possibly stale (last modified $($f.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))" } else { "" }
        Write-Log "INFO" "  - $($f.Name)$mark"
        if ($mark) {
            Write-Log "WARN" "$($f.Name) is older than $STALE_SOURCE_HOURS hours. Remove it if it belongs to a previous review."
        }
    }
    Write-Log "OK" "Pre-check passed"
}

# ================================================================
# Language auto-detection from file extensions in source-code/new
# ================================================================
function Resolve-Language {
    if ($Language -ne "auto") { return $Language }

    $files = @(Get-ChildItem $SOURCE_NEW -File -Recurse -ErrorAction SilentlyContinue)
    $exts  = @($files | ForEach-Object { $_.Extension.ToLower() })

    $detected = if ($exts -contains ".java") { "java" }
                elseif ($exts -contains ".cs") { "csharp" }
                elseif ($exts -contains ".bas" -or $exts -contains ".cls" -or
                        $exts -contains ".frm") { "vba" }
                elseif ($exts -contains ".sh" -or $exts -contains ".bash" -or
                        ($files | Where-Object { $_.Name -match '^Dockerfile' })) { "linux" }
                elseif ($exts -contains ".sql") { "sql" }
                else { $null }

    if (-not $detected) {
        Write-Log "ERROR" "Could not auto-detect language from source-code/new. Pass -Language explicitly."
        exit 1
    }
    Write-Log "OK" "Language auto-detected: $detected"
    return $detected
}

# ================================================================
# Step0: Refresh memory context from past reviews
# ================================================================
function Invoke-LoadMemory {
    param([string]$ResolvedLanguage)

    if ($NoMemory) {
        Write-Log "INFO" "Memory: skipped (-NoMemory)"
        return ""
    }

    Write-Log "INFO" "Step0: Loading memory"
    $analyzeScript = Join-Path $SCRIPT_DIR "analyze_patterns.ps1"
    if (-not (Test-Path $analyzeScript)) {
        Write-Log "WARN" "analyze_patterns.ps1 not found. Continuing without memory."
        return ""
    }

    & "$analyzeScript" `
        -RootDir     $ROOT_DIR `
        -ProjectName $ProjectName `
        -Developer   $Developer `
        -Language    $ResolvedLanguage | Out-Null

    $contextFile = Join-Path $MEMORY_DIR "memory_context.txt"
    if ((Test-Path $contextFile) -and
        -not [string]::IsNullOrWhiteSpace((Get-Content $contextFile -Raw -Encoding UTF8))) {
        Write-Log "OK" "Memory loaded"
        return $contextFile
    }
    Write-Log "INFO" "No memory context available yet"
    return ""
}

# ================================================================
# Step1: Detect context
# ================================================================
function Invoke-DetectContext {
    param([string]$ResolvedLanguage, [string]$ContextFile)

    Write-Log "INFO" "Step1: detect_context (Language=$ResolvedLanguage, Mode=$Mode)"

    & "$SCRIPT_DIR\detect_context.ps1" `
        -Language   $ResolvedLanguage `
        -Mode       $Mode `
        -RootDir    $ROOT_DIR `
        -OutputJson $ContextFile

    if ($LASTEXITCODE -ne 0) {
        Write-Log "ERROR" "detect_context.ps1 failed (exit=$LASTEXITCODE)"
        exit 1
    }
    if (-not (Test-Path $ContextFile)) {
        Write-Log "ERROR" "Context JSON not found: $ContextFile"
        exit 1
    }

    $json    = Get-Content $ContextFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $context = @{
        Language     = $json.Language
        Mode         = $json.Mode
        Tier         = [int]$json.Tier
        MatchedRules = @($json.MatchedRules)
        Agents       = @($json.Agents)
        Skills       = @($json.Skills)
    }
    Write-Log "OK" "Detected: Agents=$($context.Agents.Count), Skills=$($context.Skills.Count), Tier=$($context.Tier)"
    return $context
}

# ================================================================
# Step2: Build prompt
# ================================================================
function Invoke-BuildPrompt {
    param([string]$ContextFile, [string]$MemoryContextFile, [string]$OutputFile)

    Write-Log "INFO" "Step2: build_prompt"

    & "$SCRIPT_DIR\build_prompt.ps1" `
        -ContextJson       $ContextFile `
        -RootDir           $ROOT_DIR `
        -OutputFile        $OutputFile `
        -MemoryContextFile $MemoryContextFile

    if ($LASTEXITCODE -ne 0) {
        Write-Log "ERROR" "build_prompt.ps1 failed"
        exit 1
    }
    if (-not (Test-Path $OutputFile)) {
        Write-Log "ERROR" "Prompt not generated: $OutputFile"
        exit 1
    }
    Write-Log "OK" "Prompt generated: $OutputFile"
    return $OutputFile
}

# ================================================================
# Optional Step3: run the review via Claude CLI (closes the loop)
# ================================================================
function Invoke-AutoReview {
    param([string]$PromptFile, [string]$ResolvedLanguage, [hashtable]$Config, [string]$OutputDir)

    if (-not (Get-Command claude -ErrorAction SilentlyContinue)) {
        Write-Log "ERROR" "-AutoReview requires the Claude CLI ('claude') on PATH. Falling back to manual flow."
        return
    }

    $model      = $Config.model
    $resultFile = Join-Path $OutputDir "review_result.md"
    Write-Log "INFO" "Step3: Running Claude CLI review (model=$model). This may take a few minutes ..."

    $prevEncoding   = [Console]::OutputEncoding
    $prevOutputEnc  = $OutputEncoding
    try {
        # Force UTF-8 across the native pipe so non-ASCII review text survives.
        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
        $global:OutputEncoding    = [System.Text.Encoding]::UTF8
        $result = Get-Content $PromptFile -Raw -Encoding UTF8 | claude -p --model $model
    }
    finally {
        [Console]::OutputEncoding = $prevEncoding
        $global:OutputEncoding    = $prevOutputEnc
    }

    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace(($result -join "`n"))) {
        Write-Log "ERROR" "Claude CLI review failed (exit=$LASTEXITCODE). Run the manual flow instead."
        return
    }

    ($result -join "`n") | Out-File -FilePath $resultFile -Encoding UTF8
    Write-Log "OK" "Review result saved: $resultFile"

    & "$SCRIPT_DIR\save_memory.ps1" `
        -Language    $ResolvedLanguage `
        -Mode        $Mode `
        -ProjectName $ProjectName `
        -Developer   $Developer `
        -RootDir     $ROOT_DIR

    # A memory-save failure must not discard the already-completed review:
    # review_result.md is on disk, so warn and let the user re-save later.
    if ($LASTEXITCODE -ne 0) {
        Write-Log "WARN" "Memory save failed (exit=$LASTEXITCODE). The review itself is safe in $resultFile; re-run save_memory.ps1 to retry."
    }
}

function Write-Summary {
    param([hashtable]$Context, [string]$OutputFile, [hashtable]$Config)
    $sizeKB = [math]::Round((Get-Item $OutputFile).Length / 1KB, 1)
    Write-Host ""
    Write-Host "======================================" -ForegroundColor DarkGray
    Write-Host " Review Prompt Generated" -ForegroundColor White
    Write-Host "======================================" -ForegroundColor DarkGray
    Write-Host " Language : $($Context.Language)"
    Write-Host " Mode     : $($Context.Mode)"
    Write-Host " Project  : $ProjectName"
    Write-Host " Developer: $Developer"
    Write-Host " Tier     : $($Context.Tier)"
    Write-Host " Agents   : $($Context.Agents -join ', ')"
    Write-Host " Skills   : $($Context.Skills.Count) loaded"
    Write-Host " Memory   : $(if ($NoMemory) { 'OFF' } else { 'ON' })"
    Write-Host " Output   : $OutputFile"
    Write-Host " Size     : $sizeKB KB"
    Write-Host " Time     : $TIMESTAMP"
    Write-Host "======================================" -ForegroundColor DarkGray

    $maxKB = [double]$Config.max_prompt_size_kb
    if ($sizeKB -gt $maxKB) {
        Write-Log "WARN" "Prompt size $sizeKB KB exceeds max_prompt_size_kb ($maxKB KB). Consider reviewing fewer files at once."
    }

    Write-Host ""
    if ($AutoReview) {
        Write-Host "Auto review requested: result (if successful) is in output\review_result.md." -ForegroundColor Cyan
    } else {
        Write-Host "Next: Paste output\final_review_prompt.txt into Claude or ChatGPT." -ForegroundColor Cyan
        Write-Host "After review: Run save_review_result.ps1 to capture the AI output into memory." -ForegroundColor Yellow
    }
}

# ================================================================
# Main flow
# ================================================================
try {
    Write-Log "INFO" "Enterprise AI Review Platform started"
    Write-Log "INFO" "Language=$Language / Mode=$Mode / Project=$ProjectName"

    Invoke-PreCheck
    $config     = Get-PlatformConfig
    $outputDir  = Join-Path $ROOT_DIR $config.output_dir
    $outputFile = Join-Path $outputDir $config.final_prompt_file
    $ctxFile    = Join-Path $outputDir "_context.json"

    foreach ($d in @($outputDir, (Join-Path $outputDir "agent_outputs"))) {
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    }
    Write-Log "INFO" "Output dir: $outputDir"

    $resolvedLanguage  = Resolve-Language
    $memoryContextFile = Invoke-LoadMemory -ResolvedLanguage $resolvedLanguage
    $context           = Invoke-DetectContext -ResolvedLanguage $resolvedLanguage -ContextFile $ctxFile
    $promptFile        = Invoke-BuildPrompt -ContextFile $ctxFile -MemoryContextFile $memoryContextFile -OutputFile $outputFile

    Write-Summary -Context $context -OutputFile $promptFile -Config $config

    if ($AutoReview) {
        Invoke-AutoReview -PromptFile $promptFile -ResolvedLanguage $resolvedLanguage -Config $config -OutputDir $outputDir
    }

    if (Test-Path $ctxFile) {
        Remove-Item $ctxFile -Force
    }
}
catch {
    Write-Log "ERROR" "Unexpected error: $_"
    Write-Log "ERROR" $_.ScriptStackTrace
    exit 1
}
