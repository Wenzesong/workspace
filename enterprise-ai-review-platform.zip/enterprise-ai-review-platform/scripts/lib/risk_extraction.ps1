# risk_extraction.ps1
# Enterprise AI Review Platform - Risk extraction from AI review output
# Dot-source after common.ps1 (uses Write-Log and Get-Prop). Functions only.

# ================================================================
# Extract risks from review result text.
# Priority: fenced ```json block > regex fallback on [P0]-style lines.
# ================================================================
function Extract-Risks {
    param([string]$ReviewText)

    # --- Method 1: Extract from JSON block (high accuracy) ---
    # Capture the entire fenced block content (non-greedy up to the closing fence) so
    # nested objects/arrays survive. A brace-based pattern stops at the first "}" and
    # breaks on any nested JSON (risks is always an array of objects).
    if ($ReviewText -match '(?s)```json\s*(.+?)```') {
        $jsonText = $Matches[1].Trim()
        try {
            $parsed = $jsonText | ConvertFrom-Json
            # Property presence only - an empty "risks": [] is a VALID parsed
            # result meaning zero findings, not a reason to fall back to regex.
            # (A 0-length array is falsy in PowerShell, so do not test $parsed.risks.)
            $hasRisks = ($null -ne $parsed) -and ($parsed.PSObject.Properties.Name -contains 'risks')
            if ($hasRisks) {
                $risks = [System.Collections.Generic.List[hashtable]]::new()
                foreach ($r in @($parsed.risks)) {
                    $level = Get-Prop $r 'level' 'P3'
                    $risks.Add(@{
                        id          = Get-Prop $r 'id' $level
                        level       = $level
                        title       = Get-Prop $r 'title'
                        description = Get-Prop $r 'description'
                        category    = Get-Prop $r 'category'
                        impact      = Get-Prop $r 'impact'
                        fix         = Get-Prop $r 'fix'
                    })
                }
                Write-Log "OK" "JSON extraction: $($risks.Count) risks found"
                # CALLERS MUST wrap this call in @(...): a returned 0-length array
                # unrolls to AutomationNull on plain assignment, which later turns
                # into @($null) at parameter boundaries and crashes under StrictMode.
                # (Do NOT "fix" this with `return ,$array` - combined with @() at
                # the call site that double-wraps the array instead.)
                return $risks.ToArray()
            }
        } catch {
            Write-Log "WARN" "JSON parse failed. Falling back to regex."
        }
    }

    # --- Method 2: Regex fallback (when JSON block is missing) ---
    Write-Log "WARN" "JSON block not found. Using regex extraction."
    $risks = [System.Collections.Generic.List[hashtable]]::new()
    $lines = $ReviewText -split "`n"
    $current = $null

    foreach ($line in $lines) {
        if ($line -match '\[(P[0-3])-?(\d+)?\]\s*(.+)') {
            if ($current) { $risks.Add($current) }
            $current = @{
                id          = if ($Matches[2]) { "$($Matches[1])-$($Matches[2])" } else { $Matches[1] }
                level       = $Matches[1]
                title       = $Matches[3].Trim()
                description = ""
                category    = ""
            }
        }
        elseif ($line -match 'Category[::]\s*(.+)' -and $current) {
            $current.category = $Matches[1].Trim()
        }
        elseif ($line -match 'Problem[::]\s*(.+)' -and $current) {
            $current.description = $Matches[1].Trim()
        }
    }
    if ($current) { $risks.Add($current) }

    Write-Log "INFO" "Regex extraction: $($risks.Count) risks found"
    # See the note on the JSON path above: callers must use @(...).
    return $risks.ToArray()
}

# ================================================================
# Count risk levels
# ================================================================
function Count-RiskLevels {
    param($risks)
    $counts = @{ P0 = 0; P1 = 0; P2 = 0; P3 = 0 }
    foreach ($r in @($risks)) {
        if ($counts.ContainsKey($r.level)) {
            $counts[$r.level]++
        }
    }
    return $counts
}

# ================================================================
# Aggregate distinct categories
# ================================================================
function Get-Categories {
    param($risks)
    $categories = [System.Collections.Generic.List[string]]::new()
    foreach ($r in @($risks)) {
        if ($r.category -and -not $categories.Contains($r.category)) {
            $categories.Add($r.category)
        }
    }
    return $categories.ToArray()
}
