# common.ps1
# Enterprise AI Review Platform - Shared utilities
# Dot-source this file. It defines functions only and has no side effects.
#
# NOTE: All .ps1 files in this project must stay ASCII-only.
# Windows PowerShell 5.1 reads BOM-less files as ANSI, which corrupts
# any non-ASCII characters (this caused mojibake in earlier versions).

function Write-Log {
    param([string]$Level, [string]$Message)
    $ts = Get-Date -Format "HH:mm:ss"
    $color = switch ($Level) {
        "INFO"  { "Cyan" }
        "OK"    { "Green" }
        "WARN"  { "Yellow" }
        "ERROR" { "Red" }
        default { "White" }
    }
    Write-Host "[$ts][$Level] $Message" -ForegroundColor $color
}

# Safe property accessor: returns $Default when the property is absent or null.
# Required because Set-StrictMode -Version Latest throws on missing PSCustomObject
# properties, and AI JSON output routinely omits optional fields (impact/fix/etc.).
function Get-Prop {
    param($Obj, [string]$Name, [string]$Default = "")
    if ($null -ne $Obj -and ($Obj.PSObject.Properties.Name -contains $Name)) {
        $v = $Obj.$Name
        if ($null -ne $v -and "$v" -ne "") { return $v }
    }
    return $Default
}

# Minimal YAML reader for flat "key: value" pairs and simple one-level lists:
#   key: value
#   listKey:
#     - item1
#     - item2
# Comments (#) and blank lines are ignored. Nested maps are NOT supported here;
# use Read-YamlTierMap in routing.ps1 for the two-level tier structure.
function Read-SimpleYaml {
    param([string]$FilePath)
    if (-not (Test-Path $FilePath)) {
        Write-Log "WARN" "YAML file not found: $FilePath"
        return @{}
    }
    $lines  = Get-Content $FilePath -Encoding UTF8
    $result = @{}
    $currentKey = $null
    $listBuffer = [System.Collections.Generic.List[string]]::new()

    foreach ($line in $lines) {
        if ($line -match '^\s*#' -or $line.Trim() -eq '') { continue }

        if ($line -match '^(\w[\w_]*):\s*$') {
            if ($currentKey -and $listBuffer.Count -gt 0) {
                $result[$currentKey] = $listBuffer.ToArray()
                $listBuffer.Clear()
            }
            $currentKey = $Matches[1]
        }
        elseif ($line -match '^(\w[\w_]*):\s*(.+)$') {
            if ($currentKey -and $listBuffer.Count -gt 0) {
                $result[$currentKey] = $listBuffer.ToArray()
                $listBuffer.Clear()
            }
            $currentKey = $null
            $result[$Matches[1]] = $Matches[2].Trim().Trim('"').Trim("'")
        }
        elseif ($line -match '^\s+-\s+(.+)$' -and $currentKey) {
            $listBuffer.Add($Matches[1].Trim().Trim('"').Trim("'"))
        }
    }
    if ($currentKey -and $listBuffer.Count -gt 0) {
        $result[$currentKey] = $listBuffer.ToArray()
    }
    return $result
}
