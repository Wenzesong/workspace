# routing.ps1
# Enterprise AI Review Platform - Risk-pattern routing logic
# Dot-source after common.ps1. Functions only, no side effects.

# ------------------------------------------------------------
# Parse risk_patterns.yaml into an array of rule hashtables:
#   @{ Id; Patterns[]; Agents[]; Skills[]; Tier }
# The file is a YAML list of "- id:" blocks; we split on that marker.
# ------------------------------------------------------------
function Get-RiskPatternRules {
    param([string]$FilePath)

    if (-not (Test-Path $FilePath)) { return @() }
    $yamlText = Get-Content $FilePath -Raw -Encoding UTF8

    $rules  = [System.Collections.Generic.List[hashtable]]::new()
    $blocks = $yamlText -split '(?m)^- id:' | Where-Object { $_.Trim() -ne '' }

    foreach ($block in $blocks) {
        $blockLines = $block -split "`n"
        $ruleId     = $blockLines[0].Trim()
        # Skip the header comment chunk before the first "- id:".
        if ($ruleId -match '^#' -or $ruleId -eq '') { continue }

        $patterns = [System.Collections.Generic.List[string]]::new()
        $agents   = [System.Collections.Generic.List[string]]::new()
        $skills   = [System.Collections.Generic.List[string]]::new()
        $tier     = 1
        $section  = ""

        foreach ($line in $blockLines) {
            if ($line -match '^\s+patterns:')     { $section = "patterns"; continue }
            if ($line -match '^\s+agents:')       { $section = "agents";   continue }
            if ($line -match '^\s+skills:')       { $section = "skills";   continue }
            if ($line -match '^\s+tier:\s*(\d+)') { $tier = [int]$Matches[1]; $section = ""; continue }
            if ($line -match '^\s+-\s+(.+)$') {
                # Strip surrounding YAML quotes so patterns compare against raw source.
                $val = $Matches[1].Trim().Trim('"').Trim("'")
                switch ($section) {
                    "patterns" { $patterns.Add($val) }
                    "agents"   { $agents.Add($val) }
                    "skills"   { $skills.Add($val) }
                }
            }
        }

        $rules.Add(@{
            Id       = $ruleId
            Patterns = $patterns.ToArray()
            Agents   = $agents.ToArray()
            Skills   = $skills.ToArray()
            Tier     = $tier
        })
    }
    return $rules.ToArray()
}

# ------------------------------------------------------------
# Case-sensitive literal match with word-boundary guards.
# When the pattern starts/ends with a word character, require a
# non-word neighbor so "Statement" does not fire on "PreparedStatement"
# and "COMMIT" does not fire on "COMMITTED".
# ------------------------------------------------------------
function Test-PatternMatch {
    param([string]$Source, [string]$Pattern)

    if ([string]::IsNullOrEmpty($Pattern)) { return $false }
    $regex = [regex]::Escape($Pattern)
    if ($Pattern[0] -match '\w')  { $regex = "(?<!\w)$regex" }
    if ($Pattern[$Pattern.Length - 1] -match '\w') { $regex = "$regex(?!\w)" }
    return [bool]($Source -cmatch $regex)
}

# ------------------------------------------------------------
# Parse the two-level tier maps in skill_routing_rules.yaml:
#   sql_skill_tiers:
#     tier1:
#       - transaction_skill
# Returns a hashtable: skill name -> tier number (1/2/3).
# Skills not listed in any tier map are treated as Tier 1 by callers
# (language-specific baseline skills are always essential).
# ------------------------------------------------------------
function Get-SkillTierMap {
    param([string]$FilePath)

    $map = @{}
    if (-not (Test-Path $FilePath)) { return $map }

    $currentTier = 0
    foreach ($line in (Get-Content $FilePath -Encoding UTF8)) {
        if ($line -match '^\s*#' -or $line.Trim() -eq '') { continue }
        if ($line -match '^\w')                    { $currentTier = 0; continue }  # new top-level key
        if ($line -match '^\s+tier(\d+):\s*$')     { $currentTier = [int]$Matches[1]; continue }
        if ($currentTier -gt 0 -and $line -match '^\s+-\s+(.+)$') {
            $skill = $Matches[1].Trim()
            if (-not $map.ContainsKey($skill)) { $map[$skill] = $currentTier }
        }
    }
    return $map
}

# ------------------------------------------------------------
# Tier-priority skill selection.
# Sorts skills by tier (unknown = Tier 1, i.e. never dropped first)
# with a stable order, then truncates to $MaxCount. This guarantees
# Tier 1 essentials survive truncation, unlike a positional cut.
# ------------------------------------------------------------
function Select-SkillsByTier {
    param(
        [string[]]$Skills,
        [hashtable]$TierMap,
        [int]$MaxCount
    )

    $Skills = @($Skills)
    if ($Skills.Count -le $MaxCount) { return $Skills }

    $indexed = for ($i = 0; $i -lt $Skills.Count; $i++) {
        $name = $Skills[$i]
        $tier = if ($TierMap.ContainsKey($name)) { [int]$TierMap[$name] } else { 1 }
        [pscustomobject]@{ Name = $name; Tier = $tier; Index = $i }
    }

    $selected = $indexed |
                Sort-Object Tier, Index |
                Select-Object -First $MaxCount |
                Sort-Object Index |
                ForEach-Object { $_.Name }
    return @($selected)
}
