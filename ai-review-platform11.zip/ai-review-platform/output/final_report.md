﻿# Review Report

| Item | Value |
|---|---|
| Generated | 2026-06-25 10:40:06 |
| Language  | java |
| Mode      | new-review |
| Tier      | 2 |
| Prompt    | 40.9 KB |

## Loaded Agents (8)

- review_orchestrator_agent
- java_architect_agent
- transaction_agent
- deadlock_analysis_agent
- rollback_agent
- performance_architect_agent
- distributed_system_agent
- security_architect_agent

## Loaded Skills (10)

- spring_boot_skill
- java_skill
- transaction_skill
- deadlock_skill
- rollback_skill
- locking_skill
- consistency_skill
- async_skill
- concurrency_skill
- performance_skill

## Matched Risk Rules

- transaction
- async
- security_auth

## Next Step

Paste output\final_review_prompt.txt into Claude or ChatGPT.

