﻿# ============================================================
# detect_context.ps1
# Enterprise AI Review Platform - Context Detector
# 役割: コード解析・リスクパターン検出・Agent/Skill決定
#       routing/risk_patterns.yaml を読んでパターンマッチし
#       必要な Agent/Skill リストを hashtable で返す
# ============================================================

param(
    [Parameter(Mandatory = $true)]
    [string]$Language,

    [Parameter(Mandatory = $true)]
    [string]$Mode,

    [Parameter(Mandatory = $true)]
    [string]$RootDir,

    [Parameter(Mandatory = $false)]
    [string]$ConfigPath = "$RootDir\config\platform.yaml",

    # When provided, the detected context is also written here as JSON.
    # review.ps1 consumes this file (file-based contract).
    [Parameter(Mandatory = $false)]
    [string]$OutputJson = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ------------------------------------------------------------
# 定数
# ------------------------------------------------------------
$ROUTING_DIR      = Join-Path $RootDir "ai-review\routing"
$RISK_PATTERN_FILE = Join-Path $ROUTING_DIR "risk_patterns.yaml"
$ROUTING_RULE_FILE = Join-Path $ROUTING_DIR "skill_routing_rules.yaml"
$SOURCE_NEW        = Join-Path $RootDir "source-code\new"
$SOURCE_OLD        = Join-Path $RootDir "source-code\old"

# ------------------------------------------------------------
# ユーティリティ
# ------------------------------------------------------------
function Write-Log {
    param([string]$Level, [string]$Message)
    $ts = Get-Date -Format "HH:mm:ss"
    Write-Host "[$ts][$Level] $Message" -ForegroundColor $(
        switch ($Level) {
            "INFO" { "Cyan" } "OK" { "Green" } "WARN" { "Yellow" } "ERROR" { "Red" } default { "White" }
        }
    )
}

# ------------------------------------------------------------
# YAMLパーサ (簡易版 - キー: 値 形式のみ対応)
# 本番では powershell-yaml モジュール導入を推奨
# Install-Module -Name powershell-yaml
# ------------------------------------------------------------
function Read-SimpleYaml {
    param([string]$FilePath)
    if (-not (Test-Path $FilePath)) {
        Write-Log "WARN" "YAMLファイルが見つかりません: $FilePath"
        return @{}
    }
    $lines  = Get-Content $FilePath -Encoding UTF8
    $result = @{}
    $currentKey = $null
    $listBuffer = [System.Collections.Generic.List[string]]::new()

    foreach ($line in $lines) {
        if ($line -match '^\s*#' -or $line.Trim() -eq '') { continue }

        if ($line -match '^(\w[\w_]*):\s*$') {
            if ($currentKey -and $listBuffer.Count -gt 0) {
                $result[$currentKey] = $listBuffer.ToArray()
                $listBuffer.Clear()
            }
            $currentKey = $Matches[1]
        }
        elseif ($line -match '^(\w[\w_]*):\s*(.+)$') {
            $result[$Matches[1]] = $Matches[2].Trim()
        }
        elseif ($line -match '^\s+-\s+(.+)$' -and $currentKey) {
            $listBuffer.Add($Matches[1].Trim())
        }
    }
    if ($currentKey -and $listBuffer.Count -gt 0) {
        $result[$currentKey] = $listBuffer.ToArray()
    }
    return $result
}

# ------------------------------------------------------------
# ソースコード収集
# ------------------------------------------------------------
function Get-SourceContent {
    param([string]$Mode)

    $extensions = @("*.java", "*.cs", "*.sql", "*.sh", "*.bash",
                    "*.xml", "*.yaml", "*.yml", "*.properties", "*.json")
    $content = [System.Text.StringBuilder]::new()

    function Collect-Dir {
        param([string]$Dir, [string]$Label)
        if (-not (Test-Path $Dir)) { return }
        foreach ($ext in $extensions) {
            Get-ChildItem -Path $Dir -Filter $ext -Recurse -ErrorAction SilentlyContinue |
            ForEach-Object {
                $rel = $_.FullName.Replace($Dir, $Label)
                $null = $content.AppendLine("### [$rel]")
                $null = $content.AppendLine((Get-Content $_.FullName -Raw -Encoding UTF8))
                $null = $content.AppendLine()
            }
        }
    }

    Collect-Dir $SOURCE_NEW "[NEW]"
    if ($Mode -in @("diff-review", "diff-test")) {
        Collect-Dir $SOURCE_OLD "[OLD]"
    }

    return $content.ToString()
}

# ------------------------------------------------------------
# Risk-Based パターン検出
# risk_patterns.yaml の patterns セクションを使う
#
# risk_patterns.yaml 想定フォーマット:
#
# - id: transaction
#   patterns:
#     - "@Transactional"
#     - "BEGIN TRANSACTION"
#   agents:
#     - transaction_agent
#     - deadlock_analysis_agent
#   skills:
#     - transaction_skill
#     - deadlock_skill
#     - rollback_skill
#   tier: 1
# ------------------------------------------------------------
function Invoke-RiskPatternDetect {
    param([string]$SourceContent, [string]$Language)

    Write-Log "INFO" "risk_patterns.yaml を読み込み中..."

    if (-not (Test-Path $RISK_PATTERN_FILE)) {
        Write-Log "WARN" "risk_patterns.yaml が存在しないため、デフォルト検出を使用します"
        return Get-DefaultContext -Language $Language
    }

    $yamlText = Get-Content $RISK_PATTERN_FILE -Raw -Encoding UTF8

    # --- YAMLブロックを手動パース (- id: xxx 単位で分割) ---
    $detectedAgents = [System.Collections.Generic.List[string]]::new()
    $detectedSkills = [System.Collections.Generic.List[string]]::new()
    $maxTier = 1
    $matchedRules = [System.Collections.Generic.List[string]]::new()

    # ブロック分割: "- id:" で分割
    $blocks = $yamlText -split '(?m)^- id:' | Where-Object { $_.Trim() -ne '' }

    foreach ($block in $blocks) {
        $blockLines = $block -split "`n"

        # patterns 抽出
        $inPatterns = $false
        $patterns   = [System.Collections.Generic.List[string]]::new()
        $agents     = [System.Collections.Generic.List[string]]::new()
        $skills     = [System.Collections.Generic.List[string]]::new()
        $tier       = 1
        $ruleId     = $blockLines[0].Trim()
        $inAgents   = $false
        $inSkills   = $false

        foreach ($line in $blockLines) {
            if ($line -match '^\s+patterns:')        { $inPatterns = $true; $inAgents = $false; $inSkills = $false; continue }
            if ($line -match '^\s+agents:')          { $inAgents = $true; $inPatterns = $false; $inSkills = $false; continue }
            if ($line -match '^\s+skills:')          { $inSkills = $true; $inPatterns = $false; $inAgents = $false; continue }
            if ($line -match '^\s+tier:\s*(\d+)')    { $tier = [int]$Matches[1]; $inPatterns = $false; $inAgents = $false; $inSkills = $false; continue }
            if ($line -match '^\s+-\s+(.+)$') {
                # Strip surrounding YAML quotes so patterns compare against raw source.
                $val = $Matches[1].Trim().Trim('"').Trim("'")
                if ($inPatterns) { $patterns.Add($val) }
                if ($inAgents)   { $agents.Add($val) }
                if ($inSkills)   { $skills.Add($val) }
            }
        }

        # パターンマッチ (case-sensitive: パターンは実コードの正準表記で記述)
        $matched = $false
        foreach ($p in $patterns) {
            if ($SourceContent -cmatch [regex]::Escape($p)) {
                $matched = $true
                break
            }
        }

        if ($matched) {
            Write-Log "INFO" "  検出: [$ruleId] (Tier $tier)"
            $matchedRules.Add($ruleId)
            foreach ($a in $agents) {
                if ($detectedAgents -notcontains $a) { $detectedAgents.Add($a) }
            }
            foreach ($s in $skills) {
                if ($detectedSkills -notcontains $s) { $detectedSkills.Add($s) }
            }
            if ($tier -gt $maxTier) { $maxTier = $tier }
        }
    }

    # 言語ベースのAgent/Skillを必ず追加 (Language-Baseはベースライン)
    $baseContext = Get-BaseContext -Language $Language
    foreach ($a in $baseContext.Agents) {
        if ($detectedAgents -notcontains $a) { $detectedAgents.Insert(0, $a) }
    }
    foreach ($s in $baseContext.Skills) {
        if ($detectedSkills -notcontains $s) { $detectedSkills.Insert(0, $s) }
    }

    Write-Log "OK" "検出完了: $($matchedRules.Count) ルールマッチ, Tier=$maxTier"

    return @{
        Language     = $Language
        Mode         = $Mode
        Tier         = $maxTier
        MatchedRules = $matchedRules.ToArray()
        Agents       = $detectedAgents.ToArray()
        Skills       = $detectedSkills.ToArray()
    }
}

# ------------------------------------------------------------
# Tier適用: skill_routing_rules.yaml に基づき
# 最大Tier以下のSkillのみに絞り込む
# ------------------------------------------------------------
function Invoke-TierFilter {
    param([hashtable]$Context)

    if (-not (Test-Path $ROUTING_RULE_FILE)) {
        Write-Log "WARN" "skill_routing_rules.yaml が存在しないため、Tierフィルタをスキップします"
        return $Context
    }

    $yaml = Read-SimpleYaml $ROUTING_RULE_FILE

    # max_skill_count: Tier別最大Skill数
    $maxCount = if ($yaml.ContainsKey("max_skill_count_tier$($Context.Tier)")) {
        [int]$yaml["max_skill_count_tier$($Context.Tier)"]
    } else { 99 }

    if ($Context.Skills.Count -gt $maxCount) {
        Write-Log "WARN" "Skill数 $($Context.Skills.Count) が上限 $maxCount を超えています。切り詰めます"
        $Context.Skills = $Context.Skills[0..($maxCount - 1)]
    }

    return $Context
}

# ------------------------------------------------------------
# 言語ベースのAgent/Skill (必ずロードするベースライン)
# ------------------------------------------------------------
function Get-BaseContext {
    param([string]$Language)

    $map = @{
        java = @{
            Agents = @("java_architect_agent", "review_orchestrator_agent",
                       "security_architect_agent", "performance_architect_agent")
            Skills = @("java_skill", "spring_boot_skill", "security_skill", "performance_skill")
        }
        csharp = @{
            Agents = @("csharp_architect_agent", "review_orchestrator_agent",
                       "security_architect_agent", "performance_architect_agent")
            Skills = @("csharp_skill", "aspnet_skill", "security_skill", "performance_skill")
        }
        sql = @{
            Agents = @("sql_runtime_agent", "review_orchestrator_agent",
                       "query_analysis_agent", "security_architect_agent")
            Skills = @("sql_skill", "transaction_skill", "sql_injection_skill", "performance_skill")
        }
        linux = @{
            Agents = @("bash_agent", "review_orchestrator_agent",
                       "shell_security_agent", "docker_agent")
            Skills = @("bash_skill", "shell_security_skill", "security_skill", "docker_skill")
        }
    }

    if ($map.ContainsKey($Language)) { return $map[$Language] }
    return @{ Agents = @(); Skills = @() }
}

# ------------------------------------------------------------
# risk_patterns.yaml 未存在時のデフォルト
# ------------------------------------------------------------
function Get-DefaultContext {
    param([string]$Language)
    $base = Get-BaseContext -Language $Language
    return @{
        Language     = $Language
        Mode         = $Mode
        Tier         = 1
        MatchedRules = @()
        Agents       = $base.Agents
        Skills       = $base.Skills
    }
}

# ------------------------------------------------------------
# メイン
# ------------------------------------------------------------
try {
    Write-Log "INFO" "detect_context.ps1 開始"

    $source  = Get-SourceContent -Mode $Mode
    $srcLen  = $source.Length
    Write-Log "INFO" "ソースコード収集完了: $([math]::Round($srcLen/1KB,1)) KB"

    if ($srcLen -eq 0) {
        Write-Log "ERROR" "source-code/new にファイルが存在しません"
        exit 1
    }

    $context = Invoke-RiskPatternDetect -SourceContent $source -Language $Language
    $context = Invoke-TierFilter -Context $context

    # ソースコード本文もContextに含めてbuild_prompt.ps1へ渡す
    $context["SourceContent"] = $source

    # -OutputJson 指定時はファイルにも書き出す (review.ps1 はこのファイルを読む)
    if ($OutputJson) {
        $jsonObj = [ordered]@{
            Language      = $context.Language
            Mode          = $context.Mode
            Tier          = $context.Tier
            MatchedRules  = @($context.MatchedRules)
            Agents        = @($context.Agents)
            Skills        = @($context.Skills)
            SourceContent = $context.SourceContent
        }
        $outDir = Split-Path $OutputJson
        if ($outDir -and -not (Test-Path $outDir)) {
            New-Item -ItemType Directory -Path $outDir -Force | Out-Null
        }
        $jsonObj | ConvertTo-Json -Depth 10 -Compress | Out-File -FilePath $OutputJson -Encoding UTF8
        Write-Log "OK" "Context JSON saved: $OutputJson"
        Write-Log "OK" "detect_context.ps1 完了"
        exit 0
    }

    Write-Log "OK" "detect_context.ps1 完了"

    # hashtableをそのまま返す (呼び出し元で受け取る)
    return $context
}
catch {
    Write-Log "ERROR" "detect_context.ps1 エラー: $_"
    Write-Log "ERROR" $_.ScriptStackTrace
    exit 1
}