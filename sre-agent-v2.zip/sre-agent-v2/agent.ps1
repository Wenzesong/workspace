# エージェントメインエントリーポイント
param(
    [string]$SpecFile,
    [string]$RiskCheck
)

# スキルの読み込み
. "$PSScriptRoot\skills\Skill-ParseSpec.ps1"
. "$PSScriptRoot\skills\Skill-ReadFiles.ps1"
. "$PSScriptRoot\skills\Skill-Analyze.ps1"
. "$PSScriptRoot\skills\Skill-BuildPrompt.ps1"
. "$PSScriptRoot\skills\Skill-RiskCheck.ps1"
. "$PSScriptRoot\skills\Skill-Output.ps1"

function Agent-Run {
    # fix: 重複パラメータを削除。スクリプトスコープの変数を直接参照する
    try {
        if ($RiskCheck) {
            Write-Host "=== リスクチェックモード ===" -ForegroundColor Cyan

            # fix: ファイル存在チェックを追加
            if (-not (Test-Path $RiskCheck)) {
                throw "ファイルが見つかりません: $RiskCheck"
            }

            $code   = Get-Content $RiskCheck -Raw -Encoding UTF8
            $prompt = Skill-RiskCheck -Code $code
            Skill-Output -Prompt $prompt

        } elseif ($SpecFile) {
            Write-Host "=== コード生成モード ===" -ForegroundColor Cyan

            $spec       = Skill-ParseSpec  -SpecFile $SpecFile
            $references = Skill-ReadFiles  -Files $spec.ReferenceFiles
            $analysis   = Skill-Analyze    -References $references
            # fix: $references を Skill-BuildPrompt に渡すことで二重読み込みを解消
            $prompt     = Skill-BuildPrompt -Spec $spec -Analysis $analysis -References $references -Language $spec.Language

            Skill-Output -Prompt $prompt

        } else {
            Write-Host "使用方法：" -ForegroundColor Yellow
            Write-Host "  .\agent.ps1 -SpecFile 'specs/requirement.md'"
            Write-Host "  .\agent.ps1 -RiskCheck 'generated-code.sh'"
        }
    } catch {
        Write-Error "エージェント実行中にエラーが発生しました: $_"
        exit 1
    }
}

Agent-Run
