# MD要件ファイルを解析するスキル
function Skill-ParseSpec {
    param([string]$SpecFile)

    Write-Host "📄 要件ファイルを解析中..." -ForegroundColor Gray

    # fix: ファイル存在チェックを追加（Get-Content の例外より先に検証）
    if (-not (Test-Path $SpecFile)) {
        throw "要件ファイルが見つかりません: $SpecFile"
    }

    $content = Get-Content $SpecFile -Raw -Encoding UTF8
    $spec = @{
        Target         = ""
        Language       = "shell"
        Requirements   = @()
        ReferenceFiles = @()
    }

    # fix: Windows の CRLF (\r\n) にも対応するため \r?\n を使用
    if ($content -match '# 目標\s*\r?\n([\s\S]*?)(?=\r?\n#|$)') {
        $spec.Target = $Matches[1].Trim()
    }

    if ($content -match '# 言語\s*\r?\n([\s\S]*?)(?=\r?\n#|$)') {
        $spec.Language = $Matches[1].Trim()
    }

    if ($content -match '# 要件\s*\r?\n([\s\S]*?)(?=\r?\n#|$)') {
        $reqBlock = $Matches[1].Trim()
        # fix: 改行分割も \r?\n に対応
        $spec.Requirements = $reqBlock -split "`r?`n" |
            Where-Object { $_ -match "^-" } |
            ForEach-Object { $_.TrimStart("-").Trim() }
    }

    if ($content -match '# 参照ファイル\s*\r?\n([\s\S]*?)(?=\r?\n#|$)') {
        $refBlock = $Matches[1].Trim()
        $spec.ReferenceFiles = $refBlock -split "`r?`n" |
            Where-Object { $_ -match "^-" } |
            ForEach-Object { $_.TrimStart("-").Trim() }
    }

    Write-Host "✅ 解析完了" -ForegroundColor Green
    return $spec
}
