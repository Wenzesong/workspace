# リスク判断プロンプトを生成するスキル

# fix: 大量入力によるプロンプト肥大化を防ぐコードサイズ上限（50 KB）
$script:MaxCodeSizeBytes = 50 * 1024

function Skill-RiskCheck {
    param([string]$Code)

    Write-Host "⚠️ リスクチェックプロンプトを生成中..." -ForegroundColor Gray

    # fix: コードサイズの上限チェック
    $codeBytes = [System.Text.Encoding]::UTF8.GetByteCount($Code)
    if ($codeBytes -gt $script:MaxCodeSizeBytes) {
        $limitKB = $script:MaxCodeSizeBytes / 1024
        throw "コードが大きすぎます（${codeBytes} bytes）。上限は ${limitKB} KB です。ファイルを分割して再実行してください。"
    }

    # fix: コードをコードフェンスで囲む（プロンプトインジェクション対策）
    $fence = '```'
    $prompt = @"
あなたはセキュリティとコード品質の専門家です。
以下のスクリプトに対してリスク分析を行ってください。

## 分析対象コード
$fence
$Code
$fence

## 分析項目

1. **セキュリティリスク**
   - 権限の問題
   - 機密情報の露出
   - インジェクションの可能性

2. **ロジックリスク**
   - 境界条件の未処理
   - エラー処理の不足
   - 想定外の入力への対応

3. **パフォーマンスリスク**
   - 大量データ処理の問題
   - 無限ループの可能性
   - リソースリーク

4. **保守性リスク**
   - ハードコーディング
   - 命名の不明確さ
   - 複雑すぎるロジック

## 出力形式
各リスクを「高・中・低」で評価し、改善案も提示してください。
"@

    Write-Host "✅ リスクチェックプロンプト生成完了" -ForegroundColor Green
    return $prompt
}
