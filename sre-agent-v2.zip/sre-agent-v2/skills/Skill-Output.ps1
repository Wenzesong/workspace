# プロンプトを出力するスキル
function Skill-Output {
    param([string]$Prompt)

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Magenta
    # fix: "ChatGPT" → LLM 汎用の表現に変更
    Write-Host "   生成されたプロンプト（LLMにコピー）" -ForegroundColor Magenta
    Write-Host "========================================" -ForegroundColor Magenta
    Write-Host ""
    Write-Host $Prompt
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Magenta

    # fix: Set-Clipboard が使えない環境（SSH サーバー等）でも落ちないよう try/catch を追加
    try {
        $Prompt | Set-Clipboard
        Write-Host "✅ クリップボードにコピーしました" -ForegroundColor Green
    } catch {
        Write-Warning "クリップボードへのコピーに失敗しました（サーバー環境では未対応）: $_"
    }
}
