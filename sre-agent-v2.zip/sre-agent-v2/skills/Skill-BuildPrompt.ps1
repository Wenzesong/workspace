# プロンプトを組み立てるスキル

# fix: パストラバーサル対策として言語名の許可リストを定義
$script:AllowedLanguages = @("shell", "bash", "python", "powershell", "ruby", "perl")

function Skill-BuildPrompt {
    param(
        [hashtable]$Spec,
        [hashtable]$Analysis,
        # fix: Skill-ReadFiles の結果を受け取り、ファイルの二重読み込みを廃止
        [object]$References,
        [string]$Language
    )

    Write-Host "🔨 プロンプトを生成中..." -ForegroundColor Gray

    # fix: 言語名の許可リスト検証（パストラバーサル対策）
    if ($Language -notin $script:AllowedLanguages) {
        Write-Warning "許可されていない言語指定です: '$Language'。'shell' にフォールバックします。"
        $Language = "shell"
    }

    # テンプレート読み込み（Join-Path でパスを安全に結合）
    $templatePath = Join-Path $PSScriptRoot "..\templates\$Language.md"
    $template = ""
    if (Test-Path $templatePath) {
        $template = Get-Content $templatePath -Raw -Encoding UTF8
    }

    # fix: 参照コードをコードフェンスで囲む（プロンプトインジェクション対策）
    # fix: Skill-ReadFiles で取得済みの内容を再利用（二重読み込みを廃止）
    $fence = '```'
    $refContent = ""
    foreach ($ref in $References) {
        $refContent += "=== $($ref.FileName) ===`n${fence}`n$($ref.Content)`n${fence}`n`n"
    }

    # 要件の整形
    $reqList = ($Spec.Requirements | ForEach-Object { "- $_" }) -join "`n"

    $prompt = @"
あなたは $Language のスクリプト専門家です。

## 分析結果（参照ファイルより）
- 命名規則：$($Analysis.NamingStyle)
- エラー処理：$($Analysis.ErrorHandling)
- 構造：$($Analysis.Structure)

## 参照スクリプト
$refContent
## 新しいスクリプトの目標
$($Spec.Target)

## 要件
$reqList

## 追加指示
$template

## 出力ルール
- 参照スクリプトのスタイル・規則を踏襲すること
- コメントはすべて日本語で記述すること
- エラー処理を必ず実装すること
- コードのみを出力し、説明は不要です
"@

    Write-Host "✅ プロンプト生成完了" -ForegroundColor Green
    return $prompt
}
