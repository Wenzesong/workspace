# 参照ファイルを読み込むスキル
function Skill-ReadFiles {
    param([string[]]$Files)

    Write-Host "📂 参照ファイルを読み込み中..." -ForegroundColor Gray

    # fix: @() への += による O(n²) コピーを回避するため Generic List を使用
    $references = [System.Collections.Generic.List[hashtable]]::new()

    foreach ($file in $Files) {
        # fix: パストラバーサルの疑いがあるパスを拒否
        if ($file -match '\.\.') {
            Write-Warning "パストラバーサルの疑いがあるパスをスキップします: $file"
            continue
        }

        if (Test-Path $file) {
            $references.Add(@{
                FileName = $file
                Content  = Get-Content $file -Raw -Encoding UTF8
            })
            Write-Host "  ✅ $file" -ForegroundColor Green
        } else {
            Write-Warning "ファイルが見つかりません: $file"
        }
    }

    return $references
}
