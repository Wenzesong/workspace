# 参照ファイルのスタイルを分析するスキル
function Skill-Analyze {
    param([object]$References)

    Write-Host "🔍 スタイルを分析中..." -ForegroundColor Gray

    $analysis = @{
        NamingStyle   = "特定のパターンなし"
        ErrorHandling = "基本的なエラー処理"
        Structure     = "手続き型の構造"
    }

    # 参照ファイルが空の場合は分析をスキップ
    if (-not $References -or $References.Count -eq 0) {
        Write-Host "⚠️ 参照ファイルがないため分析をスキップします" -ForegroundColor Yellow
        return $analysis
    }

    $allContent = ($References | ForEach-Object { $_.Content }) -join "`n"

    # fix: 単語境界付きの正確な正規表現でカウントし、出現数の多い方を採用
    # （旧実装は snake_case を先にチェックするため camelCase を見落とす場合があった）
    $snakeCount = ([regex]::Matches($allContent, '\b[a-z]+(?:_[a-z]+)+\b')).Count
    $camelCount = ([regex]::Matches($allContent, '\b[a-z]+(?:[A-Z][a-z]+)+\b')).Count

    if ($snakeCount -gt 0 -and $snakeCount -ge $camelCount) {
        $analysis.NamingStyle = "スネークケース（snake_case）"
    } elseif ($camelCount -gt 0) {
        $analysis.NamingStyle = "キャメルケース（camelCase）"
    }

    # エラー処理の検出（より正確なパターンに改善）
    if ($allContent -match 'set\s+-[eo]|trap\s+|2>&1') {
        $analysis.ErrorHandling = "厳格なエラー処理あり"
    }

    # fix: 行頭の function 宣言のみ対象にしてコメント内のマッチを除外
    if ($allContent -match '(?m)^function\s+\w+') {
        $analysis.Structure = "関数ベースの構造"
    }

    Write-Host "✅ 分析完了" -ForegroundColor Green
    return $analysis
}
