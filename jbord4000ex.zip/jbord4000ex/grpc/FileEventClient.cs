// NuGet パッケージ（.NET Framework 4.5 以降対応）
// - Grpc.Core         2.46.x
// - Google.Protobuf   3.x
// - Grpc.Tools        2.46.x  ← ビルド時に file_event.proto からコードを自動生成

using System;
using System.Threading;
using System.Threading.Tasks;
using Grpc.Core;
using Jbord4000Ex.Grpc;

namespace YourApp
{
    /// <summary>
    /// Java gRPC サーバへの接続・イベント受信クラス。
    /// アプリ起動時に <see cref="StartAsync"/> を呼び出すと、
    /// Java サーバからのイベントをストリームで受け取り続ける。
    /// </summary>
    public class FileEventClient : IDisposable
    {
        private readonly Channel _channel;
        private readonly FileEventService.FileEventServiceClient _stub;

        /// <param name="javaServerHost">Java バッチサーバの IP またはホスト名</param>
        /// <param name="port">gRPC ポート番号（デフォルト: 50051）</param>
        public FileEventClient(string javaServerHost, int port = 50051)
        {
            // 社内 LAN での通信のため TLS なし（ChannelCredentials.Insecure）
            _channel = new Channel(javaServerHost, port, ChannelCredentials.Insecure);
            _stub    = new FileEventService.FileEventServiceClient(_channel);
        }

        /// <summary>
        /// Java gRPC サーバへ Subscribe し、イベントを受信し続ける。
        /// キャンセルされるまでループが継続する。
        /// </summary>
        public async Task StartAsync(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    var request = new SubscribeRequest
                    {
                        ClientId = Environment.MachineName
                    };

                    using (var call = _stub.Subscribe(request, cancellationToken: ct))
                    {
                        while (await call.ResponseStream.MoveNext(ct))
                        {
                            HandleEvent(call.ResponseStream.Current);
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    break; // 正常終了
                }
                catch (RpcException ex) when (ex.StatusCode == StatusCode.Unavailable)
                {
                    // Java サーバ未起動・ネットワーク断 → 5 秒後に再接続
                    await Task.Delay(5000, ct);
                }
            }
        }

        /// <summary>受信したイベントを種別ごとに振り分ける</summary>
        private void HandleEvent(FileEvent ev)
        {
            switch (ev.EventCase)
            {
                case FileEvent.EventOneofCase.ResponseFile:
                    OnResponseFileReceived(ev.ResponseFile);
                    break;

                case FileEvent.EventOneofCase.LeaveFile:
                    OnLeaveFileReceived(ev.LeaveFile);
                    break;

                case FileEvent.EventOneofCase.TradeFile:
                    OnTradeFileReceived(ev.TradeFile);
                    break;

                case FileEvent.EventOneofCase.UserNotify:
                    OnUserNotifyReceived(ev.UserNotify);
                    break;
            }
        }

        // ── イベントハンドラ ────────────────────────────────────────────────────
        // TODO: 各メソッド内に既存の画面更新ロジックを移植する

        private void OnResponseFileReceived(ResponseFileEvent ev)
        {
            // ev.ClordId, ev.OrdStatus を使って画面を更新
            // UI スレッド以外から呼ばれるため、WinForms は Invoke、WPF は Dispatcher.Invoke が必要
            // 例（WinForms）:
            // myForm.Invoke((Action)(() => UpdateResponseGrid(ev.ClordId, ev.OrdStatus)));
        }

        private void OnLeaveFileReceived(LeaveFileEvent ev)
        {
            // ev.OrderNumber, ev.ReservationStatus ... を使って画面を更新
        }

        private void OnTradeFileReceived(TradeFileEvent ev)
        {
            // ev.TradeId ... を使って画面を更新
        }

        private void OnUserNotifyReceived(UserNotifyEvent ev)
        {
            // ev.NotifyType, ev.Message を使って通知を表示
        }

        public void Dispose()
        {
            _channel.ShutdownAsync().Wait();
        }
    }
}
