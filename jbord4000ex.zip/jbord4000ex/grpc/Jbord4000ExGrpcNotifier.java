package jp.co.daiwa.jbord4000ex.grpc;

import java.time.format.DateTimeFormatter;
import java.util.concurrent.BlockingQueue;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TLeaveSttsMngBean;
import jp.co.daiwa.jbord4000ex.SambaWriteRequest;

/**
 * gRPC 通知ワーカー（{@link jp.co.daiwa.jbord4000ex.Jbord4000ExSambaWorker} の代替）
 *
 * <p>{@link BlockingQueue} から {@link SambaWriteRequest} を取り出し、
 * {@link FileEventServiceImpl#broadcast} で全接続クライアントへイベントを送信する。
 *
 * <p>終了制御・スレッド安全性は旧 SambaWorker と同一の Poison Pill パターンを踏襲する。
 */
public class Jbord4000ExGrpcNotifier implements Runnable {

    private static final DateTimeFormatter FILE_DATE_FORMAT =
        DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4000ExGrpcNotifier.class);

    private final BlockingQueue<SambaWriteRequest> queue;
    private final FileEventServiceImpl grpcService;

    public Jbord4000ExGrpcNotifier(BlockingQueue<SambaWriteRequest> queue,
                                    FileEventServiceImpl grpcService) {
        this.queue       = queue;
        this.grpcService = grpcService;
    }

    @Override
    public void run() {
        while (true) {
            try {
                SambaWriteRequest req = queue.take();

                if (req.isPoisonPill()) return;

                // 応答ファイル → ResponseFileEvent
                if (req.isWriteResponseFile()) {
                    grpcService.broadcast(FileEvent.newBuilder()
                        .setResponseFile(ResponseFileEvent.newBuilder()
                            .setClordId(req.getClordId())
                            .setOrdStatus(req.getOrdStatus()))
                        .build());
                }

                // リーブオーダー連携ファイル → LeaveFileEvent
                if (req.isWriteLeaveFile() && req.getLeaveSttsMngInfo() != null) {
                    grpcService.broadcast(
                        FileEvent.newBuilder()
                            .setLeaveFile(buildLeaveFileEvent(req.getLeaveSttsMngInfo()))
                            .build());
                }

                // 取引管理ファイル → TradeFileEvent
                // TODO: TTradeMngBean のフィールドが確定したら実装する
                if (req.isWriteTradeFile() && req.getTradeMngInfo() != null) {
                    grpcService.broadcast(FileEvent.newBuilder()
                        .setTradeFile(TradeFileEvent.newBuilder()
                            .setTradeId(req.getTradeMngInfo().toString()) // TODO: 適切なフィールドに修正
                            .build())
                        .build());
                }

                // ユーザ通知ファイル → UserNotifyEvent
                // TODO: UserNotificationDto のフィールドが確定したら実装する
                if (req.isWriteUserNotification() && req.getUserNotificationDto() != null) {
                    grpcService.broadcast(FileEvent.newBuilder()
                        .setUserNotify(UserNotifyEvent.newBuilder()
                            .setNotifyType("")  // TODO: UserNotificationDto から取得
                            .setMessage("")     // TODO: UserNotificationDto から取得
                            .build())
                        .build());
                }

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } catch (Exception e) {
                logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                    "MSG_J_W001", "Jbord4000ExGrpcNotifier", e);
            }
        }
    }

    private LeaveFileEvent buildLeaveFileEvent(TLeaveSttsMngBean bean) {
        return LeaveFileEvent.newBuilder()
            .setOrderNumber(bean.getOrderNumber().toString())
            .setReservationStatus(bean.getReservationStatus())
            .setDeadlineDatetimeDiv(bean.getDeadlineDatetimeDivision())
            .setDeadlineDatetime(FILE_DATE_FORMAT.format(
                bean.getDeadlineDatetime().toLocalDateTime()))
            .setLimitRate(bean.getLimitRate().toString())
            .setDeliveryDateDiv(bean.getDeliveryDateDivision())
            .setOrderDatetime(FILE_DATE_FORMAT.format(
                bean.getOrderDatetime().toLocalDateTime()))
            .setRegisterUser(bean.getRegisterUser())
            .setRegisterDatetime(FILE_DATE_FORMAT.format(
                bean.getRegisterDatetime().toLocalDateTime()))
            .setUpdateUser(bean.getUpdateUser())
            .setUpdateDatetime(FILE_DATE_FORMAT.format(
                bean.getUpdateDatetime().toLocalDateTime()))
            .build();
    }
}
