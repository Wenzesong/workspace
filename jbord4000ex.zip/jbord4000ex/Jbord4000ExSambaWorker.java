package jp.co.daiwa.jbord4000ex;

import java.io.IOException;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.FileUtil;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TLeaveSttsMngBean;
import jp.co.daiwa.jbord4000ex.SambaWriteRequest;

/**
 * Samba書込みワーカー
 *
 * <p>{@link BlockingQueue} からSamba書込み要求を取り出し、
 * 4種類のファイルを出力する {@link Runnable}。
 *
 * <p>【出力ファイル種別】
 * <ol>
 *   <li>取引管理ファイル（ブロッタ連携）：{@code tradeFilePath} へ出力</li>
 *   <li>応答ファイル（TSV）：ClOrdID・OrdStatusを出力。ファイル名にタイムスタンプ+連番付与</li>
 *   <li>リーブオーダー連携ファイル（TSV）：リーブオーダー情報一式を出力</li>
 *   <li>ユーザ通知ファイル：通知種別・メッセージを出力</li>
 * </ol>
 *
 * <p>【終了制御】
 * Poison Pillパターンを使用。{@link SambaWriteRequest#isPoisonPill()} が true の
 * 要求を受信したらループを終了する。
 * Poison Pillの投入数は {@link Jbord4000ExTasklet} がワーカースレッド数分行う。
 *
 * <p>【スレッド安全性】
 * {@link #RESPONSE_SEQ} は {@code static final AtomicLong} のため
 * 複数インスタンス間で一意なシーケンス番号を生成できる。
 *
 * <p>【パフォーマンス】
 * {@link DateTimeFormatter} は不変オブジェクトのため {@code static final} で共有する。
 * 旧実装の {@link java.text.SimpleDateFormat}（スレッドアンセーフ）は使用しない。
 *
 * <p>【インスタンス生成】
 * {@link Jbord4000ExTasklet} が Sambaワーカープール数分生成し、
 * スレッドプールに登録する。
 */
public class Jbord4000ExSambaWorker implements Runnable {

    /**
     * 応答ファイル名の一意性確保用シーケンス番号。
     * JVM内で単調増加。プロセス再起動でリセットされるが、
     * タイムスタンプ＋スレッドIDとの組み合わせで実用上一意となる。
     */
    private static final AtomicLong RESPONSE_SEQ = new AtomicLong(0L);

    /**
     * リーブオーダー連携ファイルの日時フォーマット。
     * スレッドセーフな {@link DateTimeFormatter} を使用。
     */
    private static final DateTimeFormatter FILE_DATE_FORMAT =
        DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4000ExSambaWorker.class);

    private final BlockingQueue<SambaWriteRequest> sambaQueue;
    private final String tradeFilePath;
    private final String cResFileName;
    private final String cResFilePath;
    private final String lvResFileName;
    private final String lvResFilePath;
    private final String userNotificationPath;

    public Jbord4000ExSambaWorker(
            BlockingQueue<SambaWriteRequest> sambaQueue,
            String tradeFilePath,
            String cResFileName,
            String cResFilePath,
            String lvResFileName,
            String lvResFilePath,
            String userNotificationPath) {
        this.sambaQueue          = sambaQueue;
        this.tradeFilePath       = tradeFilePath;
        this.cResFileName        = cResFileName;
        this.cResFilePath        = cResFilePath;
        this.lvResFileName       = lvResFileName;
        this.lvResFilePath       = lvResFilePath;
        this.userNotificationPath = userNotificationPath;
    }

    /**
     * キューからSamba書込み要求を取り出し、ファイルを順次書き込む。
     *
     * <p>Poison Pill 受信でループ終了。
     * ファイル書込み中の例外はWARNログを出力して次の要求の処理を継続する。
     */
    @Override
    public void run() {
        while (true) {
            try {
                SambaWriteRequest req = sambaQueue.take();

                // Poison Pill 受信 → ワーカー終了
                if (req.isPoisonPill()) return;

                // 取引管理ファイル（ブロッタ連携）
                if (req.isWriteTradeFile() && req.getTradeMngInfo() != null) {
                    FileUtil.writeTradeFile(tradeFilePath, req.getTradeMngInfo());
                }

                // クライアント用応答ファイル（TSV）
                if (req.isWriteResponseFile()) {
                    writeResponseFile(req);
                }

                // リーブオーダー連携ファイル（TSV）
                if (req.isWriteLeaveFile() && req.getLeaveSttsMngInfo() != null) {
                    writeLeaveTradeFile(req.getLeaveSttsMngInfo());
                }

                // ユーザ通知ファイル
                if (req.isWriteUserNotification() && req.getUserNotificationDto() != null) {
                    FileUtil.writeUserNotificationLogFile(
                        userNotificationPath, req.getUserNotificationDto());
                }

            } catch (InterruptedException e) {
                // スレッド割り込み → 安全に終了
                Thread.currentThread().interrupt();
                return;
            } catch (Exception e) {
                logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                    "MSG_J_W001", "Jbord4000ExSambaWorker", e);
                // ファイル書込み例外は業務継続（次の要求を処理）
            }
        }
    }

    /**
     * クライアント用応答ファイル（TSV）を出力する。
     *
     * <p>ファイル名は「プレフィックス + タイムスタンプ + "_" + スレッドID + "_" + 連番 + ".tsv"」
     * として一意性を確保する。
     *
     * <p>出力内容：ClOrdID（1列目）、OrdStatus（2列目）
     *
     * @param req 書込み要求
     * @throws IOException ファイル書込み失敗時
     */
    private void writeResponseFile(SambaWriteRequest req) throws IOException {
        String unique = System.currentTimeMillis()
            + "_" + Thread.currentThread().getId()
            + "_" + RESPONSE_SEQ.incrementAndGet();
        String filePath = Paths.get(cResFilePath,
            cResFileName + unique + ".tsv").toString();

        // 【パフォーマンス】List.of() でコピーなしの不変リストを生成
        List<List<String>> contents = List.of(
            List.of(req.getClordId(), req.getOrdStatus())
        );
        FileUtil.writeTsvFile(filePath, contents);
    }

    /**
     * リーブオーダー連携ファイル（TSV）を出力する。
     *
     * <p>ファイル名は「プレフィックス + 注文番号 + ".tsv"」。
     * 注文番号ごとに1ファイル生成する（上書き）。
     *
     * <p>出力フィールド（11列）：
     * 注文番号 / 予約ステータス / 期限日時区分 / 期限日時 / 指値 /
     * 受渡日区分 / 注文日時 / 登録ユーザ / 登録日時 / 更新ユーザ / 更新日時
     *
     * @param bean リーブオーダーステータス管理情報
     * @throws IOException ファイル書込み失敗時
     */
    private void writeLeaveTradeFile(TLeaveSttsMngBean bean) throws IOException {
        String orderNum  = bean.getOrderNumber().toString();
        String filePath  = Paths.get(lvResFilePath,
            lvResFileName + orderNum + ".tsv").toString();

        // 【パフォーマンス】List.of() でコピーなしの不変リストを生成
        List<String> row = List.of(
            orderNum,
            bean.getReservationStatus(),
            bean.getDeadlineDatetimeDivision(),
            FILE_DATE_FORMAT.format(
                bean.getDeadlineDatetime().toLocalDateTime()),
            bean.getLimitRate().toString(),
            bean.getDeliveryDateDivision(),
            FILE_DATE_FORMAT.format(
                bean.getOrderDatetime().toLocalDateTime()),
            bean.getRegisterUser(),
            FILE_DATE_FORMAT.format(
                bean.getRegisterDatetime().toLocalDateTime()),
            bean.getUpdateUser(),
            FILE_DATE_FORMAT.format(
                bean.getUpdateDatetime().toLocalDateTime())
        );
        FileUtil.writeTsvFile(filePath, List.of(row));
    }
}
