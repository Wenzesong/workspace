package jp.co.daiwa.jbord4000ex;

import jp.co.daiwa.dao.bean.TLeaveSttsMngBean;
import jp.co.daiwa.dao.bean.TTradeMngBean;
import jp.co.daiwa.dto.UserNotificationDto;

/**
 * Samba書込み要求DTO
 *
 * <p>電文処理スレッド（Jbord4000ExProcessWorker）が組み立て、
 * Samba書込みスレッド（Jbord4000ExSambaWorker）が消費する。
 *
 * <p>Poison Pillパターンで Worker の終了を通知する。
 * {@link #poisonPill()} で生成されたインスタンスを
 * キューに投入することで Worker ループを終了させる。
 *
 * <p>出力ファイル種別ごとに「書込みフラグ + データ」の組で管理する。
 * フラグが false の場合、対応するデータは参照しない。
 */
public class SambaWriteRequest {

    // ── Poison Pill ──────────────────────────────────────────────────────────

    /** Worker 終了指示フラグ（true のとき他フィールドは無効） */
    private boolean poisonPill;

    // ── 取引管理ファイル ──────────────────────────────────────────────────────

    /** 取引管理情報（ブロッタ連携ファイル出力用） */
    private TTradeMngBean tradeMngInfo;

    /** 取引管理ファイル書込みフラグ */
    private boolean writeTradeFile;

    // ── 応答ファイル ──────────────────────────────────────────────────────────

    /** ClOrdID（クライアント用応答ファイルの1列目） */
    private String clordId;

    /** 注文ステータス（クライアント用応答ファイルの2列目） */
    private String ordStatus;

    /** 応答ファイル書込みフラグ */
    private boolean writeResponseFile;

    // ── リーブオーダー連携ファイル ────────────────────────────────────────────

    /** リーブオーダーステータス管理情報（連携ファイル出力用） */
    private TLeaveSttsMngBean leaveSttsMngInfo;

    /** リーブオーダー連携ファイル書込みフラグ */
    private boolean writeLeaveFile;

    // ── ユーザ通知ファイル ────────────────────────────────────────────────────

    /** ユーザ通知情報 */
    private UserNotificationDto userNotificationDto;

    /** ユーザ通知ファイル書込みフラグ */
    private boolean writeUserNotification;

    // ── ファクトリメソッド ────────────────────────────────────────────────────

    /**
     * Poison Pill インスタンスを生成する。
     * Worker スレッドへの終了シグナルとしてキューに投入する。
     *
     * @return Poison Pill フラグが true のインスタンス
     */
    public static SambaWriteRequest poisonPill() {
        SambaWriteRequest req = new SambaWriteRequest();
        req.poisonPill = true;
        return req;
    }

    // ── 判定メソッド ──────────────────────────────────────────────────────────

    /**
     * 何らかの書込み要求を持つか判定する。
     * 書込みフラグが1つも true でない場合はキュー投入不要。
     *
     * @return true：出力対象あり
     */
    public boolean hasAnyWriteRequest() {
        return writeTradeFile || writeResponseFile
            || writeLeaveFile || writeUserNotification;
    }

    // ── Getter / Setter ───────────────────────────────────────────────────────

    public boolean isPoisonPill()                    { return poisonPill; }
    public void    setPoisonPill(boolean v)          { this.poisonPill = v; }

    public TTradeMngBean getTradeMngInfo()            { return tradeMngInfo; }
    public void setTradeMngInfo(TTradeMngBean v)      { this.tradeMngInfo = v; }

    public boolean isWriteTradeFile()                { return writeTradeFile; }
    public void    setWriteTradeFile(boolean v)      { this.writeTradeFile = v; }

    public String getClordId()                       { return clordId; }
    public void   setClordId(String v)               { this.clordId = v; }

    public String getOrdStatus()                     { return ordStatus; }
    public void   setOrdStatus(String v)             { this.ordStatus = v; }

    public boolean isWriteResponseFile()             { return writeResponseFile; }
    public void    setWriteResponseFile(boolean v)   { this.writeResponseFile = v; }

    public TLeaveSttsMngBean getLeaveSttsMngInfo()         { return leaveSttsMngInfo; }
    public void setLeaveSttsMngInfo(TLeaveSttsMngBean v)   { this.leaveSttsMngInfo = v; }

    public boolean isWriteLeaveFile()                { return writeLeaveFile; }
    public void    setWriteLeaveFile(boolean v)      { this.writeLeaveFile = v; }

    public UserNotificationDto getUserNotificationDto()       { return userNotificationDto; }
    public void setUserNotificationDto(UserNotificationDto v) { this.userNotificationDto = v; }

    public boolean isWriteUserNotification()         { return writeUserNotification; }
    public void    setWriteUserNotification(boolean v) { this.writeUserNotification = v; }
}
