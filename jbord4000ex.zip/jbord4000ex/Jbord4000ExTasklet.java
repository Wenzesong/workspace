package jp.co.daiwa.jbord4000ex;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.FxdEnum.WriterResult;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dto.fix.ExecutionReport;

/**
 * 応答電文取込処理 Tasklet（JBORD4000EX）
 *
 * <p>旧 JBORD2000・JBORD3000 を統合した応答電文取込処理の改善版。
 * Spring Batch の Tasklet として動作し、FIX 応答電文の受信から
 * DB 更新・Samba ファイル書込みまでの一連の処理を制御する。
 *
 * <p>【全体フロー】
 * <pre>
 *   while(ストップファイルなし) {
 *     1. 受電文ファイルを読み込み ExecutionReport に変換
 *     2. SambaWorkerPool（非同期）を起動
 *     3. MessageWorkerPool（並列）で DB 更新 → Samba キューに投入
 *     4. 全 MessageWorker 完了後に Poison Pill を投入して SambaWorker を終了
 *     5. SambaWorker の終了を待機
 *     6. スリープ後に次サイクルへ
 *   }
 * </pre>
 *
 * <p>【DB更新と Samba 書込みの分離】
 * DB 更新（同期・トランザクション）と Samba ファイル書込み（非同期・I/O）を
 * 別スレッドプールで分離することで、Samba ネットワーク遅延が
 * DB 処理スループットに影響しない設計とした。
 *
 * <p>【例外ハンドリング方針】
 * <ul>
 *   <li>DB接続例外：ジョブループを停止する</li>
 *   <li>その他の例外：WARNログ記録＋WARNステータス設定で処理継続</li>
 * </ul>
 *
 * <p>【バージョン情報】
 * 20240917 機能統括（元JBORD2000、元JBORD3000）
 */
@Component
@Scope("step")
public class Jbord4000ExTasklet implements Tasklet {

    // ── ジョブ制御パラメータ ───────────────────────────────────────────────────

    /** ジョブ停止ファイルパス（このファイルが存在するとジョブを正常終了） */
    @Value("${job.jbord4000.stop.file}")
    private String defStopFile;

    /** ポーリング間隔（ミリ秒） */
    @Value("${job.jbord4000.sleep.ms}")
    private Integer sleepMs;

    /** 電文処理ワーカースレッド数（並列DB更新数） */
    @Value("${job.jbord4000.message.worker.size}")
    private Integer messageWorkerSize;

    /** Samba書込みワーカースレッド数 */
    @Value("${job.jbord4000.samba.worker.size}")
    private Integer sambaWorkerSize;

    /** Sambaワーカー終了待ち時間（秒）。タイムアウト時はWARNログを出力する */
    @Value("${job.jbord4000.samba.await.seconds}")
    private Long sambaAwaitSeconds;

    // ── Samba書込み用ファイルパス・ファイル名 ────────────────────────────────

    /** ブロッタ連携ファイルディレクトリ */
    @Value("${trademng.file.path}")
    private String tradeFilePath;

    /** クライアント用応答ファイル名プレフィックス */
    @Value("${resorder.client.file}")
    private String cResFileName;

    /** クライアント用応答ファイルディレクトリ */
    @Value("${resorder.client.file.path}")
    private String cResFilePath;

    /** クライアント用リーブオーダー連携ファイル名プレフィックス */
    @Value("${resorder.leave.file}")
    private String lvResFileName;

    /** クライアント用リーブオーダー連携ファイルディレクトリ */
    @Value("${resorder.leave.file.path}")
    private String lvResFilePath;

    /** ユーザ通知ファイルディレクトリ */
    @Value("${usernotification.file.path}")
    private String userNotificationPath;

    // ── DI ───────────────────────────────────────────────────────────────────

    /** 受電文ファイル読込・FIX電文解析 */
    @Inject
    private Jbord4000ExFileReader fileReader;

    /** DB更新サービス */
    @Inject
    private Jbord4000ExDbService dbService;

    /** 変換・補正・通知生成サービス */
    @Inject
    private Jbord4000ExHelper helper;

    /** トランザクションマネージャー（電文処理スレッドに渡す） */
    @Inject
    @Named("jobTransactionManager")
    private PlatformTransactionManager transactionManager;

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4000ExTasklet.class);

    // ════════════════════════════════════════════════════════════════════════
    // メインループ
    // ════════════════════════════════════════════════════════════════════════

    /**
     * ジョブメインループ。
     *
     * <p>ストップファイルが存在するまで以下を繰り返す：
     * <ol>
     *   <li>ストップファイル確認</li>
     *   <li>電文ファイル処理サイクル</li>
     *   <li>スリープ</li>
     * </ol>
     *
     * @param contribution Step実行状態
     * @param chunkContext  チャンクコンテキスト（未使用）
     * @return {@link RepeatStatus#FINISHED}
     */
    @Override
    public RepeatStatus execute(StepContribution contribution,
                                ChunkContext chunkContext) throws Exception {
        Path stopFilePath = Paths.get(defStopFile);

        while (true) {
            // ストップファイルが存在する場合、削除してジョブ終了
            if (Files.exists(stopFilePath)) {
                deleteStopFile(stopFilePath, contribution);
                break;
            }

            try {
                processMessages(contribution);
                Thread.sleep(sleepMs);

            } catch (Exception e) {
                if (isDbException(e)) {
                    // DB接続例外はジョブループを停止する
                    logger.error(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                        "MSG_J_E001", "DB接続", e);
                    break;
                }
                // その他の例外はWARNログを出力してループ継続
                Thread.sleep(sleepMs);
            }
        }
        return RepeatStatus.FINISHED;
    }

    // ════════════════════════════════════════════════════════════════════════
    // 1サイクルの電文処理
    // ════════════════════════════════════════════════════════════════════════

    /**
     * 1サイクルの電文ファイル処理を実行する。
     *
     * <p>処理対象ファイルがない場合はすぐに返る。
     *
     * @param contribution Step実行状態
     * @throws Exception DB接続例外（呼び出し元でジョブ停止判定）
     */
    private void processMessages(StepContribution contribution) throws Exception {

        // ① 受電文ファイルを読み込み、FIX電文を解析する
        List<ExecutionReport> reports = fileReader.readAll(contribution);
        if (reports.isEmpty()) return;

        // ② 中間コミット用トランザクション定義（電文ごとに独立したトランザクション）
        DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
        definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);

        // ③ SambaWorkerPool を起動（非同期ファイル書込み）
        BlockingQueue<SambaWriteRequest> sambaQueue = new LinkedBlockingQueue<>();
        ExecutorService sambaExec = startSambaWorkers(sambaQueue);

        // ④ MessageWorkerPool で電文を並列処理（DB更新）
        ExecutorService msgExec = Executors.newFixedThreadPool(messageWorkerSize);
        List<Future<WriterResult>> futures = new ArrayList<>(reports.size());

        try {
            for (ExecutionReport report : reports) {
                futures.add(msgExec.submit(new Jbord4000ExProcessWorker(
                    report, sambaQueue, dbService, helper,
                    transactionManager, definition)));
            }
            collectResults(futures, contribution);

        } catch (Exception e) {
            if (isDbException(e)) throw e;
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "電文ファイル取込スレッド", e);
            setWarnStatus(contribution);

        } finally {
            // ⑤ MessageWorkerPool を終了し、Poison Pill で SambaWorker を終了させる
            msgExec.shutdown();
            sendPoisonPills(sambaQueue);
            sambaExec.shutdown();

            // ⑥ SambaWorker の終了を最大 sambaAwaitSeconds 秒待機
            boolean terminated = sambaExec.awaitTermination(
                sambaAwaitSeconds, TimeUnit.SECONDS);
            if (!terminated) {
                logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                    "MSG_J_W001", "SambaWorker終了待ちタイムアウト", null);
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // プライベートメソッド
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Samba書込みワーカープールを起動する。
     * ワーカーはキューから要求を取り出し、ファイルを書き込む。
     */
    private ExecutorService startSambaWorkers(BlockingQueue<SambaWriteRequest> queue) {
        ExecutorService exec = Executors.newFixedThreadPool(sambaWorkerSize);
        for (int i = 0; i < sambaWorkerSize; i++) {
            exec.submit(new Jbord4000ExSambaWorker(
                queue, tradeFilePath,
                cResFileName, cResFilePath,
                lvResFileName, lvResFilePath,
                userNotificationPath));
        }
        return exec;
    }

    /**
     * ワーカースレッド数分の Poison Pill をキューに投入する。
     * 各ワーカーが1つ受信したらループを終了する。
     */
    private void sendPoisonPills(BlockingQueue<SambaWriteRequest> queue)
            throws InterruptedException {
        for (int i = 0; i < sambaWorkerSize; i++) {
            queue.put(SambaWriteRequest.poisonPill());
        }
    }

    /**
     * 全 MessageWorker の処理結果を収集し、
     * FAILED が含まれる場合はWARNステータスを設定する。
     */
    private void collectResults(List<Future<WriterResult>> futures,
                                 StepContribution contribution) throws Exception {
        for (Future<WriterResult> future : futures) {
            if (WriterResult.FAILED.equals(future.get())) {
                setWarnStatus(contribution);
            }
        }
    }

    /**
     * ストップファイルを削除してジョブ正常終了を記録する。
     * 削除失敗の場合はWARNログを出力してジョブは終了する（処理は続行しない）。
     */
    private void deleteStopFile(Path path, StepContribution contribution) {
        try {
            Files.deleteIfExists(path);
            logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_1001", defStopFile);
        } catch (IOException e) {
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "ストップファイル削除失敗", e);
            setWarnStatus(contribution);
        }
    }

    /** Job実行コンテキストにWARNステータスを設定する */
    private void setWarnStatus(StepContribution contribution) {
        contribution.getStepExecution().getJobExecution()
            .getExecutionContext()
            .put(FxdConstants.CONTEXT_K_JOB_STATUS,
                 FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }

    /** DB接続例外か否かを判定する */
    private boolean isDbException(Exception e) {
        return e.getMessage() != null
            && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION);
    }
}
