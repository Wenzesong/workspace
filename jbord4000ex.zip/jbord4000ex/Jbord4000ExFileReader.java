package jp.co.daiwa.jbord4000ex;

import java.io.File;
import java.io.FileFilter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.StepContribution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.TargetFileFilter;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.common.parser.FixMsgParserEx;
import jp.co.daiwa.dto.fix.ExecutionReport;

/**
 * FIX電文ファイル読込クラス
 *
 * <p>指定ディレクトリの受電文ファイルを読み込み、FIX電文を解析して
 * {@link ExecutionReport} のリストとして返す。
 *
 * <p>ファイルはファイル名順（昇順）で処理し、
 * 処理済みファイルは削除する。
 * 解析失敗ファイルは ERR_ プレフィックスを付けて同ディレクトリに退避する。
 *
 * <p>【パフォーマンス】
 * FIX電文パーサー（{@link FixMsgParserEx}）はスレッドアンセーフのため
 * ファイルごとに新規生成する。fixTagMap はインジェクション済みの
 * Map を共有参照する（読み取り専用のため安全）。
 */
@Component
public class Jbord4000ExFileReader {

    /** 受電文ファイルディレクトリ */
    @Value("${job.jbord4000.output.path2}")
    private String inputFilePath;

    /** 受電文ファイル名プレフィックス（絞り込みに使用） */
    @Value("${job.jbord4000.res.output.file.name}")
    private String inputFileNamePrefix;

    /** FIX電文区切り文字 */
    @Value("${fix.msg.delimiter}")
    private String delimiter;

    /** FIX電文タグ情報（タグ番号→フィールド名マッピング） */
    @Value("#{${fix.tag}}")
    private Map<String, String> fixTagMap;

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4000ExFileReader.class);

    /**
     * 受電文ファイルを全件読み込み、解析済み電文リストを返す。
     *
     * <p>対象ファイルが存在しない場合は空リストを返す。
     * 解析エラーのファイルはスキップし、処理を継続する。
     *
     * @param contribution Stepの実行状態（WARN設定に使用）
     * @return 解析済み {@link ExecutionReport} のリスト（ファイル名昇順）
     */
    public List<ExecutionReport> readAll(StepContribution contribution) {

        // 対象ファイル一覧取得
        FileFilter filter = new TargetFileFilter(inputFileNamePrefix, "*");
        File[] files = new File(inputFilePath).listFiles(filter);

        if (files == null || files.length == 0) {
            return Collections.emptyList();
        }

        // ファイル名昇順ソート（電文の到着順序を保証）
        Arrays.sort(files);

        List<ExecutionReport> reports = new ArrayList<>(files.length);

        for (File file : files) {
            ExecutionReport report = parseOneFile(file.toPath(), contribution);
            if (report != null) {
                reports.add(report);
                // 解析済みファイルを削除（次サイクルで重複処理しないため）
                try {
                    Files.deleteIfExists(file.toPath());
                } catch (Exception e) {
                    // 削除失敗は次サイクルで再処理されるが業務継続は可能
                    logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                        "MSG_J_W001", "ファイル削除失敗: " + file.getName(), e);
                }
            }
        }
        return reports;
    }

    /**
     * 電文ファイル1件を解析し {@link ExecutionReport} に変換する。
     *
     * <p>TransactTime はFIXテキスト先頭17文字（UTCタイムスタンプ形式）で上書きする。
     * これはパーサーが17文字より長い形式で返す場合の補正処理。
     *
     * @param filePath 電文ファイルパス
     * @param contribution Stepの実行状態
     * @return 解析成功時は {@link ExecutionReport}、失敗時は null
     */
    private ExecutionReport parseOneFile(Path filePath,
                                          StepContribution contribution) {
        try {
            String fixMsgText = Files.readString(filePath);
            FixMsgParserEx parser = new FixMsgParserEx(delimiter, fixTagMap);
            parser.parse(fixMsgText);
            ExecutionReport report = parser.extractData(ExecutionReport.class);

            // TransactTimeはFIXテキスト先頭17文字（"yyyyMMdd-HH:mm:ss"形式）
            if (report.getTransactTime() != null && fixMsgText.length() >= 17) {
                report.setTransactTime(fixMsgText.substring(0, 17));
            }
            return report;

        } catch (Exception e) {
            // パース失敗ファイルをエラーディレクトリへ退避
            moveToErrorDirectory(filePath);
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W002", "parseOneFile",
                FxdConstants.ERR_PREFIX + filePath.getFileName(), e);
            setWarnStatus(contribution);
            return null;
        }
    }

    /**
     * パース失敗ファイルを ERR_ プレフィックス付きで同ディレクトリに退避する。
     *
     * @param filePath 退避対象ファイルパス
     */
    private void moveToErrorDirectory(Path filePath) {
        Path dest = Paths.get(inputFilePath,
            FxdConstants.ERR_PREFIX + filePath.getFileName());
        try {
            Files.move(filePath, dest, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            // 退避失敗は警告ログのみ（元ファイルは次サイクルで再処理）
            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "エラーファイル退避失敗: " + filePath.getFileName(), e);
        }
    }

    /** Job実行コンテキストにWARNステータスを設定する */
    private void setWarnStatus(StepContribution contribution) {
        contribution.getStepExecution().getJobExecution()
            .getExecutionContext()
            .put(FxdConstants.CONTEXT_K_JOB_STATUS,
                 FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}
