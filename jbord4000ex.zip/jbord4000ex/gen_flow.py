"""JBORD4000EX 処理フロー Excel 生成スクリプト"""

from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

def thin_border():
    s = Side(style="thin", color="999999")
    return Border(left=s, right=s, top=s, bottom=s)

def header_fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def cell_style(ws, row, col, value,
               bold=False, bg=None, align="left",
               font_size=10, font_color="000000", wrap=False):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(bold=bold, size=font_size, color=font_color)
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    c.border = thin_border()
    if bg:
        c.fill = header_fill(bg)
    return c

def merge_and_style(ws, row, col_start, col_end, value,
                    bold=False, bg=None, align="center",
                    font_size=10, font_color="000000"):
    ws.merge_cells(
        start_row=row, start_column=col_start,
        end_row=row, end_column=col_end
    )
    c = ws.cell(row=row, column=col_start, value=value)
    c.font = Font(bold=bold, size=font_size, color=font_color)
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=True)
    c.border = thin_border()
    if bg:
        c.fill = header_fill(bg)
    return c

C_TITLE    = "1F4E79"
C_H1       = "2E75B6"
C_H2       = "5B9BD5"
C_STEP     = "DDEEFF"
C_BRANCH   = "FFF2CC"
C_ERROR    = "FCE4D6"
C_END      = "E2EFDA"
C_PARALLEL = "EAD1DC"
C_DB       = "D9E1F2"
C_FILE     = "E2EFDA"

# ── Sheet 1: 全体処理フロー ───────────────────────────────────────────────────

def build_sheet1(wb):
    ws = wb.active
    ws.title = "全体処理フロー"
    ws.sheet_view.showGridLines = False

    for i, w in enumerate([4, 22, 40, 22, 18], 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    r = 1
    merge_and_style(ws, r, 1, 5,
        "JBORD4000EX　応答電文取込処理　全体処理フロー",
        bold=True, bg=C_TITLE, font_size=14, font_color="FFFFFF")
    ws.row_dimensions[r].height = 30
    r += 1

    merge_and_style(ws, r, 1, 5,
        "旧JBORD2000・JBORD3000を統合した応答電文取込処理（Spring Batch Tasklet）",
        bg="BDD7EE", font_size=10)
    ws.row_dimensions[r].height = 18
    r += 2

    merge_and_style(ws, r, 1, 5, "【凡例】", bold=True, bg=C_H1, font_color="FFFFFF")
    r += 1
    for bg, label in [
        (C_STEP,     "通常処理ステップ"),
        (C_BRANCH,   "条件分岐・判定"),
        (C_PARALLEL, "並列処理"),
        (C_DB,       "DB処理（トランザクション）"),
        (C_FILE,     "ファイルI/O"),
        (C_ERROR,    "例外処理"),
        (C_END,      "正常終了"),
    ]:
        cell_style(ws, r, 2, "　" + label, bg=bg)
        for col in [1, 3, 4, 5]:
            ws.cell(row=r, column=col).border = thin_border()
        r += 1
    r += 1

    for col, h in enumerate(["No.", "処理段階", "処理内容・説明", "担当クラス", "備考"], 1):
        cell_style(ws, r, col, h, bold=True, bg=C_H1, align="center", font_color="FFFFFF")
    ws.row_dimensions[r].height = 20
    r += 1

    rows = [
        ("─", "【START】",
         "Spring Batch Step起動 → Tasklet.execute() 呼び出し",
         "Jbord4000ExTasklet", "", C_H2),
        ("1", "ストップファイル確認",
         "設定パス（job.jbord4000.stop.file）のファイル存在を確認\n存在する場合 → ファイルを削除して正常終了",
         "Jbord4000ExTasklet\n#execute()", "Files.exists(stopFilePath)", C_BRANCH),
        ("↓", "ストップファイルなし",
         "処理サイクル（processMessages）を実行する",
         "", "", C_STEP),
        ("2", "電文ファイル読込",
         "①  受電文ディレクトリのファイルを取得\n②  ファイル名昇順ソート（到着順序の保証）\n"
         "③  FIXパーサーで1ファイルずつ解析 → ExecutionReport に変換\n"
         "④  解析済みファイルを削除\n⑤  解析失敗ファイルは ERR_ プレフィックス付きで退避",
         "Jbord4000ExFileReader\n#readAll()", "対象なし → 即リターン", C_FILE),
        ("3", "SambaWorkerPool 起動（非同期）",
         "BlockingQueue を生成し、SambaWorker を sambaWorkerSize スレッド分起動\nキューへの書込み要求を非同期でファイル出力する",
         "Jbord4000ExTasklet\n#startSambaWorkers()", "Poison Pillパターン", C_PARALLEL),
        ("4", "MessageWorkerPool 起動（並列）",
         "messageWorkerSize スレッドのプールを生成\n電文ごとに Jbord4000ExProcessWorker を submit() して並列実行",
         "Jbord4000ExTasklet\n#processMessages()", "→ Sheet「電文処理ワーカー詳細」参照", C_PARALLEL),
        ("5", "全MessageWorker 完了待機",
         "全 Future.get() で結果を収集\nFAILED が含まれる場合 → JobContext に WARN ステータスを設定",
         "Jbord4000ExTasklet\n#collectResults()", "", C_STEP),
        ("6", "Poison Pill 投入",
         "sambaWorkerSize 分の Poison Pill を BlockingQueue に put()\n各 SambaWorker が1つ受信するとループを終了する",
         "Jbord4000ExTasklet\n#sendPoisonPills()", "", C_STEP),
        ("7", "SambaWorker 終了待機",
         "sambaExec.awaitTermination(sambaAwaitSeconds) で完了を待機\nタイムアウト時は WARN ログを出力して次サイクルへ",
         "Jbord4000ExTasklet\n#processMessages()", "待機秒数は設定値", C_STEP),
        ("8", "スリープ → ループ継続",
         "sleepMs ミリ秒スリープ後、ストップファイル確認（手順1）へ戻る\n例外発生時も同様にスリープしてループ継続",
         "Jbord4000ExTasklet\n#execute()", "", C_STEP),
        ("Ex1", "DB接続例外",
         "例外メッセージに DB_IO_EXCEPTION キーワードが含まれる場合\n→ ERROR ログを出力してジョブループを停止する",
         "Jbord4000ExTasklet", "ループ脱出 → FINISHED", C_ERROR),
        ("Ex2", "その他の例外",
         "WARN ログを出力 → sleepMs スリープ → ループ継続",
         "Jbord4000ExTasklet", "業務継続", C_ERROR),
        ("─", "【END】",
         "RepeatStatus.FINISHED を返して Spring Batch Step を正常終了",
         "Jbord4000ExTasklet", "", C_END),
    ]

    for no, stage, desc, cls, note, bg in rows:
        cell_style(ws, r, 1, no,    align="center", bg=bg)
        cell_style(ws, r, 2, stage, bold=(no == "─"), bg=bg, wrap=True)
        cell_style(ws, r, 3, desc,  bg=bg, wrap=True)
        cell_style(ws, r, 4, cls,   bg=bg, wrap=True, align="center")
        cell_style(ws, r, 5, note,  bg=bg, wrap=True, font_size=9)
        ws.row_dimensions[r].height = 60 if "\n" in desc else 30
        r += 1

    ws.freeze_panes = "A14"


# ── Sheet 2: 電文処理ワーカー詳細 ─────────────────────────────────────────────

def build_sheet2(wb):
    ws = wb.create_sheet("電文処理ワーカー詳細")
    ws.sheet_view.showGridLines = False

    for i, w in enumerate([4, 26, 44, 24, 20], 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    r = 1
    merge_and_style(ws, r, 1, 5,
        "JBORD4000EX　電文処理ワーカー（Jbord4000ExProcessWorker）詳細フロー",
        bold=True, bg=C_TITLE, font_size=13, font_color="FFFFFF")
    ws.row_dimensions[r].height = 28
    r += 1
    merge_and_style(ws, r, 1, 5,
        "FIX応答電文1件を処理する Callable。Jbord4000ExTasklet が電文ごとに new で生成し、スレッドプールに submit する。",
        bg="BDD7EE", font_size=9)
    ws.row_dimensions[r].height = 18
    r += 2

    for col, h in enumerate(["No.", "処理段階", "処理内容・説明", "担当メソッド", "備考"], 1):
        cell_style(ws, r, col, h, bold=True, bg=C_H1, align="center", font_color="FFFFFF")
    ws.row_dimensions[r].height = 20
    r += 1

    rows = [
        ("─", "【initialize フェーズ】",
         "Jbord4000ExDbService#initialize() を呼び出す",
         "DbService#initialize()", "", C_H2),
        ("1", "発注履歴存在確認",
         "ClOrdIDから注文番号を抽出（ハイフン区切り第3セグメント）\n"
         "TTradeopeHistoryRepository.getRplyOrdNumber(ordNm) で発注履歴を確認\n"
         "→ null の場合：注文未存在通知（種別28）を生成してキュー投入し終了",
         "DbService#initialize()", "発注が先行していることの検証", C_BRANCH),
        ("2", "取引管理情報取得",
         "TTradeMngRepository.findMaxRevision(ordNm) で最新改版を取得\n"
         "→ null の場合：WARN ログのみ → Optional.empty() を返す（処理スキップ）",
         "DbService#initialize()", "取引管理テーブル参照", C_DB),
        ("3", "リーブオーダー情報取得",
         "ClOrdIDに CLORD_LV または CLORD_LV_CANCEL が含まれる場合のみ\n"
         "TLeaveSttsMngRepository.searchLeaveSttsInfo() でリーブオーダー情報を取得",
         "DbService#initialize()", "リーブオーダーのみ実行", C_DB),
        ("4", "OrderContext 生成",
         "注文番号・取引管理情報・リーブオーダー情報を OrderContext に格納して返す",
         "DbService.OrderContext", "スレッドごとに独立したコンテキスト", C_STEP),
        ("─", "【updateTrade フェーズ】",
         "Jbord4000ExDbService#updateTrade() を呼び出す",
         "DbService#updateTrade()", "", C_H2),
        ("5", "FIXステータス変換",
         "Helper#resolveOrderStatus(OrdStatus) で FIX コードを内部ステータスに変換\n"
         "  \"0\" → ORDER（注文受付）\n"
         "  \"2\" → CONTRACTED（約定）\n"
         "  \"3\",\"4\",\"8\",\"C\" → ORDER_CANCEL（取消）\n"
         "  その他 → null → updateTrade スキップ",
         "Helper#resolveOrderStatus()", "null の場合は更新不要", C_BRANCH),
        ("6", "約定済み重複チェック",
         "新ステータスが CONTRACTED かつ 既存ステータスも CONTRACTED の場合\n→ 重複約定を防止するためスキップして返る",
         "DbService#updateTrade()", "冪等性の確保", C_BRANCH),
        ("7", "スポット約定時の受渡日更新",
         "ClOrdIDの第2セグメントが \"1\"（現物）または \"C\"（通貨）\n"
         "かつ リーブオーダー情報の受渡日区分が SPOT\n"
         "かつ 新ステータスが CONTRACTED の場合のみ\n"
         "→ FIX SettlDate を受渡日として tradeMngInfo にセット",
         "DbService#updateTrade()", "スポット取引の特殊処理", C_BRANCH),
        ("8", "取引管理テーブル更新\n（REQUIRES_NEW TX）",
         "更新値をセット：注文ステータス・取引日時・更新ユーザ・更新日時\n"
         "取消（ORDER_CANCEL）の場合は論理削除フラグを立てる\n"
         "→ PROPAGATION_REQUIRES_NEW で独立トランザクション開始\n"
         "→ TTradeMngRepository.updateStatus(tradeMngInfo)\n"
         "→ TTradeopeHistoryRepository.registTradeOpeHistory()\n"
         "→ commit → Samba書込み要求をセット",
         "DbService#updateTrade()\n+ TTradeMngRepository",
         "他電文と独立したTX\n失敗時はロールバック+WARN", C_DB),
        ("─", "【updateLeaveOrder フェーズ】",
         "Jbord4000ExDbService#updateLeaveOrder() を呼び出す",
         "DbService#updateLeaveOrder()", "", C_H2),
        ("9", "リーブオーダー対象確認",
         "leaveSttsMngInfo == null の場合はスキップして返る",
         "DbService#updateLeaveOrder()", "通常注文は対象外", C_BRANCH),
        ("10", "アメンドフラグ判定",
         "TTradeopeHistoryRepository.getTradeOpeHistoryInfo() で操作履歴を取得\n"
         "isAmend：\"画面.アメンド\" を含む履歴が存在するか（anyMatch で短絡評価）\n"
         "isAmendCancel：\"アメンドによる取消\" を含む履歴が存在するか",
         "DbService#updateLeaveOrder()", "旧実装のバグ修正済み\n(!isEmpty→anyMatch)", C_DB),
        ("11", "予約ステータス変換",
         "Helper#resolveReservationStatus(OrdStatus)\n"
         "  \"C\" → EXPIRED（期限切れ）\n"
         "  \"2\" → DONE（約定済み）\n"
         "  \"3\",\"4\",\"8\" → CANCEL（取消）\n"
         "  \"0\" その他 → null → DB更新スキップ（通知のみ）",
         "Helper#resolveReservationStatus()", "null はステータス変更不要", C_BRANCH),
        ("12", "リーブオーダーテーブル更新\n（REQUIRES_NEW TX）",
         "→ PROPAGATION_REQUIRES_NEW で独立トランザクション開始\n"
         "→ TLeaveSttsMngRepository.registLeaveSttsMng()\n"
         "→ commit → Samba書込み要求をセット",
         "DbService#updateLeaveOrder()\n+ TLeaveSttsMngRepository",
         "失敗時はロールバック+WARN\n通知生成は別途実施", C_DB),
        ("13", "ユーザ通知生成",
         "Helper#createLeaveOrderNotification() を呼び出す\n"
         "MsgType=8：OrdStatus×アメンドフラグで通知種別を決定\n"
         "  受付(0)+isAmend → 種別36（アメンド完了）\n"
         "  Expired(C) → 種別6　約定(2) → 種別5\n"
         "  取消(4)+!isAmendCancel → 種別7（キャンセル成功）\n"
         "MsgType=9 → 種別4（キャンセル失敗）",
         "Helper#createLeaveOrderNotification()", "DB更新成否に関わらず実行", C_STEP),
        ("─", "【Sambaキュー投入フェーズ】", "", "", "", C_H2),
        ("14", "応答ファイルフラグセット",
         "request.setClordId() / setOrdStatus() / setWriteResponseFile(true)\n"
         "（initialize 成功時は常に出力）",
         "ProcessWorker#call()", "", C_FILE),
        ("15", "Sambaキューへ投入",
         "request.hasAnyWriteRequest() が true の場合のみ\nsambaQueue.put(request) でキューに追加",
         "ProcessWorker\n#enqueueIfNeeded()", "書込み対象なしはスキップ", C_PARALLEL),
        ("16", "処理時間ログ出力",
         "trade更新時間・leave更新時間・合計処理時間を INFO ログに出力",
         "ProcessWorker#call()", "パフォーマンス監視用", C_STEP),
        ("─", "【END】 WriterResult.SUCCESS を返す",
         "例外（DB接続以外）の場合は WriterResult.FAILED を返す\nDB接続例外は呼び出し元へ再スローしてジョブ停止",
         "ProcessWorker#call()", "", C_END),
    ]

    for no, stage, desc, cls, note, bg in rows:
        cell_style(ws, r, 1, no,    align="center", bg=bg, bold=(no == "─"))
        cell_style(ws, r, 2, stage, bold=(no == "─"), bg=bg, wrap=True)
        cell_style(ws, r, 3, desc,  bg=bg, wrap=True, font_size=9)
        cell_style(ws, r, 4, cls,   bg=bg, wrap=True, align="center", font_size=9)
        cell_style(ws, r, 5, note,  bg=bg, wrap=True, font_size=9)
        lines = desc.count("\n")
        ws.row_dimensions[r].height = 80 if lines >= 5 else 55 if lines >= 2 else 30
        r += 1

    ws.freeze_panes = "A5"


# ── Sheet 3: SambaWorker 詳細 ─────────────────────────────────────────────────

def build_sheet3(wb):
    ws = wb.create_sheet("SambaWorker詳細")
    ws.sheet_view.showGridLines = False

    for i, w in enumerate([4, 28, 44, 24, 20], 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    r = 1
    merge_and_style(ws, r, 1, 5,
        "JBORD4000EX　Sambaワーカー（Jbord4000ExSambaWorker）詳細フロー",
        bold=True, bg=C_TITLE, font_size=13, font_color="FFFFFF")
    ws.row_dimensions[r].height = 28
    r += 1
    merge_and_style(ws, r, 1, 5,
        "BlockingQueueからSamba書込み要求を取り出し、4種類のファイルを出力する Runnable。Poison Pill受信でループ終了。",
        bg="BDD7EE", font_size=9)
    ws.row_dimensions[r].height = 18
    r += 2

    for col, h in enumerate(["No.", "処理段階", "処理内容・説明", "担当メソッド", "備考"], 1):
        cell_style(ws, r, col, h, bold=True, bg=C_H1, align="center", font_color="FFFFFF")
    ws.row_dimensions[r].height = 20
    r += 1

    rows = [
        ("─", "【ループ開始】",
         "sambaQueue.take() でブロッキング待機（要求が入るまで待つ）",
         "SambaWorker#run()", "", C_H2),
        ("1", "Poison Pill確認",
         "req.isPoisonPill() == true の場合 → ループを終了して return\n"
         "Poison Pill の投入数 = sambaWorkerSize（Tasklet が管理）",
         "SambaWorker#run()", "終了制御パターン", C_BRANCH),
        ("2", "取引管理ファイル出力\n（ブロッタ連携）",
         "req.isWriteTradeFile() == true かつ tradeMngInfo != null の場合\n"
         "→ FileUtil.writeTradeFile(tradeFilePath, tradeMngInfo)\n"
         "出力先：${trademng.file.path}",
         "FileUtil#writeTradeFile()", "ブロッタ連携用", C_FILE),
        ("3", "応答ファイル出力（TSV）",
         "req.isWriteResponseFile() == true の場合\n"
         "ファイル名：プレフィックス + タイムスタンプ + スレッドID + 連番 + \".tsv\"\n"
         "内容：ClOrdID（1列目）、OrdStatus（2列目）\n"
         "AtomicLong で連番を生成（複数ワーカー間で一意）\n"
         "出力先：${resorder.client.file.path}",
         "SambaWorker\n#writeResponseFile()", "クライアント応答用\nファイル名一意性を保証", C_FILE),
        ("4", "リーブオーダー連携ファイル出力（TSV）",
         "req.isWriteLeaveFile() == true かつ leaveSttsMngInfo != null の場合\n"
         "ファイル名：プレフィックス + 注文番号 + \".tsv\"（注文番号ごとに上書き）\n"
         "出力フィールド（11列）：\n"
         "  注文番号 / 予約ステータス / 期限日時区分 / 期限日時 / 指値\n"
         "  受渡日区分 / 注文日時 / 登録ユーザ / 登録日時 / 更新ユーザ / 更新日時\n"
         "出力先：${resorder.leave.file.path}",
         "SambaWorker\n#writeLeaveTradeFile()", "DateTimeFormatterは\nstatic final共有", C_FILE),
        ("5", "ユーザ通知ファイル出力",
         "req.isWriteUserNotification() == true かつ userNotificationDto != null の場合\n"
         "→ FileUtil.writeUserNotificationLogFile(userNotificationPath, dto)\n"
         "出力先：${usernotification.file.path}",
         "FileUtil\n#writeUserNotificationLogFile()", "ユーザへのUI通知用", C_FILE),
        ("─", "【ループ継続】",
         "再度 sambaQueue.take() に戻る（次の要求を待機）",
         "", "", C_H2),
        ("Ex1", "InterruptedException",
         "Thread.currentThread().interrupt() を呼んでワーカーを安全に終了する",
         "SambaWorker#run()", "スレッド割り込み対応", C_ERROR),
        ("Ex2", "その他の例外",
         "WARN ログを出力して次の要求の処理を継続する（業務継続）",
         "SambaWorker#run()", "ファイル書込み失敗は継続", C_ERROR),
    ]

    for no, stage, desc, cls, note, bg in rows:
        cell_style(ws, r, 1, no,    align="center", bg=bg, bold=(no == "─"))
        cell_style(ws, r, 2, stage, bold=(no == "─"), bg=bg, wrap=True)
        cell_style(ws, r, 3, desc,  bg=bg, wrap=True, font_size=9)
        cell_style(ws, r, 4, cls,   bg=bg, wrap=True, align="center", font_size=9)
        cell_style(ws, r, 5, note,  bg=bg, wrap=True, font_size=9)
        lines = desc.count("\n")
        ws.row_dimensions[r].height = 90 if lines >= 5 else 55 if lines >= 2 else 30
        r += 1

    ws.freeze_panes = "A5"


# ── Sheet 4: クラス構成 ───────────────────────────────────────────────────────

def build_sheet4(wb):
    ws = wb.create_sheet("クラス構成")
    ws.sheet_view.showGridLines = False

    for i, w in enumerate([28, 18, 20, 46], 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    r = 1
    merge_and_style(ws, r, 1, 4,
        "JBORD4000EX　クラス構成概要",
        bold=True, bg=C_TITLE, font_size=13, font_color="FFFFFF")
    ws.row_dimensions[r].height = 28
    r += 2

    for col, h in enumerate(["クラス名", "種別", "スレッド", "役割・概要"], 1):
        cell_style(ws, r, col, h, bold=True, bg=C_H1, align="center", font_color="FFFFFF")
    ws.row_dimensions[r].height = 20
    r += 1

    classes = [
        ("Jbord4000ExTasklet",       "Tasklet",    "メインスレッド",
         "ジョブメインループ制御。ストップファイル確認・processMessages呼び出し・スリープ。"
         "SambaWorkerPool・MessageWorkerPool の起動と終了を管理する。", C_STEP),
        ("Jbord4000ExFileReader",    "Component",  "メインスレッド",
         "受電文ディレクトリのファイルを読み込み FIX電文を解析。"
         "ファイル名昇順ソート・解析済みファイル削除・エラーファイル退避を担う。", C_FILE),
        ("Jbord4000ExProcessWorker", "Callable",   "MessageWorkerスレッド",
         "FIX電文1件の処理全体を調整する。処理順序制御・タイミング計測・エラーハンドリングに専念し、"
         "業務ロジックは DbService / Helper に委譲。電文ごとに new で生成される。", C_PARALLEL),
        ("Jbord4000ExDbService",     "Service",    "MessageWorkerスレッド\n（シングルトン共有）",
         "DB更新処理を集約するシングルトンBean。initialize / updateTrade / updateLeaveOrder の3メソッドを提供。"
         "処理状態は OrderContext に格納して引数で受け渡すためスレッドセーフ。", C_DB),
        ("Jbord4000ExHelper",        "Component",  "MessageWorkerスレッド\n（シングルトン共有）",
         "FIXステータス変換・UTC→JST変換・取引時間外補正・ユーザ通知DTO生成を担う。"
         "インスタンス変数は読み取り専用の設定値のみでスレッドセーフ。", C_STEP),
        ("Jbord4000ExSambaWorker",   "Runnable",   "SambaWorkerスレッド",
         "BlockingQueueからSamba書込み要求を取り出し4種類のファイルを出力する。"
         "Poison Pillパターンで終了制御。AtomicLongで応答ファイル名の一意性を確保。", C_FILE),
        ("SambaWriteRequest",        "DTO",         "スレッド間受け渡し",
         "MessageWorker→SambaWorker間のデータ転送オブジェクト。"
         "各種書込みフラグ・取引管理情報・リーブ情報・ユーザ通知DTOを保持。"
         "Poison Pill生成用の静的ファクトリメソッドを持つ。", C_BRANCH),
        ("DbService.OrderContext",   "内部クラス",  "MessageWorkerスレッド\n（各電文で独立）",
         "1電文分の処理コンテキスト。注文番号・取引管理情報・リーブ情報を格納。"
         "initialize で生成し、以降は読み取り専用として使用する。", C_DB),
    ]

    for cls_name, kind, thread, desc, bg in classes:
        cell_style(ws, r, 1, cls_name, bold=True, bg=bg, wrap=True, font_size=9)
        cell_style(ws, r, 2, kind,     bg=bg, align="center", font_size=9)
        cell_style(ws, r, 3, thread,   bg=bg, align="center", font_size=9, wrap=True)
        cell_style(ws, r, 4, desc,     bg=bg, wrap=True, font_size=9)
        ws.row_dimensions[r].height = 50
        r += 1

    r += 1
    merge_and_style(ws, r, 1, 4, "【スレッド構成図】",
        bold=True, bg=C_H1, font_color="FFFFFF")
    ws.row_dimensions[r].height = 20
    r += 1

    diagram = (
        "メインスレッド\n"
        "  └─ Jbord4000ExTasklet（ジョブループ制御）\n"
        "       ├─ Jbord4000ExFileReader（FIX電文解析）\n"
        "       ├─ SambaWorkerPool ─────────────────── SambaWorkerThread × sambaWorkerSize\n"
        "       │    BlockingQueue<SambaWriteRequest>      Jbord4000ExSambaWorker\n"
        "       └─ MessageWorkerPool ──────────────── MessageWorkerThread × messageWorkerSize\n"
        "            ExecutorService                       Jbord4000ExProcessWorker\n"
        "                                                     ├─ DbService#initialize()\n"
        "                                                     ├─ DbService#updateTrade()\n"
        "                                                     └─ DbService#updateLeaveOrder()"
    )
    merge_and_style(ws, r, 1, 4, diagram, bg="F2F2F2", align="left", font_size=9)
    ws.row_dimensions[r].height = 150
    ws.cell(row=r, column=1).font = Font(name="Courier New", size=9)

    ws.freeze_panes = "A4"


def main():
    wb = Workbook()
    build_sheet1(wb)
    build_sheet2(wb)
    build_sheet3(wb)
    build_sheet4(wb)

    out_path = r"C:\Users\ukben\workspace\jbord4000ex\JBORD4000EX_処理フロー.xlsx"
    wb.save(out_path)
    print(f"保存完了: {out_path}")

if __name__ == "__main__":
    main()
