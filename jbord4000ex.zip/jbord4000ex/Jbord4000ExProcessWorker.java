package jp.co.daiwa.jbord4000ex;

import java.util.Optional;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.FxdEnum.WriterResult;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dto.fix.ExecutionReport;
import jp.co.daiwa.jbord4000ex.Jbord4000ExDbService.OrderContext;

/**
 * 電文処理ワーカー（1電文1スレッド）
 *
 * <p>FIX応答電文1件の処理全体を調整する {@link Callable}。
 * 実際の業務ロジックは {@link Jbord4000ExDbService}・{@link Jbord4000ExHelper} に委譲し、
 * 本クラスは処理順序の制御・タイミング計測・エラーハンドリングに専念する。
 *
 * <p>【処理フロー】
 * <ol>
 *   <li>初期化：注文存在確認・取引管理情報取得（{@link Jbord4000ExDbService#initialize}）</li>
 *   <li>取引管理DB更新（{@link Jbord4000ExDbService#updateTrade}）</li>
 *   <li>リーブオーダーDB更新（{@link Jbord4000ExDbService#updateLeaveOrder}）</li>
 *   <li>応答ファイル書込みフラグのセット</li>
 *   <li>{@link SambaWriteRequest} をキューに投入</li>
 * </ol>
 *
 * <p>【例外ハンドリング】
 * DB接続例外のみ呼び出し元（{@link Jbord4000ExTasklet}）へ再スローし、
 * ジョブループを停止させる。
 * その他の例外は {@link WriterResult#FAILED} を返してジョブを継続させる。
 *
 * <p>【インスタンス生成】
 * Springコンテナ管理外。{@link Jbord4000ExTasklet} が電文ごとに {@code new} で生成する。
 * 全依存はコンストラクタで受け取る（不完全状態でのインスタンス生成を防止）。
 */
public class Jbord4000ExProcessWorker implements Callable<WriterResult> {

    /** 処理対象 FIX 電文 */
    private final ExecutionReport report;

    /** Samba書込みワーカーとの受け渡しキュー */
    private final BlockingQueue<SambaWriteRequest> sambaQueue;

    /** DB更新サービス */
    private final Jbord4000ExDbService dbService;

    /** 変換・補正・通知生成サービス */
    private final Jbord4000ExHelper helper;

    /** トランザクションマネージャー（updateTradeに渡す） */
    private final PlatformTransactionManager transactionManager;

    /** トランザクション定義（REQUIRES_NEW、updateTradeに渡す） */
    private final DefaultTransactionDefinition definition;

    private static final LogBatchBasedLogger logger =
        LogBatchBasedLogger.getLogger(Jbord4000ExProcessWorker.class);

    public Jbord4000ExProcessWorker(
            ExecutionReport report,
            BlockingQueue<SambaWriteRequest> sambaQueue,
            Jbord4000ExDbService dbService,
            Jbord4000ExHelper helper,
            PlatformTransactionManager transactionManager,
            DefaultTransactionDefinition definition) {
        this.report             = report;
        this.sambaQueue         = sambaQueue;
        this.dbService          = dbService;
        this.helper             = helper;
        this.transactionManager = transactionManager;
        this.definition         = definition;
    }

    /**
     * 電文1件の処理を実行する。
     *
     * @return {@link WriterResult#SUCCESS}：正常終了または業務警告
     *         {@link WriterResult#FAILED}：DB接続以外の例外
     * @throws Exception DB接続例外（呼び出し元でジョブ停止判定）
     */
    @Override
    public WriterResult call() throws Exception {
        long startTime = System.currentTimeMillis();

        try {
            SambaWriteRequest request = new SambaWriteRequest();

            // ── ① 初期化：注文存在確認・取引情報取得 ───────────────────────────
            Optional<OrderContext> ctxOpt = dbService.initialize(report, request, helper);
            if (ctxOpt.isEmpty()) {
                // 注文未存在時は通知のみキューに投入して終了
                enqueueIfNeeded(request);
                return WriterResult.SUCCESS;
            }
            OrderContext ctx = ctxOpt.get();

            // ── ② 取引管理DB更新 ─────────────────────────────────────────────
            long tradeStart = System.currentTimeMillis();
            dbService.updateTrade(report, ctx, request,
                transactionManager, definition, helper);
            long tradeEnd = System.currentTimeMillis();

            // ── ③ リーブオーダーDB更新 ──────────────────────────────────────
            dbService.updateLeaveOrder(report, ctx, request, transactionManager, helper);
            long leaveEnd = System.currentTimeMillis();

            // ── ④ 応答ファイル書込みフラグをセット（init成功時は常に出力） ─────
            request.setClordId(report.getClordID());
            request.setOrdStatus(report.getOrdStatus());
            request.setWriteResponseFile(true);

            // ── ⑤ Samba書込みキューへ投入 ──────────────────────────────────
            enqueueIfNeeded(request);

            // 処理時間ログ（取引DB更新・リーブDB更新・合計）
            long totalEnd = System.currentTimeMillis();
            logger.info(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_I028",
                String.format("処理時間: trade=%dms, leave=%dms, total=%dms",
                    tradeEnd  - tradeStart,
                    leaveEnd  - tradeEnd,
                    totalEnd  - startTime),
                report.getClordID());

            return WriterResult.SUCCESS;

        } catch (Exception e) {
            // DB接続例外はジョブ停止のため呼び出し元へ再スロー
            if (isDbException(e)) throw e;

            logger.warn(JobConstants.Jbord4000, JobConstants.Jbord4000_Name,
                "MSG_J_W001", "Jbord4000ExProcessWorker", e);
            return WriterResult.FAILED;
        }
    }

    /**
     * 書込み要求がある場合のみキューへ投入する。
     * すべてのフラグが false のときはキュー投入不要。
     */
    private void enqueueIfNeeded(SambaWriteRequest request)
            throws InterruptedException {
        if (request.hasAnyWriteRequest()) {
            sambaQueue.put(request);
        }
    }

    /** DB接続例外か否かを判定する */
    private boolean isDbException(Exception e) {
        return e.getMessage() != null
            && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION);
    }
}
