package jp.co.daiwa.jbpos1100.tasklet;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashStore;
import jp.co.daiwa.jbpos1100.file.PositionSumFileWriter;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.spot.SpotSummaryService;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSummaryResult;
import jp.co.daiwa.jbpos1100.swap.SwapSummaryService;

/**
 * {@link PositionEvaluationService} の結線テスト。
 * スポット集計＋スワップ集計が呼ばれ、スワップ3成果物が delete→insert で永続化されることを検証する。
 */
class PositionEvaluationServiceTest {

    private SpotSummaryService spotSummaryService;
    private SwapSummaryService swapSummaryService;
    private SwapSumStore swapSumStore;
    private CurrencyDeltaCashStore deltaCashStore;
    private SwapPlSumStore swapPlSumStore;
    private PositionSumFileWriter fileWriter;
    private PositionEvaluationService service;

    @BeforeEach
    void setUp() {
        spotSummaryService = mock(SpotSummaryService.class);
        swapSummaryService = mock(SwapSummaryService.class);
        swapSumStore = mock(SwapSumStore.class);
        deltaCashStore = mock(CurrencyDeltaCashStore.class);
        swapPlSumStore = mock(SwapPlSumStore.class);
        fileWriter = mock(PositionSumFileWriter.class);
        service = new PositionEvaluationService(spotSummaryService, swapSummaryService,
                swapSumStore, deltaCashStore, swapPlSumStore, fileWriter, "/tmp/out");
    }

    @Test
    @DisplayName("スポット集計とスワップ集計を実行し、スワップ3成果物を delete→insert で永続化する")
    void evaluate_runsSpotAndSwapAndPersists() throws Exception {
        StepContribution contribution = mock(StepContribution.class);
        Date targetDate = new Date();
        SourcePositionSplit split = new SourcePositionSplit(
                Collections.<TPosSumSourceDataBean>emptyList(), Collections.<TPosSumSourceDataBean>emptyList());

        List<TPositionSwapSumDataBean> currencySum = Collections.singletonList(new TPositionSwapSumDataBean());
        List<TByCcyDeltaCashBalanceBean> deltaCash = Collections.singletonList(new TByCcyDeltaCashBalanceBean());
        List<TSwapPlSumDateBean> plSum = Collections.singletonList(new TSwapPlSumDateBean());
        SwapSummaryResult swapResult = new SwapSummaryResult(currencySum, deltaCash, plSum);

        when(spotSummaryService.aggregateAndStore(any(), any(), anyString(), any()))
                .thenReturn(Collections.<TPositionSpotSumDataBean>emptyList());
        when(swapSummaryService.aggregate(any(), any(), any(), any(), any(), any(), anyString()))
                .thenReturn(swapResult);

        service.evaluate(contribution, targetDate, split,
                Collections.<TPosSumSourceDataBean>emptyList(),
                Collections.emptyList(), Collections.emptyList(), "00",
                Collections.<TPositionSpotSumDataBean>emptyList());

        verify(spotSummaryService).aggregateAndStore(any(), any(), anyString(), any());
        verify(swapSummaryService).aggregate(any(), any(), any(), any(), any(), any(), anyString());
        // [I-9] 削除は権威準拠の「存在時のみ削除」（deleteIfExists）経由
        verify(swapSumStore).deleteIfExists(any());
        verify(swapSumStore).insert(currencySum);
        verify(deltaCashStore).deleteIfExists(any());
        verify(deltaCashStore).insert(deltaCash);
        verify(swapPlSumStore).deleteIfExists(any());
        verify(swapPlSumStore).insert(plSum);
        // 区分=00(Real)はスポットファイル出力、スワップ結果ありでスワップファイル出力
        verify(fileWriter).writeSpotSumFile(any(), eq("/tmp/out"), eq("00"), any());
        verify(fileWriter).writeSwapSumFile(any(), eq("/tmp/out"), eq("00"), eq(plSum), eq(deltaCash), eq(currencySum));
    }
}
