package jp.co.daiwa.jbpos1100.delta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dao.bean.TPositionPlDeltaDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * {@link PlDeltaCalculator} の単体テスト（旧 {@code setPosPlDeltaValueData} の計算部分の移植検証）。
 */
class PlDeltaCalculatorTest {

    private PlDeltaCalculator calculator;
    private JobWarningReporter reporter;
    private Date targetDate;
    private String baseDate;

    @BeforeEach
    void setUp() throws Exception {
        reporter = mock(JobWarningReporter.class);
        calculator = new PlDeltaCalculator(reporter);
        targetDate = new SimpleDateFormat("yyyy/MM/dd").parse("2026/06/28");
        baseDate = "2026/06/28";
    }

    @Test
    @DisplayName("マニュアルレート優先・決済金額=売買金額(絶対値)×取引レート・買い区分・円転1.0")
    void calculate_manualRatePreferred() {
        TPositionSpotSumDataBean spot = spot("BOOK1", "USD", new BigDecimal("100"));

        CloseRateDto usdJpyFile = closeRate("USD", new BigDecimal("150"));
        TPosSumManualRateBean usdJpyManual = manual("USD", new BigDecimal("151"));

        List<TPositionPlDeltaDataBean> result = calculator.calculate(targetDate,
                Collections.singletonList(spot), Collections.singletonList(usdJpyFile),
                Collections.singletonList(usdJpyManual));

        assertThat(result).hasSize(1);
        TPositionPlDeltaDataBean d = result.get(0);
        assertThat(d.getDealerBook()).isEqualTo("BOOK1");
        assertThat(d.getDealCurrency()).isEqualTo("USD");
        assertThat(d.getSettleCurrency()).isEqualTo("JPY");
        assertThat(d.getCurrencyPair()).isEqualTo("USDJPY");
        assertThat(d.getDealDivision()).isEqualTo("1");                 // PL>0 → 買い
        assertThat(d.getDealAmount()).isEqualByComparingTo("100");
        assertThat(d.getTradeRate()).isEqualByComparingTo("151");        // マニュアル優先
        assertThat(d.getClosingRate()).isEqualByComparingTo("150");      // 引値レートも保持
        assertThat(d.getManualClosingTtmRate()).isEqualByComparingTo("151");
        assertThat(d.getSettleAmount()).isEqualByComparingTo("15100");   // 100 × 151
        assertThat(d.getClosingYenRate()).isEqualByComparingTo("1");
        verifyNoInteractions(reporter);
    }

    @Test
    @DisplayName("マニュアルレートが無い場合は引値レートを取引レートに採用・売り区分")
    void calculate_fallsBackToCloseRate_sell() {
        TPositionSpotSumDataBean spot = spot("BOOK1", "EUR", new BigDecimal("-50"));
        CloseRateDto eurJpyFile = closeRate("EUR", new BigDecimal("160"));

        List<TPositionPlDeltaDataBean> result = calculator.calculate(targetDate,
                Collections.singletonList(spot), Collections.singletonList(eurJpyFile),
                Collections.<TPosSumManualRateBean>emptyList());

        assertThat(result).hasSize(1);
        TPositionPlDeltaDataBean d = result.get(0);
        assertThat(d.getDealDivision()).isEqualTo("2");                 // PL<0 → 売り
        assertThat(d.getDealAmount()).isEqualByComparingTo("50");        // 絶対値
        assertThat(d.getTradeRate()).isEqualByComparingTo("160");
        assertThat(d.getManualClosingTtmRate()).isNull();
        assertThat(d.getSettleAmount()).isEqualByComparingTo("8000");    // 50 × 160
    }

    @Test
    @DisplayName("JPY決済・評価PL NULL・プレ引値以外は対象外")
    void calculate_filtersExcluded() {
        TPositionSpotSumDataBean jpySettle = spot("BOOK1", "JPY", new BigDecimal("100"));
        TPositionSpotSumDataBean nullPl = spot("BOOK1", "USD", null);
        TPositionSpotSumDataBean notPreClosing = spot("BOOK1", "USD", new BigDecimal("100"));
        notPreClosing.setEvaluationRateDivision(EvaluationRateKbn.REAL.getCode());

        List<TPositionPlDeltaDataBean> result = calculator.calculate(targetDate,
                Arrays.asList(jpySettle, nullPl, notPreClosing),
                Collections.singletonList(closeRate("USD", new BigDecimal("150"))),
                Collections.<TPosSumManualRateBean>emptyList());

        assertThat(result).isEmpty();
    }

    @Test
    @DisplayName("引値レート・マニュアルレートが共に無い場合は生成せず警告する")
    void calculate_noRate_warns() {
        TPositionSpotSumDataBean spot = spot("BOOK1", "USD", new BigDecimal("100"));

        List<TPositionPlDeltaDataBean> result = calculator.calculate(targetDate,
                Collections.singletonList(spot), Collections.<CloseRateDto>emptyList(),
                Collections.<TPosSumManualRateBean>emptyList());

        assertThat(result).isEmpty();
        verify(reporter).warn(org.mockito.ArgumentMatchers.anyString(), org.mockito.ArgumentMatchers.anyString());
    }

    private TPositionSpotSumDataBean spot(String dealerBook, String settleCurrency, BigDecimal evalPlUnderlying) {
        TPositionSpotSumDataBean bean = new TPositionSpotSumDataBean();
        bean.setProcessBaseDate(targetDate);
        bean.setEvaluationRateDivision(EvaluationRateKbn.PRE_CLOSING.getCode());
        bean.setDealerBook(dealerBook);
        bean.setSettleCurrency(settleCurrency);
        bean.setEvaluationPlUnderlyingCcy(evalPlUnderlying);
        return bean;
    }

    private CloseRateDto closeRate(String dealCurrency, BigDecimal rate) {
        CloseRateDto dto = new CloseRateDto();
        dto.setBaseDate(baseDate);
        dto.setDealCurrency(dealCurrency);
        dto.setSettleCurrency("JPY");
        dto.setCloseRate(rate);
        return dto;
    }

    private TPosSumManualRateBean manual(String dealCurrency, BigDecimal ttm) {
        TPosSumManualRateBean bean = new TPosSumManualRateBean();
        bean.setDealCurrency(dealCurrency);
        bean.setSettleCurrency("JPY");
        bean.setManualClosingTtmRate(ttm);
        return bean;
    }
}
