package jp.co.daiwa.jbpos1100.delta;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * {@link CurrencyDeltaCashCalculator} の単体テスト。
 *
 * <p>主眼は旧コードの P0 バグ「{@code Map.put} の戻り値（旧値=初回 null）を加算して
 * デルタ/キャッシュ残を計算し NPE になる」が、移行版で正しく集計値を直接加算するよう
 * 修正されていることの回帰検証。</p>
 */
class CurrencyDeltaCashCalculatorTest {

    private CurrencyDeltaCashCalculator calculator;
    private StepContribution contribution;
    private Date targetDate;

    @BeforeEach
    void setUp() {
        JobWarningReporter reporter = mock(JobWarningReporter.class);
        contribution = mock(StepContribution.class);
        calculator = new CurrencyDeltaCashCalculator(reporter);
        targetDate = new Date();
    }

    @Test
    @DisplayName("引値以降のデルタ = 取引金PV(引値)+取引金PV+決済金PV（初回でもNPEにならない）")
    void calculate_afterClosing_deltaIsSumOfThreePv() throws Exception {
        TPositionSwapSumDataBean swap = swapBean("BOOK1", "USD",
                new BigDecimal("100"),   // tradeAmountPvCls
                new BigDecimal("20"),    // tradeAmountPv
                new BigDecimal("3"),     // settleAmountPv
                new BigDecimal("10"),    // dealAmount
                new BigDecimal("-4"));   // settleAmount

        List<TByCcyDeltaCashBalanceBean> result = calculator.calculate(contribution, targetDate,
                EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode(),
                EvaluationRateKbn.AFTER_CLOSING_PRICE.getName(),
                Collections.singletonList(swap),
                Collections.<TPosSumSourceDataBean>emptyList());

        assertThat(result).hasSize(1);
        // 100 + 20 + 3 = 123 （旧実装は初回 put が null を返し NPE）
        assertThat(result.get(0).getDelta()).isEqualByComparingTo("123");
    }

    @Test
    @DisplayName("基準日に受渡があるキャッシュ残 = 売買金額+決済金額")
    void calculate_cashBalanceIsDealPlusSettle() throws Exception {
        TPositionSwapSumDataBean swap = swapBean("BOOK1", "USD",
                new BigDecimal("100"), new BigDecimal("20"), new BigDecimal("3"),
                new BigDecimal("10"), new BigDecimal("-4"));

        List<TByCcyDeltaCashBalanceBean> result = calculator.calculate(contribution, targetDate,
                EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode(),
                EvaluationRateKbn.AFTER_CLOSING_PRICE.getName(),
                Collections.singletonList(swap),
                Collections.<TPosSumSourceDataBean>emptyList());

        // 10 + (-4) = 6
        assertThat(result.get(0).getCashBalance()).isEqualByComparingTo("6");
    }

    @Test
    @DisplayName("PVにNULLが含まれる場合デルタはnull（計算エラー扱い）")
    void calculate_nullPv_deltaIsNull() throws Exception {
        TPositionSwapSumDataBean swap = swapBean("BOOK1", "USD",
                null, new BigDecimal("20"), new BigDecimal("3"),
                new BigDecimal("10"), new BigDecimal("-4"));

        List<TByCcyDeltaCashBalanceBean> result = calculator.calculate(contribution, targetDate,
                EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode(),
                EvaluationRateKbn.AFTER_CLOSING_PRICE.getName(),
                Collections.singletonList(swap),
                Collections.<TPosSumSourceDataBean>emptyList());

        assertThat(result.get(0).getDelta()).isNull();
    }

    private TPositionSwapSumDataBean swapBean(String dealerBook, String currency, BigDecimal tradeAmountPvCls,
            BigDecimal tradeAmountPv, BigDecimal settleAmountPv, BigDecimal dealAmount, BigDecimal settleAmount) {
        TPositionSwapSumDataBean bean = new TPositionSwapSumDataBean();
        bean.setDealerBook(dealerBook);
        bean.setCurrency(currency);
        bean.setTradeAmountPvCls(tradeAmountPvCls);
        bean.setTradeAmountPv(tradeAmountPv);
        bean.setSettleAmountPv(settleAmountPv);
        bean.setDealAmount(dealAmount);
        bean.setSettleAmount(settleAmount);
        bean.setDeliveryDate(targetDate);
        return bean;
    }
}
