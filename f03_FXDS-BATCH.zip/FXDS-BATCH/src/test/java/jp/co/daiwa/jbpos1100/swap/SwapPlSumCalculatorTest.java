package jp.co.daiwa.jbpos1100.swap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * {@link SwapPlSumCalculator} の単体テスト。
 */
class SwapPlSumCalculatorTest {

    private SwapPlSumCalculator calculator;
    private Date targetDate;

    @BeforeEach
    void setUp() {
        calculator = new SwapPlSumCalculator(mock(JobWarningReporter.class));
        targetDate = new Date();
    }

    @Test
    @DisplayName("ディーラブック・評価レート区分単位でPLを合計し小数2桁に丸める")
    void calculate_sumsPlYenPerGroup() {
        TPositionSwapSumDataBean a = bean("BOOK1", "00", new BigDecimal("10.005"));
        TPositionSwapSumDataBean b = bean("BOOK1", "00", new BigDecimal("5.001"));

        List<TSwapPlSumDateBean> result = calculator.calculate(targetDate, "Real", Arrays.asList(a, b));

        assertThat(result).hasSize(1);
        // 10.005 + 5.001 = 15.006 -> HALF_UP(2) = 15.01
        assertThat(result.get(0).getPlTotal()).isEqualByComparingTo("15.01");
    }

    @Test
    @DisplayName("円換算PLにNULLが含まれる場合はPL合計値をnullにする")
    void calculate_nullSumPlYen_plTotalNull() {
        TPositionSwapSumDataBean a = bean("BOOK1", "00", new BigDecimal("10"));
        TPositionSwapSumDataBean b = bean("BOOK1", "00", null);

        List<TSwapPlSumDateBean> result = calculator.calculate(targetDate, "Real", Arrays.asList(a, b));

        assertThat(result.get(0).getPlTotal()).isNull();
    }

    @Test
    @DisplayName("ディーラブック/評価レート区分が異なれば別グループに集計")
    void calculate_separatesByKey() {
        TPositionSwapSumDataBean a = bean("BOOK1", "00", new BigDecimal("10"));
        TPositionSwapSumDataBean b = bean("BOOK2", "00", new BigDecimal("20"));

        List<TSwapPlSumDateBean> result = calculator.calculate(targetDate, "Real", Arrays.asList(a, b));

        assertThat(result).hasSize(2);
    }

    private TPositionSwapSumDataBean bean(String dealerBook, String evaluationRateDivision, BigDecimal sumPlYen) {
        TPositionSwapSumDataBean bean = new TPositionSwapSumDataBean();
        bean.setDealerBook(dealerBook);
        bean.setEvaluationRateDivision(evaluationRateDivision);
        bean.setSumPlYen(sumPlYen);
        return bean;
    }
}
