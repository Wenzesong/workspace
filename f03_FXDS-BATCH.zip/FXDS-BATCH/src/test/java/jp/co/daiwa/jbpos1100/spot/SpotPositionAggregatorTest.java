package jp.co.daiwa.jbpos1100.spot;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * {@link SpotPositionAggregator} の単体テスト。
 *
 * <p>逐次状態（評価ポジション・Avg コスト）と確定ポジションの振る舞いを検証する。
 * 戻り値は各グループの最終行であることに注意。</p>
 */
class SpotPositionAggregatorTest {

    private SpotPositionAggregator aggregator;
    private Date targetDate;

    @BeforeEach
    void setUp() {
        aggregator = new SpotPositionAggregator(mock(JobWarningReporter.class));
        targetDate = new Date();
    }

    @Test
    @DisplayName("単一の買いは評価ポジション=売買金額、Avgコスト=取引レート")
    void aggregate_singleBuy() {
        TPosSumSourceDataBean buy = item("1", new BigDecimal("100"), new BigDecimal("15000"),
                new BigDecimal("150"), 1);

        List<TPositionSpotSumDataBean> result = aggregator.aggregate(targetDate,
                Collections.singletonList(buy), "00", new ArrayList<TPositionSpotSumDataBean>());

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getEvaluationPosition()).isEqualByComparingTo("100");
        assertThat(result.get(0).getAvgCostRate()).isEqualByComparingTo("150");
    }

    @Test
    @DisplayName("同方向の連続買いは評価ポジションが累積し、最終行のみ返る")
    void aggregate_twoBuysAccumulate() {
        TPosSumSourceDataBean buy1 = item("1", new BigDecimal("100"), new BigDecimal("15000"),
                new BigDecimal("150"), 1);
        TPosSumSourceDataBean buy2 = item("1", new BigDecimal("50"), new BigDecimal("7600"),
                new BigDecimal("152"), 2);

        List<TPositionSpotSumDataBean> result = aggregator.aggregate(targetDate,
                Arrays.asList(buy1, buy2), "00", new ArrayList<TPositionSpotSumDataBean>());

        assertThat(result).hasSize(1);
        // 100 + 50 = 150
        assertThat(result.get(0).getEvaluationPosition()).isEqualByComparingTo("150");
        // 確定ポジションは発生しない（同方向）
        assertThat(result.get(0).getConfirmPosition()).isEqualByComparingTo("0");
    }

    @Test
    @DisplayName("売買金額0の行はReal集計で除外される")
    void aggregate_real_excludesZeroDealAmount() {
        TPosSumSourceDataBean zero = item("1", BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("150"), 1);

        List<TPositionSpotSumDataBean> result = aggregator.aggregate(targetDate,
                Collections.singletonList(zero), "00", new ArrayList<TPositionSpotSumDataBean>());

        assertThat(result).isEmpty();
    }

    private TPosSumSourceDataBean item(String dealDivision, BigDecimal dealAmount, BigDecimal settleAmount,
            BigDecimal tradeRate, int seqSeconds) {
        TPosSumSourceDataBean bean = new TPosSumSourceDataBean();
        bean.setDealerBook("BOOK1");
        bean.setCurrencyPair("USDJPY");
        bean.setDealCurrency("USD");
        bean.setSettleCurrency("JPY");
        bean.setDealDivision(dealDivision);
        bean.setDealAmount(dealAmount);
        bean.setSettleAmount(settleAmount);
        bean.setTradeRate(tradeRate);
        bean.setManualDailyRate(new BigDecimal("151"));
        bean.setExchangeDivision("0");
        bean.setAc("0");
        bean.setTradeDatetime(new Timestamp(1_700_000_000_000L + seqSeconds * 1000L));
        return bean;
    }
}
