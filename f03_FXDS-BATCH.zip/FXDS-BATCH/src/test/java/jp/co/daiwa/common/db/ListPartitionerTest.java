package jp.co.daiwa.common.db;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * {@link ListPartitioner} の単体テスト（外部依存なし）。
 */
class ListPartitionerTest {

    @Test
    @DisplayName("割り切れない件数は最後のチャンクが端数になる")
    void partition_unevenSize_lastChunkHasRemainder() {
        List<Integer> source = Arrays.asList(1, 2, 3, 4, 5);

        List<List<Integer>> result = ListPartitioner.partition(source, 2);

        assertThat(result).hasSize(3);
        assertThat(result.get(0)).containsExactly(1, 2);
        assertThat(result.get(1)).containsExactly(3, 4);
        assertThat(result.get(2)).containsExactly(5);
    }

    @Test
    @DisplayName("件数がunitちょうどの倍数なら均等分割される")
    void partition_evenSize_splitsEvenly() {
        List<Integer> source = Arrays.asList(1, 2, 3, 4);

        List<List<Integer>> result = ListPartitioner.partition(source, 2);

        assertThat(result).hasSize(2);
        assertThat(result.get(0)).containsExactly(1, 2);
        assertThat(result.get(1)).containsExactly(3, 4);
    }

    @Test
    @DisplayName("null・空リストは空の結果を返す")
    void partition_nullOrEmpty_returnsEmpty() {
        assertThat(ListPartitioner.partition(null, 3)).isEmpty();
        assertThat(ListPartitioner.partition(Collections.emptyList(), 3)).isEmpty();
    }

    @Test
    @DisplayName("unitが1未満なら例外")
    void partition_invalidUnit_throws() {
        assertThatThrownBy(() -> ListPartitioner.partition(Arrays.asList(1, 2), 0))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
