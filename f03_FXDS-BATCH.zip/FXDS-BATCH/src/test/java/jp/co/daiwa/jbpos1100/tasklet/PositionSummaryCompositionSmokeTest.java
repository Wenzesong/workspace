package jp.co.daiwa.jbpos1100.tasklet;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.lang.reflect.Field;
import java.nio.file.Path;
import java.util.Collections;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InOrder;
import org.springframework.batch.core.StepContribution;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.TDfCalcResultRepository;
import jp.co.daiwa.dao.TDfHistoryDateRepository;
import jp.co.daiwa.dao.TPosSumManualRateRepository;
import jp.co.daiwa.dao.TPosSumSourceDataRepository;
import jp.co.daiwa.dao.TPositionPlDeltaDataRepository;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.TPositionSwapSumDataRepository;
import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.daodfit.TDfarmBbgRateRepository;
import jp.co.daiwa.jbpos1100.file.PositionSumFileWriter;
import jp.co.daiwa.jbpos1100.rate.YenRateResolver;
import jp.co.daiwa.jbpos1100.source.ClosingSpotSourceLoader;
import jp.co.daiwa.jbpos1100.source.PositionSourceRepositoryGateway;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplitter;
import jp.co.daiwa.jbpos1100.spot.SpotCloseCostReplacer;
import jp.co.daiwa.jbpos1100.spot.SpotClosingRateResolver;

/**
 * [I-5] 合成ルート {@link PositionSummaryComposition#runOnce} の結線スモークテスト。
 *
 * <p>Spring コンテナを使わず、フィールドインジェクション対象をリフレクションでモック注入して
 * 1 サイクルを実行し、権威 {@code posSumTask} と同じ工程順（G-A 事前削除 → G-B/全件再取得 →
 * Real 集計）が結線されていること、および引値レートファイルが無い場合に引値チェーン
 * （[G-E] ガード配下）が実行されないことを検証する。工程の抜け・順序逆転の回帰を検出する。</p>
 *
 * <p>入力データはすべて空（業務計算は各ユニットテストで検証済みのため、ここでは配線のみを見る）。</p>
 */
class PositionSummaryCompositionSmokeTest {

    @TempDir
    Path tempDir;

    private PositionSummaryComposition composition;

    private PlatformTransactionManager transactionManager;
    private PositionSourceRepositoryGateway gateway;
    private TPosSumSourceDataRepository posSumSourceRepository;
    private TPositionSpotSumDataRepository spotSumRepository;
    private TPositionSwapSumDataRepository swapSumRepository;
    private TByCcyDeltaCashBalanceRepository deltaCashRepository;
    private TSwapPlSumDateRepository swapPlSumRepository;
    private TPositionPlDeltaDataRepository plDeltaRepository;
    private TDfCalcResultRepository dfCalcResultRepository;
    private TDfHistoryDateRepository dfHistoryRepository;
    private TPosSumManualRateRepository manualRateRepository;
    private TDfarmBbgRateRepository bbgRateRepository;
    private YenRateResolver yenRateResolver;
    private SourcePositionSplitter splitter;
    private ClosingSpotSourceLoader closingSpotSourceLoader;
    private SpotCloseCostReplacer spotCloseCostReplacer;
    private SpotClosingRateResolver spotClosingRateResolver;
    private PositionSumFileWriter fileWriter;

    @BeforeEach
    void setUp() throws Exception {
        composition = new PositionSummaryComposition();

        transactionManager = mock(PlatformTransactionManager.class);
        when(transactionManager.getTransaction(any())).thenReturn(mock(TransactionStatus.class));

        gateway = mock(PositionSourceRepositoryGateway.class);
        when(gateway.getPreviousBusinessDay(any())).thenReturn(new Date());
        when(gateway.getCurrencyMstData()).thenReturn(Collections.emptyList());
        when(gateway.getDfitCustomerData()).thenReturn(Collections.emptyList());
        when(gateway.getDfitTradeExchangeRawData(any(), any())).thenReturn(Collections.emptyList());
        when(gateway.getTradeMngSourceData(any(), any())).thenReturn(Collections.emptyList());
        when(gateway.getDfitTradeExchange(any())).thenReturn(Collections.emptyList());
        when(gateway.getBidTradeInfo(any(), any())).thenReturn(Collections.emptyList());
        when(gateway.getBidOutsideMInfo(any(), any())).thenReturn(Collections.emptyList());

        posSumSourceRepository = mock(TPosSumSourceDataRepository.class);
        when(posSumSourceRepository.getPosSumSourceDataAll(any())).thenReturn(Collections.emptyList());
        spotSumRepository = mock(TPositionSpotSumDataRepository.class);
        when(spotSumRepository.geTPositionSpotSumDataBeanAll(any())).thenReturn(Collections.emptyList());
        swapSumRepository = mock(TPositionSwapSumDataRepository.class);
        when(swapSumRepository.getPositionSwapSumDataList(any())).thenReturn(Collections.emptyList());
        deltaCashRepository = mock(TByCcyDeltaCashBalanceRepository.class);
        when(deltaCashRepository.getByCcyDeltaCashBalanceList(any())).thenReturn(Collections.emptyList());
        swapPlSumRepository = mock(TSwapPlSumDateRepository.class);
        when(swapPlSumRepository.getSwapPlSumDateList(any())).thenReturn(Collections.emptyList());
        plDeltaRepository = mock(TPositionPlDeltaDataRepository.class);
        dfCalcResultRepository = mock(TDfCalcResultRepository.class);
        when(dfCalcResultRepository.getTDfCalcResultBeanAll(any(), any())).thenReturn(Collections.emptyList());
        dfHistoryRepository = mock(TDfHistoryDateRepository.class);
        when(dfHistoryRepository.getDfHistoryDateBeanAll(any())).thenReturn(Collections.emptyList());
        manualRateRepository = mock(TPosSumManualRateRepository.class);
        when(manualRateRepository.getTPosSumManualRateBeanAll(any())).thenReturn(Collections.emptyList());
        bbgRateRepository = mock(TDfarmBbgRateRepository.class);
        when(bbgRateRepository.getTDfarmBbgRateBeanAll(any())).thenReturn(Collections.emptyList());

        yenRateResolver = mock(YenRateResolver.class);
        splitter = mock(SourcePositionSplitter.class);
        when(splitter.splitForReal(any(), any(), any())).thenReturn(new SourcePositionSplit(
                Collections.emptyList(), Collections.emptyList()));
        closingSpotSourceLoader = mock(ClosingSpotSourceLoader.class);
        spotCloseCostReplacer = mock(SpotCloseCostReplacer.class);
        spotClosingRateResolver = mock(SpotClosingRateResolver.class);
        fileWriter = mock(PositionSumFileWriter.class);

        inject("transactionManager", transactionManager);
        inject("gateway", gateway);
        inject("posSumSourceRepository", posSumSourceRepository);
        inject("spotSumRepository", spotSumRepository);
        inject("swapSumRepository", swapSumRepository);
        inject("deltaCashRepository", deltaCashRepository);
        inject("swapPlSumRepository", swapPlSumRepository);
        inject("plDeltaRepository", plDeltaRepository);
        inject("dfCalcResultRepository", dfCalcResultRepository);
        inject("dfHistoryRepository", dfHistoryRepository);
        inject("manualRateRepository", manualRateRepository);
        inject("bbgRateRepository", bbgRateRepository);
        inject("yenRateResolver", yenRateResolver);
        inject("splitter", splitter);
        inject("closingSpotSourceLoader", closingSpotSourceLoader);
        inject("spotCloseCostReplacer", spotCloseCostReplacer);
        inject("spotClosingRateResolver", spotClosingRateResolver);
        inject("fileWriter", fileWriter);

        inject("bulkInsertUnit", 100);
        inject("outputFilePath", tempDir.toString() + File.separator);
        inject("dayCloseTime", "150000");
        // レートファイルは空ディレクトリ＝ベースレート/引値レートともに空リストで読み込まれる
        inject("closeRateFilePath", tempDir.toString());
        inject("closeRateFileNamePrefix", "close_");
        inject("baseRateFilePath", tempDir.toString());
        inject("baseRateFileNamePrefix", "base_");
    }

    @Test
    @DisplayName("runOnce は G-A 事前削除 → 集計元再取得 → Real 集計の順に結線されている")
    void runOnce_wiresPreDeleteThenCollectThenRealEvaluation() throws Exception {
        StepContribution contribution = mock(StepContribution.class, RETURNS_DEEP_STUBS);
        Date targetDate = new Date();

        composition.runOnce(contribution, targetDate);

        // 工程順: [G-A] 集計元の事前削除 → 集計元の再取得 → Real 集計（ファイル出力まで到達）
        InOrder order = inOrder(posSumSourceRepository, fileWriter);
        order.verify(posSumSourceRepository).delete(any());
        order.verify(posSumSourceRepository, atLeastOnce()).getPosSumSourceDataAll(any());
        order.verify(fileWriter).writeSpotSumFile(any(), anyString(), eq(EvaluationRateKbn.REAL.getCode()), any());

        // Real 集計の仕分けと DF 入力の取得が行われている
        verify(splitter).splitForReal(any(), any(), any());
        verify(dfCalcResultRepository).getTDfCalcResultBeanAll(any(), any());
    }

    @Test
    @DisplayName("引値レートファイルが無い場合、[G-E] ガードにより引値チェーンは実行されない")
    void runOnce_withoutCloseRates_skipsClosingChain() throws Exception {
        StepContribution contribution = mock(StepContribution.class, RETURNS_DEEP_STUBS);

        composition.runOnce(contribution, new Date());

        verify(spotClosingRateResolver, never()).resolve(any(), any(), any(), any());
        verify(splitter, never()).splitForPreClosing(any(), any(), any());
        verify(plDeltaRepository, never()).getTPositionPlDeltaDataBeanAll(any());
        verify(closingSpotSourceLoader, never()).loadClosingSpotResults(any());
    }

    private void inject(String fieldName, Object value) throws Exception {
        Field field = PositionSummaryComposition.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(composition, value);
    }
}
