package jp.co.daiwa.jbpos1100.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * {@link BigDecimalSummer} の単体テスト（外部依存なし）。
 */
class BigDecimalSummerTest {

    @Test
    @DisplayName("sumNonNull はリストの値を合計する")
    void sumNonNull_addsAllValues() {
        List<BigDecimal> list = Arrays.asList(new BigDecimal("1.5"), new BigDecimal("2.5"), new BigDecimal("3"));

        BigDecimal result = BigDecimalSummer.sumNonNull(list, v -> v);

        assertThat(result).isEqualByComparingTo("7.0");
    }

    @Test
    @DisplayName("sumNonNull は空リストでゼロを返す")
    void sumNonNull_emptyList_returnsZero() {
        BigDecimal result = BigDecimalSummer.sumNonNull(Collections.<BigDecimal>emptyList(), v -> v);

        assertThat(result).isEqualByComparingTo(BigDecimal.ZERO);
    }

    @Test
    @DisplayName("sumNullSafe は null 要素を 0 として扱う")
    void sumNullSafe_treatsNullAsZero() {
        List<BigDecimal> list = Arrays.asList(new BigDecimal("10"), null, new BigDecimal("5"));

        BigDecimal result = BigDecimalSummer.sumNullSafe(list, v -> v);

        assertThat(result).isEqualByComparingTo("15");
    }
}
