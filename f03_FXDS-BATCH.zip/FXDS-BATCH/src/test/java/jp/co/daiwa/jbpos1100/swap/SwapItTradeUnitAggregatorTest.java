package jp.co.daiwa.jbpos1100.swap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * {@link SwapItTradeUnitAggregator} の単体テスト。
 * Map.put 戻り値バグ修正後の通貨単位ネットと、NULL 金額時に NPE にならないことを検証する。
 */
class SwapItTradeUnitAggregatorTest {

    private SwapItTradeUnitAggregator aggregator;

    @BeforeEach
    void setUp() {
        aggregator = new SwapItTradeUnitAggregator(mock(JobWarningReporter.class));
    }

    @Test
    @DisplayName("売買通貨側はネット金額で約定済CF行が作られる")
    void aggregate_netsDealSide() {
        TPosSumSourceDataBean buy = row("USD", "JPY", "1", new BigDecimal("100"), new BigDecimal("-15000"));

        List<TPosSumSourceDataBean> result = aggregator.aggregate(Collections.singletonList(buy));

        TPosSumSourceDataBean usdRow = result.stream()
                .filter(r -> "USD".equals(r.getDealCurrency())).findFirst().orElseThrow(AssertionError::new);
        assertThat(usdRow.getExchangeDivision()).isEqualTo("4");
        assertThat(usdRow.getCurrencyPair()).isEqualTo("USDJPY");
        assertThat(usdRow.getDealDivision()).isEqualTo("1");
        assertThat(usdRow.getDealAmount()).isEqualByComparingTo("100");
        assertThat(usdRow.getSettleAmount()).isEqualByComparingTo("0");
    }

    @Test
    @DisplayName("NULL金額の通貨があってもNPEにならず0扱いになる（Map.putバグ回帰）")
    void aggregate_nullAmount_noNpe() {
        TPosSumSourceDataBean nullSettle = row("USD", "JPY", "1", new BigDecimal("100"), null);

        // 例外なく完了し、結果が返ること（旧実装は put が null を返し NPE）
        List<TPosSumSourceDataBean> result = aggregator.aggregate(Collections.singletonList(nullSettle));

        assertThat(result).isNotEmpty();
    }

    private TPosSumSourceDataBean row(String dealCcy, String settleCcy, String dealDivision,
            BigDecimal dealAmount, BigDecimal settleAmount) {
        TPosSumSourceDataBean bean = new TPosSumSourceDataBean();
        bean.setDealerBook("BOOK1");
        bean.setDealCurrency(dealCcy);
        bean.setSettleCurrency(settleCcy);
        bean.setCurrencyPair(dealCcy + settleCcy);
        bean.setDealDivision(dealDivision);
        bean.setDealAmount(dealAmount);
        bean.setSettleAmount(settleAmount);
        bean.setDeliveryDate(new java.util.Date(1_700_000_000_000L));
        bean.setTradeDatetime(new Timestamp(1_700_000_000_000L));
        bean.setExchangeDivision("1");
        bean.setAc("0");
        bean.setInputDataSource("FXDS");
        return bean;
    }
}
