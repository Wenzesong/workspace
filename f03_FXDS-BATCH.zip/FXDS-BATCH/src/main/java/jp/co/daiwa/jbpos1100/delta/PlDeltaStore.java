package jp.co.daiwa.jbpos1100.delta;

import java.util.List;

import jp.co.daiwa.dao.TPositionPlDeltaDataRepository;
import jp.co.daiwa.dao.bean.TPositionPlDeltaDataBean;
import jp.co.daiwa.common.db.TransactionalBatchExecutor;

/**
 * 決済通貨外貨 PL デルタ生成情報テーブルの永続化（中間コミット）クラス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#posPlDeltaDataDelete} / {@code insertPosPlDeltaData} を
 * {@link TransactionalBatchExecutor} へ委譲したもの。</p>
 */
public class PlDeltaStore {

    private static final String LABEL_DELETE = "決済通貨外貨PLデルタ生成情報削除処理";
    private static final String LABEL_INSERT = "決済通貨外貨PLデルタ生成情報登録処理";

    private final TPositionPlDeltaDataRepository repository;
    private final TransactionalBatchExecutor executor;
    private final int bulkInsertUnit;

    public PlDeltaStore(TPositionPlDeltaDataRepository repository, TransactionalBatchExecutor executor,
            int bulkInsertUnit) {
        this.repository = repository;
        this.executor = executor;
        this.bulkInsertUnit = bulkInsertUnit;
    }

    public void delete(TPositionPlDeltaDataBean condition) throws Exception {
        executor.runInNewTransaction(LABEL_DELETE, () -> repository.delete(condition));
    }

    public void insert(List<TPositionPlDeltaDataBean> items) throws Exception {
        executor.bulkInsertWithRetry(LABEL_INSERT, items, bulkInsertUnit, repository::insert);
    }
}
