package jp.co.daiwa.jbpos1100.delta;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.jbpos1100.common.BigDecimalSummer;
import jp.co.daiwa.common.db.DbConnectionFailures;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * 通貨別デルタ・キャッシュ残情報の集計を担うクラス。
 *
 * <p>旧 {@code Jbpos1000SwapSummary#mkByCcyDeltaCashBalance} を、継承（旧クラスは
 * {@code Jbpos1000PosSumTasklet} を継承していた）ではなく独立した集計クラスへ切り出し、
 * 通貨単位の集計ロジックを {@link #calculateForKey} に分割してテスト容易にする。</p>
 *
 * <h2>[Fixed P0] Map.put の戻り値（旧値）を計算に使用していた不具合</h2>
 * <p>旧コードはデルタ／キャッシュ残を以下のように算出していた:</p>
 * <pre>
 *   delta = totaldealAmountPvClsMap.put(key, sumTradeAmountPvCls)   // ← put は「直前の値」を返す
 *             .add(totaldealAmountPvMap.put(key, sumTradeAmountPv))
 *             .add(totalsettleAmountPvMap.put(key, sumSettleAmountPv));
 * </pre>
 * <p>{@link Map#put} は「新しい値」ではなく「直前の値」を返す。各 Map はループ内で
 * 都度 new されるため初回 put は必ず null を返し、{@code null.add(...)} で NPE となる
 * （＝デルタ算出が常に失敗し警告に落ちる）。本クラスでは集計済みのローカル値を直接
 * 加算する正しい実装に修正している。これに伴い、書き込み専用で読まれなくなった
 * 一時 Map 群（{@code totaldealAmountPvClsMap} 等）は不要となるため削除した。</p>
 */
public class CurrencyDeltaCashCalculator {

    private static final LogBatchBasedLogger logger =
            LogBatchBasedLogger.getLogger(CurrencyDeltaCashCalculator.class);
    private static final String LABEL = "通貨別デルタ・キャッシュ残情報集計処理";

    private final JobWarningReporter warningReporter;

    /**
     * @param warningReporter 警告レポータ
     */
    public CurrencyDeltaCashCalculator(JobWarningReporter warningReporter) {
        this.warningReporter = warningReporter;
    }

    /**
     * 通貨別デルタ・キャッシュ残情報を集計する。
     *
     * @param contribution        ステップ実行コンテキスト（DB 切断時の終了判定用）
     * @param targetDate          基準日
     * @param evaluationRateKbn   評価レート区分コード
     * @param evaluationRateName  評価レート区分名（ログ用）
     * @param positionSwapSumData スワップ集計結果
     * @param positionSourceList  ポジション集計元情報
     * @return 通貨別デルタ・キャッシュ残情報リスト
     * @throws Exception DB 切断由来の例外
     */
    public List<TByCcyDeltaCashBalanceBean> calculate(StepContribution contribution, java.util.Date targetDate,
            String evaluationRateKbn, String evaluationRateName,
            List<TPositionSwapSumDataBean> positionSwapSumData,
            List<TPosSumSourceDataBean> positionSourceList) throws Exception {

        List<TByCcyDeltaCashBalanceBean> result = new ArrayList<>();

        // 集計キー: ディーラブック, 通貨
        Map<String, List<TPositionSwapSumDataBean>> sumMap = positionSwapSumData.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getCurrency()));

        // 前日日締めで作成されたスタートポジション（約定済 CF）
        List<TPosSumSourceDataBean> startPositionList = positionSourceList.stream()
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                .filter(d -> d.getSeqNo().equals(BigDecimal.ZERO)
                        && BatchConstants.EXCHANGE_DIVISION_TRADED_CF.equals(d.getExchangeDivision()))
                .collect(Collectors.toList());

        for (Map.Entry<String, List<TPositionSwapSumDataBean>> entry : sumMap.entrySet()) {
            try {
                TByCcyDeltaCashBalanceBean bean = calculateForKey(targetDate, evaluationRateKbn, evaluationRateName,
                        entry.getKey(), entry.getValue(), startPositionList);
                result.add(bean);
            } catch (Exception e) {
                if (DbConnectionFailures.isDisconnect(e)) {
                    logger.error(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_E001", "DB接続", e);
                    throw e;
                }
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", LABEL,
                        entry.getKey(), e);
                warningReporter.markJobWarning();
            }
        }
        return result;
    }

    /**
     * 1 集計キー（ディーラブック・通貨）分のデルタ・キャッシュ残を算出する。
     *
     * @param targetDate         基準日
     * @param evaluationRateKbn  評価レート区分コード
     * @param evaluationRateName 評価レート区分名（警告用）
     * @param dealerBookCcyKey   "ディーラブック,通貨" 形式のキー
     * @param swapSumGroup       当該キーのスワップ集計結果
     * @param startPositionList  当該基準日のスタートポジション
     * @return 通貨別デルタ・キャッシュ残情報 Bean
     */
    private TByCcyDeltaCashBalanceBean calculateForKey(java.util.Date targetDate, String evaluationRateKbn,
            String evaluationRateName, String dealerBookCcyKey, List<TPositionSwapSumDataBean> swapSumGroup,
            List<TPosSumSourceDataBean> startPositionList) {

        String[] split = dealerBookCcyKey.split(",");
        String dealerBook = split[0];
        String currency = split[1];

        List<TPosSumSourceDataBean> startPositionGroup = startPositionList.stream()
                .filter(e -> e.getDealerBook().equals(dealerBook))
                .filter(e -> e.getDealCurrency().equals(currency))
                .collect(Collectors.toList());

        // NULL 有無判定（いずれかが NULL の場合は当該集計値を未確定とする）
        boolean hasDealAmountNull = anyNull(swapSumGroup, TPositionSwapSumDataBean::getDealAmount);
        boolean hasSettleAmountNull = anyNull(swapSumGroup, TPositionSwapSumDataBean::getSettleAmount);
        boolean hasTradePvNull = anyNull(swapSumGroup, TPositionSwapSumDataBean::getTradeAmountPv);
        boolean hasTradePvClsNull = anyNull(swapSumGroup, TPositionSwapSumDataBean::getTradeAmountPvCls);
        boolean hasSettlePvNull = anyNull(swapSumGroup, TPositionSwapSumDataBean::getSettleAmountPv);
        boolean hasBeforeTradePvClsNull = anyNull(startPositionGroup, TPosSumSourceDataBean::getBeforeTradeAmountPvCls);

        // 各 PV の集計（NULL を含む場合は対応する判定フラグで未確定にする）
        // 旧 mkByCcyDeltaCashBalance は NULL チェックで集計をゲートし、NULL 時は集計せず ZERO 据置で
        // delta=null とする（行は必ず生成）。ここでは sumNullSafe を用いて同一の観測挙動を保ちつつ、
        // NULL 要素による NPE を回避する（NULL 時の集計値は resolveDelta が null を返すため未使用）。
        BigDecimal sumTradeAmountPvCls = BigDecimalSummer.sumNullSafe(swapSumGroup,
                TPositionSwapSumDataBean::getTradeAmountPvCls);
        BigDecimal sumTradeAmountPv = BigDecimalSummer.sumNullSafe(swapSumGroup,
                TPositionSwapSumDataBean::getTradeAmountPv);
        BigDecimal sumSettleAmountPv = BigDecimalSummer.sumNullSafe(swapSumGroup,
                TPositionSwapSumDataBean::getSettleAmountPv);
        BigDecimal sumBeforeTradeAmountPvCls = BigDecimalSummer.sumNullSafe(startPositionGroup,
                TPosSumSourceDataBean::getBeforeTradeAmountPvCls);

        TByCcyDeltaCashBalanceBean bean = new TByCcyDeltaCashBalanceBean();
        bean.setProcessBaseDate(targetDate);
        bean.setEvaluationRateDivision(evaluationRateKbn);
        bean.setDealerBook(dealerBook);
        bean.setCurrency(currency);

        // ---- デルタ算出 [Fixed P0] ローカル集計値を直接加算（旧: Map.put の戻り値=旧値を加算し NPE） ----
        BigDecimal delta = resolveDelta(evaluationRateKbn, hasTradePvNull, hasTradePvClsNull, hasSettlePvNull,
                hasBeforeTradePvClsNull, sumTradeAmountPvCls, sumTradeAmountPv, sumSettleAmountPv,
                sumBeforeTradeAmountPvCls);
        bean.setDelta(delta);
        if (delta == null) {
            warningReporter.warn(LABEL, "評価レート区分:" + evaluationRateName + ",ディーラブック:" + dealerBook
                    + ",通貨:" + currency + " のNULLデータが存在したため、デルタの計算エラー");
        }

        // ---- キャッシュ残算出（基準日に受渡が発生したもののみ）----
        List<TPositionSwapSumDataBean> deliveredToday = swapSumGroup.stream()
                .filter(e -> e.getDeliveryDate().equals(targetDate))
                .collect(Collectors.toList());
        if (!deliveredToday.isEmpty()) {
            BigDecimal sumDealAmount = hasDealAmountNull ? BigDecimal.ZERO
                    : BigDecimalSummer.sumNonNull(deliveredToday, TPositionSwapSumDataBean::getDealAmount);
            BigDecimal sumSettleAmount = hasSettleAmountNull ? BigDecimal.ZERO
                    : BigDecimalSummer.sumNonNull(deliveredToday, TPositionSwapSumDataBean::getSettleAmount);
            // [Fixed P0] 旧: totaldealAmountMap.put(key, sumdealAmount).add(totalsettleAmountMap.put(...))
            bean.setCashBalance(sumDealAmount.add(sumSettleAmount));
        }
        // deliveredToday が空の場合はキャッシュ残を設定しない（旧挙動: 既存値据え置き）

        bean.setRegisterUser(JobConstants.Jbpos1000);
        bean.setUpdateUser(JobConstants.Jbpos1000);
        return bean;
    }

    /**
     * 評価レート区分に応じてデルタを算出する。NULL 要素を含む場合は null を返す。
     *
     * @return デルタ値（未確定の場合 null）
     */
    private BigDecimal resolveDelta(String evaluationRateKbn, boolean hasTradePvNull, boolean hasTradePvClsNull,
            boolean hasSettlePvNull, boolean hasBeforeTradePvClsNull, BigDecimal sumTradeAmountPvCls,
            BigDecimal sumTradeAmountPv, BigDecimal sumSettleAmountPv, BigDecimal sumBeforeTradeAmountPvCls) {

        if (evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
            // 引値以降: 取引金PV(引値) + 取引金PV + 決済金PV
            if (hasTradePvNull || hasTradePvClsNull || hasSettlePvNull) {
                return null;
            }
            return sumTradeAmountPvCls.add(sumTradeAmountPv).add(sumSettleAmountPv);
        }
        // 引値以降以外: 前日約定済CFの取引金PV(引値) + 取引金PV + 決済金PV
        if (hasBeforeTradePvClsNull || hasTradePvNull || hasSettlePvNull) {
            return null;
        }
        return sumBeforeTradeAmountPvCls.add(sumTradeAmountPv).add(sumSettleAmountPv);
    }

    private <T> boolean anyNull(List<T> list, java.util.function.Function<T, BigDecimal> getter) {
        return list.stream().anyMatch(e -> getter.apply(e) == null);
    }
}
