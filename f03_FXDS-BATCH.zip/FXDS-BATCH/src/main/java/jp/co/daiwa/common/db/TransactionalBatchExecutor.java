package jp.co.daiwa.common.db;

import java.util.ArrayList;
import java.util.List;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

/**
 * 中間コミット（PROPAGATION_REQUIRES_NEW）の定型処理を共通化するテンプレートクラス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet} / {@code Jbpos1000SwapSummary} では
 * delete/insert/update の各メソッドで以下のパターンが約 14 箇所重複していた:</p>
 * <pre>
 *   DefaultTransactionDefinition def = new DefaultTransactionDefinition();
 *   def.setPropagationBehavior(PROPAGATION_REQUIRES_NEW);
 *   TransactionStatus status = null;
 *   try {
 *       status = txManager.getTransaction(def);
 *       ...DB操作...
 *       txManager.commit(status);
 *   } catch (Exception e) {
 *       if (DB切断) throw e;       // 終了
 *       logger.warn(...); rollback; ジョブ警告状態設定;
 *   }
 * </pre>
 *
 * <p>このクラスは「実行する DB 操作」を {@link DbWork} / {@link BatchInsert} で受け取り、
 * トランザクション境界・ロールバック・DB 切断時の再スロー・警告状態設定を一手に担う。
 * 「一括 INSERT 失敗時に 1 件ずつ再 INSERT する」リトライロジックも共通化する。</p>
 *
 * <p>依存はコンストラクタ injection で受け取り、{@link PlatformTransactionManager} を
 * モックに差し替えて JUnit で検証できる設計とする。</p>
 */
public class TransactionalBatchExecutor {

    private final PlatformTransactionManager transactionManager;
    private final JobWarningReporter warningReporter;

    /**
     * @param transactionManager トランザクションマネージャ
     * @param warningReporter    警告状態レポータ（1 実行あたり 1 インスタンス）
     */
    public TransactionalBatchExecutor(PlatformTransactionManager transactionManager,
            JobWarningReporter warningReporter) {
        this.transactionManager = transactionManager;
        this.warningReporter = warningReporter;
    }

    /**
     * 単一の DB 操作を新規トランザクションで実行し中間コミットする。
     *
     * <p>delete / update / 単発 insert 用。DB 切断由来の例外は呼び出し元へ再スローし、
     * それ以外の例外はロールバックのうえ警告状態を設定して握る（旧挙動を踏襲）。</p>
     *
     * @param processLabel 処理名（ログ用）
     * @param work         実行する DB 操作
     * @throws Exception DB 切断由来の例外
     */
    public void runInNewTransaction(String processLabel, DbWork work) throws Exception {
        DefaultTransactionDefinition definition = newRequiresNewDefinition();
        TransactionStatus status = null;
        try {
            status = transactionManager.getTransaction(definition);
            work.execute();
            transactionManager.commit(status);
        } catch (Exception e) {
            rollbackQuietly(status);
            if (DbConnectionFailures.isDisconnect(e)) {
                // DB 切断時は処理終了させるため再スロー
                throw e;
            }
            warningReporter.warn(processLabel, e);
        }
    }

    /**
     * リストを {@code bulkUnit} 件ずつ一括 INSERT する。チャンク失敗時は 1 件ずつ再 INSERT する。
     *
     * <p>旧 {@code posSumSourceDataInsert} / {@code spotSumDataInsert} 等の
     * 「バルク INSERT → 失敗したら 1 件ずつ INSERT し直す」リトライ構造を共通化したもの。</p>
     *
     * @param processLabel 処理名（ログ用）
     * @param items        登録対象（null/空なら何もしない）
     * @param bulkUnit     1 回の一括 INSERT 件数
     * @param insert       INSERT 操作
     * @param <T>          Bean 型
     * @throws Exception DB 切断由来の例外
     */
    public <T> void bulkInsertWithRetry(String processLabel, List<T> items, int bulkUnit, BatchInsert<T> insert)
            throws Exception {
        if (items == null || items.isEmpty()) {
            return;
        }
        DefaultTransactionDefinition definition = newRequiresNewDefinition();
        for (List<T> chunk : ListPartitioner.partition(items, bulkUnit)) {
            TransactionStatus status = null;
            try {
                status = transactionManager.getTransaction(definition);
                insert.insert(chunk);
                transactionManager.commit(status);
            } catch (Exception e) {
                rollbackQuietly(status);
                if (DbConnectionFailures.isDisconnect(e)) {
                    throw e;
                }
                // チャンク失敗時は 1 件ずつ再 INSERT
                insertOneByOne(definition, chunk, insert);
                warningReporter.warn(processLabel, e);
            }
        }
    }

    /**
     * チャンク INSERT 失敗後の 1 件ずつ再 INSERT。
     *
     * @param definition トランザクション定義
     * @param chunk      対象チャンク
     * @param insert     INSERT 操作
     * @param <T>        Bean 型
     * @throws Exception DB 切断由来の例外
     */
    private <T> void insertOneByOne(TransactionDefinition definition, List<T> chunk, BatchInsert<T> insert)
            throws Exception {
        for (T bean : chunk) {
            TransactionStatus status = null;
            try {
                List<T> single = new ArrayList<>(1);
                single.add(bean);
                status = transactionManager.getTransaction(definition);
                insert.insert(single);
                transactionManager.commit(status);
            } catch (Exception ex) {
                rollbackQuietly(status);
                if (DbConnectionFailures.isDisconnect(ex)) {
                    throw ex;
                }
                // 1 件単位の失敗は当該レコードを諦め継続（旧挙動を踏襲）
            }
        }
    }

    private DefaultTransactionDefinition newRequiresNewDefinition() {
        DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
        definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        return definition;
    }

    /**
     * status が取得できている場合のみロールバックする。
     *
     * <p>[Fixed P1] 旧コードは getTransaction 失敗時に status が null のまま
     * rollback(status) を呼び NPE になり得た。null ガードを共通化。</p>
     *
     * @param status トランザクションステータス（null 可）
     */
    private void rollbackQuietly(TransactionStatus status) {
        if (status != null) {
            transactionManager.rollback(status);
        }
    }
}
