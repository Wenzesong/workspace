package jp.co.daiwa.jbpos1100.common;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Function;

/**
 * {@link BigDecimal} のリスト合計ユーティリティ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#sumBigDecimal} を、継承で共有するのではなく
 * 独立クラスとして提供する。null 要素を 0 として扱う安全合計も用意する。</p>
 */
public final class BigDecimalSummer {

    private BigDecimalSummer() {
    }

    /**
     * リストの各要素を {@code mapper} で {@link BigDecimal} に変換して合計する（<b>NULL 非許容</b>）。
     *
     * <p>旧 {@code sumBigDecimal} と同一挙動（要素が null を返すと NPE）。呼び出し側で NULL 有無を
     * 判定済み（{@code anyNull} ガード・非 null フィルタ等）の「確定値の合計」専用。NULL を取り得る
     * 集計には {@link #sumNullSafe} を使用すること。</p>
     *
     * <p>[I-1] 旧名 {@code sum} は NULL 非許容であることが名前から読み取れず、{@code sumNullSafe} との
     * 取り違え（H-3 の NPE）を誘発したため、契約を名前に明示した。</p>
     *
     * @param list   対象リスト（各要素の変換結果は非 null であること）
     * @param mapper 要素 → BigDecimal 変換関数
     * @param <T>    要素型
     * @return 合計値（空リストなら {@link BigDecimal#ZERO}）
     */
    public static <T> BigDecimal sumNonNull(List<T> list, Function<T, BigDecimal> mapper) {
        return list.stream().map(mapper).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * null 値を 0 とみなして安全に合計する。
     *
     * @param list   対象リスト
     * @param mapper 要素 → BigDecimal 変換関数
     * @param <T>    要素型
     * @return 合計値（空リスト・全 null なら {@link BigDecimal#ZERO}）
     */
    public static <T> BigDecimal sumNullSafe(List<T> list, Function<T, BigDecimal> mapper) {
        return list.stream()
                .map(mapper)
                .map(v -> v == null ? BigDecimal.ZERO : v)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
