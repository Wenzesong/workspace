package jp.co.daiwa.jbpos1100.swap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.TPositionSwapSumDataDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.common.db.DbConnectionFailures;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * ポジションスワップ集計（CF 単位）の各 PV を算出して {@link TPositionSwapSumDataDto} を組み立てるクラス。
 *
 * <p>旧 {@code Jbpos1000SwapSummary#getTPosCashSumData}（破損なし・約500行の単一メソッド）の移植版。
 * <b>計算式・符号・丸め（HALF_UP, scale=2）・条件分岐・警告ログは一切変更せず</b>、
 * 1 メソッドに凝集していたロジックを「PV 項目ごとの段階メソッド」へ分割して 500 行制約と
 * テスト容易性を満たす。各段階メソッドは DTO を順に更新する（旧コードと同じ逐次依存を維持）。</p>
 *
 * <p>項目単位の計算エラーは警告ログのみ（ジョブ警告状態は立てない＝旧挙動）。
 * 例外時のみ {@link JobWarningReporter} でジョブ警告状態を設定する。</p>
 */
public class SwapCashSumAssembler {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(SwapCashSumAssembler.class);
    private static final String CALC_LABEL = "ポジションスワップ集計";
    private static final int SCALE = 2;

    private final JobWarningReporter warningReporter;

    /**
     * @param warningReporter 警告レポータ
     */
    public SwapCashSumAssembler(JobWarningReporter warningReporter) {
        this.warningReporter = warningReporter;
    }

    /**
     * ポジションスワップ集計（CF 単位）を組み立てる。
     *
     * @param targetDate         基準日
     * @param sourceList         スワップ対象の集計元データ
     * @param dfCalcResult       DF 算出結果
     * @param dfHistory          DF 履歴情報
     * @param evaluationRateKbn  評価レート区分コード
     * @param evaluationRateName 評価レート区分名（ログ用）
     * @return スワップ集計 DTO リスト
     * @throws Exception DB 切断由来の例外
     */
    public List<TPositionSwapSumDataDto> assemble(Date targetDate, List<TPosSumSourceDataBean> sourceList,
            List<TDfCalcResultBean> dfCalcResult, List<TDfHistoryDateBean> dfHistory,
            String evaluationRateKbn, String evaluationRateName) throws Exception {

        List<TPositionSwapSumDataDto> result = new ArrayList<>();

        List<TPosSumSourceDataBean> sortedList = sourceList.stream()
                .sorted(Comparator.comparing(TPosSumSourceDataBean::getDealerBook)
                        .thenComparing(TPosSumSourceDataBean::getCurrencyPair))
                .collect(Collectors.toList());

        for (TPosSumSourceDataBean item : sortedList) {
            try {
                result.add(buildDto(targetDate, item, dfCalcResult, dfHistory, evaluationRateKbn, evaluationRateName));
            } catch (Exception e) {
                if (DbConnectionFailures.isDisconnect(e)) {
                    logger.error(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_E001", "DB接続", e);
                    throw e;
                }
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", "ポジションスワップ集計処理 ",
                        "評価レート区分:" + evaluationRateName + "," + item.getDealerBook() + "," + item.getCurrencyPair(),
                        e);
                warningReporter.markJobWarning();
            }
        }
        return result;
    }

    /**
     * 1 件分の DTO を組み立てる。PV 項目ごとの段階メソッドを順に呼び出し、逐次依存を維持する。
     */
    private TPositionSwapSumDataDto buildDto(Date targetDate, TPosSumSourceDataBean item,
            List<TDfCalcResultBean> dfCalcResult, List<TDfHistoryDateBean> dfHistory,
            String evaluationRateKbn, String evaluationRateName) {

        String deliveryDateYmd = new SimpleDateFormat(BatchConstants.DATE_PATTERN_SLASH).format(item.getDeliveryDate());
        TPositionSwapSumDataDto dto = new TPositionSwapSumDataDto();

        DfFactors df = lookupDfFactors(item, targetDate, dfCalcResult, dfHistory);

        applyAmountsAndHeader(dto, item, targetDate, evaluationRateKbn);
        applyTradeAmountPvCls(dto, item, df, evaluationRateName, deliveryDateYmd);
        applyTradeAmountPv(dto, item, df, evaluationRateKbn, evaluationRateName, deliveryDateYmd);
        applyTradeAmountPvYen(dto, item, evaluationRateKbn, evaluationRateName);
        applyTradeAmountPvEva(dto, item, evaluationRateKbn, evaluationRateName);
        applyTradeAmountPvEvaYen(dto, item, evaluationRateKbn, evaluationRateName);
        applySettleAmountPv(dto, item, df, evaluationRateKbn, evaluationRateName, deliveryDateYmd);
        applySettleAmountPvYen(dto, item, evaluationRateKbn, evaluationRateName);
        applyPlAndFinalRates(dto, item, evaluationRateKbn);
        return dto;
    }

    /** 売買金額・決済金額（符号反転）とヘッダ項目を設定する。 */
    private void applyAmountsAndHeader(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item, Date targetDate,
            String evaluationRateKbn) {
        boolean buy = BatchConstants.DEAL_DIVISION_BUY.equals(item.getDealDivision());
        dto.setDealAmount(buy ? item.getDealAmount() : item.getDealAmount().negate());
        dto.setSettleAmount(buy ? item.getSettleAmount() : item.getSettleAmount().negate());

        dto.setProcessBaseDate(targetDate);
        dto.setDealerBook(item.getDealerBook());
        dto.setEvaluationRateDivision(evaluationRateKbn);
        dto.setCurrencyPair(item.getCurrencyPair());
        dto.setExchangeDivision(item.getExchangeDivision().substring(0, 1));
        dto.setDeliveryDate(item.getDeliveryDate());
        dto.setSettleYenRate(item.getRealYenRate());
    }

    /** 取引金PV(引値)・同円転を設定する（約定済CF＆スタートは前日値、約定済CF＆非スタートはDF履歴、その他は0）。 */
    private void applyTradeAmountPvCls(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item, DfFactors df,
            String evaluationRateName, String deliveryDateYmd) {
        boolean tradedCf = isTradedCf(item);
        boolean startPosition = item.getSeqNo().compareTo(BigDecimal.ZERO) == 0;

        if (tradedCf && startPosition) {
            dto.setTradeAmountPvCls(item.getBeforeTradeAmountPvCls());
            dto.setTradeAmountPvClsYen(item.getBeforeTradeAmountPvClsYen());
            return;
        }
        if (tradedCf) {
            BigDecimal pvCls;
            if (df.dealHistory != null && df.dealHistory.getDiscountFactor() != null) {
                pvCls = dto.getDealAmount().multiply(df.dealHistory.getDiscountFactor()).setScale(SCALE, RoundingMode.HALF_UP);
            } else {
                pvCls = null;
                logCalcWarn("評価レート区分:" + evaluationRateName + ",通貨:" + item.getDealCurrency() + ",受渡日:"
                        + deliveryDateYmd + ",DF履歴情報のディスカウントファクターが取得できなかったため、取引金PV(引値)の計算エラー");
            }
            dto.setTradeAmountPvCls(pvCls);
            dto.setTradeAmountPvClsYen(resolveTradeAmountPvClsYen(dto, item, evaluationRateName));
            return;
        }
        dto.setTradeAmountPvCls(BigDecimal.ZERO);
        dto.setTradeAmountPvClsYen(BigDecimal.ZERO);
    }

    /** 取引金PV(引値)円転を求める（約定済CF＆非スタート用）。 */
    private BigDecimal resolveTradeAmountPvClsYen(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item,
            String evaluationRateName) {
        if (dto.getTradeAmountPvCls() == null) {
            return null;
        }
        if (BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency())) {
            if (item.getClosingYenRate() != null) {
                return dto.getTradeAmountPvCls().multiply(item.getClosingYenRate()).setScale(SCALE, RoundingMode.HALF_UP);
            }
            logCalcWarn("評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                    + ":引値円転レートが取得できなかったため、取引金PV(引値)円転の計算エラー");
            return null;
        }
        return dto.getTradeAmountPvCls();
    }

    /** 取引金PVを設定する（Real/引値以降はDF算出結果、それ以外はDF履歴）。 */
    private void applyTradeAmountPv(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item, DfFactors df,
            String evaluationRateKbn, String evaluationRateName, String deliveryDateYmd) {
        BigDecimal pv;
        if (isRealOrAfterClosing(evaluationRateKbn)) {
            if (df.dealCalc != null && df.dealCalc.getDiscountFactor() != null) {
                pv = dto.getDealAmount().multiply(df.dealCalc.getDiscountFactor()).setScale(SCALE, RoundingMode.HALF_UP);
            } else {
                pv = null;
                logCalcWarn("評価レート区分:" + evaluationRateName + ",通貨:" + item.getDealCurrency() + ",受渡日:"
                        + deliveryDateYmd + ",DF算出結果のディスカウントファクターが取得できなかったため、取引金PVの計算エラー");
            }
        } else {
            if (df.dealHistory != null && df.dealHistory.getDiscountFactor() != null) {
                pv = dto.getDealAmount().multiply(df.dealHistory.getDiscountFactor()).setScale(SCALE, RoundingMode.HALF_UP);
            } else {
                pv = null;
                logCalcWarn("評価レート区分:" + evaluationRateName + ",通貨:" + item.getDealCurrency() + ",受渡日:"
                        + deliveryDateYmd + ",DF履歴情報のディスカウントファクターが取得できなかったため、取引金PVの計算エラー");
            }
        }
        dto.setTradeAmountPv(pv);
    }

    /** 取引金PV円転（約定済CFのみ）を設定し、引値区分の場合は取引金PV(引値)とその円転も上書きする。 */
    private void applyTradeAmountPvYen(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item,
            String evaluationRateKbn, String evaluationRateName) {
        if (!isTradedCf(item)) {
            return;
        }
        BigDecimal pvYen;
        if (BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency()) && dto.getTradeAmountPv() != null) {
            if (evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
                pvYen = multiplyOrWarn(dto.getTradeAmountPv(), item.getClosingYenRate(),
                        "評価レート区分:," + evaluationRateName + item.getCurrencyPair()
                                + ":引値円転レートが取得できなかったため、取引金PV円転の計算エラー");
            } else if (hasUsableDealRate(item)) {
                if (item.getManualDailyRate() != null) {
                    pvYen = dto.getTradeAmountPv().multiply(item.getManualDailyRate()).setScale(SCALE, RoundingMode.HALF_UP);
                } else {
                    pvYen = null;
                    logCalcWarn("評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                            + ":売買円転レートが取得できなかったため、取引金PV円転の計算エラー");
                }
            } else {
                pvYen = dto.getTradeAmountPv();
            }
        } else {
            pvYen = BigDecimal.ZERO;
        }
        dto.setTradeAmountPvYen(pvYen);

        // 評価レート区分が引値の場合、取引金PV(引値)＝取引金PV として再設定
        if (evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
            dto.setTradeAmountPvCls(dto.getTradeAmountPv());
            if (dto.getTradeAmountPvCls() != null) {
                dto.setTradeAmountPvClsYen(multiplyOrWarn(dto.getTradeAmountPvCls(), item.getClosingYenRate(),
                        "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                + ":引値円転レートが取得できなかったため、取引金PV(引値)円転の計算エラー"));
            } else {
                dto.setTradeAmountPvClsYen(null);
            }
        }
    }

    /** 取引金PV評価換算を設定する（約定済CFは0、それ以外はマニュアル/ST/BBG/引値で換算）。 */
    private void applyTradeAmountPvEva(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item,
            String evaluationRateKbn, String evaluationRateName) {
        if (isTradedCf(item)) {
            dto.setTradeAmountPvEva(BigDecimal.ZERO);
            return;
        }
        BigDecimal pv = dto.getTradeAmountPv();
        if (pv == null) {
            dto.setTradeAmountPvEva(null);
        } else if (isRealOrAfterClosing(evaluationRateKbn)) {
            dto.setTradeAmountPvEva(evaluateRealOrAfter(item, pv, evaluationRateName));
        } else {
            dto.setTradeAmountPvEva(evaluateClosing(item, pv, evaluationRateName));
        }
    }

    /** Real/引値以降の取引金PV評価換算（マニュアル日中→ST(Real)→BBG）。 */
    private BigDecimal evaluateRealOrAfter(TPosSumSourceDataBean item, BigDecimal pv, String evaluationRateName) {
        if (item.getManualDailyRate() != null) {
            return pv.multiply(item.getManualDailyRate()).setScale(SCALE, RoundingMode.HALF_UP);
        }
        if (BatchConstants.RATE_SOURCE_SMART.equals(item.getRateSource())) {
            return multiplyOrWarn(pv, item.getRealRate(), "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                    + ":Real評価レートが取得できなかったため、取引金PV評価換算の計算エラー");
        }
        if (BatchConstants.RATE_SOURCE_BBG.equals(item.getRateSource())) {
            return multiplyOrWarn(pv, item.getBbgRate(), "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                    + ":BBGレートが取得できなかったため、取引金PV評価換算の計算エラー");
        }
        return BigDecimal.ZERO;
    }

    /** 引値区分の取引金PV評価換算（マニュアル引値TTM→引値レート）。 */
    private BigDecimal evaluateClosing(TPosSumSourceDataBean item, BigDecimal pv, String evaluationRateName) {
        if (item.getManualClosingTtmRate() != null) {
            return pv.multiply(item.getManualClosingTtmRate()).setScale(SCALE, RoundingMode.HALF_UP);
        }
        return multiplyOrWarn(pv, item.getClosingRate(), "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                + ":引値評価レートが取得できなかったため、取引金PV評価換算の計算エラー");
    }

    /** 取引金PV評価換算円転を設定する。 */
    private void applyTradeAmountPvEvaYen(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item,
            String evaluationRateKbn, String evaluationRateName) {
        BigDecimal eva = dto.getTradeAmountPvEva();
        BigDecimal evaYen;
        if (eva == null) {
            evaYen = null;
        } else if (eva.compareTo(BigDecimal.ZERO) == 0) {
            evaYen = BigDecimal.ZERO;
        } else if (isRealOrAfterClosing(evaluationRateKbn)) {
            evaYen = multiplyOrWarn(eva, item.getRealYenRate(), "評価レート区分:" + evaluationRateName + ","
                    + item.getCurrencyPair() + ":Real円転レートが取得できなかったため、取引金PV評価換算円転の計算エラー");
        } else {
            evaYen = multiplyOrWarn(eva, item.getClosingYenRate(), "評価レート区分:" + evaluationRateName + ","
                    + item.getCurrencyPair() + ":引値評価レートが取得できなかったため、取引金PV評価換算円転の計算エラー");
        }
        dto.setTradeAmountPvEvaYen(evaYen);
    }

    /** 決済金PVを設定する（約定済CFは0、それ以外はDF算出結果/DF履歴）。 */
    private void applySettleAmountPv(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item, DfFactors df,
            String evaluationRateKbn, String evaluationRateName, String deliveryDateYmd) {
        if (isTradedCf(item)) {
            dto.setSettleAmountPv(BigDecimal.ZERO);
            return;
        }
        BigDecimal settlePv;
        if (isRealOrAfterClosing(evaluationRateKbn)) {
            if (df.settleCalc != null && df.settleCalc.getDiscountFactor() != null) {
                settlePv = dto.getSettleAmount().multiply(df.settleCalc.getDiscountFactor()).setScale(SCALE, RoundingMode.HALF_UP);
            } else {
                settlePv = null;
                logCalcWarn("評価レート区分:" + evaluationRateName + ",通貨:" + item.getSettleCurrency() + ",受渡日:"
                        + deliveryDateYmd + ",DF算出結果のディスカウントファクターが取得できなかったため、決済金PVの計算エラー");
            }
        } else {
            if (df.settleHistory != null && df.settleHistory.getDiscountFactor() != null) {
                settlePv = dto.getSettleAmount().multiply(df.settleHistory.getDiscountFactor()).setScale(SCALE, RoundingMode.HALF_UP);
            } else {
                settlePv = null;
                logCalcWarn("評価レート区分:" + evaluationRateName + ",通貨:" + item.getSettleCurrency() + ",受渡日:"
                        + deliveryDateYmd + ",DF履歴情報のディスカウントファクターが取得できなかったため、決済金PVの計算エラー");
            }
        }
        dto.setSettleAmountPv(settlePv);
    }

    /** 決済金PV円転を設定する。 */
    private void applySettleAmountPvYen(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item,
            String evaluationRateKbn, String evaluationRateName) {
        if (isTradedCf(item)) {
            dto.setSettleAmountPvYen(BigDecimal.ZERO);
            return;
        }
        BigDecimal settlePv = dto.getSettleAmountPv();
        BigDecimal settlePvYen;
        if (settlePv == null) {
            settlePvYen = null;
        } else if (BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency().trim())) {
            settlePvYen = settlePv;
        } else if (isRealOrAfterClosing(evaluationRateKbn)) {
            settlePvYen = multiplyOrWarn(settlePv, item.getRealYenRate(), "評価レート区分:" + evaluationRateName + ","
                    + item.getCurrencyPair() + "のReal円転レートが取得できなかったため、決済金PV円転の計算エラー");
        } else {
            settlePvYen = multiplyOrWarn(settlePv, item.getClosingYenRate(), "評価レート区分:" + evaluationRateName + ","
                    + item.getCurrencyPair() + "の引値円転レートが取得できなかったため、決済金PV円転の計算エラー");
        }
        dto.setSettleAmountPvYen(settlePvYen);
    }

    /** PL(円)・CF金額・最終レート群を設定する。 */
    private void applyPlAndFinalRates(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item, String evaluationRateKbn) {
        dto.setSumPlYen(resolvePlYen(dto, item, evaluationRateKbn));

        dto.setCashAmount(dto.getDealAmount().add(dto.getSettleAmount()).setScale(SCALE, RoundingMode.HALF_UP));

        if (BatchConstants.RATE_SOURCE_BBG.equals(item.getRateSource())) {
            dto.setRealRate(item.getBbgRate());
        } else {
            dto.setRealRate(item.getRealRate());
        }
        dto.setClosingRate(item.getClosingRate());
        dto.setRealYenRate(item.getRealYenRate());
        dto.setClosingYenRate(item.getClosingYenRate());
        dto.setDealYenRate(item.getRealYenRate());
        dto.setDealYenClosingRate(item.getClosingYenRate());
    }

    /** PL(円)を求める。 */
    private BigDecimal resolvePlYen(TPositionSwapSumDataDto dto, TPosSumSourceDataBean item, String evaluationRateKbn) {
        boolean startPosition = item.getSeqNo().compareTo(BigDecimal.ZERO) == 0;
        // 引値以降でない、かつスタートポジション
        if (!evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode()) && startPosition) {
            if (dto.getTradeAmountPvYen() == null || item.getBeforeTradeAmountPvClsYen() == null) {
                return null;
            }
            return dto.getTradeAmountPvYen().subtract(item.getBeforeTradeAmountPvClsYen()).setScale(SCALE, RoundingMode.HALF_UP);
        }
        if (isTradedCf(item)) {
            if (dto.getTradeAmountPvYen() == null || dto.getTradeAmountPvClsYen() == null) {
                return null;
            }
            return dto.getTradeAmountPvYen().subtract(dto.getTradeAmountPvClsYen()).setScale(SCALE, RoundingMode.HALF_UP);
        }
        if (dto.getSettleAmountPvYen() == null || dto.getTradeAmountPvEvaYen() == null) {
            return null;
        }
        return dto.getSettleAmountPvYen().subtract(dto.getTradeAmountPvEvaYen()).setScale(SCALE, RoundingMode.HALF_UP);
    }

    /** DF（算出結果・履歴）を売買通貨側／決済通貨側で取得する。 */
    private DfFactors lookupDfFactors(TPosSumSourceDataBean item, Date targetDate,
            List<TDfCalcResultBean> dfCalcResult, List<TDfHistoryDateBean> dfHistory) {
        DfFactors df = new DfFactors();
        df.dealCalc = dfCalcResult.stream()
                .filter(b -> b.getCurrency().equals(item.getDealCurrency().trim()))
                .filter(b -> b.getGridDate().equals(item.getDeliveryDate())).findFirst().orElse(null);
        df.settleCalc = dfCalcResult.stream()
                .filter(b -> b.getCurrency().equals(item.getSettleCurrency().trim()))
                .filter(b -> b.getGridDate().equals(item.getDeliveryDate())).findFirst().orElse(null);
        df.dealHistory = dfHistory.stream()
                .filter(b -> targetDate.equals(b.getBaseDate()))
                .filter(b -> b.getCurrency().equals(item.getDealCurrency().trim()))
                .filter(b -> b.getGridDate().equals(item.getDeliveryDate())).findFirst().orElse(null);
        df.settleHistory = dfHistory.stream()
                .filter(b -> targetDate.equals(b.getBaseDate()))
                .filter(b -> b.getCurrency().equals(item.getSettleCurrency().trim()))
                .filter(b -> b.getGridDate().equals(item.getDeliveryDate())).findFirst().orElse(null);
        return df;
    }

    /** 「複雑な売買円転レート利用可否」条件（旧コードの else-if 条件を踏襲）。 */
    private boolean hasUsableDealRate(TPosSumSourceDataBean item) {
        return item.getManualDailyRate() != null
                || item.getRateSource() == null
                || (BatchConstants.RATE_SOURCE_SMART.equals(item.getRateSource()) && item.getRealYenRate() != null)
                || (BatchConstants.RATE_SOURCE_BBG.equals(item.getRateSource()) && item.getBbgRate() != null);
    }

    private boolean isTradedCf(TPosSumSourceDataBean item) {
        return BatchConstants.EXCHANGE_DIVISION_TRADED_CF.equals(item.getExchangeDivision());
    }

    private boolean isRealOrAfterClosing(String evaluationRateKbn) {
        return evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode());
    }

    /** rate が非 null なら base*rate(HALF_UP,2)、null なら警告ログを出して null を返す。 */
    private BigDecimal multiplyOrWarn(BigDecimal base, BigDecimal rate, String warnDetail) {
        if (rate != null) {
            return base.multiply(rate).setScale(SCALE, RoundingMode.HALF_UP);
        }
        logCalcWarn(warnDetail);
        return null;
    }

    private void logCalcWarn(String detail) {
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", CALC_LABEL, detail);
    }

    /** DF（算出結果・履歴）の売買/決済通貨側をまとめた内部ホルダ。 */
    private static final class DfFactors {
        private TDfCalcResultBean dealCalc;
        private TDfCalcResultBean settleCalc;
        private TDfHistoryDateBean dealHistory;
        private TDfHistoryDateBean settleHistory;
    }
}
