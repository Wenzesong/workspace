package jp.co.daiwa.jbpos1100.source;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * 取得した集計元 DTO（{@link PosSumSourceDto}）を、検証のうえポジション集計元 Bean
 * （{@link TPosSumSourceDataBean}）へ変換するマッパー。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setSourceData} の移植版。旧コードは
 * {@code continue} 後に壊れた分岐が続く制御構造崩壊で破損していたため、jbpos1000 側で
 * 「ループ先頭のバリデーション・ガード節」へ再構成済み。ここではそれを独立クラス化し、
 * 検証（{@link #isValid}）と変換（{@link #toBean}）を分離してテスト容易にする。</p>
 */
public class SourceDataMapper {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(SourceDataMapper.class);
    private static final String LABEL = "ポジション集計データ取得情報";

    private final JobWarningReporter warningReporter;

    /**
     * @param warningReporter 警告レポータ
     */
    public SourceDataMapper(JobWarningReporter warningReporter) {
        this.warningReporter = warningReporter;
    }

    /**
     * 集計元 DTO を検証・変換して Bean リストを返す。必須項目欠落データは警告のうえ除外する。
     *
     * @param targetDate 基準日
     * @param sourceDtos 集計元 DTO リスト
     * @return 変換後の集計元 Bean リスト
     */
    public List<TPosSumSourceDataBean> map(Date targetDate, List<PosSumSourceDto> sourceDtos) {
        List<TPosSumSourceDataBean> result = new ArrayList<>();
        for (PosSumSourceDto item : sourceDtos) {
            if (!isValid(item)) {
                continue;
            }
            result.add(toBean(targetDate, item));
        }
        return result;
    }

    /**
     * 必須項目（約定日／ディーラブック／受渡日）を検証する。欠落時は警告ログを出し false を返す。
     *
     * @param item 集計元 DTO
     * @return 有効なら true
     */
    private boolean isValid(PosSumSourceDto item) {
        if (item.getTradeRate() == null && BatchConstants.DATA_SOURCE_BID_REAL.equals(item.getInputDataSource())) {
            warnExclude("ディーラブック:" + item.getDealerBook() + FxdConstants.COMMA
                    + "通貨ペア:" + item.getCurrencyPair() + FxdConstants.COMMA
                    + "データ源別:" + item.getInputDataSource() + FxdConstants.COMMA
                    + "の約定トレード取得情報に問題があるため処理から除外");
            return false;
        }
        if (item.getTradeRate() == null) {
            warnExclude("通貨ペア:" + item.getCurrencyPair() + FxdConstants.COMMA
                    + "データ源別:" + item.getInputDataSource() + FxdConstants.COMMA
                    + "の約定トレード取得情報に問題があるため処理から除外");
            return false;
        }
        if (item.getDealerBook() == null) {
            warnExclude("通貨ペア:" + item.getCurrencyPair() + FxdConstants.COMMA
                    + "データ源別:" + item.getInputDataSource() + FxdConstants.COMMA
                    + "の約定トレード取得情報に問題があるため処理から除外");
            return false;
        }
        if (item.getDeliveryDate() == null) {
            warnExclude("ディーラブック:" + item.getDealerBook() + FxdConstants.COMMA
                    + "通貨ペア:" + item.getCurrencyPair() + FxdConstants.COMMA
                    + "データ源別:" + item.getInputDataSource()
                    + "の受渡日が取得できなかったため処理から除外");
            return false;
        }
        return true;
    }

    /**
     * 集計元 DTO を Bean へ変換する。
     *
     * @param targetDate 基準日
     * @param item       集計元 DTO（検証済み）
     * @return 集計元 Bean
     */
    private TPosSumSourceDataBean toBean(Date targetDate, PosSumSourceDto item) {
        TPosSumSourceDataBean bean = new TPosSumSourceDataBean();
        bean.setProcessBaseDate(targetDate);
        bean.setTradeDatetime(new Timestamp(item.getTradeDatetime().getTime()));
        bean.setDealerBook(item.getDealerBook());
        bean.setInputDataSource(item.getInputDataSource());
        bean.setAc(item.getAc());
        bean.setDealCurrency(item.getDealCurrency());
        bean.setSettleCurrency(item.getSettleCurrency());
        bean.setCurrencyPair(item.getCurrencyPair());
        bean.setExchangeDivision(item.getExchangeDivision());
        bean.setDeliveryDate(item.getDeliveryDate());
        bean.setDealDivision(item.getDealDivision());
        bean.setDealAmount(item.getDealAmount());
        bean.setTradeRate(item.getTradeRate());
        bean.setSettleAmount(item.getSettleAmount());
        return bean;
    }

    private void warnExclude(String detail) {
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", LABEL, detail, "");
        warningReporter.markJobWarning();
    }
}
