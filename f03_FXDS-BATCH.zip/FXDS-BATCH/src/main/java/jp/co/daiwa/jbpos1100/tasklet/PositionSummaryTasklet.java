package jp.co.daiwa.jbpos1100.tasklet;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.common.db.DbConnectionFailures;

/**
 * ポジション集計常駐バッチの Tasklet（旧 {@code Jbpos1000PosSumTasklet} の刷新版）。
 *
 * <p>旧クラスは約 3,400 行・1 クラスに「ループ制御・データ取得・マッピング・集計・
 * DB 登録/削除・ファイル I/O」を全て抱えていた。本クラスは<b>常駐ループのオーケストレーション
 * のみ</b>に責務を限定し、実集計は {@link PositionSummaryCycle} 実装へ委譲する。</p>
 *
 * <h2>移行時の修正</h2>
 * <ul>
 *   <li>[Fixed P1] ループ内の明示的 {@code Runtime.getRuntime().gc()} を廃止（GC 阻害要因）。</li>
 *   <li>[Fixed P1] {@code InterruptedException} 握り潰しを廃止し、割り込みフラグを復元してループ終了。</li>
 *   <li>可変 static フィールド（旧 {@code static Date targetDate/busiDaysBefore}）を廃止し、
 *       基準日はサイクル内のローカル変数として扱う（状態リーク・スレッド安全性の改善）。</li>
 * </ul>
 */
@Component
@Scope("step")
public class PositionSummaryTasklet implements Tasklet {

    private static final LogBatchBasedLogger logger =
            LogBatchBasedLogger.getLogger(PositionSummaryTasklet.class);

    /** 非営業日時のループ間隔（ミリ秒）。 */
    private static final int IDLE_INTERVAL_MILLIS = 60_000;

    @Value("${job.jbpos1000.file.stop}")
    private String stopFile;

    @Value("${job.jbpos1000.interval}")
    private String jobInterval;

    private final PositionSummaryCycle cycle;

    /**
     * @param cycle 1 サイクル分の集計処理（委譲先）
     */
    public PositionSummaryTasklet(PositionSummaryCycle cycle) {
        this.cycle = cycle;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        Path stopPath = Paths.get(stopFile);
        int activeIntervalMillis = Integer.parseInt(jobInterval) * 1000;

        while (true) {
            try {
                long startTime = System.currentTimeMillis();
                if (Files.exists(stopPath)) {
                    Files.deleteIfExists(stopPath);
                    logger.info(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_I001", stopFile);
                    break;
                }

                Date targetDate = cycle.resolveTargetDate();
                if (targetDate != null) {
                    cycle.runOnce(contribution, targetDate);
                    Thread.sleep(activeIntervalMillis);
                } else {
                    Thread.sleep(IDLE_INTERVAL_MILLIS);
                }

                long endTime = System.currentTimeMillis();
                logger.trace(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_I028",
                        Thread.currentThread().getStackTrace()[1].getMethodName(),
                        "処理時間:" + (endTime - startTime) + " ms");
            } catch (InterruptedException ie) {
                // [Fixed P1] 割り込みフラグを復元してループを終了する
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                // [I-7] 切断判定は DbConnectionFailures に集約（型判定＋原因チェーン走査＋メッセージ照合）
                if (DbConnectionFailures.isDisconnect(e)) {
                    logger.error(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_E001", "DB接続", e);
                    // DB 切断時は処理終了
                    break;
                }
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                        JobConstants.Jbpos1000_Name, e);
                contribution.getStepExecution().getJobExecution().getExecutionContext()
                        .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
                try {
                    // 大量エラーログの出力を回避する
                    Thread.sleep(IDLE_INTERVAL_MILLIS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        return RepeatStatus.FINISHED;
    }
}
