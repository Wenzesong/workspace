package jp.co.daiwa.jbpos1100.rate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.TargetFileFilter;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * 当日引けレートファイル（タブ区切り）を読み込み {@link CloseRateDto} リストへ変換するリーダ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#getCloseRateInfo} を単一責務クラスとして分離。</p>
 *
 * <p>堅牢化（旧レビュー P1 修正を踏襲）:
 * listFiles の null ガード、ファイル名長チェック（substring の StringIndexOutOfBounds 回避）、
 * ファイルごとの try-with-resources、列数チェック。</p>
 */
public class CloseRateFileReader {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(CloseRateFileReader.class);
    private static final String LABEL = "当日引けレート取得処理";
    private static final int REQUIRED_COLUMNS = 6;
    private static final int FILENAME_DATE_BEGIN = 11;
    private static final int FILENAME_DATE_END = 19;

    private final String inputFilePath;
    private final String fileNamePrefix;
    private final JobWarningReporter warningReporter;

    /**
     * @param inputFilePath   引けレートファイル格納ディレクトリ
     * @param fileNamePrefix  対象ファイル名プレフィックス
     * @param warningReporter 警告レポータ
     */
    public CloseRateFileReader(String inputFilePath, String fileNamePrefix, JobWarningReporter warningReporter) {
        this.inputFilePath = inputFilePath;
        this.fileNamePrefix = fileNamePrefix;
        this.warningReporter = warningReporter;
    }

    /**
     * 基準日に一致する当日引けレートを読み込む。
     *
     * @param targetDate 基準日
     * @return 引けレートリスト（対象なしの場合は空リスト）
     */
    public List<CloseRateDto> read(Date targetDate) {
        List<CloseRateDto> list = new ArrayList<>();
        String targetDateYmd = new SimpleDateFormat(BatchConstants.DATE_PATTERN_YMD).format(targetDate);

        // [Fixed P1] listFiles の null ガード
        File[] files = new File(inputFilePath).listFiles(new TargetFileFilter(fileNamePrefix, ".*"));
        if (files == null || files.length == 0) {
            warningReporter.warn(LABEL, "対象ファイルが存在しません: " + inputFilePath);
            return list;
        }

        for (File file : files) {
            String fileName = file.getName();
            // [Fixed P1] ファイル名長を確認してから substring（StringIndexOutOfBounds 回避）
            if (fileName.length() < FILENAME_DATE_END) {
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", LABEL,
                        "ファイル名が想定書式と異なるためスキップ: " + fileName);
                continue;
            }
            String fileDate = fileName.substring(FILENAME_DATE_BEGIN, FILENAME_DATE_END);
            if (!fileDate.equals(targetDateYmd)) {
                continue;
            }
            readSingleFile(file, list);
        }
        return list;
    }

    private void readSingleFile(File file, List<CloseRateDto> list) {
        // [Fixed P1] ファイルごとに try-with-resources で確実にクローズ
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] columns = line.split("\t");
                // [Fixed P1] 列数不足の行はスキップ（columns[5] 参照前にチェック）
                if (columns.length < REQUIRED_COLUMNS) {
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", LABEL,
                            "列数が不足しているため行をスキップ: " + line);
                    continue;
                }
                list.add(toDto(columns));
            }
        } catch (Exception e) {
            warningReporter.warn(LABEL, e);
        }
    }

    private CloseRateDto toDto(String[] columns) {
        CloseRateDto dto = new CloseRateDto();
        dto.setBaseDate(columns[0]);
        dto.setDealCurrency(columns[1]);
        dto.setSettleCurrency(columns[2]);
        dto.setCloseRate(new BigDecimal(columns[5]));
        return dto;
    }
}
