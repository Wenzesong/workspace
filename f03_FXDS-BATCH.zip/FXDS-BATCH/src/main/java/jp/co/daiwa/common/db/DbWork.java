package jp.co.daiwa.common.db;

/**
 * トランザクション境界内で実行する DB 操作を表す関数型インタフェース。
 *
 * <p>{@link TransactionalBatchExecutor#runInNewTransaction(String, DbWork)} に
 * 「コミット対象の処理本体」だけを渡せるようにする。検査例外を投げられる点が
 * {@link Runnable} との違い。</p>
 */
@FunctionalInterface
public interface DbWork {

    /**
     * DB 操作本体を実行する。
     *
     * @throws Exception DB アクセス等で発生する任意の例外
     */
    void execute() throws Exception;
}
