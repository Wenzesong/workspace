package jp.co.daiwa.jbpos1100.source;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfarmBbgRateBean;
import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.dto.PosBaseRateDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.common.db.DbConnectionFailures;
import jp.co.daiwa.common.db.JobWarningReporter;
import jp.co.daiwa.jbpos1100.rate.RateLookupContext;
import jp.co.daiwa.jbpos1100.rate.YenRateResolver;

/**
 * ポジション集計元データに各種レート（Real/引値/円転/マニュアル/BBG）を割り当てるマッパー。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#posSumSourceDataMapping} の移植版。旧コードは
 * 型不整合・未定義変数・findFirst 欠落で破損していたため jbpos1000 側で修正済み。
 * ここではデータ取得を {@link RateLookupContext} に外出しし、円転レート選択を
 * {@link YenRateResolver} へ委譲して、マッパー本体をテスト容易にする。</p>
 */
public class PositionSourceRateMapper {

    private final YenRateResolver yenRateResolver;
    private final JobWarningReporter warningReporter;

    /**
     * @param yenRateResolver 円転レートリゾルバ
     * @param warningReporter 警告レポータ
     */
    public PositionSourceRateMapper(YenRateResolver yenRateResolver, JobWarningReporter warningReporter) {
        this.yenRateResolver = yenRateResolver;
        this.warningReporter = warningReporter;
    }

    /**
     * 集計元データにレートを割り当てた新リストを返す。
     *
     * @param targetDate 基準日
     * @param sourceList 集計元データ
     * @param context    レート照会データ一式
     * @return レート割当済みリスト
     * @throws Exception DB 切断由来の例外
     */
    public List<TPosSumSourceDataBean> map(Date targetDate, List<TPosSumSourceDataBean> sourceList,
            RateLookupContext context) throws Exception {

        List<TPosSumSourceDataBean> result = new ArrayList<>();
        BigDecimal maxSeqNo = resolveMaxSeqNo(sourceList);
        BigDecimal index = BigDecimal.ZERO;

        for (TPosSumSourceDataBean item : sourceList) {
            try {
                result.add(toBean(targetDate, item, context, maxSeqNo, index));
                index = index.add(BigDecimal.ONE);
            } catch (Exception e) {
                if (DbConnectionFailures.isDisconnect(e)) {
                    throw e;
                }
                warningReporter.warn("ポジション集計データマッピング処理", e);
            }
        }
        return result;
    }

    /**
     * 採番起点となる SeqNo 最大値を求める。
     *
     * @param sourceList 集計元データ
     * @return SeqNo 最大値（空なら 0）
     */
    private BigDecimal resolveMaxSeqNo(List<TPosSumSourceDataBean> sourceList) {
        if (sourceList.isEmpty()) {
            return BigDecimal.ZERO;
        }
        return sourceList.stream()
                .max(Comparator.comparing(TPosSumSourceDataBean::getSeqNo))
                .get().getSeqNo();
    }

    /**
     * 1 件分のレート割当済み Bean を生成する。
     *
     * @param targetDate 基準日
     * @param item       元データ
     * @param context    レート照会データ
     * @param maxSeqNo   SeqNo 採番起点
     * @param index      採番オフセット
     * @return レート割当済み Bean
     */
    private TPosSumSourceDataBean toBean(Date targetDate, TPosSumSourceDataBean item, RateLookupContext context,
            BigDecimal maxSeqNo, BigDecimal index) {

        TCurrencyMstBean currencyMst = findCurrencyMst(context.getCurrencyMstList(), item);
        TDfarmBbgRateBean bbgRate = context.getBbgRateList().stream()
                .filter(c -> c.getDealCurrency().equals(item.getCurrencyPair()))
                .findFirst().orElse(null);
        TPosSumManualRateBean manualRate = findManualRate(context.getManualRateList(), item);
        CloseRateDto closeRate = findCloseRate(context.getCloseRateList(), context.getBaseDate(), item);
        PosBaseRateDto baseRate = context.getBaseRateList().stream()
                .filter(a -> a.getCurrencyPair().equals(item.getCurrencyPair()))
                .findFirst().orElse(null);

        TPosSumSourceDataBean data = new TPosSumSourceDataBean();
        data.setSeqNo(item.getSeqNo() != null ? item.getSeqNo() : maxSeqNo.add(index));
        data.setProcessBaseDate(targetDate);
        data.setTradeDatetime(new Timestamp(item.getTradeDatetime().getTime()));
        data.setDealerBook(item.getDealerBook());
        data.setInputDataSource(item.getInputDataSource());
        data.setAc(item.getAc().trim());
        data.setDealCurrency(item.getDealCurrency().trim());
        data.setSettleCurrency(item.getSettleCurrency().trim());
        data.setCurrencyPair(item.getCurrencyPair());
        data.setExchangeDivision(item.getExchangeDivision().substring(0, 1));
        data.setDeliveryDate(item.getDeliveryDate());
        data.setDealDivision(item.getDealDivision().trim());
        data.setDealAmount(item.getDealAmount());
        data.setTradeRate(item.getTradeRate());
        data.setSettleAmount(item.getSettleAmount());
        data.setEvaluationRateDivision(null);
        applyRealAndClosingRate(data, item, baseRate, closeRate);
        data.setManualDailyRate(manualRate != null ? manualRate.getManualDailyRate() : null);
        data.setManualClosingTtmRate(manualRate != null ? manualRate.getManualClosingTtmRate() : null);
        data.setRateSource(currencyMst != null ? currencyMst.getRateSource() : null);
        data.setBbgRate(bbgRate != null ? bbgRate.getRate() : null);
        data.setRealYenRate(yenRateResolver.resolveRealYenRate(context.getBaseRateList(), item,
                context.getManualRateList(), context.getBbgRateList(), context.getJpySettleCurrencyMstList()));
        data.setClosingYenRate(yenRateResolver.resolveClosingYenRate(context.getCloseRateList(), item,
                context.getBaseDate(), context.getManualRateList()));
        data.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
        data.setBeforeTradeAmountPvCls(item.getBeforeTradeAmountPvCls());
        data.setBeforeTradeAmountPvClsYen(item.getBeforeTradeAmountPvClsYen());
        data.setRegisterUser(JobConstants.Jbpos1000);
        data.setRegisterDatetime(null);
        data.setUpdateUser(JobConstants.Jbpos1000);
        data.setUpdateDatetime(null);
        return data;
    }

    /**
     * Real レート・引値レートを設定する（売買/決済とも JPY なら 1.0、それ以外はベース/引値レート）。
     */
    private void applyRealAndClosingRate(TPosSumSourceDataBean data, TPosSumSourceDataBean item,
            PosBaseRateDto baseRate, CloseRateDto closeRate) {
        if (BatchConstants.CURRENCY_JPY.equals(item.getDealCurrency())
                && BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency())) {
            data.setRealRate(BigDecimal.ONE);
            data.setClosingRate(BigDecimal.ONE);
        } else {
            data.setRealRate(baseRate != null
                    ? new BigDecimal(baseRate.getBidRate()).add(new BigDecimal(baseRate.getAskRate()))
                            .divide(new BigDecimal(2))
                    : null);
            data.setClosingRate(closeRate != null ? closeRate.getCloseRate() : null);
        }
    }

    private TCurrencyMstBean findCurrencyMst(List<TCurrencyMstBean> currencyMstList, TPosSumSourceDataBean item) {
        return currencyMstList.stream()
                .filter(c -> c.getDealCurrency().equals(item.getDealCurrency()))
                .filter(c -> c.getSettleCurrency().equals(item.getSettleCurrency()))
                .findFirst().orElse(null);
    }

    private TPosSumManualRateBean findManualRate(List<TPosSumManualRateBean> manualRateList,
            TPosSumSourceDataBean item) {
        return manualRateList.stream()
                .filter(c -> c.getDealCurrency().equals(item.getDealCurrency()))
                .filter(c -> c.getSettleCurrency().equals(item.getSettleCurrency()))
                .findFirst().orElse(null);
    }

    private CloseRateDto findCloseRate(List<CloseRateDto> closeRateList, String baseDate, TPosSumSourceDataBean item) {
        return closeRateList.stream()
                .filter(b -> baseDate.equals(b.getBaseDate()))
                .filter(b -> b.getDealCurrency().equals(item.getDealCurrency()))
                .filter(b -> b.getSettleCurrency().equals(item.getSettleCurrency()))
                .findFirst().orElse(null);
    }
}
