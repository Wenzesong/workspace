package jp.co.daiwa.common.db;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * リストを一定件数ごとのサブリストに分割するユーティリティ。
 *
 * <p>旧コードは外部の {@code DBUtil#divideList} に依存していたが、
 * バルク INSERT の単体テストを {@code DBUtil} 非依存で行えるよう、
 * 同等の分割ロジックを本パッケージ内に切り出す（static メソッドではなく
 * テスト容易な純粋関数として提供）。</p>
 */
public final class ListPartitioner {

    private ListPartitioner() {
    }

    /**
     * リストを {@code unit} 件ごとのサブリストに分割する。
     *
     * @param source 分割対象（null の場合は空リスト扱い）
     * @param unit   1 サブリストあたりの最大件数（1 以上）
     * @param <T>    要素型
     * @return 分割後のサブリストのリスト（読み取り専用ビューではなく新規リスト）
     * @throws IllegalArgumentException {@code unit} が 1 未満の場合
     */
    public static <T> List<List<T>> partition(List<T> source, int unit) {
        if (unit < 1) {
            throw new IllegalArgumentException("unit must be >= 1 but was " + unit);
        }
        if (source == null || source.isEmpty()) {
            return Collections.emptyList();
        }
        List<List<T>> result = new ArrayList<>();
        for (int from = 0; from < source.size(); from += unit) {
            int to = Math.min(from + unit, source.size());
            result.add(new ArrayList<>(source.subList(from, to)));
        }
        return result;
    }
}
