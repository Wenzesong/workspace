package jp.co.daiwa.jbpos1100.source;

import java.util.List;

import jp.co.daiwa.dao.TPosSumSourceDataRepository;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.common.db.TransactionalBatchExecutor;

/**
 * ポジション集計元情報テーブルへの登録/削除/更新（中間コミット）を担う永続化クラス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet} の {@code posSumSourceDataDelete} /
 * {@code posSumSourceDataInsert} / {@code posSumSourceDataUpdate} に分散していた
 * 「トランザクション定義生成 → 開始 → 処理 → commit → 例外時 rollback」の重複を、
 * すべて {@link TransactionalBatchExecutor} へ委譲して排除する。</p>
 *
 * <p>特に登録処理の「一括 INSERT 失敗時に 1 件ずつ再 INSERT」も
 * {@link TransactionalBatchExecutor#bulkInsertWithRetry} に共通化済み。</p>
 */
public class PositionSourceStore {

    private static final String LABEL_DELETE = "ポジション集計元情報削除処理";
    private static final String LABEL_INSERT = "ポジション集計元情報登録処理";
    private static final String LABEL_UPDATE = "ポジション集計元情報更新処理";

    private final TPosSumSourceDataRepository repository;
    private final TransactionalBatchExecutor executor;
    private final int bulkInsertUnit;

    /**
     * @param repository     ポジション集計元情報リポジトリ
     * @param executor       中間コミット実行テンプレート
     * @param bulkInsertUnit 一括 INSERT 単位
     */
    public PositionSourceStore(TPosSumSourceDataRepository repository,
            TransactionalBatchExecutor executor, int bulkInsertUnit) {
        this.repository = repository;
        this.executor = executor;
        this.bulkInsertUnit = bulkInsertUnit;
    }

    /**
     * 削除（中間コミット）。
     *
     * @param condition 削除条件 Bean
     * @throws Exception DB 切断由来の例外
     */
    public void delete(TPosSumSourceDataBean condition) throws Exception {
        executor.runInNewTransaction(LABEL_DELETE, () -> repository.delete(condition));
    }

    /**
     * 一括登録（中間コミット＋1 件ずつ再 INSERT リトライ）。
     *
     * @param items 登録対象リスト
     * @throws Exception DB 切断由来の例外
     */
    public void insert(List<TPosSumSourceDataBean> items) throws Exception {
        executor.bulkInsertWithRetry(LABEL_INSERT, items, bulkInsertUnit, repository::insert);
    }

    /**
     * 更新（中間コミット）。
     *
     * @param items 更新対象リスト
     * @throws Exception DB 切断由来の例外
     */
    public void update(List<TPosSumSourceDataBean> items) throws Exception {
        executor.runInNewTransaction(LABEL_UPDATE, () -> repository.update(items));
    }
}
