package jp.co.daiwa.jbpos1100.tasklet;

import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashStore;
import jp.co.daiwa.jbpos1100.spot.SpotSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSumStore;

/**
 * 1 サイクル分の集計結果 Store 一式（スポット／スワップ／通貨別デルタ・キャッシュ残／スワップ PL 合計）。
 *
 * <p>[I-2] 旧: {@code PositionSummaryComposition} の {@code buildEvaluationService} と
 * {@code buildEndOfDayClosingService} が同じ 4 Store を**2 箇所で重複生成**していた。
 * サイクル単位で 1 度だけ構築し、両サービスで共有する（生成箇所の一元化・引数取り違え防止）。
 * Store はステートレス（Repository＋中間コミット executor への委譲のみ）のため共有しても挙動は不変。</p>
 */
class StoreBundle {

    private final SpotSumStore spotSumStore;
    private final SwapSumStore swapSumStore;
    private final CurrencyDeltaCashStore deltaCashStore;
    private final SwapPlSumStore swapPlSumStore;

    /**
     * @param spotSumStore   ポジションスポット集計 Store
     * @param swapSumStore   ポジションスワップ集計 Store
     * @param deltaCashStore 通貨別デルタ・キャッシュ残 Store
     * @param swapPlSumStore スワップ PL 合計 Store
     */
    StoreBundle(SpotSumStore spotSumStore, SwapSumStore swapSumStore,
            CurrencyDeltaCashStore deltaCashStore, SwapPlSumStore swapPlSumStore) {
        this.spotSumStore = spotSumStore;
        this.swapSumStore = swapSumStore;
        this.deltaCashStore = deltaCashStore;
        this.swapPlSumStore = swapPlSumStore;
    }

    SpotSumStore getSpotSumStore() {
        return spotSumStore;
    }

    SwapSumStore getSwapSumStore() {
        return swapSumStore;
    }

    CurrencyDeltaCashStore getDeltaCashStore() {
        return deltaCashStore;
    }

    SwapPlSumStore getSwapPlSumStore() {
        return swapPlSumStore;
    }
}
