package jp.co.daiwa.jbpos1100.tasklet;

import java.util.Date;
import java.util.List;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.TPositionSwapSumDataRepository;
import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.jbpos1100.common.EndOfDayClosingDuplicator;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashStore;
import jp.co.daiwa.jbpos1100.spot.SpotSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSumStore;

/**
 * 引値集計結果を日締め（評価レート区分 03＝END_OF_DAY_CLOSING）として複製・登録するサービス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet} の各永続化メソッド（{@code setSpotSumDate} ほか）に
 * 織り込まれていた日締めデータ生成（{@code setClosingData} 等で複製→登録）を、引値集計の
 * 後処理として 1 箇所へ集約したもの。スポット／スワップ／通貨別デルタ・キャッシュ残／
 * スワップ PL 合計の 4 種を対象とする。</p>
 *
 * <h2>登録条件（旧コードを忠実移植）</h2>
 * <ul>
 *   <li>システム時刻が日締め時刻以降（{@code afterDayClose}）かつ評価レート区分が引値のときのみ実行
 *       （実行可否の判定は呼び出し側＝{@link ClosingEvaluationService}）。</li>
 *   <li>各種別で、引値集計結果が非空 <b>かつ</b> 当該基準日の日締めデータ（03）が未登録の場合のみ複製を登録する
 *       （日締めデータの削除は行わない＝既存があればスキップ）。</li>
 * </ul>
 */
public class EndOfDayClosingService {

    private static final String END_OF_DAY = EvaluationRateKbn.END_OF_DAY_CLOSING.getCode();

    private final EndOfDayClosingDuplicator duplicator;
    private final SpotSumStore spotSumStore;
    private final SwapSumStore swapSumStore;
    private final CurrencyDeltaCashStore deltaCashStore;
    private final SwapPlSumStore swapPlSumStore;
    private final TPositionSpotSumDataRepository spotRepository;
    private final TPositionSwapSumDataRepository swapRepository;
    private final TByCcyDeltaCashBalanceRepository deltaCashRepository;
    private final TSwapPlSumDateRepository swapPlSumRepository;

    public EndOfDayClosingService(EndOfDayClosingDuplicator duplicator, SpotSumStore spotSumStore,
            SwapSumStore swapSumStore, CurrencyDeltaCashStore deltaCashStore, SwapPlSumStore swapPlSumStore,
            TPositionSpotSumDataRepository spotRepository, TPositionSwapSumDataRepository swapRepository,
            TByCcyDeltaCashBalanceRepository deltaCashRepository, TSwapPlSumDateRepository swapPlSumRepository) {
        this.duplicator = duplicator;
        this.spotSumStore = spotSumStore;
        this.swapSumStore = swapSumStore;
        this.deltaCashStore = deltaCashStore;
        this.swapPlSumStore = swapPlSumStore;
        this.spotRepository = spotRepository;
        this.swapRepository = swapRepository;
        this.deltaCashRepository = deltaCashRepository;
        this.swapPlSumRepository = swapPlSumRepository;
    }

    /**
     * 引値集計結果を日締め（03）として複製・登録する。
     *
     * @param targetDate 基準日
     * @param result     引値集計の結果（スポット／スワップ各成果物）
     * @throws Exception DB 切断由来の例外
     */
    public void duplicateClosingToEndOfDay(Date targetDate, PositionEvaluationResult result) throws Exception {
        duplicateIfAbsent(result.getSpotSumList(), () -> findSpotEndOfDay(targetDate),
                duplicator::duplicateSpot, spotSumStore::insert);
        duplicateIfAbsent(result.getSwapSumList(), () -> findSwapEndOfDay(targetDate),
                duplicator::duplicateSwap, swapSumStore::insert);
        duplicateIfAbsent(result.getDeltaCashList(), () -> findDeltaCashEndOfDay(targetDate),
                duplicator::duplicateDeltaCash, deltaCashStore::insert);
        duplicateIfAbsent(result.getSwapPlSumList(), () -> findSwapPlSumEndOfDay(targetDate),
                duplicator::duplicateSwapPlSum, swapPlSumStore::insert);
    }

    /**
     * [I-4] 種別共通の複製・登録定型。「引値結果が非空 かつ 日締め（03）未登録のときのみ複製を INSERT
     * （既登録ならスキップ、削除は行わない）」の不変条件を 1 箇所に集約する。
     *
     * <p>既存照会（{@code endOfDayQuery}）は引値結果が非空のときのみ実行する（旧実装の
     * 短絡評価と同一＝空のときの無駄な SELECT を発行しない）。</p>
     *
     * @param closingResults 引値集計結果
     * @param endOfDayQuery  当該基準日の日締め（03）既存データ照会
     * @param duplicate      日締め（03）への複製変換
     * @param insert         中間コミット登録
     * @param <T>            集計結果の型
     */
    private <T> void duplicateIfAbsent(List<T> closingResults, Supplier<List<?>> endOfDayQuery,
            UnaryOperator<List<T>> duplicate, EndOfDayInsert<T> insert) throws Exception {
        if (closingResults.isEmpty()) {
            return;
        }
        List<?> existing = endOfDayQuery.get();
        if (existing != null && !existing.isEmpty()) {
            return;
        }
        insert.insert(duplicate.apply(closingResults));
    }

    /** 中間コミット登録（checked 例外を許容するための関数型 IF）。 */
    @FunctionalInterface
    private interface EndOfDayInsert<T> {
        void insert(List<T> items) throws Exception;
    }

    private List<TPositionSpotSumDataBean> findSpotEndOfDay(Date targetDate) {
        TPositionSpotSumDataBean condition = new TPositionSpotSumDataBean();
        condition.setProcessBaseDate(targetDate);
        condition.setEvaluationRateDivision(END_OF_DAY);
        return spotRepository.geTPositionSpotSumDataBeanAll(condition);
    }

    private List<TPositionSwapSumDataBean> findSwapEndOfDay(Date targetDate) {
        TPositionSwapSumDataBean condition = new TPositionSwapSumDataBean();
        condition.setProcessBaseDate(targetDate);
        condition.setEvaluationRateDivision(END_OF_DAY);
        return swapRepository.getPositionSwapSumDataList(condition);
    }

    private List<TByCcyDeltaCashBalanceBean> findDeltaCashEndOfDay(Date targetDate) {
        TByCcyDeltaCashBalanceBean condition = new TByCcyDeltaCashBalanceBean();
        condition.setProcessBaseDate(targetDate);
        condition.setEvaluationRateDivision(END_OF_DAY);
        return deltaCashRepository.getByCcyDeltaCashBalanceList(condition);
    }

    private List<TSwapPlSumDateBean> findSwapPlSumEndOfDay(Date targetDate) {
        TSwapPlSumDateBean condition = new TSwapPlSumDateBean();
        condition.setProcessBaseDate(targetDate);
        condition.setEvaluationRateDivision(END_OF_DAY);
        return swapPlSumRepository.getSwapPlSumDateList(condition);
    }
}
