package jp.co.daiwa.jbpos1100.swap;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.jbpos1100.common.BigDecimalSummer;
import jp.co.daiwa.common.db.JobWarningReporter;

/**
 * 引値以降集計向け：スワップの IT 分取引を符号調整し、ディーラブック・受渡日・通貨単位で纏めるアグリゲータ。
 *
 * <p>旧 {@code Jbpos1000SwapSummary#setPosSwapItData}（符号調整）＋ {@code setTradeUnitTransaction}
 * （通貨単位纏め）の移植版。</p>
 *
 * <h2>[Fixed P0] Map.put の戻り値（旧値）を加算していた不具合</h2>
 * <p>旧 {@code setTradeUnitTransaction} は売買区分・売買金額の算出で
 * {@code totalDealDateMap.put(k,v).add(totalSettleDateMap.put(k,v))} としており、
 * {@code put} の戻り値（直前値）を加算していた。売買金額が NULL の通貨では当該 Map に値が無く
 * {@code put} が null を返し NPE となる。集計済みローカル値を直接加算する正しい実装に修正。</p>
 */
public class SwapItTradeUnitAggregator {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(SwapItTradeUnitAggregator.class);

    private final JobWarningReporter warningReporter;

    /**
     * @param warningReporter 警告レポータ
     */
    public SwapItTradeUnitAggregator(JobWarningReporter warningReporter) {
        this.warningReporter = warningReporter;
    }

    /**
     * スワップ IT 分取引を符号調整のうえ通貨単位に纏める。
     *
     * @param swapItSourceList スワップ IT 分の集計元データ
     * @return 通貨単位に纏めた集計元データ
     */
    public List<TPosSumSourceDataBean> aggregate(List<TPosSumSourceDataBean> swapItSourceList) {
        return aggregateByTradeUnit(buildSignedRows(swapItSourceList));
    }

    /** 売買区分に応じて売買金額・決済金額の符号を調整した行を作る（旧 setPosSwapItData）。 */
    private List<TPosSumSourceDataBean> buildSignedRows(List<TPosSumSourceDataBean> swapItSourceList) {
        List<TPosSumSourceDataBean> rows = new ArrayList<>();
        for (TPosSumSourceDataBean item : swapItSourceList) {
            TPosSumSourceDataBean pos = new TPosSumSourceDataBean();
            pos.setDealerBook(item.getDealerBook());
            pos.setTradeDatetime(item.getTradeDatetime());
            pos.setInputDataSource(item.getInputDataSource());
            pos.setAc(item.getAc());
            pos.setDeliveryDate(item.getDeliveryDate());
            pos.setExchangeDivision(item.getExchangeDivision());
            pos.setDealDivision(item.getDealDivision());
            pos.setDealCurrency(item.getDealCurrency());
            pos.setTradeRate(item.getTradeRate());
            pos.setSettleCurrency(item.getSettleCurrency());
            pos.setCurrencyPair(item.getCurrencyPair());
            boolean buy = BatchConstants.DEAL_DIVISION_BUY.equals(item.getDealDivision());
            pos.setDealAmount(buy ? item.getDealAmount() : item.getDealAmount().negate());
            pos.setSettleAmount(buy ? item.getSettleAmount() : item.getSettleAmount().negate());
            rows.add(pos);
        }
        return rows;
    }

    /** ディーラブック・受渡日・通貨単位で売買金額＋決済金額をネットして約定済CF行を作る（旧 setTradeUnitTransaction）。 */
    private List<TPosSumSourceDataBean> aggregateByTradeUnit(List<TPosSumSourceDataBean> signedRows) {
        List<TPosSumSourceDataBean> result = new ArrayList<>();
        Map<String, Map<Date, List<TPosSumSourceDataBean>>> sumMap = signedRows.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getSettleCurrency(),
                        Collectors.groupingBy(TPosSumSourceDataBean::getDeliveryDate)));

        for (Map.Entry<String, Map<Date, List<TPosSumSourceDataBean>>> bookEntry : sumMap.entrySet()) {
            String dealerBook = bookEntry.getKey().split(",")[0];
            for (Map.Entry<Date, List<TPosSumSourceDataBean>> dateEntry : bookEntry.getValue().entrySet()) {
                try {
                    result.addAll(aggregateForDate(dealerBook, dateEntry.getKey(), dateEntry.getValue()));
                } catch (Exception e) {
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002",
                            dealerBook + ",スワップのIT分取引通貨別トランザクション纏め処理", e);
                    warningReporter.markJobWarning();
                }
            }
        }
        return result;
    }

    /** 1（ディーラブック, 受渡日）グループを通貨単位でネットする。 */
    private List<TPosSumSourceDataBean> aggregateForDate(String dealerBook, Date deliveryDate,
            List<TPosSumSourceDataBean> group) {
        List<TPosSumSourceDataBean> rows = new ArrayList<>();
        for (String currency : distinctCurrencies(group)) {
            TPosSumSourceDataBean head = group.get(0);
            TPosSumSourceDataBean pos = new TPosSumSourceDataBean();
            pos.setDealerBook(dealerBook);
            pos.setTradeDatetime(head.getTradeDatetime());
            pos.setInputDataSource(head.getInputDataSource());
            pos.setAc(head.getAc());
            pos.setDeliveryDate(deliveryDate);
            pos.setExchangeDivision(BatchConstants.EXCHANGE_DIVISION_TRADED_CF);
            pos.setDealCurrency(currency);
            pos.setTradeRate(null);
            pos.setSettleCurrency(BatchConstants.CURRENCY_JPY);
            pos.setCurrencyPair(currency.concat(BatchConstants.CURRENCY_JPY));

            BigDecimal totalDeal = sumIfNoNull(group, currency, true, TPosSumSourceDataBean::getDealAmount);
            BigDecimal totalSettle = sumIfNoNull(group, currency, false, TPosSumSourceDataBean::getSettleAmount);

            // [Fixed P0] 集計済みローカル値を直接加算（旧: Map.put の戻り値を加算し NPE）
            BigDecimal netAmount = totalDeal.add(totalSettle);
            pos.setDealDivision(netAmount.compareTo(BigDecimal.ZERO) >= 0
                    ? BatchConstants.DEAL_DIVISION_BUY : BatchConstants.DEAL_DIVISION_SELL);
            pos.setDealAmount(netAmount.abs());
            pos.setSettleAmount(BigDecimal.ZERO);
            rows.add(pos);
        }
        return rows;
    }

    /** グループ内の売買側・決済側通貨の重複なしリスト。 */
    private List<String> distinctCurrencies(List<TPosSumSourceDataBean> group) {
        List<String> currencies = new ArrayList<>();
        group.forEach(d -> {
            currencies.add(d.getDealCurrency());
            currencies.add(d.getSettleCurrency());
        });
        return currencies.stream().distinct().collect(Collectors.toList());
    }

    /**
     * 指定通貨側（売買側 or 決済側）に NULL 金額が無ければ合計、あれば 0 を返す（旧挙動踏襲）。
     */
    private BigDecimal sumIfNoNull(List<TPosSumSourceDataBean> group, String currency, boolean dealSide,
            Function<TPosSumSourceDataBean, BigDecimal> getter) {
        List<TPosSumSourceDataBean> sideList = group.stream()
                .filter(d -> currency.equals(dealSide ? d.getDealCurrency() : d.getSettleCurrency()))
                .collect(Collectors.toList());
        boolean hasNull = sideList.stream().anyMatch(d -> getter.apply(d) == null);
        if (hasNull) {
            return BigDecimal.ZERO;
        }
        return BigDecimalSummer.sumNonNull(sideList, getter);
    }
}
