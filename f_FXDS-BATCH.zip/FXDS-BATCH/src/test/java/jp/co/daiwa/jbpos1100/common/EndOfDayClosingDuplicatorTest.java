package jp.co.daiwa.jbpos1100.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;

/**
 * {@link EndOfDayClosingDuplicator} の単体テスト。評価レート区分を日締めへ差し替えつつ値を複製することを検証する。
 */
class EndOfDayClosingDuplicatorTest {

    private EndOfDayClosingDuplicator duplicator;

    @BeforeEach
    void setUp() {
        duplicator = new EndOfDayClosingDuplicator();
    }

    @Test
    @DisplayName("スポット: 評価レート区分を日締め(03)に差し替え、値は複製する")
    void duplicateSpot_overridesDivisionKeepsValues() {
        TPositionSpotSumDataBean item = new TPositionSpotSumDataBean();
        item.setDealerBook("BOOK1");
        item.setCurrencyPair("USDJPY");
        item.setEvaluationRateDivision(EvaluationRateKbn.CLOSING_PRICE.getCode());
        item.setSumPlYen(new BigDecimal("123.45"));

        List<TPositionSpotSumDataBean> result = duplicator.duplicateSpot(Collections.singletonList(item));

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getEvaluationRateDivision())
                .isEqualTo(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
        assertThat(result.get(0).getDealerBook()).isEqualTo("BOOK1");
        assertThat(result.get(0).getSumPlYen()).isEqualByComparingTo("123.45");
    }

    @Test
    @DisplayName("デルタ・キャッシュ残: 日締め区分へ差し替え、デルタ/残を複製する")
    void duplicateDeltaCash_overridesDivision() {
        TByCcyDeltaCashBalanceBean item = new TByCcyDeltaCashBalanceBean();
        item.setDealerBook("BOOK1");
        item.setCurrency("USD");
        item.setEvaluationRateDivision(EvaluationRateKbn.CLOSING_PRICE.getCode());
        item.setDelta(new BigDecimal("10"));
        item.setCashBalance(new BigDecimal("20"));

        List<TByCcyDeltaCashBalanceBean> result = duplicator.duplicateDeltaCash(Collections.singletonList(item));

        assertThat(result.get(0).getEvaluationRateDivision())
                .isEqualTo(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
        assertThat(result.get(0).getDelta()).isEqualByComparingTo("10");
        assertThat(result.get(0).getCashBalance()).isEqualByComparingTo("20");
    }

    @Test
    @DisplayName("スワップPL合計: 日締め区分へ差し替え、PL合計を複製する")
    void duplicateSwapPlSum_overridesDivision() {
        TSwapPlSumDateBean item = new TSwapPlSumDateBean();
        item.setDealerBook("BOOK1");
        item.setEvaluationRateDivision(EvaluationRateKbn.CLOSING_PRICE.getCode());
        item.setPlTotal(new BigDecimal("999"));

        List<TSwapPlSumDateBean> result = duplicator.duplicateSwapPlSum(Collections.singletonList(item));

        assertThat(result.get(0).getEvaluationRateDivision())
                .isEqualTo(EvaluationRateKbn.END_OF_DAY_CLOSING.getCode());
        assertThat(result.get(0).getPlTotal()).isEqualByComparingTo("999");
    }
}
