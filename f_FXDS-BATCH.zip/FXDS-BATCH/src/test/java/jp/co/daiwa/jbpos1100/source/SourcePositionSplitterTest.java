package jp.co.daiwa.jbpos1100.source;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.common.constant.ExchangeKbnEnum.ExchangeKbn;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;

/**
 * {@link SourcePositionSplitter} の単体テスト。Real／プレ引値／引値スワップの振り分けを検証する。
 */
class SourcePositionSplitterTest {

    private SourcePositionSplitter splitter;
    private Date targetDate;
    private Date busiDaysBefore;

    @BeforeEach
    void setUp() throws Exception {
        splitter = new SourcePositionSplitter();
        SimpleDateFormat ymd = new SimpleDateFormat("yyyy/MM/dd");
        targetDate = ymd.parse("2026/06/29");
        busiDaysBefore = ymd.parse("2026/06/26");
    }

    @Test
    @DisplayName("Real: 当日約定のスポットはスポット側、スワップ区分はスワップ側へ")
    void splitForReal_routesByExchangeDivision() {
        TPosSumSourceDataBean spot = item(ExchangeKbn.SPOT.getCode(), "0", todayAt("100000"));
        TPosSumSourceDataBean swap = item(ExchangeKbn.SWAP_START.getCode(), "0", todayAt("100000"));

        SourcePositionSplit split = splitter.splitForReal(Arrays.asList(spot, swap), targetDate, busiDaysBefore);

        assertThat(split.getSpotList()).containsExactly(spot);
        assertThat(split.getSwapList()).containsExactly(swap);
    }

    @Test
    @DisplayName("プレ引値: 当日00:00-20:59かつAC=0のスポットのみ、スワップは対象外")
    void splitForPreClosing_spotOnly() {
        TPosSumSourceDataBean spot = item(ExchangeKbn.SPOT.getCode(), "0", todayAt("100000"));
        TPosSumSourceDataBean swap = item(ExchangeKbn.SWAP_START.getCode(), "0", todayAt("100000"));

        SourcePositionSplit split = splitter.splitForPreClosing(Arrays.asList(spot, swap), targetDate, busiDaysBefore);

        assertThat(split.getSpotList()).containsExactly(spot);
        assertThat(split.getSwapList()).isEmpty();
    }

    @Test
    @DisplayName("プレ引値: AC=1（インタイム外）の当日約定スポットはウィンドウ対象外で除外")
    void splitForPreClosing_excludesAfterCloseIntraday() {
        TPosSumSourceDataBean spotAc = item(ExchangeKbn.SPOT.getCode(), "1", todayAt("100000"));

        SourcePositionSplit split = splitter.splitForPreClosing(Arrays.asList(spotAc), targetDate, busiDaysBefore);

        assertThat(split.getSpotList()).isEmpty();
    }

    @Test
    @DisplayName("引値以降AC分: 当日AC=1のスポット/スワップをそれぞれ抽出")
    void splitForAfterAc_extractsTodayAc() {
        TPosSumSourceDataBean spotAc = item(ExchangeKbn.SPOT.getCode(), "1", todayAt("100000"));
        TPosSumSourceDataBean swapAc = item(ExchangeKbn.SWAP_START.getCode(), "1", todayAt("100000"));
        TPosSumSourceDataBean spotInTime = item(ExchangeKbn.SPOT.getCode(), "0", todayAt("100000"));

        SourcePositionSplit split = splitter.splitForAfterAc(Arrays.asList(spotAc, swapAc, spotInTime), targetDate);

        assertThat(split.getSpotList()).containsExactly(spotAc);
        assertThat(split.getSwapList()).containsExactly(swapAc);
    }

    @Test
    @DisplayName("引値スワップ: スワップ区分のみ、スポットは対象外")
    void splitForClosingSwap_swapOnly() {
        TPosSumSourceDataBean spot = item(ExchangeKbn.SPOT.getCode(), "0", todayAt("100000"));
        TPosSumSourceDataBean swap = item(ExchangeKbn.SWAP_END.getCode(), "0", todayAt("100000"));

        SourcePositionSplit split = splitter.splitForClosingSwap(Arrays.asList(spot, swap), targetDate, busiDaysBefore);

        assertThat(split.getSpotList()).isEmpty();
        assertThat(split.getSwapList()).containsExactly(swap);
    }

    private TPosSumSourceDataBean item(String exchangeDivision, String ac, Timestamp tradeDatetime) {
        TPosSumSourceDataBean bean = new TPosSumSourceDataBean();
        bean.setProcessBaseDate(targetDate);
        bean.setExchangeDivision(exchangeDivision);
        bean.setAc(ac);
        bean.setSeqNo(BigDecimal.ONE);
        bean.setTradeDatetime(tradeDatetime);
        return bean;
    }

    private Timestamp todayAt(String hhmmss) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss");
            return new Timestamp(f.parse("20260629" + hhmmss).getTime());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
