package jp.co.daiwa.jbpos1100.tasklet;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.TPositionSwapSumDataRepository;
import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.common.EndOfDayClosingDuplicator;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashStore;
import jp.co.daiwa.jbpos1100.spot.SpotSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSumStore;

/**
 * {@link EndOfDayClosingService} の単体テスト。
 *
 * <p>「引値結果が非空かつ既存の日締め（03）データが無い場合のみ複製を登録する」という
 * 旧コードの登録条件を検証する。</p>
 */
class EndOfDayClosingServiceTest {

    private SpotSumStore spotSumStore;
    private SwapSumStore swapSumStore;
    private CurrencyDeltaCashStore deltaCashStore;
    private SwapPlSumStore swapPlSumStore;
    private TPositionSpotSumDataRepository spotRepository;
    private TPositionSwapSumDataRepository swapRepository;
    private TByCcyDeltaCashBalanceRepository deltaCashRepository;
    private TSwapPlSumDateRepository swapPlSumRepository;
    private EndOfDayClosingService service;
    private Date targetDate;

    @BeforeEach
    void setUp() {
        spotSumStore = mock(SpotSumStore.class);
        swapSumStore = mock(SwapSumStore.class);
        deltaCashStore = mock(CurrencyDeltaCashStore.class);
        swapPlSumStore = mock(SwapPlSumStore.class);
        spotRepository = mock(TPositionSpotSumDataRepository.class);
        swapRepository = mock(TPositionSwapSumDataRepository.class);
        deltaCashRepository = mock(TByCcyDeltaCashBalanceRepository.class);
        swapPlSumRepository = mock(TSwapPlSumDateRepository.class);
        service = new EndOfDayClosingService(new EndOfDayClosingDuplicator(), spotSumStore, swapSumStore,
                deltaCashStore, swapPlSumStore, spotRepository, swapRepository, deltaCashRepository,
                swapPlSumRepository);
        targetDate = new Date();
    }

    @Test
    @DisplayName("引値スポット結果があり日締めデータが未登録なら複製を登録する")
    void duplicate_spotPresentAndNoEndOfDay_inserts() throws Exception {
        when(spotRepository.geTPositionSpotSumDataBeanAll(any()))
                .thenReturn(Collections.<TPositionSpotSumDataBean>emptyList());

        TPositionSpotSumDataBean spot = new TPositionSpotSumDataBean();
        spot.setProcessBaseDate(targetDate);
        PositionEvaluationResult result = new PositionEvaluationResult(Collections.singletonList(spot),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        service.duplicateClosingToEndOfDay(targetDate, result);

        verify(spotSumStore).insert(any());
    }

    @Test
    @DisplayName("既に日締めデータが存在する場合は複製を登録しない")
    void duplicate_endOfDayExists_skips() throws Exception {
        TPositionSpotSumDataBean existing = new TPositionSpotSumDataBean();
        when(spotRepository.geTPositionSpotSumDataBeanAll(any()))
                .thenReturn(Collections.singletonList(existing));

        TPositionSpotSumDataBean spot = new TPositionSpotSumDataBean();
        PositionEvaluationResult result = new PositionEvaluationResult(Collections.singletonList(spot),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        service.duplicateClosingToEndOfDay(targetDate, result);

        verify(spotSumStore, never()).insert(any());
    }

    @Test
    @DisplayName("引値結果が空の種別は存在確認も登録も行わない")
    void duplicate_emptyResult_noInteraction() throws Exception {
        PositionEvaluationResult result = new PositionEvaluationResult(Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        service.duplicateClosingToEndOfDay(targetDate, result);

        verify(spotSumStore, never()).insert(any());
        verify(swapSumStore, never()).insert(any());
        verify(deltaCashStore, never()).insert(any());
        verify(swapPlSumStore, never()).insert(any());
    }
}
