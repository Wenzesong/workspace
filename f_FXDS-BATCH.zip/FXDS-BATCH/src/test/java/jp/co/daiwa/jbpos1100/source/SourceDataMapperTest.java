package jp.co.daiwa.jbpos1100.source;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.PosSumSourceDto;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;

/**
 * {@link SourceDataMapper} の単体テスト。検証ガード（必須項目欠落の除外）を中心に確認する。
 */
class SourceDataMapperTest {

    private SourceDataMapper mapper;
    private Date targetDate;

    @BeforeEach
    void setUp() {
        mapper = new SourceDataMapper(mock(JobWarningReporter.class));
        targetDate = new Date();
    }

    @Test
    @DisplayName("取引レートが欠落したデータは除外される（旧 setSourceData L542 の有効条件）")
    void map_tradeRateNull_excluded() {
        PosSumSourceDto invalid = dto(new Date(), "BOOK1", new Date());
        invalid.setTradeRate(null);
        PosSumSourceDto valid = dto(new Date(), "BOOK1", new Date());

        List<TPosSumSourceDataBean> result = mapper.map(targetDate, Arrays.asList(invalid, valid));

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getDealerBook()).isEqualTo("BOOK1");
    }

    @Test
    @DisplayName("ディーラブック欠落・受渡日欠落も除外される")
    void map_missingDealerBookOrDelivery_excluded() {
        PosSumSourceDto noDealerBook = dto(new Date(), null, new Date());
        PosSumSourceDto noDelivery = dto(new Date(), "BOOK1", null);

        List<TPosSumSourceDataBean> result = mapper.map(targetDate, Arrays.asList(noDealerBook, noDelivery));

        assertThat(result).isEmpty();
    }

    @Test
    @DisplayName("有効データは処理基準日が設定され変換される")
    void map_valid_setsProcessBaseDate() {
        PosSumSourceDto valid = dto(new Date(), "BOOK1", new Date());

        List<TPosSumSourceDataBean> result = mapper.map(targetDate, Arrays.asList(valid));

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getProcessBaseDate()).isEqualTo(targetDate);
    }

    private PosSumSourceDto dto(Date tradeDate, String dealerBook, Date deliveryDate) {
        PosSumSourceDto dto = new PosSumSourceDto();
        dto.setTradeDate(tradeDate);
        dto.setDealerBook(dealerBook);
        dto.setDeliveryDate(deliveryDate);
        dto.setInputDataSource("FXDS");
        dto.setCurrencyPair("USDJPY");
        // 旧 setSourceData の有効条件は取引レート必須。既定で非 NULL を設定し、欠落テストでのみ null に上書きする。
        dto.setTradeRate(BigDecimal.ONE);
        return dto;
    }
}
