package jp.co.daiwa.jbpos1100.tasklet;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.rate.RateLookupContext;
import jp.co.daiwa.jbpos1100.source.PositionSourceRateMapper;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplitter;
import jp.co.daiwa.jbpos1100.spot.SpotCloseCostReplacer;
import jp.co.daiwa.jbpos1100.swap.SwapItTradeUnitAggregator;

/**
 * {@link AfterClosingEvaluationService} の結線テスト。
 * AC分＋持ち替え分（スポット）、AC分＋IT分（スワップ）を組み立て、引値以降区分で評価サービスへ委譲することを検証する。
 */
class AfterClosingEvaluationServiceTest {

    private SourcePositionSplitter splitter;
    private SwapItTradeUnitAggregator swapItAggregator;
    private SpotCloseCostReplacer spotCloseCostReplacer;
    private PositionSourceRateMapper rateMapper;
    private PositionEvaluationService evaluationService;
    private AfterClosingEvaluationService service;

    @BeforeEach
    void setUp() {
        splitter = mock(SourcePositionSplitter.class);
        swapItAggregator = mock(SwapItTradeUnitAggregator.class);
        spotCloseCostReplacer = mock(SpotCloseCostReplacer.class);
        rateMapper = mock(PositionSourceRateMapper.class);
        evaluationService = mock(PositionEvaluationService.class);
        service = new AfterClosingEvaluationService(splitter, swapItAggregator, spotCloseCostReplacer,
                rateMapper, evaluationService);
    }

    @Test
    @DisplayName("AC分とIT分/持ち替え分を結合し、引値以降区分で評価サービスへ委譲する")
    void evaluate_combinesAndDelegates() throws Exception {
        StepContribution contribution = mock(StepContribution.class);
        Date targetDate = new Date();
        Date busiDaysBefore = new Date();

        TPosSumSourceDataBean spotAc = bean("spotAc");
        TPosSumSourceDataBean swapAc = bean("swapAc");
        TPosSumSourceDataBean spotMapped = bean("spotMapped");
        TPosSumSourceDataBean itMapped = bean("itMapped");

        when(splitter.splitForAfterAc(any(), any()))
                .thenReturn(new SourcePositionSplit(Collections.singletonList(spotAc),
                        Collections.singletonList(swapAc)));
        when(splitter.splitForClosingSwap(any(), any(), any()))
                .thenReturn(new SourcePositionSplit(Collections.<TPosSumSourceDataBean>emptyList(),
                        Collections.singletonList(bean("itRaw"))));
        when(swapItAggregator.aggregate(any())).thenReturn(Collections.singletonList(bean("itNetted")));
        when(spotCloseCostReplacer.replace(any(), any())).thenReturn(Collections.singletonList(bean("spotReplaced")));
        // rateMapper は IT 分→itMapped、持ち替え分→spotMapped を返す
        when(rateMapper.map(any(), any(), any()))
                .thenReturn(Collections.singletonList(itMapped))
                .thenReturn(Collections.singletonList(spotMapped));

        // RateLookupContext は final な不変ホルダのため mock 不可。実インスタンスを生成して渡す
        // （内容は rateMapper（モック）へ素通しされるだけで本テストの検証には影響しない）。
        RateLookupContext rateContext = new RateLookupContext("2026/06/28",
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

        service.evaluate(contribution, targetDate, busiDaysBefore,
                Collections.<TPosSumSourceDataBean>emptyList(),
                Collections.<TPositionSpotSumDataBean>emptyList(),
                rateContext, Collections.emptyList(), Collections.emptyList(),
                Collections.<TPositionSpotSumDataBean>emptyList());

        ArgumentCaptor<SourcePositionSplit> splitCaptor = ArgumentCaptor.forClass(SourcePositionSplit.class);
        verify(evaluationService).evaluate(any(), any(), splitCaptor.capture(), any(), any(), any(),
                eq(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode()), any());

        List<TPosSumSourceDataBean> spot = splitCaptor.getValue().getSpotList();
        List<TPosSumSourceDataBean> swap = splitCaptor.getValue().getSwapList();
        assertThat(spot).containsExactly(spotAc, spotMapped);
        assertThat(swap).containsExactly(swapAc, itMapped);
    }

    private TPosSumSourceDataBean bean(String dealerBook) {
        TPosSumSourceDataBean bean = new TPosSumSourceDataBean();
        bean.setDealerBook(dealerBook);
        return bean;
    }
}
