package jp.co.daiwa.jbpos1100.swap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.dto.TPositionSwapSumDataDto;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashCalculator;

/**
 * {@link SwapSummaryService} の結線テスト。
 *
 * <p>各専門クラスをモック化し、旧 {@code mkPositionSwapSumData} と同じ順序
 * （CF組立 → 通貨纏め → デルタ → PL合計）で呼び出され、3 つの成果物が結果に集約される
 * ことを検証する。</p>
 */
class SwapSummaryServiceTest {

    private SwapCashSumAssembler cashSumAssembler;
    private SwapCurrencyAggregator currencyAggregator;
    private CurrencyDeltaCashCalculator deltaCashCalculator;
    private SwapPlSumCalculator plSumCalculator;
    private SwapSummaryService service;

    private StepContribution contribution;
    private Date targetDate;

    @BeforeEach
    void setUp() {
        cashSumAssembler = mock(SwapCashSumAssembler.class);
        currencyAggregator = mock(SwapCurrencyAggregator.class);
        deltaCashCalculator = mock(CurrencyDeltaCashCalculator.class);
        plSumCalculator = mock(SwapPlSumCalculator.class);
        service = new SwapSummaryService(cashSumAssembler, currencyAggregator, deltaCashCalculator, plSumCalculator);
        contribution = mock(StepContribution.class);
        targetDate = new Date();
    }

    @Test
    @DisplayName("CF組立→通貨纏め→デルタ→PL合計 の順で呼び出し、結果を集約する")
    void aggregate_wiresPipelineInOrder() throws Exception {
        List<TPositionSwapSumDataDto> cashSum = Collections.singletonList(new TPositionSwapSumDataDto());
        List<TPositionSwapSumDataBean> currencySum = Collections.singletonList(new TPositionSwapSumDataBean());
        List<TByCcyDeltaCashBalanceBean> deltaCash = Collections.singletonList(new TByCcyDeltaCashBalanceBean());
        List<TSwapPlSumDateBean> plSum = Collections.singletonList(new TSwapPlSumDateBean());

        when(cashSumAssembler.assemble(any(), any(), any(), any(), anyString(), any())).thenReturn(cashSum);
        when(currencyAggregator.aggregate(cashSum)).thenReturn(currencySum);
        when(deltaCashCalculator.calculate(any(), any(), anyString(), any(), eq(currencySum), any()))
                .thenReturn(deltaCash);
        when(plSumCalculator.calculate(any(), any(), eq(currencySum))).thenReturn(plSum);

        SwapSummaryResult result = service.aggregate(contribution, targetDate,
                Collections.<TPosSumSourceDataBean>emptyList(), Collections.<TPosSumSourceDataBean>emptyList(),
                Collections.emptyList(), Collections.emptyList(), "00");

        assertThat(result.getCurrencySumList()).isSameAs(currencySum);
        assertThat(result.getDeltaCashList()).isSameAs(deltaCash);
        assertThat(result.getPlSumList()).isSameAs(plSum);

        InOrder inOrder = inOrder(cashSumAssembler, currencyAggregator, deltaCashCalculator, plSumCalculator);
        inOrder.verify(cashSumAssembler).assemble(any(), any(), any(), any(), anyString(), any());
        inOrder.verify(currencyAggregator).aggregate(cashSum);
        inOrder.verify(deltaCashCalculator).calculate(any(), any(), anyString(), any(), eq(currencySum), any());
        inOrder.verify(plSumCalculator).calculate(any(), any(), eq(currencySum));
    }
}
