package jp.co.daiwa.jbpos1100.common;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;

import jp.co.daiwa.common.constant.FxdConstants;

/**
 * {@link TransactionalBatchExecutor} の単体テスト。
 *
 * <p>{@link PlatformTransactionManager} と {@link JobWarningReporter} をモック化し、
 * 中間コミット・ロールバック・DB 切断時の再スロー・一括 INSERT の 1 件リトライを検証する。</p>
 */
class TransactionalBatchExecutorTest {

    private PlatformTransactionManager txManager;
    private JobWarningReporter warningReporter;
    private TransactionStatus status;
    private TransactionalBatchExecutor executor;

    @BeforeEach
    void setUp() {
        txManager = mock(PlatformTransactionManager.class);
        warningReporter = mock(JobWarningReporter.class);
        status = mock(TransactionStatus.class);
        when(txManager.getTransaction(any())).thenReturn(status);
        executor = new TransactionalBatchExecutor(txManager, warningReporter);
    }

    @Test
    @DisplayName("成功時はコミットされ、ロールバック・警告は発生しない")
    void runInNewTransaction_success_commits() throws Exception {
        executor.runInNewTransaction("test", () -> { /* 正常終了 */ });

        verify(txManager).commit(status);
        verify(txManager, never()).rollback(any());
        verify(warningReporter, never()).warn(any(), any(Throwable.class));
    }

    @Test
    @DisplayName("業務例外時はロールバックし警告状態にする（再スローしない）")
    void runInNewTransaction_businessError_rollbackAndWarn() throws Exception {
        executor.runInNewTransaction("test", () -> {
            throw new IllegalStateException("boom");
        });

        verify(txManager).rollback(status);
        verify(warningReporter).warn(eq("test"), any(Throwable.class));
        verify(txManager, never()).commit(any());
    }

    @Test
    @DisplayName("DB切断由来の例外は再スローする")
    void runInNewTransaction_dbDisconnect_rethrows() {
        assertThatThrownBy(() -> executor.runInNewTransaction("test", () -> {
            throw new RuntimeException(FxdConstants.DB_IO_EXCEPTION);
        })).isInstanceOf(RuntimeException.class);

        verify(txManager).rollback(status);
    }

    @Test
    @DisplayName("一括INSERTは指定単位でチャンク分割しコミットする")
    void bulkInsert_chunksByUnit() throws Exception {
        List<Integer> items = Arrays.asList(1, 2, 3, 4, 5);
        List<List<Integer>> inserted = new ArrayList<>();

        executor.bulkInsertWithRetry("ins", items, 2, chunk -> inserted.add(new ArrayList<>(chunk)));

        // 5件 / 2 = 3チャンク
        assertThat(inserted).hasSize(3);
        verify(txManager, times(3)).commit(status);
    }

    @Test
    @DisplayName("チャンクINSERT失敗時は1件ずつ再INSERTする")
    void bulkInsert_chunkFails_retriesOneByOne() throws Exception {
        List<Integer> items = Arrays.asList(1, 2);
        List<List<Integer>> attempts = new ArrayList<>();

        executor.bulkInsertWithRetry("ins", items, 2, chunk -> {
            attempts.add(new ArrayList<>(chunk));
            if (chunk.size() > 1) {
                throw new IllegalStateException("bulk fails");
            }
        });

        // 1回目: 2件まとめて失敗 → 1件ずつ2回 = 計3回呼び出し
        assertThat(attempts).hasSize(3);
        assertThat(attempts.get(0)).hasSize(2);
        assertThat(attempts.get(1)).hasSize(1);
        assertThat(attempts.get(2)).hasSize(1);
        verify(warningReporter).warn(eq("ins"), any(Throwable.class));
    }
}
