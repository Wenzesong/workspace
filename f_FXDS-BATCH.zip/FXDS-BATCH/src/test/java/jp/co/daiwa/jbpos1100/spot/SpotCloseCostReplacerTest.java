package jp.co.daiwa.jbpos1100.spot;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;

/**
 * {@link SpotCloseCostReplacer} の単体テスト。符号・取引レート優先・決済金額の算出を検証する。
 */
class SpotCloseCostReplacerTest {

    private SpotCloseCostReplacer replacer;
    private Date targetDate;

    @BeforeEach
    void setUp() {
        replacer = new SpotCloseCostReplacer();
        targetDate = new Date();
    }

    @Test
    @DisplayName("評価ポジションが正なら買い・絶対値、取引レートはマニュアル引値TTM優先")
    void replace_positivePosition_usesManualTtm() {
        TPositionSpotSumDataBean item = spot(new BigDecimal("100"), new BigDecimal("151"), new BigDecimal("150"));

        List<TPosSumSourceDataBean> result = replacer.replace(Collections.singletonList(item), targetDate);

        TPosSumSourceDataBean pos = result.get(0);
        assertThat(pos.getDealDivision()).isEqualTo("1");
        assertThat(pos.getDealAmount()).isEqualByComparingTo("100");
        assertThat(pos.getTradeRate()).isEqualByComparingTo("151");
        // 決済金額 = 100 * 151
        assertThat(pos.getSettleAmount()).isEqualByComparingTo("15100");
        assertThat(pos.getExchangeDivision()).isNotNull();
    }

    @Test
    @DisplayName("マニュアルレートが無ければ引値レートを使用、負ポジションは売り・絶対値")
    void replace_negativePosition_usesClosingRate() {
        TPositionSpotSumDataBean item = spot(new BigDecimal("-80"), null, new BigDecimal("150"));

        List<TPosSumSourceDataBean> result = replacer.replace(Collections.singletonList(item), targetDate);

        TPosSumSourceDataBean pos = result.get(0);
        assertThat(pos.getDealDivision()).isEqualTo("2");
        assertThat(pos.getDealAmount()).isEqualByComparingTo("80");
        assertThat(pos.getTradeRate()).isEqualByComparingTo("150");
        assertThat(pos.getSettleAmount()).isEqualByComparingTo("12000");
    }

    private TPositionSpotSumDataBean spot(BigDecimal evaluationPosition, BigDecimal manualTtm, BigDecimal closingRate) {
        TPositionSpotSumDataBean bean = new TPositionSpotSumDataBean();
        bean.setDealerBook("BOOK1");
        bean.setCurrencyPair("USDJPY");
        bean.setDealCurrency("USD");
        bean.setSettleCurrency("JPY");
        bean.setExchangeDivision("0");
        bean.setEvaluationPosition(evaluationPosition);
        bean.setManualClosingTtmRate(manualTtm);
        bean.setClosingRate(closingRate);
        bean.setEvaluationRateDivision("01");
        return bean;
    }
}
