package jp.co.daiwa.jbpos1100.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * {@link BigDecimalSummer} の単体テスト（外部依存なし）。
 */
class BigDecimalSummerTest {

    @Test
    @DisplayName("リストの値を合計する")
    void sum_addsAllValues() {
        List<BigDecimal> list = Arrays.asList(new BigDecimal("1.5"), new BigDecimal("2.5"), new BigDecimal("3"));

        BigDecimal result = BigDecimalSummer.sum(list, v -> v);

        assertThat(result).isEqualByComparingTo("7.0");
    }

    @Test
    @DisplayName("空リストはゼロを返す")
    void sum_emptyList_returnsZero() {
        BigDecimal result = BigDecimalSummer.sum(Collections.<BigDecimal>emptyList(), v -> v);

        assertThat(result).isEqualByComparingTo(BigDecimal.ZERO);
    }

    @Test
    @DisplayName("sumNullSafe は null 要素を 0 として扱う")
    void sumNullSafe_treatsNullAsZero() {
        List<BigDecimal> list = Arrays.asList(new BigDecimal("10"), null, new BigDecimal("5"));

        BigDecimal result = BigDecimalSummer.sumNullSafe(list, v -> v);

        assertThat(result).isEqualByComparingTo("15");
    }
}
