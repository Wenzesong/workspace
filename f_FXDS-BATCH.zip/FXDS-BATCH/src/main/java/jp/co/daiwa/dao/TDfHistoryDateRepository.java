package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TDfHistoryDateBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TDfHistoryDateRepository}（DF 履歴情報）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TDfHistoryDateRepository {

    List<TDfHistoryDateBean> getDfHistoryDateBeanAll(TDfHistoryDateBean condition);
}
