package jp.co.daiwa.base;

/**
 * コンパイル補足用スタブ（jbpos1100 を本リポジトリ単体でコンパイルさせるための最小定義）。
 *
 * <p>実体は FXDS 共通基盤の {@code jp.co.daiwa.base.LogBatchBasedLogger}。
 * jbpos1100 からは {@code getLogger(Class)} と可変長引数の info/warn/error/trace のみ使用される。
 * 実プロジェクトへ戻す際は本スタブを削除し、本来のロガー実装を使用すること。</p>
 */
public final class LogBatchBasedLogger {

    private LogBatchBasedLogger() {
    }

    public static LogBatchBasedLogger getLogger(Class<?> clazz) {
        return new LogBatchBasedLogger();
    }

    public void info(Object... args) {
    }

    public void warn(Object... args) {
    }

    public void error(Object... args) {
    }

    public void trace(Object... args) {
    }

    public void debug(Object... args) {
    }
}
