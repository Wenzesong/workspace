package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TDfarmBbgRateBean}（BBG レート情報）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TDfarmBbgRateBean {

    private String currencyPair;
    private String dealCurrency;
    private BigDecimal rate;

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getDealCurrency() {
        return dealCurrency;
    }

    public void setDealCurrency(String dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }
}
