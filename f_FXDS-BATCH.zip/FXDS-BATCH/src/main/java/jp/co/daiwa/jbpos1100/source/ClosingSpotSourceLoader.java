package jp.co.daiwa.jbpos1100.source;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.TPositionPlDeltaDataRepository;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionPlDeltaDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.common.BatchConstants;

/**
 * 引値／引値以降集計で必要な「DB 集計結果由来のスポット集計元」を取得・変換するローダ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setSpotSumData}（プレ引値スポット結果→集計元）と
 * {@code setDeltaData}（PL デルタ→集計元）の移植版。DB 取得（リポジトリ）と
 * Bean→集計元 変換をまとめる。計算式・符号は変更しない。</p>
 */
public class ClosingSpotSourceLoader {

    private final TPositionSpotSumDataRepository spotSumRepository;
    private final TPositionPlDeltaDataRepository plDeltaRepository;

    /**
     * @param spotSumRepository ポジションスポット集計結果リポジトリ
     * @param plDeltaRepository 決済通貨外貨 PL デルタ生成情報リポジトリ
     */
    public ClosingSpotSourceLoader(TPositionSpotSumDataRepository spotSumRepository,
            TPositionPlDeltaDataRepository plDeltaRepository) {
        this.spotSumRepository = spotSumRepository;
        this.plDeltaRepository = plDeltaRepository;
    }

    /**
     * プレ引値のスポット集計結果を取得し、集計元情報へ変換する（旧 setSpotSumData）。
     *
     * @param targetDate 基準日
     * @return 集計元情報リスト
     */
    public List<TPosSumSourceDataBean> loadPreClosingSpotAsSource(Date targetDate) {
        TPositionSpotSumDataBean condition = new TPositionSpotSumDataBean();
        condition.setProcessBaseDate(targetDate);
        List<TPositionSpotSumDataBean> spotSumList = spotSumRepository.geTPositionSpotSumDataBeanAll(condition).stream()
                .filter(d -> d.getEvaluationRateDivision().equals(EvaluationRateKbn.PRE_CLOSING.getCode()))
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                .collect(Collectors.toList());

        List<TPosSumSourceDataBean> result = new ArrayList<>();
        for (TPositionSpotSumDataBean item : spotSumList) {
            result.add(toSpotSource(item, targetDate));
        }
        return result;
    }

    /**
     * 引値スポット集計結果（評価レート区分=引値）を取得する（引値以降集計の入力）。
     *
     * @param targetDate 基準日
     * @return スポット引値集計結果リスト
     */
    public List<TPositionSpotSumDataBean> loadClosingSpotResults(Date targetDate) {
        TPositionSpotSumDataBean condition = new TPositionSpotSumDataBean();
        condition.setProcessBaseDate(targetDate);
        return spotSumRepository.geTPositionSpotSumDataBeanAll(condition).stream()
                .filter(d -> d.getEvaluationRateDivision().trim().equals(EvaluationRateKbn.CLOSING_PRICE.getCode()))
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                .collect(Collectors.toList());
    }

    /**
     * 決済通貨外貨 PL デルタ生成情報を取得し、集計元情報へ変換する（旧 setDeltaData）。
     *
     * @param targetDate 基準日
     * @return 集計元情報リスト
     */
    public List<TPosSumSourceDataBean> loadDeltaAsSource(Date targetDate) {
        TPositionPlDeltaDataBean condition = new TPositionPlDeltaDataBean();
        condition.setProcessBaseDate(targetDate);
        List<TPositionPlDeltaDataBean> plDeltaList = plDeltaRepository.getTPositionPlDeltaDataBeanAll(condition);

        List<TPosSumSourceDataBean> result = new ArrayList<>();
        for (TPositionPlDeltaDataBean item : plDeltaList) {
            result.add(toDeltaSource(item, targetDate));
        }
        return result;
    }

    private TPosSumSourceDataBean toSpotSource(TPositionSpotSumDataBean item, Date targetDate) {
        TPosSumSourceDataBean pos = new TPosSumSourceDataBean();
        pos.setProcessBaseDate(item.getProcessBaseDate());
        pos.setTradeDatetime(new Timestamp(targetDate.getTime()));
        pos.setDealerBook(item.getDealerBook());
        pos.setAc(item.getAc());
        pos.setDealCurrency(item.getDealCurrency());
        pos.setSettleCurrency(item.getSettleCurrency());
        pos.setCurrencyPair(item.getCurrencyPair());
        pos.setExchangeDivision(item.getExchangeDivision());
        pos.setDealDivision(item.getEvaluationPosition().compareTo(BigDecimal.ZERO) >= 0
                ? BatchConstants.DEAL_DIVISION_BUY : BatchConstants.DEAL_DIVISION_SELL);
        pos.setDealAmount(item.getEvaluationPosition().abs());
        pos.setTradeRate(item.getAvgCostRate());
        pos.setSettleAmount(item.getPendingSettleAmount().abs());
        pos.setClosingRate(item.getClosingRate());
        pos.setManualClosingTtmRate(item.getManualClosingTtmRate());
        pos.setClosingYenRate(item.getClosingYenRate());
        pos.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
        return pos;
    }

    private TPosSumSourceDataBean toDeltaSource(TPositionPlDeltaDataBean item, Date targetDate) {
        TPosSumSourceDataBean pos = new TPosSumSourceDataBean();
        pos.setProcessBaseDate(item.getProcessBaseDate());
        // ソート時に外貨PLデルタをプレ引値の後に追加するため時刻に +1
        pos.setTradeDatetime(new Timestamp(targetDate.getTime() + 1));
        pos.setDealerBook(item.getDealerBook());
        pos.setAc(item.getAc());
        pos.setDealCurrency(item.getDealCurrency());
        pos.setSettleCurrency(item.getSettleCurrency());
        pos.setCurrencyPair(item.getCurrencyPair());
        pos.setExchangeDivision(item.getExchangeDivision());
        pos.setDealDivision(item.getDealDivision());
        pos.setDealAmount(item.getDealAmount());
        pos.setTradeRate(item.getTradeRate());
        pos.setSettleAmount(item.getSettleAmount());
        pos.setClosingRate(item.getClosingRate());
        pos.setManualClosingTtmRate(item.getManualClosingTtmRate());
        pos.setClosingYenRate(item.getClosingYenRate());
        return pos;
    }
}
