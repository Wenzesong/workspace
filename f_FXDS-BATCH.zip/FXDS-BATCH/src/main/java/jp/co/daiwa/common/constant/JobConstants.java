package jp.co.daiwa.common.constant;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code jp.co.daiwa.common.constant.JobConstants}。
 *
 * <p>jbpos1100 から参照されるジョブ ID / ジョブ名のみ定義（ともに文字列。ロガー引数や
 * 登録更新者カラムに使用される）。値は実プロジェクトの正規値に従う。</p>
 */
public final class JobConstants {

    private JobConstants() {
    }

    /** ジョブ ID。 */
    public static final String Jbpos1000 = "JBPOS1000";

    /** ジョブ名。 */
    public static final String Jbpos1000_Name = "ポジション集計バッチ";
}
