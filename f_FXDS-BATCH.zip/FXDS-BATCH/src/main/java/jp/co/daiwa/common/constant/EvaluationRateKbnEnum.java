package jp.co.daiwa.common.constant;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code EvaluationRateKbnEnum}。
 *
 * <p>jbpos1100 は内包 enum {@link EvaluationRateKbn} の各区分と {@code getCode()}/{@code getName()}
 * を使用する。コード値（00/01/02/03/99）は jbpos1100 内のコメント・分岐から推定した既定値であり、
 * 実プロジェクトの正規コードで検証すること。</p>
 */
public final class EvaluationRateKbnEnum {

    private EvaluationRateKbnEnum() {
    }

    public enum EvaluationRateKbn {
        REAL("00", "Real"),
        CLOSING_PRICE("01", "引値"),
        AFTER_CLOSING_PRICE("02", "引値以降"),
        END_OF_DAY_CLOSING("03", "日締め"),
        PRE_CLOSING("99", "プレ引値");

        private final String code;
        private final String name;

        EvaluationRateKbn(String code, String name) {
            this.code = code;
            this.name = name;
        }

        public String getCode() {
            return code;
        }

        public String getName() {
            return name;
        }
    }
}
