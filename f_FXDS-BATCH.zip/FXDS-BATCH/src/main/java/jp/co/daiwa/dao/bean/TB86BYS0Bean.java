package jp.co.daiwa.dao.bean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TB86BYS0Bean}（BID 外 M データ仕分けの検索条件）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TB86BYS0Bean {

    private String yakymd1;
    private String chuymd;

    public String getYakymd1() {
        return yakymd1;
    }

    public void setYakymd1(String yakymd1) {
        this.yakymd1 = yakymd1;
    }

    public String getChuymd() {
        return chuymd;
    }

    public void setChuymd(String chuymd) {
        this.chuymd = chuymd;
    }
}
