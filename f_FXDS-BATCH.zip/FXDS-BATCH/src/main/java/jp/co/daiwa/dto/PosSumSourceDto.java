package jp.co.daiwa.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code jp.co.daiwa.dto.PosSumSourceDto}（ポジション集計元 DTO）。
 *
 * <p>jbpos1100 の突合（{@code PositionSourceMatcher}）・検証変換（{@code SourceDataMapper}）が参照する
 * アクセサのみ定義。注文番号/訂正番号は利用側で {@code toString()} のみ使用するため String で保持する。</p>
 */
public class PosSumSourceDto {

    private String tradeDivision;
    private String product;
    private String orderNumber;
    private String revisionNumber;
    private String exchangeDivision;
    private String dealCurrency;
    private String settleCurrency;
    private BigDecimal dealAmount;
    private BigDecimal tradeRate;
    private BigDecimal settleAmount;
    private String inputDataSource;
    private String bidHonkbn;
    private String bidAtbutcd;
    private String bidAkokcd1;
    private String departmentCode;
    private String customerCode;
    private String departmentCodeSpot;
    private String customerCodeSpot;
    private String departmentCodeSwap;
    private String customerCodeSwap;
    private String dealerBook;
    private String customerDivision;
    private String currencyPair;
    private Date deliveryDate;
    private Date tradeDatetime;
    private String ac;
    private String dealDivision;

    public String getTradeDivision() {
        return tradeDivision;
    }

    public void setTradeDivision(String tradeDivision) {
        this.tradeDivision = tradeDivision;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getRevisionNumber() {
        return revisionNumber;
    }

    public void setRevisionNumber(String revisionNumber) {
        this.revisionNumber = revisionNumber;
    }

    public String getExchangeDivision() {
        return exchangeDivision;
    }

    public void setExchangeDivision(String exchangeDivision) {
        this.exchangeDivision = exchangeDivision;
    }

    public String getDealCurrency() {
        return dealCurrency;
    }

    public void setDealCurrency(String dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    public String getSettleCurrency() {
        return settleCurrency;
    }

    public void setSettleCurrency(String settleCurrency) {
        this.settleCurrency = settleCurrency;
    }

    public BigDecimal getDealAmount() {
        return dealAmount;
    }

    public void setDealAmount(BigDecimal dealAmount) {
        this.dealAmount = dealAmount;
    }

    public BigDecimal getTradeRate() {
        return tradeRate;
    }

    public void setTradeRate(BigDecimal tradeRate) {
        this.tradeRate = tradeRate;
    }

    public BigDecimal getSettleAmount() {
        return settleAmount;
    }

    public void setSettleAmount(BigDecimal settleAmount) {
        this.settleAmount = settleAmount;
    }

    public String getInputDataSource() {
        return inputDataSource;
    }

    public void setInputDataSource(String inputDataSource) {
        this.inputDataSource = inputDataSource;
    }

    public String getBidHonkbn() {
        return bidHonkbn;
    }

    public void setBidHonkbn(String bidHonkbn) {
        this.bidHonkbn = bidHonkbn;
    }

    public String getBidAtbutcd() {
        return bidAtbutcd;
    }

    public void setBidAtbutcd(String bidAtbutcd) {
        this.bidAtbutcd = bidAtbutcd;
    }

    public String getBidAkokcd1() {
        return bidAkokcd1;
    }

    public void setBidAkokcd1(String bidAkokcd1) {
        this.bidAkokcd1 = bidAkokcd1;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getDepartmentCodeSpot() {
        return departmentCodeSpot;
    }

    public void setDepartmentCodeSpot(String departmentCodeSpot) {
        this.departmentCodeSpot = departmentCodeSpot;
    }

    public String getCustomerCodeSpot() {
        return customerCodeSpot;
    }

    public void setCustomerCodeSpot(String customerCodeSpot) {
        this.customerCodeSpot = customerCodeSpot;
    }

    public String getDepartmentCodeSwap() {
        return departmentCodeSwap;
    }

    public void setDepartmentCodeSwap(String departmentCodeSwap) {
        this.departmentCodeSwap = departmentCodeSwap;
    }

    public String getCustomerCodeSwap() {
        return customerCodeSwap;
    }

    public void setCustomerCodeSwap(String customerCodeSwap) {
        this.customerCodeSwap = customerCodeSwap;
    }

    public String getDealerBook() {
        return dealerBook;
    }

    public void setDealerBook(String dealerBook) {
        this.dealerBook = dealerBook;
    }

    public String getCustomerDivision() {
        return customerDivision;
    }

    public void setCustomerDivision(String customerDivision) {
        this.customerDivision = customerDivision;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public Date getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public Date getTradeDatetime() {
        return tradeDatetime;
    }

    public void setTradeDatetime(Date tradeDatetime) {
        this.tradeDatetime = tradeDatetime;
    }

    /** {@code tradeDatetime} と同一フィールドへの別名アクセサ（旧 DTO の getTradeDatetime/setTradeDate 不一致に対応）。 */
    public Date getTradeDate() {
        return tradeDatetime;
    }

    public void setTradeDate(Date tradeDate) {
        this.tradeDatetime = tradeDate;
    }

    public String getAc() {
        return ac;
    }

    public void setAc(String ac) {
        this.ac = ac;
    }

    public String getDealDivision() {
        return dealDivision;
    }

    public void setDealDivision(String dealDivision) {
        this.dealDivision = dealDivision;
    }
}
