package jp.co.daiwa.jbpos1000;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.DateUtil;
import jp.co.daiwa.common.FileUtil;
import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;

/**
 * ポジション集計ファイル出力<br>
 *
 * スポット集計ファイル出力処理<br>
 * スワップ集計ファイル出力処理<br>
 *
 * @author nttd
 *
 */
public class Jbpos1000PositionSumDateFileUtil {

    /** ポジションスポット集計ファイル名 */
    private static final String SOPT_FILE = "position_spot_sum_";
    /** ポジションスワップ集計ファイル名 */
    private static final String SWAP_FILE = "position_swap_sum_";
    /** 計算エラーメッセージ */
    private static final String CALC_ERR = "計算エラー";
    /** TSVファイル */
    private static final String FILE_TSV = ".tsv";
    /** Logger */
    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(Jbpos1000PositionSumDateFileUtil.class);

    /**
     * ポジションスポット集計ファイルの出力
     *
     * @param contribution                ジョブStepContribution
     * @param outputFilePath              出力先フォルダ
     * @param evaluationRateKbn           評価レート区分コード値
     * @param tPositionSpotSumDataBeanList ポジションスポット集計情報
     */
    public static void writePostSumDateFile(StepContribution contribution,
            String outputFilePath,
            String evaluationRateKbn,
            List<TPositionSpotSumDataBean> tPositionSpotSumDataBeanList) {
        String filename = outputFilePath + SOPT_FILE + EvaluationRateKbn.getByCode(evaluationRateKbn).getName() + FILE_TSV;
        List<List<String>> fileData = new ArrayList<>();
        try {
            for (TPositionSpotSumDataBean item : tPositionSpotSumDataBeanList) {
                List<String> lineData = new ArrayList<>();
                StringBuilder sb = new StringBuilder();
                // 実行日
                sb.append(DateUtil.convertDateToStrYmdSlash(item.getProcessBaseDate()));
                sb.append(FxdConstants.KEY_TAB);
                // ディーラブック
                sb.append(item.getDealerBook());
                sb.append(FxdConstants.KEY_TAB);
                // 通貨ペア
                sb.append(item.getCurrencyPair());
                sb.append(FxdConstants.KEY_TAB);
                // Real評価レート(ストリーミングレート)
                sb.append(item.getRealRate());
                sb.append(FxdConstants.KEY_TAB);
                // 引値評価レート
                sb.append(item.getClosingRate());
                sb.append(FxdConstants.KEY_TAB);
                // マニュアル(日中時価評価レート)
                sb.append(item.getManualDailyRate());
                sb.append(FxdConstants.KEY_TAB);
                // マニュアル(引けレート、TTM)
                sb.append(item.getManualClosingTtmRate());
                sb.append(FxdConstants.KEY_TAB);
                // Avgコストレート
                sb.append(item.getAvgCostRate());
                sb.append(FxdConstants.KEY_TAB);
                // 評価ポジション
                sb.append(item.getEvaluationPosition());
                sb.append(FxdConstants.KEY_TAB);
                // 評価PL(円換算)
                sb.append(item.getEvaluationPlYenConversion() == null ? CALC_ERR : item.getEvaluationPlYenConversion());
                sb.append(FxdConstants.KEY_TAB);
                // 累積確定PL(円換算)
                sb.append(item.getSumPlYenConversion());
                sb.append(FxdConstants.KEY_TAB);
                // 合計PL額
                sb.append(item.getSumPlYen() == null ? CALC_ERR : item.getSumPlYen());
                sb.append(FxdConstants.KEY_TAB);
                // 前日繰越
                sb.append(item.getBeforeEvaluationPosition());
                sb.append(FxdConstants.KEY_TAB);
                // ネット増減
                sb.append(item.getNetIncreaseOrDecrease());
                sb.append(FxdConstants.KEY_TAB);
                // 更新者
                sb.append(item.getUpdateUser());
                sb.append(FxdConstants.KEY_TAB);
                // 更新日時
                sb.append(new Timestamp(System.currentTimeMillis()));
                lineData.add(sb.toString());
                fileData.add(lineData);
            }
            FileUtil.writeTsvFile(filename, fileData);
        } catch (Exception e) {
            logger.warn("PositionSumDateFileUtil.writePosSumDateFile", "ポジションスポット集計ファイル出力", "MSG_J_W002", e);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
    }

    /**
     * ポジションスワップ集計ファイルの出力
     *
     * @param contribution               StepContribution
     * @param outputFilePath             出力先フォルダ
     * @param evaluationRateKbn          評価レート区分コード値
     * @param tPosSwapPlSumDataList      ポジションスワップ集計情報
     * @param tByCcyDletaCashBalanceList 通貨別デルタ・キャッシュ残情報
     * @param tposSwapSumCcyDataList     ポジションスワップ集計結果情報
     */
    public static void writeSwapSumDateFile(StepContribution contribution,
            String outputFilePath,
            String evaluationRateKbn,
            List<TSwapPlSumDateBean> tPosSwapPlSumDataList,
            List<TByCcyDeltaCashBalanceBean> tByCcyDletaCashBalanceList,
            List<TPositionSwapSumDataBean> tposSwapSumCcyDataList) {
        String filename = outputFilePath + SWAP_FILE + EvaluationRateKbn.getByCode(evaluationRateKbn).getName() + FILE_TSV;
        List<List<String>> fileData = new ArrayList<>();
        try {
            for (TSwapPlSumDateBean item : tPosSwapPlSumDataList) {
                List<String> lineData = new ArrayList<>();
                StringBuilder sb = new StringBuilder();
                // 実行日
                sb.append(DateUtil.convertDateToStrYmdSlash(item.getProcessBaseDate()));
                sb.append(FxdConstants.KEY_TAB);
                // ディーラブック
                sb.append(item.getDealerBook());
                sb.append(FxdConstants.KEY_TAB);
                // PL合計値
                sb.append(item.getPlTotal() == null ? CALC_ERR : item.getPlTotal());
                lineData.add(sb.toString());
                fileData.add(lineData);
            }
            fileData.add(Arrays.asList(""));
            for (TByCcyDeltaCashBalanceBean item : tByCcyDletaCashBalanceList) {
                List<String> lineData = new ArrayList<>();
                StringBuilder sb = new StringBuilder();
                // 実行日
                sb.append(DateUtil.convertDateToStrYmdSlash(item.getProcessBaseDate()));
                sb.append(FxdConstants.KEY_TAB);
                // ディーラブック
                sb.append(item.getDealerBook());
                sb.append(FxdConstants.KEY_TAB);
                // 通貨
                sb.append(item.getCurrency());
                sb.append(FxdConstants.KEY_TAB);
                // Dleta
                sb.append(item.getDelta() == null ? CALC_ERR : item.getDelta());
                sb.append(FxdConstants.KEY_TAB);
                // キャッシュ残
                sb.append(item.getCashBalance() == null ? BigDecimal.ZERO : item.getCashBalance());
                lineData.add(sb.toString());
                fileData.add(lineData);
            }
            fileData.add(Arrays.asList(""));
            for (TPositionSwapSumDataBean item : tposSwapSumCcyDataList) {
                List<String> lineData = new ArrayList<>();
                StringBuilder sb = new StringBuilder();
                // 処理基準日
                sb.append(DateUtil.convertDateToStrYmdSlash(item.getProcessBaseDate()));
                sb.append(FxdConstants.KEY_TAB);
                // ディーラブック
                sb.append(item.getDealerBook());
                sb.append(FxdConstants.KEY_TAB);
                // 通貨
                sb.append(item.getCurrency());
                sb.append(FxdConstants.KEY_TAB);
                // 受渡日
                sb.append(DateUtil.convertDateToStrYmdSlash(item.getDeliveryDate()));
                sb.append(FxdConstants.KEY_TAB);
                // CF金額
                sb.append(item.getCashAmount());
                lineData.add(sb.toString());
                fileData.add(lineData);
            }
            FileUtil.writeTsvFile(filename, fileData);
        } catch (Exception e) {
            logger.warn("PositionSumDateFileUtil.writeSwapSumDateFile", "ポジションスワップ集計ファイル出力", "MSG_J_W002", e);
            // ジョブ警告状態を設定
            contribution.getStepExecution().getJobExecution().getExecutionContext()
                    .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
        }
    }
}
