package jp.co.daiwa.jbpos1100.common;

import java.util.ArrayList;
import java.util.List;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;

/**
 * 引値集計結果を日締め（END_OF_DAY_CLOSING＝評価レート区分 03）用に複製するユーティリティ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setClosingData} / {@code setSwapClosingData} /
 * {@code setCcyDeltaCashClosingData} / {@code setSwapPlSumClosingData} の移植版。
 * 各項目を複製し、評価レート区分のみ日締めコードへ差し替える（値・符号は変更しない）。</p>
 *
 * <p>旧 {@code closingDataLsit}（綴り誤り）は {@code closingDataList} に修正。</p>
 */
public class EndOfDayClosingDuplicator {

    private static final String END_OF_DAY = EvaluationRateKbn.END_OF_DAY_CLOSING.getCode();

    /**
     * スポット集計結果を日締め用に複製する。
     *
     * @param spotSumList スポット集計結果
     * @return 日締め用スポット集計結果
     */
    public List<TPositionSpotSumDataBean> duplicateSpot(List<TPositionSpotSumDataBean> spotSumList) {
        List<TPositionSpotSumDataBean> closingDataList = new ArrayList<>();
        for (TPositionSpotSumDataBean item : spotSumList) {
            TPositionSpotSumDataBean pos = new TPositionSpotSumDataBean();
            pos.setProcessBaseDate(item.getProcessBaseDate());
            pos.setDealerBook(item.getDealerBook());
            pos.setEvaluationRateDivision(END_OF_DAY);
            pos.setDealCurrency(item.getDealCurrency());
            pos.setSettleCurrency(item.getSettleCurrency());
            pos.setCurrencyPair(item.getCurrencyPair());
            pos.setExchangeDivision(item.getExchangeDivision());
            pos.setDealAmount(item.getDealAmount());
            pos.setSettleAmount(item.getSettleAmount());
            pos.setAc(item.getAc());
            pos.setDealDivision(item.getDealDivision());
            pos.setRateSource(item.getRateSource());
            pos.setBbgRate(item.getBbgRate());
            pos.setRealRate(item.getRealRate());
            pos.setClosingRate(item.getClosingRate());
            pos.setAvgCostRate(item.getAvgCostRate());
            pos.setManualDailyRate(item.getManualDailyRate());
            pos.setManualClosingTtmRate(item.getManualClosingTtmRate());
            pos.setRealYenRate(item.getRealYenRate());
            pos.setClosingYenRate(item.getClosingYenRate());
            pos.setEvaluationPosition(item.getEvaluationPosition());
            pos.setEvaluationPlUnderlyingCcy(item.getEvaluationPlUnderlyingCcy());
            pos.setEvaluationPlYenConversion(item.getEvaluationPlYenConversion());
            pos.setPendingSettleAmount(item.getPendingSettleAmount());
            pos.setConfirmPosition(item.getConfirmPosition());
            pos.setConfirmUnderlyingCcy(item.getConfirmUnderlyingCcy());
            pos.setSumPlUnderlyingCcy(item.getSumPlUnderlyingCcy());
            pos.setSumPlYenConversion(item.getSumPlYenConversion());
            pos.setSumPlYen(item.getSumPlYen());
            pos.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
            pos.setNetIncreaseOrDecrease(item.getNetIncreaseOrDecrease());
            pos.setRegisterUser(item.getRegisterUser());
            pos.setRegisterDatetime(item.getRegisterDatetime());
            pos.setUpdateUser(item.getUpdateUser());
            pos.setUpdateDatetime(item.getUpdateDatetime());
            closingDataList.add(pos);
        }
        return closingDataList;
    }

    /**
     * スワップ集計結果を日締め用に複製する。
     *
     * @param swapSumList スワップ集計結果
     * @return 日締め用スワップ集計結果
     */
    public List<TPositionSwapSumDataBean> duplicateSwap(List<TPositionSwapSumDataBean> swapSumList) {
        List<TPositionSwapSumDataBean> closingDataList = new ArrayList<>();
        for (TPositionSwapSumDataBean item : swapSumList) {
            TPositionSwapSumDataBean pos = new TPositionSwapSumDataBean();
            pos.setProcessBaseDate(item.getProcessBaseDate());
            pos.setDealerBook(item.getDealerBook());
            pos.setEvaluationRateDivision(END_OF_DAY);
            pos.setCurrency(item.getCurrency());
            pos.setExchangeDivision(item.getExchangeDivision());
            pos.setDeliveryDate(item.getDeliveryDate());
            pos.setDealAmount(item.getDealAmount());
            pos.setSettleAmount(item.getSettleAmount());
            pos.setRealRate(item.getRealRate());
            pos.setClosingRate(item.getClosingRate());
            pos.setRealYenRate(item.getRealYenRate());
            pos.setClosingYenRate(item.getClosingYenRate());
            pos.setDealYenRate(item.getRealYenRate());
            pos.setDealYenClosingRate(item.getClosingYenRate());
            pos.setTradeAmountPvCls(item.getTradeAmountPvCls());
            pos.setTradeAmountPvClsYen(item.getTradeAmountPvClsYen());
            pos.setTradeAmountPv(item.getTradeAmountPv());
            pos.setTradeAmountPvYen(item.getTradeAmountPvYen());
            pos.setTradeAmountPvEva(item.getTradeAmountPvEva());
            pos.setTradeAmountPvEvaYen(item.getTradeAmountPvEvaYen());
            pos.setSettleYenRate(item.getRealYenRate());
            pos.setSettleAmountPv(item.getSettleAmountPv());
            pos.setSettleAmountPvYen(item.getSettleAmountPvYen());
            pos.setCashAmount(item.getCashAmount());
            pos.setSumPlYen(item.getSumPlYen());
            pos.setRegisterUser(item.getRegisterUser());
            pos.setRegisterDatetime(item.getRegisterDatetime());
            pos.setUpdateUser(item.getUpdateUser());
            pos.setUpdateDatetime(item.getUpdateDatetime());
            closingDataList.add(pos);
        }
        return closingDataList;
    }

    /**
     * 通貨別デルタ・キャッシュ残情報を日締め用に複製する。
     *
     * @param deltaCashList 通貨別デルタ・キャッシュ残情報
     * @return 日締め用通貨別デルタ・キャッシュ残情報
     */
    public List<TByCcyDeltaCashBalanceBean> duplicateDeltaCash(List<TByCcyDeltaCashBalanceBean> deltaCashList) {
        List<TByCcyDeltaCashBalanceBean> closingDataList = new ArrayList<>();
        for (TByCcyDeltaCashBalanceBean item : deltaCashList) {
            TByCcyDeltaCashBalanceBean pos = new TByCcyDeltaCashBalanceBean();
            pos.setProcessBaseDate(item.getProcessBaseDate());
            pos.setEvaluationRateDivision(END_OF_DAY);
            pos.setDealerBook(item.getDealerBook());
            pos.setCurrency(item.getCurrency());
            pos.setDelta(item.getDelta());
            pos.setCashBalance(item.getCashBalance());
            pos.setRegisterUser(item.getRegisterUser());
            pos.setRegisterDatetime(item.getRegisterDatetime());
            pos.setUpdateUser(item.getUpdateUser());
            pos.setUpdateDatetime(item.getUpdateDatetime());
            closingDataList.add(pos);
        }
        return closingDataList;
    }

    /**
     * スワップ PL 合計値情報を日締め用に複製する。
     *
     * @param swapPlSumList スワップ PL 合計値情報
     * @return 日締め用スワップ PL 合計値情報
     */
    public List<TSwapPlSumDateBean> duplicateSwapPlSum(List<TSwapPlSumDateBean> swapPlSumList) {
        List<TSwapPlSumDateBean> closingDataList = new ArrayList<>();
        for (TSwapPlSumDateBean item : swapPlSumList) {
            TSwapPlSumDateBean pos = new TSwapPlSumDateBean();
            pos.setProcessBaseDate(item.getProcessBaseDate());
            pos.setEvaluationRateDivision(END_OF_DAY);
            pos.setDealerBook(item.getDealerBook());
            pos.setPlTotal(item.getPlTotal());
            pos.setRegisterUser(item.getRegisterUser());
            pos.setRegisterDatetime(item.getRegisterDatetime());
            pos.setUpdateUser(item.getUpdateUser());
            pos.setUpdateDatetime(item.getUpdateDatetime());
            closingDataList.add(pos);
        }
        return closingDataList;
    }
}
