package jp.co.daiwa.jbpos1100.tasklet;

import java.util.List;

import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;

/**
 * 1 評価レート区分の集計・永続化結果（スポット／スワップ各成果物）を保持する不変ホルダ。
 *
 * <p>{@link PositionEvaluationService#evaluate} の結果を呼び出し側へ返し、引値集計後の
 * 日締めデータ複製（{@link EndOfDayClosingService}）で再利用するために用いる。</p>
 */
public final class PositionEvaluationResult {

    private final List<TPositionSpotSumDataBean> spotSumList;
    private final List<TPositionSwapSumDataBean> swapSumList;
    private final List<TByCcyDeltaCashBalanceBean> deltaCashList;
    private final List<TSwapPlSumDateBean> swapPlSumList;

    public PositionEvaluationResult(List<TPositionSpotSumDataBean> spotSumList,
            List<TPositionSwapSumDataBean> swapSumList, List<TByCcyDeltaCashBalanceBean> deltaCashList,
            List<TSwapPlSumDateBean> swapPlSumList) {
        this.spotSumList = spotSumList;
        this.swapSumList = swapSumList;
        this.deltaCashList = deltaCashList;
        this.swapPlSumList = swapPlSumList;
    }

    public List<TPositionSpotSumDataBean> getSpotSumList() {
        return spotSumList;
    }

    public List<TPositionSwapSumDataBean> getSwapSumList() {
        return swapSumList;
    }

    public List<TByCcyDeltaCashBalanceBean> getDeltaCashList() {
        return deltaCashList;
    }

    public List<TSwapPlSumDateBean> getSwapPlSumList() {
        return swapPlSumList;
    }
}
