package jp.co.daiwa.jbpos1100.rate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.TargetFileFilter;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dto.PosBaseRateDto;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;

/**
 * ベースレートファイル（タブ区切り）を読み込み {@link PosBaseRateDto} リストへ変換するリーダ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#getBaseRateInfo} を、ファイル I/O の単一責務クラスとして分離。
 * 集計ロジックからファイル読込を切り離すことで、リーダ単体でのテストを可能にする。</p>
 *
 * <p>堅牢化（旧レビューで適用済みの P1 修正を踏襲）:
 * listFiles の null/空ガード、try-with-resources、列数チェック。</p>
 */
public class BaseRateFileReader {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(BaseRateFileReader.class);
    private static final String LABEL = "ベースレート取得処理";
    private static final int REQUIRED_COLUMNS = 4;

    private final String baseRateFilePath;
    private final String fileNamePrefix;
    private final JobWarningReporter warningReporter;

    /**
     * @param baseRateFilePath ベースレートファイル格納ディレクトリ
     * @param fileNamePrefix   対象ファイル名プレフィックス
     * @param warningReporter  警告レポータ
     */
    public BaseRateFileReader(String baseRateFilePath, String fileNamePrefix, JobWarningReporter warningReporter) {
        this.baseRateFilePath = baseRateFilePath;
        this.fileNamePrefix = fileNamePrefix;
        this.warningReporter = warningReporter;
    }

    /**
     * ベースレートを読み込む（ファイル名最大＝最新のファイル 1 件）。
     *
     * @return ベースレートリスト（対象なしの場合は空リスト）
     */
    public List<PosBaseRateDto> read() {
        List<PosBaseRateDto> list = new ArrayList<>();

        // [Fixed P1] listFiles は対象ディレクトリ不在時に null を返すためガード
        File[] files = new File(baseRateFilePath).listFiles(new TargetFileFilter(fileNamePrefix, ".*"));
        if (files == null || files.length == 0) {
            warningReporter.warn(LABEL, "対象ファイルが存在しません: " + baseRateFilePath);
            return list;
        }

        File latestFile = pickLatestByName(files);
        try (BufferedReader br = new BufferedReader(new FileReader(latestFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] columns = line.split("\t");
                // [Fixed P1] 列数不足の行はスキップ（ArrayIndexOutOfBounds 回避）
                if (columns.length < REQUIRED_COLUMNS) {
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", LABEL,
                            "列数が不足しているため行をスキップ: " + line);
                    continue;
                }
                list.add(toDto(columns));
            }
        } catch (Exception e) {
            warningReporter.warn(LABEL, e);
        }
        return list;
    }

    private File pickLatestByName(File[] files) {
        File latest = files[0];
        for (int i = 1; i < files.length; i++) {
            if (latest.getName().compareTo(files[i].getName()) < 0) {
                latest = files[i];
            }
        }
        return latest;
    }

    private PosBaseRateDto toDto(String[] columns) {
        PosBaseRateDto dto = new PosBaseRateDto();
        dto.setCurrencyPair(columns[0]);
        dto.setMdEntrySize(columns[1]);
        dto.setBidRate(columns[2]);
        dto.setAskRate(columns[3]);
        return dto;
    }
}
