package jp.co.daiwa.jbpos1100.source;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import jp.co.daiwa.common.constant.ExchangeKbnEnum.ExchangeKbn;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.jbpos1100.common.BatchConstants;

/**
 * 集計元データをスポット／スワップ対象へ振り分けるスプリッタ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setPosRealData} の抽出条件（Real 集計）を移植したもの。
 * 為替区分（スポット／スワップスタート・エンド／約定済CF）と、約定日時・AC・スタートポジション
 * （seqNo=0）の条件で対象を絞り込む。判定条件・符号は変更しない。</p>
 *
 * <p>プレ引値／引値／引値以降は抽出条件が一部異なるため、別メソッドとして追加する想定
 * （本クラスでは Real の {@link #splitForReal} を提供）。</p>
 */
public class SourcePositionSplitter {

    private static final String WINDOW_START_TIME = "000000";
    private static final String WINDOW_END_TIME = "210000";

    /**
     * Real 集計用にスポット／スワップを振り分ける。
     *
     * @param sourceList     集計元データ
     * @param targetDate     基準日
     * @param busiDaysBefore 前営業日
     * @return スポット／スワップ振り分け結果
     */
    public SourcePositionSplit splitForReal(List<TPosSumSourceDataBean> sourceList, Date targetDate,
            Date busiDaysBefore) {

        SimpleDateFormat fmt = new SimpleDateFormat(BatchConstants.DATE_PATTERN_YMD);
        String beforeBusiDays = fmt.format(busiDaysBefore);
        String targetDateYmd = fmt.format(targetDate);

        Predicate<TPosSumSourceDataBean> baseDate = d -> d.getProcessBaseDate().equals(targetDate);
        Predicate<TPosSumSourceDataBean> timing = d -> isWithinRealTiming(d, fmt, targetDate, targetDateYmd,
                beforeBusiDays, busiDaysBefore);

        List<TPosSumSourceDataBean> spotList = sourceList.stream()
                .filter(baseDate)
                .filter(timing)
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SPOT.getCode()))
                .collect(Collectors.toList());

        List<TPosSumSourceDataBean> swapList = sourceList.stream()
                .filter(baseDate)
                .filter(timing)
                .filter(this::isSwapOrTradedCf)
                .collect(Collectors.toList());

        return new SourcePositionSplit(spotList, swapList);
    }

    /**
     * プレ引値集計用にスポットを振り分ける（スワップは対象外＝空）。
     *
     * <p>旧 {@code setPosPreClosingData} 相当。約定日時が当日 00:00〜20:59 かつ AC=0、
     * もしくは休日作成約定／スタートポジション／前営業日以前のアフタークローズのスポット。</p>
     *
     * @param sourceList     集計元データ
     * @param targetDate     基準日
     * @param busiDaysBefore 前営業日
     * @return スポットのみ（スワップは空リスト）
     */
    public SourcePositionSplit splitForPreClosing(List<TPosSumSourceDataBean> sourceList, Date targetDate,
            Date busiDaysBefore) {
        SimpleDateFormat fmt = new SimpleDateFormat(BatchConstants.DATE_PATTERN_YMD);
        SimpleDateFormat formatter = new SimpleDateFormat(BatchConstants.DATE_PATTERN_YMD_HMS);

        List<TPosSumSourceDataBean> spotList = sourceList.stream()
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                .filter(d -> isWithinClosingWindow(d, fmt, formatter, targetDate, busiDaysBefore))
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SPOT.getCode()))
                .collect(Collectors.toList());
        return new SourcePositionSplit(spotList, java.util.Collections.<TPosSumSourceDataBean>emptyList());
    }

    /**
     * 引値集計用にスワップを振り分ける（スポットは DB の集計結果由来のため対象外＝空）。
     *
     * <p>旧 {@code setClosingValueData} のスワップ抽出条件相当。</p>
     *
     * @param sourceList     集計元データ
     * @param targetDate     基準日
     * @param busiDaysBefore 前営業日
     * @return スワップのみ（スポットは空リスト）
     */
    public SourcePositionSplit splitForClosingSwap(List<TPosSumSourceDataBean> sourceList, Date targetDate,
            Date busiDaysBefore) {
        SimpleDateFormat fmt = new SimpleDateFormat(BatchConstants.DATE_PATTERN_YMD);
        SimpleDateFormat formatter = new SimpleDateFormat(BatchConstants.DATE_PATTERN_YMD_HMS);

        List<TPosSumSourceDataBean> swapList = sourceList.stream()
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                .filter(d -> isWithinClosingWindow(d, fmt, formatter, targetDate, busiDaysBefore))
                .filter(this::isSwapOrTradedCf)
                .collect(Collectors.toList());
        return new SourcePositionSplit(java.util.Collections.<TPosSumSourceDataBean>emptyList(), swapList);
    }

    /**
     * 引値以降集計用に「当日 AC=1」のスポット／スワップ（AC 分）を振り分ける。
     *
     * <p>旧 {@code setClosingAfterValueData} の AC 対象抽出（6.1/6.2）相当。</p>
     *
     * @param sourceList 集計元データ
     * @param targetDate 基準日
     * @return AC 分のスポット／スワップ
     */
    public SourcePositionSplit splitForAfterAc(List<TPosSumSourceDataBean> sourceList, Date targetDate) {
        SimpleDateFormat fmt = new SimpleDateFormat(BatchConstants.DATE_PATTERN_YMD);
        String targetDateYmd = fmt.format(targetDate);

        Predicate<TPosSumSourceDataBean> todayAc = d -> fmt.format(d.getTradeDatetime()).equals(targetDateYmd)
                && BatchConstants.AC_FLAG_AFTER_CLOSE.equals(d.getAc().trim());

        List<TPosSumSourceDataBean> spotAc = sourceList.stream()
                .filter(todayAc)
                .filter(d -> d.getExchangeDivision().trim().equals(ExchangeKbn.SPOT.getCode()))
                .collect(Collectors.toList());
        List<TPosSumSourceDataBean> swapAc = sourceList.stream()
                .filter(todayAc)
                .filter(this::isSwapOrTradedCf)
                .collect(Collectors.toList());
        return new SourcePositionSplit(spotAc, swapAc);
    }

    /**
     * Real 集計の約定日時条件（当日約定／休日作成約定／前営業日以前のアフタークローズ／スタートポジション）。
     */
    private boolean isWithinRealTiming(TPosSumSourceDataBean d, SimpleDateFormat fmt, Date targetDate,
            String targetDateYmd, String beforeBusiDays, Date busiDaysBefore) {
        String tradeYmd = fmt.format(d.getTradeDatetime());
        boolean today = tradeYmd.equals(fmt.format(targetDate));
        boolean createdOnHoliday = tradeYmd.compareTo(beforeBusiDays) > 0 && tradeYmd.compareTo(targetDateYmd) < 0;
        boolean afterCloseInTime = tradeYmd.compareTo(fmt.format(busiDaysBefore)) <= 0
                && BatchConstants.AC_FLAG_AFTER_CLOSE.equals(d.getAc().trim());
        boolean startPosition = d.getSeqNo().equals(BigDecimal.ZERO);
        return today || createdOnHoliday || afterCloseInTime || startPosition;
    }

    /**
     * 引値ウィンドウ判定（当日 00:00〜20:59 かつ AC=0／休日作成約定／スタートポジション／
     * 前営業日以前のアフタークローズ）。Pre/Closing で共通。
     */
    private boolean isWithinClosingWindow(TPosSumSourceDataBean d, SimpleDateFormat fmt, SimpleDateFormat formatter,
            Date targetDate, Date busiDaysBefore) {
        String targetDateYmd = fmt.format(targetDate);
        String beforeBusiDays = fmt.format(busiDaysBefore);
        String tradeYmdHms = formatter.format(d.getTradeDatetime());
        String tradeYmd = fmt.format(d.getTradeDatetime());

        boolean intradayInTime = tradeYmdHms.compareTo(targetDateYmd.concat(WINDOW_START_TIME)) >= 0
                && tradeYmdHms.compareTo(targetDateYmd.concat(WINDOW_END_TIME)) < 0
                && BatchConstants.AC_FLAG_IN_TIME.equals(d.getAc().trim());
        boolean createdOnHoliday = tradeYmd.compareTo(beforeBusiDays) > 0 && tradeYmd.compareTo(targetDateYmd) < 0;
        boolean startPosition = d.getSeqNo().compareTo(BigDecimal.ZERO) == 0;
        boolean afterCloseInTime = tradeYmd.compareTo(beforeBusiDays) <= 0
                && BatchConstants.AC_FLAG_AFTER_CLOSE.equals(d.getAc().trim());
        return intradayInTime || createdOnHoliday || startPosition || afterCloseInTime;
    }

    /** 為替区分がスワップスタート／エンド／約定済CFか。 */
    private boolean isSwapOrTradedCf(TPosSumSourceDataBean d) {
        String division = d.getExchangeDivision().trim();
        return division.equals(ExchangeKbn.SWAP_START.getCode())
                || division.equals(ExchangeKbn.SWAP_END.getCode())
                || ExchangeKbn.TRADEDCF.getCode().equals(division);
    }
}
