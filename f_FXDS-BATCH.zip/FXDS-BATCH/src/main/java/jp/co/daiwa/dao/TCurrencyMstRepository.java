package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TCurrencyMstBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TCurrencyMstRepository}（通貨マスタ）。
 * 旧 {@code Jbpos1000PosSumTasklet#init} が {@code getTCurrencyMstAll()} を呼ぶため定義。
 */
public interface TCurrencyMstRepository {

    List<TCurrencyMstBean> getTCurrencyMstAll();
}
