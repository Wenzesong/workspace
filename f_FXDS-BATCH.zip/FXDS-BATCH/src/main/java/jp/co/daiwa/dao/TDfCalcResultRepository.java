package jp.co.daiwa.dao;

import java.util.Date;
import java.util.List;

import jp.co.daiwa.dao.bean.TDfCalcResultBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TDfCalcResultRepository}（DF 算出結果）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TDfCalcResultRepository {

    List<TDfCalcResultBean> getTDfCalcResultBeanAll(Date previousBusinessDate, Date targetDate);
}
