package jp.co.daiwa.common.constant;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code jp.co.daiwa.common.constant.FxdConstants}。
 *
 * <p>jbpos1100 から参照される定数のみ定義。値は推定の既定値であり、実プロジェクトの
 * 正規の値で上書きされる前提（特に {@link #DB_IO_EXCEPTION} は DB 切断判定に影響する）。</p>
 */
public final class FxdConstants {

    private FxdConstants() {
    }

    /** DB 切断（I/O 例外）判定用のメッセージ断片。実プロジェクトの正規値に置換すること。 */
    public static final String DB_IO_EXCEPTION = "I/O error";

    /** ジョブ実行ステータスを格納する ExecutionContext キー。 */
    public static final String CONTEXT_K_JOB_STATUS = "jobStatus";

    /** ジョブ実行ステータス値（警告）。 */
    public static final String CONTEXT_V_JOB_STATUS_WARN = "WARN";

    /** TSV 区切り文字（タブ）。 */
    public static final String KEY_TAB = "\t";

    /** カンマ。 */
    public static final String COMMA = ",";
}
