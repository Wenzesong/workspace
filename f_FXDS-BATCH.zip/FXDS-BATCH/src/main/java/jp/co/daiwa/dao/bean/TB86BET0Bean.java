package jp.co.daiwa.dao.bean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TB86BET0Bean}（営業日マスタ）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TB86BET0Bean {

    private String rekiymd;

    public String getRekiymd() {
        return rekiymd;
    }

    public void setRekiymd(String rekiymd) {
        this.rekiymd = rekiymd;
    }
}
