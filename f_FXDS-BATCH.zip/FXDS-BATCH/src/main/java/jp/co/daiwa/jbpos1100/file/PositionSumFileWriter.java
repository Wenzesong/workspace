package jp.co.daiwa.jbpos1100.file;

import java.util.List;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;

/**
 * ポジション集計結果ファイル出力の抽象境界。
 *
 * <p>旧コードは出力ユーティリティ {@code Jbpos1000PositionSumDateFileUtil} の static メソッドを
 * 直接呼び出していた。要件（static 多用を避け JUnit でモック可能なインスタンスメソッドを優先）に従い、
 * 集計サービスはこのインタフェースに依存し、テスト時はモックへ差し替える。</p>
 *
 * <p>実ファイル書き込みロジックは jbpos1100 側へ移植済みで、既定実装
 * {@link DefaultPositionSumFileWriter} が担う（jbpos1000 への依存は持たない）。</p>
 */
public interface PositionSumFileWriter {

    /**
     * スポット集計結果ファイルを出力する。
     *
     * @param contribution      ステップ実行コンテキスト
     * @param outputFilePath    出力先パス
     * @param evaluationRateKbn 評価レート区分コード
     * @param spotSumList       スポット集計結果
     */
    void writeSpotSumFile(StepContribution contribution, String outputFilePath, String evaluationRateKbn,
            List<TPositionSpotSumDataBean> spotSumList);

    /**
     * スワップ集計結果ファイルを出力する。
     *
     * @param contribution      ステップ実行コンテキスト
     * @param outputFilePath    出力先パス
     * @param evaluationRateKbn 評価レート区分コード
     * @param plSumList         スワップ PL 合計
     * @param deltaCashList     通貨別デルタ・キャッシュ残
     * @param currencySumList   通貨単位纏めスワップ集計
     */
    void writeSwapSumFile(StepContribution contribution, String outputFilePath, String evaluationRateKbn,
            List<TSwapPlSumDateBean> plSumList, List<TByCcyDeltaCashBalanceBean> deltaCashList,
            List<TPositionSwapSumDataBean> currencySumList);
}
