package jp.co.daiwa.jbpos1000;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;

@Component
public class Jbpos1000JobListener implements JobExecutionListener {
    /** Logger */
    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(Jbpos1000JobListener.class);

    @Override
    public void beforeJob(JobExecution jobExecution) {
        logger.info(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_I030");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        // 警告終了確認
        if (jobExecution.getExecutionContext().containsKey(FxdConstants.CONTEXT_K_JOB_STATUS)) {
            String execStatus = jobExecution.getExecutionContext().getString(FxdConstants.CONTEXT_K_JOB_STATUS);
            if (FxdConstants.CONTEXT_V_JOB_STATUS_WARN.equals(execStatus)) {
                jobExecution.setExitStatus(new ExitStatus("WARN"));
            }
        }
        // 異常終了確認
        jobExecution.getStepExecutions().forEach(stepExecution -> {
            if (ExitStatus.FAILED.getExitCode().equals(stepExecution.getExitStatus().getExitCode())) {
                logger.error(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_E001",
                        JobConstants.Jbpos1000_Name, stepExecution);
                jobExecution.setExitStatus(ExitStatus.FAILED);
            }
        });
        // ジョブ終了ステータスと詳細を出力する
        logger.info(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_I002",
                jobExecution.getExitStatus().getExitCode(), jobExecution);
    }
}