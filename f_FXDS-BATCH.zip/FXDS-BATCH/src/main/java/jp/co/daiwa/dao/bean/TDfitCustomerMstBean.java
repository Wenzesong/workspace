package jp.co.daiwa.dao.bean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TDfitCustomerMstBean}（DFIT 部課別顧客マスタ）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TDfitCustomerMstBean {

    private String departmentCode;
    private String customerCode;
    private String customerName;
    private String remarks;
    private String referAuthSection;

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getReferAuthSection() {
        return referAuthSection;
    }

    public void setReferAuthSection(String referAuthSection) {
        this.referAuthSection = referAuthSection;
    }
}
