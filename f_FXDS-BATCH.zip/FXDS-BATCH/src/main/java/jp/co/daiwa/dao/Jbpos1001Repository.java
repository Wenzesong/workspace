package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TB86BYG0Bean;
import jp.co.daiwa.dao.bean.TB86BYS0Bean;
import jp.co.daiwa.dao.bean.TTradeMngBean;
import jp.co.daiwa.dto.PosSumSourceDto;

/**
 * コンパイル補足用スタブ（MyBatis マッパー想定）。実体は FXDS の {@code Jbpos1001Repository}。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface Jbpos1001Repository {

    List<PosSumSourceDto> getTradeMngFxAll(TTradeMngBean condition);

    List<PosSumSourceDto> getBidTrade(TB86BYG0Bean condition);

    List<PosSumSourceDto> getBidOutsideM(TB86BYS0Bean condition);
}
