package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TPositionPlDeltaDataBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPositionPlDeltaDataRepository}（PL デルタ生成情報）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TPositionPlDeltaDataRepository {

    void delete(TPositionPlDeltaDataBean condition);

    void insert(List<TPositionPlDeltaDataBean> items);

    List<TPositionPlDeltaDataBean> getTPositionPlDeltaDataBeanAll(TPositionPlDeltaDataBean condition);
}
