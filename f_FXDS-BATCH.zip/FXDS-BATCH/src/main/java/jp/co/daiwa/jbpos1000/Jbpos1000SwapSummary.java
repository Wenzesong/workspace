package jp.co.daiwa.jbpos1000;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.batch.core.StepContribution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.dto.TPositionSwapSumDataDto;

/**
 * @author CHEN
 *
 */
@Transactional(transactionManager = "jobTransactionManager")
public class Jbpos1000SwapSummary extends Jbpos1000PosSumTasklet {

    // レート取得先(スマトレ)
    private static final String RATESOURCESMART = "1";
    // レート取得先(BBG)
    private static final String RATESOURCEBBG = "0";
    // 対円通貨
    private static final String JPY = "JPY";
    // 為替区分(約定済CF)
    private static final String TRADEDCF = "4";
    // 売買区分(買)
    private static final String BUY = "1";
    // 売買区分(売)
    private static final String SELL = "2";

    /**
     * コンストラクター
     *
     */
    public Jbpos1000SwapSummary() {
        // 自動生成されたコンストラクター・スタブ
    }

    /** 出力ファイル格納場所 */
    @Value("${job.jbpos1000.path}")
    private String outputFilePath;
    public static final SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(Jbpos1000SwapSummary.class);

    /**
     * ①ポジションスワップ集計結果集計用
     *
     * @param tPosSumSourceList
     * @param tPosSumSourceDataSwapList
     * @param dfCalcResult
     * @param dfHistory
     * @param tCuyMstList
     * @param targetDate
     * @param evaluationRateKbn
     * @return positionSwapSumDataList
     * @throws Exception
     */

    static List<TPositionSwapSumDataDto> getTPosCashSumData(StepContribution contribution,
            List<TPosSumSourceDataBean> tPosSumSourceList, List<TDfCalcResultBean> dfCalcResult,
            List<TDfHistoryDateBean> dfHistory, List<TCurrencyMstBean> tCurrencyMst, Date targetDate,
            String evaluationRateKbn, String evaluationRateName) throws Exception {

        List<TPositionSwapSumDataDto> posSwapSumDataList = new ArrayList<>();

        // ディーラブック、通貨ペア順にソート
        List<TPosSumSourceDataBean> sortedList = tPosSumSourceList.stream().sorted(Comparator
                .comparing(TPosSumSourceDataBean::getDealerBook).thenComparing(TPosSumSourceDataBean::getCurrencyPair))
                .collect(Collectors.toList());

        for (TPosSumSourceDataBean item : sortedList) {
            TPositionSwapSumDataDto posSwapSumDataDto = new TPositionSwapSumDataDto();
            String deliveryDateymd = new SimpleDateFormat("yyyy/MM/dd").format(item.getDeliveryDate());
            try {
                // 売買金額
                if (BUY.equals(item.getDealDivision())) {
                    posSwapSumDataDto.setDealAmount(item.getDealAmount());
                } else {
                    // 符号反転
                    posSwapSumDataDto.setDealAmount(item.getDealAmount().negate());
                }
                // 決済金額
                if (BUY.equals(item.getDealDivision())) {
                    posSwapSumDataDto.setSettleAmount(item.getSettleAmount());
                    // 符号反転
                } else {
                    posSwapSumDataDto.setSettleAmount(item.getSettleAmount().negate());
                }

                // ディスカウントファクター取得(DF算出結果)(売買通貨側)
                TDfCalcResultBean dDfCalc = dfCalcResult.stream()
                        // DF算出結果の通貨 = 取得売買通貨
                        .filter(b -> b.getCurrency().equals(item.getDealCurrency().trim()))
                        // DF算出結果のグリッド日 = 取得受渡日
                        .filter(b -> b.getGridDate().equals(item.getDeliveryDate())).findFirst().orElse(null);

                // ディスカウントファクター取得(DF算出結果)(決済通貨側)
                TDfCalcResultBean sDfCalc = dfCalcResult.stream()
                        // DF算出結果の通貨 = 取得決済通貨
                        .filter(b -> b.getCurrency().equals(item.getSettleCurrency().trim()))
                        // DF算出結果のグリッド日 = 取得受渡日
                        .filter(b -> b.getGridDate().equals(item.getDeliveryDate())).findFirst().orElse(null);

                // ディスカウントファクター取得(DF履歴情報)(売買通貨側)
                TDfHistoryDateBean dDfHis = dfHistory.stream()
                        // DF履歴情報の基準日 = バッチ実行日
                        .filter(b -> targetDate.equals(b.getBaseDate()))
                        // DF履歴情報の通貨 = 取得売買通貨
                        .filter(b -> b.getCurrency().equals(item.getDealCurrency().trim()))
                        // DF履歴情報のグリッド日 = 取得受渡日
                        .filter(b -> b.getGridDate().equals(item.getDeliveryDate())).findFirst().orElse(null);

                // ディスカウントファクター取得(DF履歴情報)(決済通貨側)
                TDfHistoryDateBean sDfHis = dfHistory.stream()
                        // DF履歴情報の基準日 = バッチ実行日
                        .filter(b -> targetDate.equals(b.getBaseDate()))
                        // DF履歴情報の通貨 = 取得決済通貨
                        .filter(b -> b.getCurrency().equals(item.getSettleCurrency().trim()))
                        // DF履歴情報のグリッド日 = 取得受渡日
                        .filter(b -> b.getGridDate().equals(item.getDeliveryDate())).findFirst().orElse(null);

                // 取引金PV円転
                BigDecimal tradeAmountPvYen = BigDecimal.ZERO;
                // 取引金PV(引値)
                BigDecimal tradeAmountPvCls = BigDecimal.ZERO;
                // 取引金PV(引値)円転
                BigDecimal tradeAmountPvClsYen = BigDecimal.ZERO;

                // 基準日
                posSwapSumDataDto.setProcessBaseDate(targetDate);
                // ディーラブック
                posSwapSumDataDto.setDealerBook(item.getDealerBook());
                // 評価レート区分
                posSwapSumDataDto.setEvaluationRateDivision(evaluationRateKbn);
                // 通貨ペア
                posSwapSumDataDto.setCurrencyPair(item.getCurrencyPair());
                // 為替区分
                posSwapSumDataDto.setExchangeDivision(item.getExchangeDivision().substring(0, 1));
                // 受渡日
                posSwapSumDataDto.setDeliveryDate(item.getDeliveryDate());
                // 決済円転レート
                posSwapSumDataDto.setSettleYenRate(item.getRealYenRate());

                // 取引金PV(引値)
                // 為替区分が約定済み(スタートポジション)の場合
                if (TRADEDCF.equals(item.getExchangeDivision()) && item.getSeqNo().compareTo(BigDecimal.ZERO) == 0) {
                    // 前日取引金PV(引値)
                    posSwapSumDataDto.setTradeAmountPvCls(item.getBeforeTradeAmountPvCls());
                    // 前日取引金PV(引値)円転
                    posSwapSumDataDto.setTradeAmountPvClsYen(item.getBeforeTradeAmountPvClsYen());
                    // 当日の為替区分が約定済みかつシーケンスNOが0でない場合
                } else if (TRADEDCF.equals(item.getExchangeDivision())
                        && item.getSeqNo().compareTo(BigDecimal.ZERO) != 0) {
                    // ディスカウントファクターがNULLの場合
                    if (dDfHis != null && dDfHis.getDiscountFactor() != null) {
                        // 売買金額*DF履歴情報のDF
                        tradeAmountPvCls = posSwapSumDataDto.getDealAmount().multiply(dDfHis.getDiscountFactor())
                                .setScale(2, RoundingMode.HALF_UP);
                    } else {
                        tradeAmountPvCls = null;
                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスワップ集計",
                                "評価レート区分:" + evaluationRateName.concat(",通貨:" + item.getDealCurrency()).concat(",")
                                        .concat("受渡日:" + deliveryDateymd)
                                        .concat(",DF履歴情報のディスカウントファクターが取得できなかったため、取引金PV(引値)の計算エラー"));
                    }
                    // 取引金PV(引値)
                    posSwapSumDataDto.setTradeAmountPvCls(tradeAmountPvCls);
                    // 取引金PV(引値)円転
                    if (posSwapSumDataDto.getTradeAmountPvCls() == null) {
                        tradeAmountPvClsYen = null;
                    } else if (JPY.equals(item.getSettleCurrency())) {
                        if (item.getClosingYenRate() != null) {
                            // 取引金PV(引値)*引値円転レート
                            tradeAmountPvClsYen = posSwapSumDataDto.getTradeAmountPvCls()
                                    .multiply(item.getClosingYenRate()).setScale(2, RoundingMode.HALF_UP);
                        } else {
                            tradeAmountPvClsYen = null;
                            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                    "ポジションスワップ集計", "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                        + ":引値円転レートが取得できなかったため、取引金PV(引値)円転の計算エラー");
                    }
                } else {
                    tradeAmountPvClsYen = posSwapSumDataDto.getTradeAmountPvCls();
                }
                    // 取引金PV(引値)円転
                    posSwapSumDataDto.setTradeAmountPvClsYen(tradeAmountPvClsYen);
                    // 為替区分が約定済み以外の場合
                } else {
                    // 取引金PV(引値)
                    posSwapSumDataDto.setTradeAmountPvCls(BigDecimal.ZERO);
                    // 取引金PV(引値)円転
                    posSwapSumDataDto.setTradeAmountPvClsYen(BigDecimal.ZERO);
                }
                // 取引金PV
                BigDecimal tradeAmountPv = BigDecimal.ZERO;
                // 取引金PV
                if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                        || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                    if (dDfCalc != null && dDfCalc.getDiscountFactor() != null) {
                        // 売買金額*DF算出結果のDF
                        tradeAmountPv = posSwapSumDataDto.getDealAmount()
                                .multiply(((TDfCalcResultBean) dDfCalc).getDiscountFactor())
                                .setScale(2, RoundingMode.HALF_UP);
                    } else {
                        tradeAmountPv = null;
                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスワップ集計",
                                "評価レート区分:" + evaluationRateName.concat(",通貨:" + item.getDealCurrency()).concat(",")
                                        .concat("受渡日:" + deliveryDateymd)
                                        .concat(",DF算出結果のディスカウントファクターが取得できなかったため、取引金PVの計算エラー"));
                    }
                } else {
                    if (dDfHis != null && dDfHis.getDiscountFactor() != null) {
                        // 売買金額*DF履歴情報のDF
                        tradeAmountPv = posSwapSumDataDto.getDealAmount().multiply(dDfHis.getDiscountFactor())
                                .setScale(2, RoundingMode.HALF_UP);
                    } else {
                        // 取引金PV
                        tradeAmountPv = null;
                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスワップ集計",
                                "評価レート区分:" + evaluationRateName.concat(",通貨:" + item.getDealCurrency()).concat(",")
                                        .concat("受渡日:" + deliveryDateymd)
                                        .concat(",DF履歴情報のディスカウントファクターが取得できなかったため、取引金PVの計算エラー"));
                    }
                }
                posSwapSumDataDto.setTradeAmountPv(tradeAmountPv);
                // 取引金PV円転(為替区分が約定済CFのみ)
                if (TRADEDCF.equals(item.getExchangeDivision())) {
                    if (JPY.equals(item.getSettleCurrency()) && posSwapSumDataDto.getTradeAmountPv() != null) {
                        // 評価レート区分が引値の場合
                        if (evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
                            if (item.getClosingYenRate() != null) {
                                // 取引金PV円転(取引金PV*売買円転レート(引値円転レート))
                                tradeAmountPvYen = posSwapSumDataDto.getTradeAmountPv()
                                        .multiply(item.getClosingYenRate()).setScale(2, RoundingMode.HALF_UP);
                            } else {
                                tradeAmountPvYen = null;
                                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                        "ポジションスワップ集計", "評価レート区分:" + "," + evaluationRateName + item.getCurrencyPair()
                                                + ":引値円転レートが取得できなかったため、取引金PV円転の計算エラー");

                            }
                            // 評価レート区分が引値以外の場合
                        } else if (item.getManualDailyRate() != null ||
                                item.getRateSource() == null ||
                                (RATESOURCESMART.equals(item.getRateSource()) && item.getRealYenRate() != null) ||
                                (RATESOURCEBBG.equals(item.getRateSource()) && item.getBbgRate() != null)) {
                            // マニュアルレートが存在する場合、取引金PV円転 = 取引金PV*売買円転レート(マニュアル(日中時価評価レート))
                            if (item.getManualDailyRate() != null) {
                                tradeAmountPvYen = posSwapSumDataDto.getTradeAmountPv().multiply(item.getManualDailyRate())
                                        .setScale(2, RoundingMode.HALF_UP);
                            }
                            // レート取得先がnull(JPY/JPY)の場合、取引金PV円転 = 取引金PV*売買円転レート(1固定)
                            else if (item.getRateSource() == null) {
                                tradeAmountPvYen = posSwapSumDataDto.getTradeAmountPv()
                                        .multiply(BigDecimal.ONE)
                                        .setScale(2, RoundingMode.HALF_UP);
                            }
                            // レート取得先がスマトレの場合、取引金PV円転 = 取引金PV*売買円転レート(Real円転レート)
                            else if (RATESOURCESMART.equals(item.getRateSource())) {
                                tradeAmountPvYen = posSwapSumDataDto.getTradeAmountPv()
                                        .multiply(item.getRealYenRate())
                                        .setScale(2, RoundingMode.HALF_UP);
                            }
                            // レート取得先がBBGの場合、取引金PV円転 = 取引金PV*売買円転レート(BBGレート)
                            else if (RATESOURCEBBG.equals(item.getRateSource())) {
                                tradeAmountPvYen = posSwapSumDataDto.getTradeAmountPv()
                                        .multiply(item.getBbgRate())
                                        .setScale(2, RoundingMode.HALF_UP);
                            }
                        } else {
                                tradeAmountPvYen = null;
                                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                        "ポジションスワップ集計", "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                                + ":売買円転レートが取得できなかったため、取引金PV円転の計算エラー");
                            }
                        } else {
                            tradeAmountPvYen = posSwapSumDataDto.getTradeAmountPv();
                        }
                    } else {
                        tradeAmountPvYen = BigDecimal.ZERO;
                    }
                    posSwapSumDataDto.setTradeAmountPvYen(tradeAmountPvYen);
                    // 評価レート区分が引値の場合
                    if (evaluationRateKbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode())) {
                        // 取引金PV=取引金PV(引値)
                        posSwapSumDataDto.setTradeAmountPvCls(posSwapSumDataDto.getTradeAmountPv());
                        if (posSwapSumDataDto.getTradeAmountPvCls() != null) {
                            if (item.getClosingYenRate() != null) {
                                // 取引金PV(引値)*引値円転レート
                                tradeAmountPvClsYen = posSwapSumDataDto.getTradeAmountPvCls()
                                        .multiply(item.getClosingYenRate()).setScale(2, RoundingMode.HALF_UP);
                            } else {
                                tradeAmountPvClsYen = null;
                                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                        "ポジションスワップ集計", "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                                + ":引値円転レートが取得できなかったため、取引金PV(引値)円転の計算エラー");
                            }
                            // 取引金PV(引値)円転
                            posSwapSumDataDto.setTradeAmountPvClsYen(tradeAmountPvClsYen);
                        } else {
                            posSwapSumDataDto.setTradeAmountPvClsYen(null);
                        }
                    }

                    // 取引金PV評価換算
                    BigDecimal tradeAmountPvEva = BigDecimal.ZERO;
                    // 取引金PV評価換算円転
                    BigDecimal tradeAmountPvEvaYen = BigDecimal.ZERO;
                    // 取引金PV評価換算
                    // 為替区分が約定済CFの場合
                    if (TRADEDCF.equals(item.getExchangeDivision())) {
                        // 為替区分が約定済CFの場合は計算不要
                        tradeAmountPvEva = BigDecimal.ZERO;
                    } else {
                        if (posSwapSumDataDto.getTradeAmountPv() == null) {
                            tradeAmountPvEva = null;
                        } else if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                                || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                            // マニュアル(日中時価評価レート)が存在した場合
                            if (item.getManualDailyRate() != null) {
                                // 取引金PV*マニュアル(日中時価評価レート)
                                tradeAmountPvEva = posSwapSumDataDto.getTradeAmountPv().multiply(item.getManualDailyRate())
                                        .setScale(2, RoundingMode.HALF_UP);
                                // マニュアル(日中時価評価レート)が存在しない場合
                            } else {
                                // レート取得先がスマトレの場合
                                if (RATESOURCESMART.equals(item.getRateSource())) {
                                    if (item.getRealRate() != null) {
                                        // 取引金PV*Real評価レート
                                        tradeAmountPvEva = posSwapSumDataDto.getTradeAmountPv().multiply(item.getRealRate())
                                                .setScale(2, RoundingMode.HALF_UP);
                                    } else {
                                        tradeAmountPvEva = null;
                                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                                "ポジションスワップ集計", "評価レート区分:" + evaluationRateName + ","
                                                        + item.getCurrencyPair() + ":Real評価レートが取得できなかったため、取引金PV評価換算の計算エラー");
                                    }
                                    // レート取得先がBBGの場合
                                } else if (RATESOURCEBBG.equals(item.getRateSource())) {
                                    if (item.getBbgRate() != null) {
                                        // 取引金PV*BBGレート
                                        tradeAmountPvEva = posSwapSumDataDto.getTradeAmountPv().multiply(item.getBbgRate())
                                                .setScale(2, RoundingMode.HALF_UP);
                                    } else {
                                        tradeAmountPvEva = null;
                                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                                "ポジションスワップ集計", "評価レート区分:" + evaluationRateName + ","
                                                        + item.getCurrencyPair() + ":BBGレートが取得できなかったため、取引金PV評価換算の計算エラー");
                                    }
                                }
                            }
                            // 評価レート区分が引値の場合
                        } else {
                            // マニュアル(引けレート、TTM)が存在した場合
                            if (item.getManualClosingTtmRate() != null) {
                                // 取引金PV*マニュアル(引けレート、TTM)
                                tradeAmountPvEva = posSwapSumDataDto.getTradeAmountPv()
                                        .multiply(item.getManualClosingTtmRate()).setScale(2, RoundingMode.HALF_UP);
                                // マニュアル(引けレート、TTM)が存在しない場合
                            } else {
                                if (item.getClosingRate() != null) {
                                    // 取引金PV*評価レート(引値レート)
                                    tradeAmountPvEva = posSwapSumDataDto.getTradeAmountPv().multiply(item.getClosingRate())
                                            .setScale(2, RoundingMode.HALF_UP);
                                } else {
                                    tradeAmountPvEva = null;
                                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                            "ポジションスワップ集計", "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                                    + ":引値評価レートが取得できなかったため、取引金PV評価換算の計算エラー");
                                }
                            }
                        }
                    }

                    posSwapSumDataDto.setTradeAmountPvEva(tradeAmountPvEva);
                    // 取引金PV評価換算円転
                    // 為替区分が約定済CFの場合
                    if (posSwapSumDataDto.getTradeAmountPvEva() == null) {
                        tradeAmountPvEvaYen = null;
                    } else if (posSwapSumDataDto.getTradeAmountPvEva().compareTo(BigDecimal.ZERO) == 0) {
                        tradeAmountPvEvaYen = BigDecimal.ZERO;

                    } else if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                            || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                        if (item.getRealYenRate() != null) {
                            // 取引金PV評価換算*Real円転レート
                            tradeAmountPvEvaYen = posSwapSumDataDto.getTradeAmountPvEva().multiply(item.getRealYenRate())
                                    .setScale(2, RoundingMode.HALF_UP);
                        } else {
                            tradeAmountPvEvaYen = null;
                            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスワップ集計",
                                    "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                            + ":Real円転レートが取得できなかったため、取引金PV評価換算円転の計算エラー");
                        }
                    } else {
                        if (item.getClosingYenRate() != null) {
                            // 取引金PV評価換算*引値円転レート
                            tradeAmountPvEvaYen = posSwapSumDataDto.getTradeAmountPvEva().multiply(item.getClosingYenRate())
                                    .setScale(2, RoundingMode.HALF_UP);
                        } else {
                            tradeAmountPvEvaYen = null;
                            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "ポジションスワップ集計",
                                    "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                            + ":引値評価レートが取得できなかったため、取引金PV評価換算円転の計算エラー");
                        }
                    }
                posSwapSumDataDto.setTradeAmountPvEvaYen(tradeAmountPvEvaYen);
                // 決済金PV
                BigDecimal settleAmountPv = BigDecimal.ZERO;
                // 決済金PV円転
                BigDecimal settleAmountPvYen = BigDecimal.ZERO;
                // 決済金PV(為替区分が約定済みの場合)
                if (TRADEDCF.equals(item.getExchangeDivision())) {
                    // 決済金PV
                    settleAmountPv = BigDecimal.ZERO;
                    // 決済金PV(為替区分が約定済み以外)
                } else {
                    if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                            || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                        if (sDfCalc != null && sDfCalc.getDiscountFactor() != null) {
                            // 決済金額*DF算出結果のDF
                            settleAmountPv = posSwapSumDataDto.getSettleAmount().multiply(sDfCalc.getDiscountFactor())
                                    .setScale(2, RoundingMode.HALF_UP);
                        } else {
                            // 決済金PV
                            settleAmountPv = null;
                            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                    "ポジションスワップ集計",
                                    "評価レート区分:" + evaluationRateName.concat(",通貨:" + item.getSettleCurrency())
                                            .concat(",").concat("受渡日:" + deliveryDateymd)
                                            .concat(",DF算出結果のディスカウントファクターが取得できなかったため、決済金PVの計算エラー"));
                        }
                    } else {
                        if (sDfHis != null && sDfHis.getDiscountFactor() != null) {
                            // 決済金額*DF履歴情報のDF
                            settleAmountPv = posSwapSumDataDto.getSettleAmount().multiply(sDfHis.getDiscountFactor())
                                    .setScale(2, RoundingMode.HALF_UP);
                        } else {
                            // 決済金PV
                            settleAmountPv = null;
                            logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                    "ポジションスワップ集計",
                                    "評価レート区分:" + evaluationRateName.concat(",通貨:" + item.getSettleCurrency())
                                            .concat(",").concat("受渡日:" + deliveryDateymd)
                                            .concat(",DF履歴情報のディスカウントファクターが取得できなかったため、決済金PVの計算エラー"));
                        }
                    }
                }
                // 決済金PV設定
                posSwapSumDataDto.setSettleAmountPv(settleAmountPv);
                // 決済金PV円転
                // 為替区分が約定済みの場合
                if (TRADEDCF.equals(item.getExchangeDivision())) {
                    settleAmountPvYen = BigDecimal.ZERO;
                    // 為替区分が約定済み以外の場合
                } else {
                    // 決済金PVがNULL
                    if (posSwapSumDataDto.getSettleAmountPv() == null) {
                        // 決済金PV円転をNULLに設定
                        settleAmountPvYen = null;
                        // 決済通貨がJPYの場合
                    } else if (JPY.equals(item.getSettleCurrency().trim())) {
                        // 決済金PV円転を決済金PVに設定
                        settleAmountPvYen = posSwapSumDataDto.getSettleAmountPv();
                    } else {
                        if (evaluationRateKbn.equals(EvaluationRateKbn.REAL.getCode())
                                || evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                            if (item.getRealYenRate() != null) {
                                // 決済金PV*Real円転レート
                                settleAmountPvYen = posSwapSumDataDto.getSettleAmountPv()
                                        .multiply(item.getRealYenRate()).setScale(2, RoundingMode.HALF_UP);

                            } else {
                                settleAmountPvYen = null;
                                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                        "ポジションスワップ集計", "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                                + "のReal円転レートが取得できなかったため、決済金PV円転の計算エラー");
                            }
                        } else {
                            if (item.getClosingYenRate() != null) {
                                // 決済金PV*引値円転レート
                                settleAmountPvYen = posSwapSumDataDto.getSettleAmountPv()
                                        .multiply(item.getClosingYenRate()).setScale(2, RoundingMode.HALF_UP);
                            } else {
                                settleAmountPvYen = null;
                                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                                        "ポジションスワップ集計", "評価レート区分:" + evaluationRateName + "," + item.getCurrencyPair()
                                                + "の引値円転レートが取得できなかったため、決済金PV円転の計算エラー");
                            }
                        }
                    }
                }
                // 決済金PV円転
                posSwapSumDataDto.setSettleAmountPvYen(settleAmountPvYen);
                // PL(円)
                BigDecimal plYen = BigDecimal.ZERO;
                // 為替区分が約定済みの場合
                // 評価レート区分が引値以降でない、かつシーケンスNOが0の場合(スタートポジション)
                if (!evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())
                        && item.getSeqNo().compareTo(BigDecimal.ZERO) == 0) {
                    if (posSwapSumDataDto.getTradeAmountPvYen() == null
                            || item.getBeforeTradeAmountPvClsYen() == null) {
                        plYen = null;
                    } else {
                        // PL(円)=取引金PV円転-前日取引金PV(引値)円転
                        plYen = posSwapSumDataDto.getTradeAmountPvYen().subtract(item.getBeforeTradeAmountPvClsYen())
                                .setScale(2, RoundingMode.HALF_UP);
                    }
                    // 評価レート区分が引値以降の場合
                } else 
                    // 為替区分が約定済みの場合
                    if (TRADEDCF.equals(item.getExchangeDivision())) {
                        // 取引金PV円転がNULLの場合、もしくは取引金PV(引値)(円転)がNULLの場合
                        if (posSwapSumDataDto.getTradeAmountPvYen() == null
                                || posSwapSumDataDto.getTradeAmountPvClsYen() == null) {
                            plYen = null;
                        } else {
                            // 取引金PV円転-取引金PV(引値)(円転)
                            plYen = posSwapSumDataDto.getTradeAmountPvYen()
                                    .subtract(posSwapSumDataDto.getTradeAmountPvClsYen()).setScale(2, RoundingMode.HALF_UP);
                        }
                        // 為替区分が約定済み以外の場合
                        // 決済金PV円転がNULLの場合、もしくは取引金PV評価換算円転がNULLの場合
                    } else if (posSwapSumDataDto.getSettleAmountPvYen() == null
                            || posSwapSumDataDto.getTradeAmountPvEvaYen() == null) {
                        plYen = null;
                    } else {
                        // 決済金PV円転 - 取引金PV評価換算円転
                        plYen = posSwapSumDataDto.getSettleAmountPvYen()
                                .subtract(posSwapSumDataDto.getTradeAmountPvEvaYen()).setScale(2, RoundingMode.HALF_UP);
                    }
                
                // CF金額
                // 該当通貨、受渡日の売買金額と決済金額の合計値
                posSwapSumDataDto.setCashAmount(posSwapSumDataDto.getDealAmount()
                        .add(posSwapSumDataDto.getSettleAmount()).setScale(2, RoundingMode.HALF_UP));

                // レート取得先がBBGレート(0)の場合
                if (RATESOURCEBBG.equals(item.getRateSource())) {
                    // BBGレートをReal評価レートに設定
                    posSwapSumDataDto.setRealRate(item.getBbgRate());
                } else {
                    // Real評価レート
                    posSwapSumDataDto.setRealRate(item.getRealRate());
                }
                // 引値評価レート
                posSwapSumDataDto.setClosingRate(item.getClosingRate());
                // Real円転レート
                posSwapSumDataDto.setRealYenRate(item.getRealYenRate());
                // 引値円転レート
                posSwapSumDataDto.setClosingYenRate(item.getClosingYenRate());
                // 売買円転レート
                posSwapSumDataDto.setDealYenRate(item.getRealYenRate());
                // 売買円転レート(引値)
                posSwapSumDataDto.setDealYenClosingRate(item.getClosingYenRate());
                // PL(円)
                posSwapSumDataDto.setSumPlYen(plYen);

                // リストに追加
                posSwapSumDataList.add(posSwapSumDataDto);
        } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                    logger.error(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_E001", "DB接続", e);
                    // DB切断された時、処理終了
                    throw e;
                }
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", "ポジションスワップ集計処理 ",
                        "評価レート区分:" + evaluationRateName + ","
                                + item.getDealerBook().concat(",").concat(item.getCurrencyPair()),
                        e);
                // ジョブ警告状態を設定
                contribution.getStepExecution().getJobExecution().getExecutionContext()
                        .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
            }
        }
        return posSwapSumDataList;
    }

    /**
     * ①ポジションスワップディーラブック、通貨、受渡日を纏め処理
     *
     * @param contribution
     * @param posSwapSumDataList
     * @return positionSwapSumDataList
     * @throws positionSwapSumDataList
     */

    static List<TPositionSwapSumDataBean> sumPositionSwapData(StepContribution contribution,
            List<TPositionSwapSumDataDto> tposSwapSumDataList) {

        List<TPositionSwapSumDataBean> positionSwapSumDataList = new ArrayList<>();

        Map<String, Map<Date, List<TPositionSwapSumDataDto>>> sumMap = tposSwapSumDataList.stream().collect(Collectors
                .groupingBy(g -> g.getDealerBook(), Collectors.groupingBy(TPositionSwapSumDataDto::getDeliveryDate)));

        for (String dealerBookKey : sumMap.keySet()) {
            for (Date dateKey : sumMap.get(dealerBookKey).keySet()) {

                // 売買通貨、受渡日毎売買金額合計Map
                Map<String, BigDecimal> totalDealDateMap = new HashMap<>();
                // 決済通貨、受渡日毎決済金額合計Map
                Map<String, BigDecimal> totalSettleDateMap = new HashMap<>();
                // 売買通貨、受渡日毎取引金PV合計Map
                Map<String, BigDecimal> totaldealAmountPvMap = new HashMap<>();
                // 売買通貨、受渡日毎取引金PV円転合計Map
                Map<String, BigDecimal> totaldealAmountPvYenMap = new HashMap<>();
                // 売買通貨、受渡日毎取引金PV評価換算合計Map
                Map<String, BigDecimal> totalTradeAmountPvEvaMap = new HashMap<>();
                // 売買通貨、受渡日毎取引金PV評価換算合計円転Map
                Map<String, BigDecimal> totalTradeAmountPvEvaYenMap = new HashMap<>();
                // 決済通貨、受渡日毎決済金PV合計MapdealAmountPv
                Map<String, BigDecimal> totalSettleAmountPvMap = new HashMap<>();
                // 決済通貨、受渡日毎決済金PV合計MapdealAmountPv
                Map<String, BigDecimal> totalSettleAmountPvYenMap = new HashMap<>();
                // 売買通貨、受渡日毎取引金PV(引値)合計Map
                Map<String, BigDecimal> totalTradeAmountPvClsMap = new HashMap<>();
                // 決済通貨、受渡日毎取引金PV(引値)円転合計
                Map<String, BigDecimal> totalTradeAmountPvClsYenMap = new HashMap<>();

                // 売買通貨リスト
                List<String> dealCurrencyList = sumMap.get(dealerBookKey).get(dateKey).stream()
                        .map(d -> d.getCurrencyPair().substring(0, 3).trim()).collect(Collectors.toList());
                // 決済通貨リスト
                List<String> settleCurrencyList = sumMap.get(dealerBookKey).get(dateKey).stream()
                        .map(d -> d.getCurrencyPair().substring(3, 6).trim()).collect(Collectors.toList());

                // 利用通貨リスト
                List<String> currencyList = new ArrayList<>();
                currencyList.addAll(dealCurrencyList);
                currencyList.addAll(settleCurrencyList);
                currencyList = currencyList.stream().distinct().collect(Collectors.toList());

                // 通貨単位で纏める
                for (String currency : currencyList) {

                    List<TPositionSwapSumDataDto> posdata = sumMap.get(dealerBookKey).get(dateKey).stream()
                            .filter(d -> d.getCurrencyPair().substring(0, 3).trim().equals(currency)
                                    || d.getCurrencyPair().substring(3, 6).trim().equals(currency))
                            .collect(Collectors.toList());

                    List<TPositionSwapSumDataDto> dealPosData = sumMap.get(dealerBookKey).get(dateKey).stream()
                            .filter(d -> d.getCurrencyPair().substring(0, 3).trim().equals(currency))
                            .collect(Collectors.toList());

                    List<TPositionSwapSumDataDto> settlePosData = sumMap.get(dealerBookKey).get(dateKey).stream()
                            .filter(d -> d.getCurrencyPair().substring(3, 6).trim().equals(currency))
                            .collect(Collectors.toList());

                    // 取引金PVNULLチェック
                    List<TPositionSwapSumDataDto> dealAmountPvNullList = sumMap.get(dealerBookKey).get(dateKey).stream()
                            .filter(d -> d.getCurrencyPair().substring(0, 3).trim().equals(currency))
                            .filter(e -> e.getTradeAmountPv() == null).collect(Collectors.toList());

                    // 取引金円転PVNULLチェック
                    List<TPositionSwapSumDataDto> dealAmountPvYenNullList = sumMap.get(dealerBookKey).get(dateKey)
                            .stream().filter(d -> d.getCurrencyPair().substring(0, 3).trim().equals(currency))
                            .filter(e -> e.getTradeAmountPvYen() == null).collect(Collectors.toList());

                    // 取引金PV評価換算NULLチェック
                    List<TPositionSwapSumDataDto> tradeAmountPvEvaNullList = sumMap.get(dealerBookKey).get(dateKey)
                            .stream().filter(d -> d.getCurrencyPair().substring(0, 3).trim().equals(currency))
                            .filter(e -> e.getTradeAmountPvEva() == null).collect(Collectors.toList());

                    // 取引金PV評価換算円転NULLチェック
                    List<TPositionSwapSumDataDto> tradeAmountPvEvaYenNullList = sumMap.get(dealerBookKey).get(dateKey)
                            .stream().filter(d -> d.getCurrencyPair().substring(0, 3).trim().equals(currency))
                            .filter(e -> e.getTradeAmountPvEvaYen() == null).collect(Collectors.toList());

                    // 取引金PV(引値)NULLチェック
                    List<TPositionSwapSumDataDto> dealAmountPvClsNullList = sumMap.get(dealerBookKey).get(dateKey)
                            .stream().filter(d -> d.getCurrencyPair().substring(0, 3).trim().equals(currency))
                            .filter(e -> e.getTradeAmountPvCls() == null).collect(Collectors.toList());

                    // 取引金PV(引値)円転NULLチェック
                    List<TPositionSwapSumDataDto> dealAmountPvClsYenNullList = sumMap.get(dealerBookKey).get(dateKey)
                            .stream().filter(d -> d.getCurrencyPair().substring(0, 3).trim().equals(currency))
                            .filter(e -> e.getTradeAmountPvClsYen() == null).collect(Collectors.toList());

                    // 決済金PVNULLチェック
                    List<TPositionSwapSumDataDto> settleAmountPvNullList = sumMap.get(dealerBookKey).get(dateKey)
                            .stream().filter(d -> d.getCurrencyPair().substring(3, 6).trim().equals(currency))
                            .filter(e -> e.getSettleAmountPv() == null).collect(Collectors.toList());

                    // 決済金PV円転NULLチェック
                    List<TPositionSwapSumDataDto> settleAmountPvYenNullList = sumMap.get(dealerBookKey).get(dateKey)
                            .stream().filter(d -> d.getCurrencyPair().substring(3, 6).trim().equals(currency))
                            .filter(e -> e.getSettleAmountPvYen() == null).collect(Collectors.toList());
                    try {
                        // 集計結果格納リスト
                        TPositionSwapSumDataBean posSwapSumData = new TPositionSwapSumDataBean();
                        // 基準日
                        posSwapSumData.setProcessBaseDate(posdata.get(0).getProcessBaseDate());
                        // ディーラブック
                        posSwapSumData.setDealerBook(dealerBookKey);
                        // 評価レート区分
                        posSwapSumData.setEvaluationRateDivision(posdata.get(0).getEvaluationRateDivision());
                        // 通貨
                        posSwapSumData.setCurrency(currency);
                        // 為替区分
                        posSwapSumData.setExchangeDivision(posdata.get(0).getExchangeDivision().substring(0, 1));
                        // 受渡日
                        posSwapSumData.setDeliveryDate(dateKey);
                        // ディーラブック、受渡日、売買通貨毎売買金額合計
                        List<TPositionSwapSumDataDto> dList = sumMap.get(dealerBookKey).get(dateKey).stream()
                                .filter(a -> a.getCurrencyPair().substring(0, 3).trim().equals(currency))
                                .filter(a -> a.getDeliveryDate().equals(dateKey)).collect(Collectors.toList());
                        // 売買金額集計
                        BigDecimal totalDealAmount = sumBigDecimal(dList, TPositionSwapSumDataDto::getDealAmount);
                        totalDealDateMap.put(currency, totalDealAmount);
                        // 売買金額
                        posSwapSumData.setDealAmount(totalDealDateMap.get(currency));
                        // 決済通貨毎決済金額合計
                        List<TPositionSwapSumDataDto> sList = sumMap.get(dealerBookKey).get(dateKey).stream()
                                .filter(b -> b.getCurrencyPair().substring(3, 6).trim().equals(currency))
                                .filter(b -> b.getSettleAmount() != null).collect(Collectors.toList());
                        // 決済金額集計
                        BigDecimal totalSettleAmount = sumBigDecimal(sList, TPositionSwapSumDataDto::getSettleAmount);
                        totalSettleDateMap.put(currency, totalSettleAmount);
                        // 決済金額
                        posSwapSumData.setSettleAmount(totalSettleDateMap.get(currency));
                        // Real評価レート
                        posSwapSumData.setRealRate(posdata.get(0).getRealRate());
                        // 引値評価レート
                        posSwapSumData.setClosingRate(posdata.get(0).getClosingRate());
                        // Real円転レート
                        posSwapSumData.setRealYenRate(posdata.get(0).getRealYenRate());
                        // 引値円転レート
                        posSwapSumData.setClosingYenRate(posdata.get(0).getClosingYenRate());
                        // 売買円転レート
                        posSwapSumData.setDealYenRate(posdata.get(0).getRealYenRate());
                        // 売買円転レート(引値)
                        posSwapSumData.setDealYenClosingRate(posdata.get(0).getClosingYenRate());
                        // 取引金PV(引値)
                        if (dealAmountPvClsNullList.size() == 0) {
                            BigDecimal totalTradeAmountPvCls = sumBigDecimal(dealPosData,
                                    TPositionSwapSumDataDto::getTradeAmountPvCls);
                            totalTradeAmountPvClsMap.put(currency, totalTradeAmountPvCls);
                            posSwapSumData.setTradeAmountPvCls(totalTradeAmountPvClsMap.get(currency));
                        } else {
                            posSwapSumData.setTradeAmountPvCls(BigDecimal.ZERO);
                        }
                        // 取引金PV(引値)円転
                        if (dealAmountPvClsYenNullList.size() == 0
                                && posSwapSumData.getTradeAmountPvCls().compareTo(BigDecimal.ZERO) != 0) {
                            BigDecimal totalTradeAmountPvClsYen = sumBigDecimal(dealPosData,
                                    TPositionSwapSumDataDto::getTradeAmountPvClsYen);
                            totalTradeAmountPvClsYenMap.put(currency, totalTradeAmountPvClsYen);
                            posSwapSumData.setTradeAmountPvClsYen(totalTradeAmountPvClsYenMap.get(currency));
                        } else {
                            posSwapSumData.setTradeAmountPvClsYen(BigDecimal.ZERO);
                        }
                        // 取引金PV
                        if (dealAmountPvNullList.size() == 0) {
                            BigDecimal totalTradeAmountPv = sumBigDecimal(dealPosData,
                                    TPositionSwapSumDataDto::getTradeAmountPv);
                            totaldealAmountPvMap.put(currency, totalTradeAmountPv);
                            posSwapSumData.setTradeAmountPv(totaldealAmountPvMap.get(currency));
                        } else {
                            posSwapSumData.setTradeAmountPv(null);
                        }
                        // 取引金PV円転
                        if (dealAmountPvYenNullList.size() > 0) {
                            posSwapSumData.setTradeAmountPvYen(null);
                        } else {
                            BigDecimal totalTradeAmountPvYen = sumBigDecimal(dealPosData,
                                    TPositionSwapSumDataDto::getTradeAmountPvYen);
                            totaldealAmountPvYenMap.put(currency, totalTradeAmountPvYen);
                            posSwapSumData.setTradeAmountPvYen(totaldealAmountPvYenMap.get(currency));
                        }
                        // 取引金PV評価換算
                        if (tradeAmountPvEvaNullList.size() > 0) {
                            posSwapSumData.setTradeAmountPvEva(BigDecimal.ZERO);
                        } else {
                            BigDecimal totalTradeAmountPvEva = sumBigDecimal(dealPosData,
                                    TPositionSwapSumDataDto::getTradeAmountPvEva);
                            totalTradeAmountPvEvaMap.put(currency, totalTradeAmountPvEva);
                            posSwapSumData.setTradeAmountPvEva(totalTradeAmountPvEvaMap.get(currency));
                        }

                        // 取引金PV評価換算円転
                        if (tradeAmountPvEvaYenNullList.size() > 0) {
                            posSwapSumData.setTradeAmountPvEvaYen(BigDecimal.ZERO);
                        } else {
                            BigDecimal totalTradeAmountPvEvaYen = sumBigDecimal(dealPosData,
                                    TPositionSwapSumDataDto::getTradeAmountPvEvaYen);
                            totalTradeAmountPvEvaYenMap.put(currency, totalTradeAmountPvEvaYen);
                            posSwapSumData.setTradeAmountPvEvaYen(totalTradeAmountPvEvaYenMap.get(currency));
                        }

                        // 決済円転レート
                        posSwapSumData.setSettleYenRate(posdata.get(0).getRealYenRate());
                        // 決済金PV
                        if (settleAmountPvNullList.size() > 0) {
                            posSwapSumData.setSettleAmountPv(BigDecimal.ZERO);
                        } else {
                            BigDecimal totalSettleAmountPv = sumBigDecimal(settlePosData,
                                    TPositionSwapSumDataDto::getSettleAmountPv);
                            totalSettleAmountPvMap.put(currency, totalSettleAmountPv);
                            posSwapSumData.setSettleAmountPv(totalSettleAmountPvMap.get(currency));
                        }
                        // 決済金PV円転
                        if (settleAmountPvYenNullList.size() > 0) {
                            posSwapSumData.setSettleAmountPvYen(BigDecimal.ZERO);
                        } else {
                            BigDecimal totalSettleAmountPvYen = sumBigDecimal(settlePosData,
                                    TPositionSwapSumDataDto::getSettleAmountPvYen);
                            totalSettleAmountPvYenMap.put(currency, totalSettleAmountPvYen);
                            posSwapSumData.setSettleAmountPvYen(totalSettleAmountPvYenMap.get(currency));
                        }
                        // CF金額
                        // 該当通貨、受渡日の売買金額と決済金額の合計値
                        posSwapSumData
                                .setCashAmount(posSwapSumData.getDealAmount().add(posSwapSumData.getSettleAmount()));
                        // PL(円)
                        posSwapSumData.setSumPlYen(null);

                        // 登録者
                        posSwapSumData.setRegisterUser(JobConstants.Jbpos1000);
                        // 登録日時
                        posSwapSumData.setRegisterDatetime(null);
                        // 更新者
                        posSwapSumData.setUpdateUser(JobConstants.Jbpos1000);
                        // 更新日時
                        posSwapSumData.setUpdateDatetime(null);

                        // リストに追加
                        positionSwapSumDataList.add(posSwapSumData);
                    } catch (Exception e) {
                        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", "ポジションスワップ集計処理",
                                dealerBookKey.concat(",").concat(currency), e);
                        // ジョブ警告状態を設定
                        contribution.getStepExecution().getJobExecution().getExecutionContext()
                                .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
                    }
                }
            }
        }
        return positionSwapSumDataList;
    }


    /**
     * ②通貨別デルタ・キャッシュ残情報集計処理
     *
     * @param contribution
     * @param targetDate
     * @param evaluationRateKbn
     * @param tPositionSwapSumData
     * @param posSumSourceList
     * @return tByCcyDeltaCashBalanceList
     * @throws ParseException
     * @throws IOException
     */
    static List<TByCcyDeltaCashBalanceBean> mkByCcyDeltaCashBalance(StepContribution contribution, Date targetDate,
            String evaluationRateKbn, String evaluationRateName, List<TPositionSwapSumDataBean> tPositionSwapSumData,
            List<TPosSumSourceDataBean> posSumSourceList) throws ParseException, IOException {

        List<TByCcyDeltaCashBalanceBean> tByCcyDeltaCashBalanceList = new ArrayList<>();

        // 集計キー:ディーラブック、通貨
        Map<String, List<TPositionSwapSumDataBean>> sumMap = tPositionSwapSumData.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getCurrency()));

        List<TPosSumSourceDataBean> tPosSumSourceData = posSumSourceList.stream()
                // 処理基準日がバッチ実行日
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                // シーケンスNOが0(スタートポジション)かつ為替区分が約定済CFの場合
                .filter(d -> d.getSeqNo().equals(BigDecimal.ZERO) && TRADEDCF.equals(d.getExchangeDivision()))
                .collect(Collectors.toList());

        for (String dealerBookCcy : sumMap.keySet()) {
            try {
                String[] split = dealerBookCcy.split(",");
                // 売買通貨、受渡日毎取引金合計Map
                Map<String, BigDecimal> totaldealAmountMap = new HashMap<>();
                // 決済通貨、受渡日毎決済金PV合計Map
                Map<String, BigDecimal> totalsettleAmountMap = new HashMap<>();
                // 売買通貨、受渡日毎取引金PV合計Map
                Map<String, BigDecimal> totaldealAmountPvMap = new HashMap<>();
                // 売買通貨、受渡日毎取引金PV(引値)合計Map
                Map<String, BigDecimal> totaldealAmountPvClsMap = new HashMap<>();
                // 売買通貨、受渡日毎決済金PV合計Map
                Map<String, BigDecimal> totalsettleAmountPvMap = new HashMap<>();
                // 売買通貨、受渡日毎前日取引金PV(引値)合計Map
                Map<String, BigDecimal> totalBeTradeAmountPvClsMap = new HashMap<>();

                // 売買金額NULLチェック
                List<TPositionSwapSumDataBean> dealAmountNullList = sumMap.get(dealerBookCcy).stream()
                        .filter(e -> e.getDealAmount() == null).collect(Collectors.toList());
                // 決済金額NULLチェック
                List<TPositionSwapSumDataBean> settleAmountNullList = sumMap.get(dealerBookCcy).stream()
                        .filter(e -> e.getSettleAmount() == null).collect(Collectors.toList());

                // 取引金PVNULLチェック
                List<TPositionSwapSumDataBean> dealAmountPvNullList = sumMap.get(dealerBookCcy).stream()
                        .filter(e -> e.getTradeAmountPv() == null).collect(Collectors.toList());

                // 取引金PV(引値)NULLチェック
                List<TPositionSwapSumDataBean> dealAmountPvClsNullList = sumMap.get(dealerBookCcy).stream()
                        .filter(e -> e.getTradeAmountPvCls() == null).collect(Collectors.toList());

                // 決済金PVNULLチェック
                List<TPositionSwapSumDataBean> settleAmountPvNullList = sumMap.get(dealerBookCcy).stream()
                        .filter(e -> e.getSettleAmountPv() == null).collect(Collectors.toList());
                // 前日取引金PV(引値)NULLチェック
                List<TPosSumSourceDataBean> beTradeAmountPvClsNullList = tPosSumSourceData.stream()
                        .filter(e -> e.getDealerBook().equals(split[0]))
                        .filter(e -> e.getDealCurrency().equals(split[1]))
                        .filter(e -> e.getBeforeTradeAmountPvCls() == null).collect(Collectors.toList());

                List<TPosSumSourceDataBean> beTradeAmountPvClsList = tPosSumSourceData.stream()
                        .filter(e -> e.getDealerBook().equals(split[0]))
                        .filter(e -> e.getDealCurrency().equals(split[1])).collect(Collectors.toList());

                TByCcyDeltaCashBalanceBean byCcyDeltaCash = new TByCcyDeltaCashBalanceBean();

                // 基準日
                byCcyDeltaCash.setProcessBaseDate(targetDate);
                // 評価レート区分
                byCcyDeltaCash.setEvaluationRateDivision(evaluationRateKbn);
                // ディーラブック
                byCcyDeltaCash.setDealerBook(split[0]);
                // 通貨
                byCcyDeltaCash.setCurrency(split[1]);
                BigDecimal sumdealAmount = BigDecimal.ZERO;
                BigDecimal sumSettleAmount = BigDecimal.ZERO;
                BigDecimal Delta = BigDecimal.ZERO;
                BigDecimal sumTradeAmountPvCls = BigDecimal.ZERO;
                BigDecimal sumTradeAmountPv = BigDecimal.ZERO;
                BigDecimal sumSettleAmountPv = BigDecimal.ZERO;
                BigDecimal sumBeforeTradeAmountPvCls = BigDecimal.ZERO;

                // 取引金PV(引値) NULLチェック
                if (dealAmountPvClsNullList.size() == 0) {
                    // 取引金PV(引値) 集計
                    sumTradeAmountPvCls = sumBigDecimal(sumMap.get(dealerBookCcy),
                            TPositionSwapSumDataBean::getTradeAmountPvCls);
                    totaldealAmountPvClsMap.put(dealerBookCcy, sumTradeAmountPvCls);

                }
                // 取引金PVNULLチェック
                if (dealAmountPvNullList.size() == 0) {
                    // 取引金PV集計
                    sumTradeAmountPv = sumBigDecimal(sumMap.get(dealerBookCcy),
                            TPositionSwapSumDataBean::getTradeAmountPv);
                    totaldealAmountPvMap.put(dealerBookCcy, sumTradeAmountPv);
                }
                // 決済金PVNULLチェック
                if (settleAmountPvNullList.size() == 0) {
                    // 決済金PV集計
                    sumSettleAmountPv = sumBigDecimal(sumMap.get(dealerBookCcy),
                            TPositionSwapSumDataBean::getSettleAmountPv);
                    totalsettleAmountPvMap.put(dealerBookCcy, sumSettleAmountPv);
                }
                // 前日取引金PV(引値)PVNULLチェック
                if (beTradeAmountPvClsNullList.size() == 0) {
                    // 前日取引金PV(引値)集計
                    sumBeforeTradeAmountPvCls = sumBigDecimal(beTradeAmountPvClsList,
                            TPosSumSourceDataBean::getBeforeTradeAmountPvCls);
                    totalBeTradeAmountPvClsMap.put(dealerBookCcy, sumBeforeTradeAmountPvCls);
                }

                // 評価レート区分が引値以降の場合
                if (evaluationRateKbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode())) {
                    // 取引金PV(引値)、取引金PV、決済金PVのNULLチェック
                    if (dealAmountPvNullList.size() > 0 || dealAmountPvClsNullList.size() > 0
                            || settleAmountPvNullList.size() > 0) {
                        Delta = null;
                    } else {
                        // 取引金PV(引値)+取引金PV+決済金PVの合計値
                        Delta = totaldealAmountPvClsMap.put(dealerBookCcy, sumTradeAmountPvCls)
                                .add(totaldealAmountPvMap.put(dealerBookCcy, sumTradeAmountPv))
                                .add(totalsettleAmountPvMap.put(dealerBookCcy, sumSettleAmountPv));
                    }
                    // 評価レート区分が引値以降でないの場合
                } else {
                    // 取引金PV、決済金PVのNULLチェック
                    if (beTradeAmountPvClsNullList.size() > 0 || dealAmountPvNullList.size() > 0
                            || settleAmountPvNullList.size() > 0) {
                        Delta = null;
                    } else {
                        // 前日日締めで作成された約定済CFの取引金PV(引値)+取引金PV+決済金PVの合計値
                        Delta = totalBeTradeAmountPvClsMap.put(dealerBookCcy, sumBeforeTradeAmountPvCls)
                                .add(totaldealAmountPvMap.put(dealerBookCcy, sumTradeAmountPv))
                                .add(totalsettleAmountPvMap.put(dealerBookCcy, sumSettleAmountPv));
                    }
                }
                byCcyDeltaCash.setDelta(Delta);
                // デルタ
                if (byCcyDeltaCash.getDelta() == null) {
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001",
                            "通貨別デルタ・キャッシュ残情報集計処理", "評価レート区分:" + evaluationRateName + "," + "ディーラブック:" + split[0]
                                    .concat(",").concat("通貨:" + split[1]).concat("のNULLデータが存在したため、デルタの計算エラー"));
                }

                List<TPositionSwapSumDataBean> deliveryDate = sumMap.get(dealerBookCcy).stream()
                        .filter(e -> e.getDeliveryDate().equals(targetDate)).collect(Collectors.toList());
                // 売買金額NULLチェック
                if (dealAmountNullList.size() == 0) {
                    // 売買金額集計
                    sumdealAmount = sumBigDecimal(deliveryDate, TPositionSwapSumDataBean::getDealAmount);
                    totaldealAmountMap.put(dealerBookCcy, sumdealAmount);
                }
                // 決済金額NULLチェック
                if (settleAmountNullList.size() == 0) {
                    // 決済金額集計
                    sumSettleAmount = sumBigDecimal(deliveryDate, TPositionSwapSumDataBean::getSettleAmount);
                    totalsettleAmountMap.put(dealerBookCcy, sumSettleAmount);
                }
                // キャッシュ残
                if (deliveryDate.size() > 0) {
                    // 基準日時点で落ちた取引残高と決済残高の合計値
                    byCcyDeltaCash.setCashBalance(totaldealAmountMap.put(dealerBookCcy, sumdealAmount)
                            .add(totalsettleAmountMap.put(dealerBookCcy, sumSettleAmount)));

                } else {
                    byCcyDeltaCash.setCashBalance(byCcyDeltaCash.getCashBalance());
                }
                // 登録者
                byCcyDeltaCash.setRegisterUser(JobConstants.Jbpos1000);
                // 更新者
                byCcyDeltaCash.setUpdateUser(JobConstants.Jbpos1000);

                // リスト追加
                tByCcyDeltaCashBalanceList.add(byCcyDeltaCash);

            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)) {
                    logger.error(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_E001", "DB接続", e);
                    // DB切断された時、処理終了
                    throw e;
                }
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", "通貨別デルタ・キャッシュ残情報集計処理 ",
                        dealerBookCcy, e);
                // ジョブ警告状態を設定
                contribution.getStepExecution().getJobExecution().getExecutionContext()
                        .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
            }
        }
        return tByCcyDeltaCashBalanceList;
    }

    /**
     * ③スワップPL合計値情報集計処理
     *
     * @param wkPosSwapSumList
     * @param targetDate
     * @param updateList
     * @param insertList
     * @return
     * @return
     * @return
     * @throws IOException
     */
    static List<TSwapPlSumDateBean> mkSwapPlSumDate(StepContribution contribution, Date targetDate,
            String evaluationRateKbn, String evaluationRateName,
            List<TPositionSwapSumDataDto> posSwapSumDataList)throws ParseException, IOException  {

        List<TSwapPlSumDateBean> tPosSwapPlSumDataList = new ArrayList<>();
        List<TPositionSwapSumDataDto> nullList = new ArrayList<>();
        // 集計キー:ディーラブック、評価レート区分
        Map<String, List<TPositionSwapSumDataDto>> sumMap = posSwapSumDataList.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getEvaluationRateDivision()));

        for (String dealerbookEva : sumMap.keySet()) {
            try {
                nullList = sumMap.get(dealerbookEva).stream().filter(e -> e.getSumPlYen() == null)
                        .collect(Collectors.toList());

                TSwapPlSumDateBean swapPlSumDate = new TSwapPlSumDateBean();
                String[] split = dealerbookEva.split(",");
                // 基準日
                swapPlSumDate.setProcessBaseDate(targetDate);
                // 評価レート区分
                swapPlSumDate.setEvaluationRateDivision(split[1]);
                // ディーラブック
                swapPlSumDate.setDealerBook(split[0]);
                // PL合計値
                if (nullList.size() > 0) {
                    swapPlSumDate.setPlTotal(null);
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", "スワップPL合計値情報集計処理",
                            "評価レート区分:" + evaluationRateName + "," + "ディーラブック:"
                                    + split[0].concat("のNULLデータが存在したため、PL合計値の計算エラー"));
                } else {
                    BigDecimal plSum = sumBigDecimal(sumMap.get(dealerbookEva), TPositionSwapSumDataDto::getSumPlYen);
                    swapPlSumDate.setPlTotal(plSum.setScale(2, RoundingMode.HALF_UP));
                }
                // 登録者
                swapPlSumDate.setRegisterUser(JobConstants.Jbpos1000);
                // 更新者
                swapPlSumDate.setUpdateUser(JobConstants.Jbpos1000);

                // リスト追加
                tPosSwapPlSumDataList.add(swapPlSumDate);
            } catch (Exception e) {
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", "スワップPL合計値情報集計処理 ",
                        "評価レート区分:" + evaluationRateName + "," + dealerbookEva, e);
                // ジョブ警告状態を設定
                contribution.getStepExecution().getJobExecution().getExecutionContext()
                        .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
            }
        }
        return tPosSwapPlSumDataList;
    }

    /**
     * 6.3.2スワップのIT分取引を設定処理
     *
     * @param wkPosSwapSumList
     * @param targetDate
     * @param updateList
     * @param insertList
     * @return
     * @throws ParseException
     */
    static List<TPosSumSourceDataBean> setPosSwapItData(StepContribution contribution,
            List<TPosSumSourceDataBean> PosSumSourceDataSwapIt) throws ParseException {

        List<TPosSumSourceDataBean> tPosSwapItDataLsit = new ArrayList<>();

        for (TPosSumSourceDataBean item : PosSumSourceDataSwapIt) {
            TPosSumSourceDataBean pos = new TPosSumSourceDataBean();
            // ディーラブック
            pos.setDealerBook(item.getDealerBook());
            // 約定日時
            pos.setTradeDatetime(item.getTradeDatetime());
            // データ源泉
            pos.setInputDataSource(item.getInputDataSource());
            // AC
            pos.setAc(item.getAc());
            // 受渡日
            pos.setDeliveryDate(item.getDeliveryDate());
            // 為替区分
            pos.setExchangeDivision(item.getExchangeDivision());
            // 売買区分
            pos.setDealDivision(item.getDealDivision());
            // 売買通貨
            pos.setDealCurrency(item.getDealCurrency());
            // 取引レート
            pos.setTradeRate(item.getTradeRate());
            // 決済通貨
            pos.setSettleCurrency(item.getSettleCurrency());
            // 通貨ペア
            pos.setCurrencyPair(item.getCurrencyPair());
            // 売買金額
            // 売買区分が買の場合
            if (BUY.equals(item.getDealDivision())) {
                pos.setDealAmount(item.getDealAmount());
            } else {
                // マイナス反転
                pos.setDealAmount(item.getDealAmount().negate());
            }
            // 決済金額
            if (BUY.equals(item.getDealDivision())) {
                pos.setSettleAmount(item.getSettleAmount());
            } else {
                // マイナス反転
                pos.setSettleAmount(item.getSettleAmount().negate());
            }
            // リストに追加
            tPosSwapItDataLsit.add(pos);
        }
        List<TPosSumSourceDataBean> tPosSwapItDataList = setTradeUnitTransaction(contribution, tPosSwapItDataLsit);

        return tPosSwapItDataList;
    }

    /**
     * 6.4.スワップのIT分取引、ディーラーブック、受渡日、通貨別のトランザクション纏め処理
     *
     * @param wkPosSwapSumList
     * @param targetDate
     * @param updateList
     * @param insertList
     * @return
     * @throws ParseException
     */
    static List<TPosSumSourceDataBean> setTradeUnitTransaction(StepContribution contribution,
            List<TPosSumSourceDataBean> tPosSwapItDataLsit) throws ParseException {

        List<TPosSumSourceDataBean> tPosSumSourceDataBeanList = new ArrayList<>();

        Map<String, Map<Date, List<TPosSumSourceDataBean>>> dealwkMap = tPosSwapItDataLsit.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getSettleCurrency(),
                        Collectors.groupingBy(TPosSumSourceDataBean::getDeliveryDate)));

        for (String bookCcyKey : dealwkMap.keySet()) {
            for (Date dateKey : dealwkMap.get(bookCcyKey).keySet()) {
                String[] split = bookCcyKey.split(",");
                try {

                    // 売買通貨、受渡日毎売買金額合計Map
                    Map<String, BigDecimal> totalDealDateMap = new HashMap<>();
                    // 決済通貨、受渡日毎決済金額合計Map
                    Map<String, BigDecimal> totalSettleDateMap = new HashMap<>();

                    // 売買通貨リスト
                    List<String> dealCurrencyList = dealwkMap.get(bookCcyKey).get(dateKey).stream()
                            .map(d -> d.getDealCurrency()).collect(Collectors.toList());
                    // 決済通貨リスト
                    List<String> settleCurrencyList = dealwkMap.get(bookCcyKey).get(dateKey).stream()
                            .map(d -> d.getSettleCurrency()).collect(Collectors.toList());
                    // 利用通貨リスト
                    List<String> currencyList = new ArrayList<>();
                    currencyList.addAll(dealCurrencyList);
                    currencyList.addAll(settleCurrencyList);
                    currencyList = currencyList.stream().distinct().collect(Collectors.toList());

                    // 通貨単位で纏める
                    for (String currency : currencyList) {

                        TPosSumSourceDataBean pos = new TPosSumSourceDataBean();

                        List<TPosSumSourceDataBean> posdata = dealwkMap.get(bookCcyKey).get(dateKey).stream()
                                .collect(Collectors.toList());
                        // ディーラブック
                        pos.setDealerBook(split[0]);
                        // 約定日時
                        pos.setTradeDatetime(posdata.get(0).getTradeDatetime());
                        // データ源泉
                        pos.setInputDataSource(posdata.get(0).getInputDataSource());
                        // AC
                        pos.setAc(posdata.get(0).getAc());
                        // 受渡日
                        pos.setDeliveryDate(dateKey);
                        // 為替区分
                        pos.setExchangeDivision("4");
                        // 売買通貨
                        pos.setDealCurrency(currency);
                        // 取引レート
                        pos.setTradeRate(null);
                        // 決済通貨
                        pos.setSettleCurrency("JPY");
                        // 通貨ペア
                        pos.setCurrencyPair(currency.concat("JPY"));
                        // 売買通貨側
                        List<TPosSumSourceDataBean> dList = dealwkMap.get(bookCcyKey).get(dateKey).stream()
                                .filter(a -> a.getDealCurrency().equals(currency)).collect(Collectors.toList());

                        BigDecimal totalDealAmount = BigDecimal.ZERO;
                        // 売買金額NULLチェック
                        List<TPosSumSourceDataBean> dealAmountNullList = dealwkMap.get(bookCcyKey).get(dateKey).stream()
                                .filter(e -> e.getDealCurrency().equals(currency))
                                .filter(e -> e.getDealAmount() == null).collect(Collectors.toList());
                        if (dealAmountNullList.size() == 0) {
                            // 売買金額集計
                            totalDealAmount = sumBigDecimal(dList, TPosSumSourceDataBean::getDealAmount);
                            totalDealDateMap.put(currency, totalDealAmount);
                        } else {
                            totalDealAmount = BigDecimal.ZERO;
                        }
                        // 決済通貨側
                        List<TPosSumSourceDataBean> sList = dealwkMap.get(bookCcyKey).get(dateKey).stream()
                                .filter(a -> a.getSettleCurrency().equals(currency)).collect(Collectors.toList());

                        // 決済金額NULLチェック
                        BigDecimal totalSettleAmount = BigDecimal.ZERO;
                        List<TPosSumSourceDataBean> settleAmountNullList = dealwkMap.get(bookCcyKey).get(dateKey)
                                .stream().filter(e -> e.getSettleCurrency().equals(currency))
                                .filter(e -> e.getSettleAmount() == null).collect(Collectors.toList());
                        if (settleAmountNullList.size() == 0) {
                            // 決済金額集計
                            totalSettleAmount = sumBigDecimal(sList, TPosSumSourceDataBean::getSettleAmount);
                            totalSettleDateMap.put(currency, totalSettleAmount);
                        } else {
                            totalSettleAmount = BigDecimal.ZERO;
                        }
                        // 売買区分
                        if (totalDealDateMap.put(currency, totalDealAmount)
                                .add(totalSettleDateMap.put(currency, totalSettleAmount))
                                .compareTo(BigDecimal.ZERO) >= 0) {
                            pos.setDealDivision(BUY);
                        } else {
                            pos.setDealDivision(SELL);
                        }
                        // 売買金額(絶対値)
                        pos.setDealAmount(totalDealDateMap.put(currency, totalDealAmount)
                                .add(totalSettleDateMap.put(currency, totalSettleAmount)).abs());
                        // 決済金額
                        pos.setSettleAmount(BigDecimal.ZERO);
                        tPosSumSourceDataBeanList.add(pos);
                    }
                } catch (Exception e) {
                    logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002",
                            split[0].concat(",").concat(split[1].concat("JPY").concat("スワップのIT分取引通貨など別のトランザクション纏め処理 "),
                            e);
                    // ジョブ警告状態を設定
                    contribution.getStepExecution().getJobExecution().getExecutionContext()
                            .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
                }
            }
        }
        return tPosSumSourceDataBeanList;
    }

    /**
     * 集計用メソッド
     *
     * @param <T>
     * @param list
     * @param mapper
     * @return
     */
    public static <T> BigDecimal sumBigDecimal(List<T> list, Function<T, BigDecimal> mapper) {
        return list.stream().map(mapper).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}