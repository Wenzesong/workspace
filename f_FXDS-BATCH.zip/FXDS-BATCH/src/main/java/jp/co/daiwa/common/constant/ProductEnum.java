package jp.co.daiwa.common.constant;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code ProductEnum}。
 *
 * <p>jbpos1100 は {@link #FBOND_TRADE}（外債売買）と {@code getCode()} を使用する。
 * コード値は推定の既定値であり、実プロジェクトの正規コードで検証すること。</p>
 */
public enum ProductEnum {

    FBOND_TRADE("1");

    private final String code;

    ProductEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
