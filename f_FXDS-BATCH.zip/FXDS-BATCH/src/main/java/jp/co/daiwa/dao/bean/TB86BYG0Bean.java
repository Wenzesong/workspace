package jp.co.daiwa.dao.bean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TB86BYG0Bean}（BID 為替約定の検索条件）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TB86BYG0Bean {

    private String sgymd1;
    private String yakymd1;

    public String getSgymd1() {
        return sgymd1;
    }

    public void setSgymd1(String sgymd1) {
        this.sgymd1 = sgymd1;
    }

    public String getYakymd1() {
        return yakymd1;
    }

    public void setYakymd1(String yakymd1) {
        this.yakymd1 = yakymd1;
    }
}
