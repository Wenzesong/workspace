package jp.co.daiwa.common;

import java.io.File;
import java.io.FilenameFilter;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code jp.co.daiwa.common.TargetFileFilter}。
 *
 * <p>{@code File#listFiles(FilenameFilter)} に渡される。コンストラクタ引数は
 * (ファイル名プレフィックス, サフィックス/正規表現)。実際の照合仕様は実プロジェクトに従う。</p>
 */
public class TargetFileFilter implements FilenameFilter {

    private final String prefix;
    private final String suffix;

    public TargetFileFilter(String prefix, String suffix) {
        this.prefix = prefix;
        this.suffix = suffix;
    }

    @Override
    public boolean accept(File dir, String name) {
        boolean prefixOk = prefix == null || name.startsWith(prefix);
        boolean suffixOk = suffix == null || name.matches(".*" + suffix);
        return prefixOk && suffixOk;
    }
}
