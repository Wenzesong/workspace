package jp.co.daiwa.jbpos1100.swap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.jbpos1100.common.BigDecimalSummer;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;

/**
 * スワップ PL 合計値情報を集計するクラス。
 *
 * <p>旧 {@code Jbpos1000SwapSummary#mkSwapPlSumDate} の移植版。旧コードは呼び出し側
 * （通貨単位纏め結果 {@code List<TPositionSwapSumDataBean>}）とパラメータ型
 * （{@code List<TPositionSwapSumDataDto>}）が不整合だったため jbpos1000 側で Bean 型に統一済み。
 * ここでは集計ロジックを独立クラス化する。</p>
 *
 * <p>ディーラブック・評価レート区分単位で円換算 PL（{@code sumPlYen}）を合計する。
 * いずれかの行で {@code sumPlYen} が NULL の場合は当該グループの PL 合計値を NULL（計算エラー）とする。</p>
 */
public class SwapPlSumCalculator {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(SwapPlSumCalculator.class);
    private static final String LABEL = "スワップPL合計値情報集計処理";
    private static final int PL_SCALE = 2;

    private final JobWarningReporter warningReporter;

    /**
     * @param warningReporter 警告レポータ
     */
    public SwapPlSumCalculator(JobWarningReporter warningReporter) {
        this.warningReporter = warningReporter;
    }

    /**
     * スワップ PL 合計値情報を集計する。
     *
     * @param targetDate         基準日
     * @param evaluationRateName 評価レート区分名（ログ用）
     * @param swapSumDataList    通貨単位纏め済みスワップ集計結果
     * @return スワップ PL 合計値情報リスト
     */
    public List<TSwapPlSumDateBean> calculate(Date targetDate, String evaluationRateName,
            List<TPositionSwapSumDataBean> swapSumDataList) {

        List<TSwapPlSumDateBean> result = new ArrayList<>();
        // 集計キー: ディーラブック, 評価レート区分
        Map<String, List<TPositionSwapSumDataBean>> sumMap = swapSumDataList.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getEvaluationRateDivision()));

        for (Map.Entry<String, List<TPositionSwapSumDataBean>> entry : sumMap.entrySet()) {
            try {
                result.add(toPlSumBean(targetDate, evaluationRateName, entry.getKey(), entry.getValue()));
            } catch (Exception e) {
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", LABEL,
                        "評価レート区分:" + evaluationRateName + "," + entry.getKey(), e);
                warningReporter.markJobWarning();
            }
        }
        return result;
    }

    /**
     * 1 集計キー分の PL 合計値 Bean を生成する。
     *
     * @param targetDate         基準日
     * @param evaluationRateName 評価レート区分名（警告用）
     * @param dealerBookEvaKey   "ディーラブック,評価レート区分" 形式キー
     * @param group              当該キーの集計結果
     * @return PL 合計値 Bean
     */
    private TSwapPlSumDateBean toPlSumBean(Date targetDate, String evaluationRateName, String dealerBookEvaKey,
            List<TPositionSwapSumDataBean> group) {
        String[] split = dealerBookEvaKey.split(",");
        String dealerBook = split[0];
        String evaluationRateDivision = split[1];

        TSwapPlSumDateBean bean = new TSwapPlSumDateBean();
        bean.setProcessBaseDate(targetDate);
        bean.setEvaluationRateDivision(evaluationRateDivision);
        bean.setDealerBook(dealerBook);

        boolean hasNull = group.stream().anyMatch(e -> e.getSumPlYen() == null);
        if (hasNull) {
            bean.setPlTotal(null);
            warningReporter.warn(LABEL, "評価レート区分:" + evaluationRateName + ",ディーラブック:" + dealerBook
                    + "のNULLデータが存在したため、PL合計値の計算エラー");
        } else {
            BigDecimal plSum = BigDecimalSummer.sum(group, TPositionSwapSumDataBean::getSumPlYen);
            bean.setPlTotal(plSum.setScale(PL_SCALE, RoundingMode.HALF_UP));
        }

        bean.setRegisterUser(JobConstants.Jbpos1000);
        bean.setUpdateUser(JobConstants.Jbpos1000);
        return bean;
    }
}
