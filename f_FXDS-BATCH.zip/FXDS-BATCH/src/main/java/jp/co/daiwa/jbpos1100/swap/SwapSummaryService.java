package jp.co.daiwa.jbpos1100.swap;

import java.util.Date;
import java.util.List;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.dto.TPositionSwapSumDataDto;
import jp.co.daiwa.jbpos1100.common.EvaluationRateNames;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashCalculator;

/**
 * スワップ集計の計算パイプライン（1 評価レート区分分）を結線するサービス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#mkPositionSwapSumData} の計算工程を、移植済みの
 * 専門クラス群へ委譲して再構成したもの（継承ではなくコンポジション）。処理順は旧コードと同一:</p>
 * <ol>
 *   <li>{@link SwapCashSumAssembler} … CF 単位の PV 組立</li>
 *   <li>{@link SwapCurrencyAggregator} … 通貨単位の纏め</li>
 *   <li>{@link CurrencyDeltaCashCalculator} … 通貨別デルタ・キャッシュ残</li>
 *   <li>{@link SwapPlSumCalculator} … スワップ PL 合計</li>
 * </ol>
 *
 * <p>本サービスは「計算」に専念し、ファイル出力・DB 永続化（{@code SwapSumStore} 等）・
 * 日締めデータ複製はオーケストレータ側に委ねる（単一責務）。</p>
 */
public class SwapSummaryService {

    private final SwapCashSumAssembler cashSumAssembler;
    private final SwapCurrencyAggregator currencyAggregator;
    private final CurrencyDeltaCashCalculator deltaCashCalculator;
    private final SwapPlSumCalculator plSumCalculator;

    /**
     * @param cashSumAssembler    CF 単位 PV 組立
     * @param currencyAggregator  通貨単位纏め
     * @param deltaCashCalculator 通貨別デルタ・キャッシュ残集計
     * @param plSumCalculator     スワップ PL 合計集計
     */
    public SwapSummaryService(SwapCashSumAssembler cashSumAssembler, SwapCurrencyAggregator currencyAggregator,
            CurrencyDeltaCashCalculator deltaCashCalculator, SwapPlSumCalculator plSumCalculator) {
        this.cashSumAssembler = cashSumAssembler;
        this.currencyAggregator = currencyAggregator;
        this.deltaCashCalculator = deltaCashCalculator;
        this.plSumCalculator = plSumCalculator;
    }

    /**
     * スワップ集計の計算パイプラインを実行する。
     *
     * @param contribution      ステップ実行コンテキスト（DB 切断時の終了判定用）
     * @param targetDate        基準日
     * @param swapSourceList    スワップ対象の集計元データ
     * @param allSourceList     当該基準日の全集計元データ（デルタ集計のスタートポジション抽出に使用）
     * @param dfCalcResult      DF 算出結果
     * @param dfHistory         DF 履歴情報
     * @param evaluationRateKbn 評価レート区分コード
     * @return スワップ集計結果（通貨単位纏め・デルタ／キャッシュ残・PL合計）
     * @throws Exception DB 切断由来の例外
     */
    public SwapSummaryResult aggregate(StepContribution contribution, Date targetDate,
            List<TPosSumSourceDataBean> swapSourceList, List<TPosSumSourceDataBean> allSourceList,
            List<TDfCalcResultBean> dfCalcResult, List<TDfHistoryDateBean> dfHistory,
            String evaluationRateKbn) throws Exception {

        String evaluationRateName = EvaluationRateNames.of(evaluationRateKbn);

        // 1. CF 単位の PV 組立
        List<TPositionSwapSumDataDto> cashSumList = cashSumAssembler.assemble(targetDate, swapSourceList,
                dfCalcResult, dfHistory, evaluationRateKbn, evaluationRateName);

        // 2. 通貨単位の纏め
        List<TPositionSwapSumDataBean> currencySumList = currencyAggregator.aggregate(cashSumList);

        // 3. 通貨別デルタ・キャッシュ残
        List<TByCcyDeltaCashBalanceBean> deltaCashList = deltaCashCalculator.calculate(contribution, targetDate,
                evaluationRateKbn, evaluationRateName, currencySumList, allSourceList);

        // 4. スワップ PL 合計
        List<TSwapPlSumDateBean> plSumList = plSumCalculator.calculate(targetDate, evaluationRateName, currencySumList);

        return new SwapSummaryResult(currencySumList, deltaCashList, plSumList);
    }
}
