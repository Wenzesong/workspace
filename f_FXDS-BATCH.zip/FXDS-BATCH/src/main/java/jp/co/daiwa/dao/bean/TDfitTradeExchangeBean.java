package jp.co.daiwa.dao.bean;

import java.security.Timestamp;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TDfitTradeExchangeBean}（DFIT 為替トレードデータ）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TDfitTradeExchangeBean {

    private String inputDataId;

    private Timestamp tradeDateTime;
    
    public String getInputDataId() {
        return inputDataId;
    }

    public void setInputDataId(String inputDataId) {
        this.inputDataId = inputDataId;
    }

    public Timestamp getTradeDateTime() {
        return tradeDateTime;
    }

    public void setTradeDateTime(Timestamp tradeDateTime) {
        this.tradeDateTime = tradeDateTime;
    }
}
