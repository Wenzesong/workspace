package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TSwapPlSumDateBean}（スワップ PL 合計値情報）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TSwapPlSumDateBean {

    private Date processBaseDate;
    private String evaluationRateDivision;
    private String dealerBook;
    private BigDecimal plTotal;
    private String registerUser;
    private Timestamp registerDatetime;
    private String updateUser;
    private Timestamp updateDatetime;

    public Date getProcessBaseDate() {
        return processBaseDate;
    }

    public void setProcessBaseDate(Date processBaseDate) {
        this.processBaseDate = processBaseDate;
    }

    public String getEvaluationRateDivision() {
        return evaluationRateDivision;
    }

    public void setEvaluationRateDivision(String evaluationRateDivision) {
        this.evaluationRateDivision = evaluationRateDivision;
    }

    public String getDealerBook() {
        return dealerBook;
    }

    public void setDealerBook(String dealerBook) {
        this.dealerBook = dealerBook;
    }

    public BigDecimal getPlTotal() {
        return plTotal;
    }

    public void setPlTotal(BigDecimal plTotal) {
        this.plTotal = plTotal;
    }

    public String getRegisterUser() {
        return registerUser;
    }

    public void setRegisterUser(String registerUser) {
        this.registerUser = registerUser;
    }

    public Timestamp getRegisterDatetime() {
        return registerDatetime;
    }

    public void setRegisterDatetime(Timestamp registerDatetime) {
        this.registerDatetime = registerDatetime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Timestamp getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(Timestamp updateDatetime) {
        this.updateDatetime = updateDatetime;
    }
}
