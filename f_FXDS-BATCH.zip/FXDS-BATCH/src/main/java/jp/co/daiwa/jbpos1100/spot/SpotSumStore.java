package jp.co.daiwa.jbpos1100.spot;

import java.util.List;

import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.common.TransactionalBatchExecutor;

/**
 * ポジションスポット集計結果テーブルの永続化（中間コミット）クラス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#spotSumDataDelete} / spot insert（一括＋1 件リトライ）の
 * 重複トランザクション処理を {@link TransactionalBatchExecutor} へ委譲したもの。</p>
 */
public class SpotSumStore {

    private static final String LABEL_DELETE = "ポジションスポット集計結果削除処理";
    private static final String LABEL_INSERT = "ポジションスポット集計結果登録処理";

    private final TPositionSpotSumDataRepository repository;
    private final TransactionalBatchExecutor executor;
    private final int bulkInsertUnit;

    public SpotSumStore(TPositionSpotSumDataRepository repository, TransactionalBatchExecutor executor,
            int bulkInsertUnit) {
        this.repository = repository;
        this.executor = executor;
        this.bulkInsertUnit = bulkInsertUnit;
    }

    /**
     * 削除（中間コミット）。
     *
     * @param condition 削除条件
     * @throws Exception DB 切断由来の例外
     */
    public void delete(TPositionSpotSumDataBean condition) throws Exception {
        executor.runInNewTransaction(LABEL_DELETE, () -> repository.delete(condition));
    }

    /**
     * 一括登録（中間コミット＋1 件ずつ再 INSERT リトライ）。
     *
     * @param items 登録対象
     * @throws Exception DB 切断由来の例外
     */
    public void insert(List<TPositionSpotSumDataBean> items) throws Exception {
        executor.bulkInsertWithRetry(LABEL_INSERT, items, bulkInsertUnit, repository::insert);
    }
}
