package jp.co.daiwa.dto;

import java.math.BigDecimal;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code jp.co.daiwa.dto.CloseRateDto}（当日引けレート）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class CloseRateDto {

    private String baseDate;
    private String dealCurrency;
    private String settleCurrency;
    private BigDecimal closeRate;

    public String getBaseDate() {
        return baseDate;
    }

    public void setBaseDate(String baseDate) {
        this.baseDate = baseDate;
    }

    public String getDealCurrency() {
        return dealCurrency;
    }

    public void setDealCurrency(String dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    public String getSettleCurrency() {
        return settleCurrency;
    }

    public void setSettleCurrency(String settleCurrency) {
        this.settleCurrency = settleCurrency;
    }

    public BigDecimal getCloseRate() {
        return closeRate;
    }

    public void setCloseRate(BigDecimal closeRate) {
        this.closeRate = closeRate;
    }
}
