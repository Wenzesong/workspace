package jp.co.daiwa.jbpos1100.tasklet;

import java.util.Date;

import org.springframework.batch.core.StepContribution;

/**
 * ポジション集計の 1 サイクル（1 回分の集計処理）を表すインタフェース。
 *
 * <p>常駐ループを回す {@link PositionSummaryTasklet}（オーケストレーション役）と、
 * 実際の集計処理（実装役）を分離するための境界。Tasklet をループ制御に専念させ、
 * 集計本体はモック実装に差し替えてループ挙動を単体テストできるようにする。</p>
 */
public interface PositionSummaryCycle {

    /**
     * バッチ実行基準日を解決する（営業日でなければ null）。
     *
     * @return 営業日の基準日、非営業日なら null
     */
    Date resolveTargetDate();

    /**
     * 1 サイクル分のポジション集計を実行する。
     *
     * @param contribution ステップ実行コンテキスト
     * @param targetDate   基準日
     * @throws Exception DB 切断等、ループを終了させるべき例外
     */
    void runOnce(StepContribution contribution, Date targetDate) throws Exception;
}
