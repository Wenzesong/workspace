package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TDfCalcResultBean}（DF 算出結果）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TDfCalcResultBean {

    private String currency;
    private Date gridDate;
    private BigDecimal discountFactor;

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Date getGridDate() {
        return gridDate;
    }

    public void setGridDate(Date gridDate) {
        this.gridDate = gridDate;
    }

    public BigDecimal getDiscountFactor() {
        return discountFactor;
    }

    public void setDiscountFactor(BigDecimal discountFactor) {
        this.discountFactor = discountFactor;
    }
}
