package jp.co.daiwa.jbpos1100.rate;

import java.math.BigDecimal;
import java.util.List;

import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfarmBbgRateBean;
import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.dto.PosBaseRateDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;

/**
 * 対円（円転）レートの選択を担うリゾルバ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#getRealJpyRate} / {@code getClosingJpyRate} の移植版
 * （両メソッドとも破損はなく、対象通貨の選び方が同型のため 1 クラスに集約）。</p>
 *
 * <p>対象通貨は「為替区分が約定済CF（スワップのスタートポジション）の場合は売買通貨、
 * それ以外は決済通貨」を JPY へ換算する、という共通則。対象通貨が JPY なら 1.0 を返す。</p>
 */
public class YenRateResolver {

    /**
     * Real 円転レートを決定する（優先: マニュアル日中時価 → ST(ベースレート仲値) → BBG）。
     *
     * @param baseRateMap          ベースレート（ST）情報
     * @param data                 集計元データ
     * @param manualRateList       マニュアルレート情報
     * @param bbgRateList          BBG レート情報
     * @param jpySettleCurrencyMst 決済通貨=JPY の通貨マスタ（レート取得先判定用）
     * @return Real 円転レート（取得不可なら null）
     */
    public BigDecimal resolveRealYenRate(List<PosBaseRateDto> baseRateMap, TPosSumSourceDataBean data,
            List<TPosSumManualRateBean> manualRateList, List<TDfarmBbgRateBean> bbgRateList,
            List<TCurrencyMstBean> jpySettleCurrencyMst) {

        boolean tradedCf = isTradedCf(data);
        String targetCcy = tradedCf ? data.getDealCurrency() : data.getSettleCurrency();
        if (BatchConstants.CURRENCY_JPY.equals(targetCcy)) {
            return BigDecimal.ONE;
        }
        String bbgSecondCcy = tradedCf ? data.getSettleCurrency() : BatchConstants.CURRENCY_JPY;

        TCurrencyMstBean settleJpyInfo = jpySettleCurrencyMst.stream()
                .filter(a -> a.getDealCurrency().equals(targetCcy)).findFirst().orElse(null);
        PosBaseRateDto stRate = baseRateMap.stream()
                .filter(a -> a.getCurrencyPair().equals(targetCcy + BatchConstants.CURRENCY_JPY))
                .findFirst().orElse(null);
        TDfarmBbgRateBean bbgRate = bbgRateList.stream()
                .filter(y -> y.getCurrencyPair().substring(0, 3).equals(targetCcy))
                .filter(y -> y.getCurrencyPair().substring(3, 6).equals(bbgSecondCcy))
                .findFirst().orElse(null);
        TPosSumManualRateBean manualRate = findManualJpyRate(manualRateList, targetCcy);

        if (manualRate != null && manualRate.getManualDailyRate() != null) {
            return manualRate.getManualDailyRate();
        }
        if (settleJpyInfo != null && BatchConstants.RATE_SOURCE_SMART.equals(settleJpyInfo.getRateSource())) {
            return stRate != null ? midRate(stRate) : null;
        }
        return bbgRate != null ? bbgRate.getRate() : null;
    }

    /**
     * 引値円転レートを決定する（優先: マニュアル引値TTM → 引値レートファイル）。
     *
     * @param closeRateList  引値レートファイル情報
     * @param data           集計元データ
     * @param baseDate       基準日（yyyy/MM/dd）
     * @param manualRateList マニュアルレート情報
     * @return 引値円転レート（取得不可なら null）
     */
    public BigDecimal resolveClosingYenRate(List<CloseRateDto> closeRateList, TPosSumSourceDataBean data,
            String baseDate, List<TPosSumManualRateBean> manualRateList) {

        String targetCcy = isTradedCf(data) ? data.getDealCurrency() : data.getSettleCurrency();
        if (BatchConstants.CURRENCY_JPY.equals(targetCcy)) {
            return BigDecimal.ONE;
        }
        CloseRateDto closeYenRate = closeRateList.stream()
                .filter(b -> b.getBaseDate().equals(baseDate))
                .filter(b -> b.getDealCurrency().equals(targetCcy))
                .filter(b -> BatchConstants.CURRENCY_JPY.equals(b.getSettleCurrency()))
                .findFirst().orElse(null);
        TPosSumManualRateBean manualRate = findManualJpyRate(manualRateList, targetCcy);

        if (manualRate != null && manualRate.getManualClosingTtmRate() != null) {
            return manualRate.getManualClosingTtmRate();
        }
        return closeYenRate != null ? closeYenRate.getCloseRate() : null;
    }

    private boolean isTradedCf(TPosSumSourceDataBean data) {
        return BatchConstants.EXCHANGE_DIVISION_TRADED_CF.equals(data.getExchangeDivision());
    }

    private TPosSumManualRateBean findManualJpyRate(List<TPosSumManualRateBean> manualRateList, String dealCcy) {
        return manualRateList.stream()
                .filter(c -> c.getDealCurrency().equals(dealCcy))
                .filter(c -> c.getSettleCurrency().equals(BatchConstants.CURRENCY_JPY))
                .findFirst().orElse(null);
    }

    private BigDecimal midRate(PosBaseRateDto stRate) {
        return new BigDecimal(stRate.getBidRate())
                .add(new BigDecimal(stRate.getAskRate()))
                .divide(new BigDecimal(2));
    }
}
