package jp.co.daiwa.common.constant;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code ExchangeKbnEnum}。
 *
 * <p>jbpos1100 は内包 enum {@link ExchangeKbn}（スポット/スワップスタート/スワップエンド/約定済CF）と
 * {@code getCode()} を使用する。コード値は推定の既定値であり、実プロジェクトの正規コードで検証すること。</p>
 */
public final class ExchangeKbnEnum {

    private ExchangeKbnEnum() {
    }

    public enum ExchangeKbn {
        SPOT("1"),
        SWAP_START("2"),
        SWAP_END("3"),
        TRADEDCF("4");

        private final String code;

        ExchangeKbn(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }
    }
}
