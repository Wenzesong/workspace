package jp.co.daiwa.jbpos1100.tasklet;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.source.ClosingSpotSourceLoader;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplitter;

/**
 * 引値（Closing）集計のオーケストレーションサービス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setClosingValueData} の移植・結線版。引値のスポットは
 * 当日約定ではなく DB のプレ引値スポット集計結果＋PL デルタ生成情報から構成する点が特徴。</p>
 * <ol>
 *   <li>スポット＝プレ引値スポット結果（{@link ClosingSpotSourceLoader#loadPreClosingSpotAsSource}）
 *       ＋PL デルタ（{@link ClosingSpotSourceLoader#loadDeltaAsSource}、存在時のみ）。</li>
 *   <li>スワップ＝引値ウィンドウのスワップ（{@link SourcePositionSplitter#splitForClosingSwap}）。</li>
 *   <li>{@link PositionEvaluationService} で集計＋永続化（引値区分）。</li>
 * </ol>
 */
public class ClosingEvaluationService {

    private final ClosingSpotSourceLoader spotSourceLoader;
    private final SourcePositionSplitter splitter;
    private final PositionEvaluationService evaluationService;
    private final EndOfDayClosingService endOfDayClosingService;

    /**
     * @param spotSourceLoader       プレ引値スポット／PL デルタの取得・変換
     * @param splitter               振り分け
     * @param evaluationService      スポット／スワップ集計＋永続化（共通）
     * @param endOfDayClosingService 引値結果の日締め（03）複製・登録
     */
    public ClosingEvaluationService(ClosingSpotSourceLoader spotSourceLoader, SourcePositionSplitter splitter,
            PositionEvaluationService evaluationService, EndOfDayClosingService endOfDayClosingService) {
        this.spotSourceLoader = spotSourceLoader;
        this.splitter = splitter;
        this.evaluationService = evaluationService;
        this.endOfDayClosingService = endOfDayClosingService;
    }

    /**
     * 引値集計を実行・永続化する。
     *
     * @param contribution     ステップ実行コンテキスト
     * @param targetDate       基準日
     * @param busiDaysBefore   前営業日
     * @param allSourceList    当該基準日の全集計元
     * @param dfCalcResult     DF 算出結果
     * @param dfHistory        DF 履歴情報
     * @param preClosingPlList プレ引値の確定PL参照用リスト（スポット集計の共有状態）
     * @param afterDayClose    システム時刻が日締め時刻以降か（旧 nowDateYmdhms >= dayCloseTime）
     * @throws Exception DB 切断由来の例外
     */
    public void evaluate(StepContribution contribution, Date targetDate, Date busiDaysBefore,
            List<TPosSumSourceDataBean> allSourceList, List<TDfCalcResultBean> dfCalcResult,
            List<TDfHistoryDateBean> dfHistory, List<TPositionSpotSumDataBean> preClosingPlList,
            boolean afterDayClose) throws Exception {

        // スポット＝プレ引値スポット結果＋PLデルタ（存在時）
        List<TPosSumSourceDataBean> combinedSpot = new ArrayList<>(
                spotSourceLoader.loadPreClosingSpotAsSource(targetDate));
        List<TPosSumSourceDataBean> delta = spotSourceLoader.loadDeltaAsSource(targetDate);
        if (!delta.isEmpty()) {
            combinedSpot.addAll(delta);
        }

        // スワップ＝引値ウィンドウのスワップ
        List<TPosSumSourceDataBean> swap = splitter
                .splitForClosingSwap(allSourceList, targetDate, busiDaysBefore).getSwapList();

        SourcePositionSplit split = new SourcePositionSplit(combinedSpot, swap);
        PositionEvaluationResult result = evaluationService.evaluate(contribution, targetDate, split, allSourceList,
                dfCalcResult, dfHistory, EvaluationRateKbn.CLOSING_PRICE.getCode(), preClosingPlList);

        // システム時刻が日締め時刻以降の場合、引値集計結果を日締め（03）として複製・登録
        if (afterDayClose) {
            endOfDayClosingService.duplicateClosingToEndOfDay(targetDate, result);
        }
    }
}
