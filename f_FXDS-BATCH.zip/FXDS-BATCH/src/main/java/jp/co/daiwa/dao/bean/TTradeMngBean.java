package jp.co.daiwa.dao.bean;

import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TTradeMngBean}（取引管理データの検索条件）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TTradeMngBean {

    private Date tradeDatetime;
    private String note;

    public Date getTradeDatetime() {
        return tradeDatetime;
    }

    public void setTradeDatetime(Date tradeDatetime) {
        this.tradeDatetime = tradeDatetime;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
