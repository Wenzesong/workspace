package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TSwapPlSumDateRepository}（スワップ PL 合計値情報）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TSwapPlSumDateRepository {

    void delete(TSwapPlSumDateBean condition);

    void insert(List<TSwapPlSumDateBean> items);

    List<TSwapPlSumDateBean> getSwapPlSumDateList(TSwapPlSumDateBean condition);
}
