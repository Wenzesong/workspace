package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TDfitCustomerMstBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TDfitCustomerMstRepository}（DFIT 部課別顧客マスタ）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TDfitCustomerMstRepository {

    List<TDfitCustomerMstBean> getDfitCustomerMstData(TDfitCustomerMstBean condition);
}
