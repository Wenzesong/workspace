package jp.co.daiwa.jbpos1100.spot;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.jbpos1100.common.EvaluationRateNames;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;

/**
 * スポット集計（評価ポジション・Avg コスト・評価PL・確定PL・累積PL）を算出するアグリゲータ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setSpotSumDate}（健全・約680行の単一メソッド）の移植版。
 * 「ディーラブック・通貨ペア」単位で約定を時系列に走査し、<b>直前行の状態</b>（評価ポジション・
 * Avg コスト・累積PL 等）に依存して各行を算出する逐次アルゴリズムを保持する。
 * 計算式・符号・丸め（HALF_UP, scale=2／Avg コストは scale=8）・分岐・警告は変更しない。</p>
 *
 * <h2>移植時に反映した jbpos1000 側のバグ修正</h2>
 * <ul>
 *   <li>[Fixed P1] {@code BigDecimal == BigDecimal.ZERO}（参照比較）→ {@code compareTo == 0}。</li>
 *   <li>[Fixed P1] {@code x.equals(null)}（常に false／NPE）→ {@code x == null}。</li>
 * </ul>
 *
 * <p>本クラスは「計算」に専念し、ファイル出力・DB 永続化・日締め複製はオーケストレータへ委ねる。
 * 戻り値は各（ディーラブック・通貨ペア）グループの最終行（＝最終ネットポジション）のリスト。</p>
 */
public class SpotPositionAggregator {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(SpotPositionAggregator.class);
    private static final String LABEL = "スポット集計処理";
    private static final int SCALE = 2;
    private static final int AVG_SCALE = 8;
    private static final String SIGN_PLUS = "1";
    private static final String SIGN_MINUS = "2";

    private final JobWarningReporter warningReporter;

    /**
     * @param warningReporter 警告レポータ
     */
    public SpotPositionAggregator(JobWarningReporter warningReporter) {
        this.warningReporter = warningReporter;
    }

    /**
     * スポット集計を実行する。
     *
     * @param targetDate        基準日
     * @param sourceList        スポット対象の集計元データ
     * @param evaluationRateKbn 評価レート区分コード
     * @param preClosingPlList  プレ引値の確定PL参照用リスト（引値集計で参照・プレ引値/引値で追記する共有状態）
     * @return 各グループの最終行リスト
     */
    public List<TPositionSpotSumDataBean> aggregate(Date targetDate, List<TPosSumSourceDataBean> sourceList,
            String evaluationRateKbn, List<TPositionSpotSumDataBean> preClosingPlList) {

        String evaluationRateName = EvaluationRateNames.of(evaluationRateKbn);
        Map<String, List<TPosSumSourceDataBean>> groups = sourceList.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getCurrencyPair()));

        List<TPositionSpotSumDataBean> result = new ArrayList<>();
        for (Map.Entry<String, List<TPosSumSourceDataBean>> entry : groups.entrySet()) {
            String[] split = entry.getKey().split(",");
            List<TPosSumSourceDataBean> sortedList = sortForKbn(entry.getValue(), evaluationRateKbn);
            if (sortedList.isEmpty()) {
                continue;
            }
            List<TPositionSpotSumDataBean> groupRows = aggregateGroup(targetDate, split, sortedList,
                    evaluationRateKbn, evaluationRateName, preClosingPlList);
            if (groupRows.isEmpty()) {
                continue;
            }
            TPositionSpotSumDataBean last = groupRows.get(groupRows.size() - 1);
            result.add(last);
            if (isPreClosing(evaluationRateKbn) || isClosing(evaluationRateKbn)) {
                preClosingPlList.add(last);
            }
        }
        return result;
    }

    /** 評価レート区分に応じてソート（Real/プレ引値は売買金額0以外で抽出）。 */
    private List<TPosSumSourceDataBean> sortForKbn(List<TPosSumSourceDataBean> group, String evaluationRateKbn) {
        Comparator<TPosSumSourceDataBean> order = Comparator
                .comparing(TPosSumSourceDataBean::getTradeDatetime).thenComparing(TPosSumSourceDataBean::getAc);
        if (isReal(evaluationRateKbn) || isPreClosing(evaluationRateKbn)) {
            return group.stream()
                    .filter(d -> d.getDealAmount().compareTo(BigDecimal.ZERO) != 0)
                    .sorted(order).collect(Collectors.toList());
        }
        return group.stream().sorted(order).collect(Collectors.toList());
    }

    /** 1 グループ（ディーラブック・通貨ペア）を時系列走査して各行を算出する。 */
    private List<TPositionSpotSumDataBean> aggregateGroup(Date targetDate, String[] split,
            List<TPosSumSourceDataBean> sortedList, String evaluationRateKbn, String evaluationRateName,
            List<TPositionSpotSumDataBean> preClosingPlList) {

        List<TPositionSpotSumDataBean> rows = new ArrayList<>();
        TPositionSpotSumDataBean prev = null;
        for (TPosSumSourceDataBean item : sortedList) {
            TPositionSpotSumDataBean bean = new TPositionSpotSumDataBean();
            TPositionSpotSumDataBean plMatch = matchPreClosing(preClosingPlList, item, evaluationRateKbn);
            try {
                computeRow(bean, prev, item, evaluationRateKbn, evaluationRateName, plMatch);
            } catch (Exception e) {
                logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W002", LABEL,
                        "評価レート区分:" + evaluationRateName + "," + split[0] + "," + split[1], e);
                warningReporter.markJobWarning();
            }
            applyHeaderAndTotal(bean, item, targetDate, split, evaluationRateKbn, evaluationRateName);
            rows.add(bean);
            prev = bean;
        }
        return rows;
    }

    /** 引値集計時のみ、プレ引値の同一ディーラブック・通貨ペア行を取得する。 */
    private TPositionSpotSumDataBean matchPreClosing(List<TPositionSpotSumDataBean> preClosingPlList,
            TPosSumSourceDataBean item, String evaluationRateKbn) {
        if (!isClosing(evaluationRateKbn)) {
            return null;
        }
        return preClosingPlList.stream()
                .filter(d -> d.getDealerBook().equals(item.getDealerBook()))
                .filter(c -> c.getCurrencyPair().equals(item.getCurrencyPair()))
                .filter(e -> e.getEvaluationRateDivision().equals(EvaluationRateKbn.PRE_CLOSING.getCode()))
                .findFirst().orElse(null);
    }

    /** 1 行の各 PV/PL 項目を、直前行 prev に依存して算出する（旧コードの try ブロック相当）。 */
    private void computeRow(TPositionSpotSumDataBean bean, TPositionSpotSumDataBean prev, TPosSumSourceDataBean item,
            String evaluationRateKbn, String evaluationRateName, TPositionSpotSumDataBean plMatch) {

        applyAmounts(bean, item);
        applyEvaluationPosition(bean, prev, item);

        String preEva = (prev != null && prev.getEvaluationPosition().compareTo(BigDecimal.ZERO) >= 0)
                ? SIGN_PLUS : SIGN_MINUS;
        String tposEva = bean.getEvaluationPosition().compareTo(BigDecimal.ZERO) >= 0 ? SIGN_PLUS : SIGN_MINUS;

        applyAvgCostAndPending(bean, prev, item, preEva, tposEva, evaluationRateName);
        applyEvaluationPl(bean, item, evaluationRateKbn, evaluationRateName);
        applyEvaluationPlYen(bean, item, evaluationRateKbn, evaluationRateName);
        applyConfirmPosition(bean, prev, item, evaluationRateKbn, preEva, tposEva, plMatch);
        applyConfirmUnderlyingCcy(bean, prev, item, evaluationRateKbn, plMatch, evaluationRateName);
        applySumPlUnderlyingCcy(bean, prev, item, evaluationRateKbn, plMatch, evaluationRateName);
        applySumPlYenConversion(bean, prev, item, evaluationRateKbn, plMatch, evaluationRateName);
        applyBeforeEvalAndNet(bean, prev, item);
    }

    /** 売買金額・決済金額（売は符号反転）を設定。 */
    private void applyAmounts(TPositionSpotSumDataBean bean, TPosSumSourceDataBean item) {
        bean.setDealAmount(item.getDealAmount());
        if (item.getSettleAmount() == null) {
            bean.setSettleAmount(null);
        } else if (isBuy(item)) {
            bean.setSettleAmount(item.getSettleAmount());
        } else {
            bean.setSettleAmount(item.getSettleAmount().negate());
        }
    }

    /** 評価ポジション（前回±今回取引金額、初回は今回取引金額／売は反転）を設定。 */
    private void applyEvaluationPosition(TPositionSpotSumDataBean bean, TPositionSpotSumDataBean prev,
            TPosSumSourceDataBean item) {
        if (prev != null) {
            bean.setEvaluationPosition(isBuy(item)
                    ? prev.getEvaluationPosition().add(item.getDealAmount())
                    : prev.getEvaluationPosition().subtract(item.getDealAmount()));
        } else {
            bean.setEvaluationPosition(isBuy(item) ? item.getDealAmount() : item.getDealAmount().negate());
        }
    }

    /** Avg コストレート・未確定決済金額を設定（確定ポジション有無で処理順が変わる）。 */
    private void applyAvgCostAndPending(TPositionSpotSumDataBean bean, TPositionSpotSumDataBean prev,
            TPosSumSourceDataBean item, String preEva, String tposEva, String evaluationRateName) {
        if (prev != null) {
            boolean ready = prev.getPendingSettleAmount() != null && item.getSettleAmount() != null
                    && prev.getAvgCostRate() != null && item.getTradeRate() != null;
            if (!ready) {
                bean.setAvgCostRate(null);
                bean.setPendingSettleAmount(null);
                warnCalc(evaluationRateName, item, "Avgコストレートと未確定決済金額がNULLであるため、計算エラー");
                return;
            }
            if (preEva.equals(item.getDealDivision())) {
                // 確定ポジション発生しない
                bean.setPendingSettleAmount(prev.getPendingSettleAmount()
                        .add(bean.getSettleAmount()).setScale(SCALE, RoundingMode.HALF_UP));
                bean.setAvgCostRate(bean.getPendingSettleAmount()
                        .divide(bean.getEvaluationPosition(), AVG_SCALE, RoundingMode.HALF_UP));
            } else if (preEva.equals(tposEva)) {
                bean.setAvgCostRate(prev.getAvgCostRate());
                bean.setPendingSettleAmount(bean.getEvaluationPosition()
                        .multiply(prev.getAvgCostRate()).setScale(SCALE, RoundingMode.HALF_UP));
            } else {
                bean.setAvgCostRate(item.getTradeRate());
                bean.setPendingSettleAmount(bean.getEvaluationPosition()
                        .multiply(item.getTradeRate()).setScale(SCALE, RoundingMode.HALF_UP));
            }
            return;
        }
        // 初回
        if (item.getTradeRate() != null && bean.getSettleAmount() != null) {
            bean.setAvgCostRate(item.getTradeRate());
            bean.setPendingSettleAmount(isBuy(item) ? bean.getSettleAmount() : bean.getSettleAmount().negate());
        } else {
            bean.setAvgCostRate(null);
            bean.setPendingSettleAmount(null);
            warnCalc(evaluationRateName, item, "Avgコストレートと未確定決済金額がNULLであるため、計算エラー");
        }
    }

    /** 評価PL(原通貨)＝評価ポジション×(評価レート − Avg コスト)。 */
    private void applyEvaluationPl(TPositionSpotSumDataBean bean, TPosSumSourceDataBean item,
            String evaluationRateKbn, String evaluationRateName) {
        if (bean.getAvgCostRate() == null) {
            bean.setEvaluationPlUnderlyingCcy(null);
            warnCalc(evaluationRateName, item, "Avgコストレートが取得できなかったため、評価PL(原通貨)の計算エラー");
            return;
        }
        BigDecimal rate = isRealOrAfter(evaluationRateKbn) ? realEvalRate(item) : closingEvalRate(item);
        if (rate == null) {
            bean.setEvaluationPlUnderlyingCcy(null);
            warnCalc(evaluationRateName, item, evalRateMissingMessage(evaluationRateKbn, item));
            return;
        }
        bean.setEvaluationPlUnderlyingCcy(bean.getEvaluationPosition()
                .multiply(rate.subtract(bean.getAvgCostRate())).setScale(SCALE, RoundingMode.HALF_UP));
    }

    /** Real/引値以降の評価レート（マニュアル日中→ST(Real)→BBG）。 */
    private BigDecimal realEvalRate(TPosSumSourceDataBean item) {
        if (item.getManualDailyRate() != null) {
            return item.getManualDailyRate();
        }
        if (BatchConstants.RATE_SOURCE_SMART.equals(item.getRateSource())) {
            return item.getRealRate();
        }
        if (BatchConstants.RATE_SOURCE_BBG.equals(item.getRateSource())) {
            return item.getBbgRate();
        }
        return null;
    }

    /** 引値系の評価レート（マニュアル引値TTM→引値レート）。 */
    private BigDecimal closingEvalRate(TPosSumSourceDataBean item) {
        if (item.getManualClosingTtmRate() != null) {
            return item.getManualClosingTtmRate();
        }
        return item.getClosingRate();
    }

    /** 評価PL(円換算)＝評価PL(原通貨)×円転レート（決済通貨JPY は円転なし）。 */
    private void applyEvaluationPlYen(TPositionSpotSumDataBean bean, TPosSumSourceDataBean item,
            String evaluationRateKbn, String evaluationRateName) {
        if (BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency())
                || bean.getEvaluationPlUnderlyingCcy() == null) {
            bean.setEvaluationPlYenConversion(bean.getEvaluationPlUnderlyingCcy());
            return;
        }
        BigDecimal yenRate = isRealOrAfter(evaluationRateKbn) ? item.getRealYenRate() : item.getClosingYenRate();
        if (yenRate == null) {
            bean.setEvaluationPlYenConversion(null);
            warnCalc(evaluationRateName, item.getDealerBook(), item.getSettleCurrency() + "JPY",
                    (isRealOrAfter(evaluationRateKbn) ? "Real" : "引値") + "円転レートが取得できなかったため、評価PL(円換算)の計算エラー");
            return;
        }
        bean.setEvaluationPlYenConversion(bean.getEvaluationPlUnderlyingCcy()
                .multiply(yenRate).setScale(SCALE, RoundingMode.HALF_UP));
    }

    /** 確定ポジションを設定。 */
    private void applyConfirmPosition(TPositionSpotSumDataBean bean, TPositionSpotSumDataBean prev,
            TPosSumSourceDataBean item, String evaluationRateKbn, String preEva, String tposEva,
            TPositionSpotSumDataBean plMatch) {
        if (prev == null && plMatch != null && isClosing(evaluationRateKbn)) {
            bean.setConfirmPosition(plMatch.getConfirmPosition());
        } else if (prev != null) {
            if (preEva.equals(item.getDealDivision())) {
                bean.setConfirmPosition(BigDecimal.ZERO);
            } else if (preEva.equals(tposEva)) {
                bean.setConfirmPosition(prev.getEvaluationPosition().subtract(bean.getEvaluationPosition()));
            } else {
                bean.setConfirmPosition(prev.getEvaluationPosition());
            }
        } else {
            bean.setConfirmPosition(BigDecimal.ZERO);
        }
    }

    /** 確定PL(原通貨)を設定。 */
    private void applyConfirmUnderlyingCcy(TPositionSpotSumDataBean bean, TPositionSpotSumDataBean prev,
            TPosSumSourceDataBean item, String evaluationRateKbn, TPositionSpotSumDataBean plMatch,
            String evaluationRateName) {
        if (prev == null && plMatch != null && isClosing(evaluationRateKbn)) {
            bean.setConfirmUnderlyingCcy(plMatch.getConfirmUnderlyingCcy());
        } else if (prev != null) {
            // [Fixed P1] BigDecimal == 比較を compareTo に統一
            if (bean.getConfirmPosition().compareTo(BigDecimal.ZERO) == 0) {
                bean.setConfirmUnderlyingCcy(BigDecimal.ZERO);
            } else if (prev.getAvgCostRate() != null) {
                bean.setConfirmUnderlyingCcy(bean.getConfirmPosition()
                        .multiply(item.getTradeRate().subtract(prev.getAvgCostRate()))
                        .setScale(SCALE, RoundingMode.HALF_UP));
            } else {
                bean.setConfirmUnderlyingCcy(null);
                warnCalc(evaluationRateName, item, "前回Avgコストレートが取得できなかったため、確定PL(原通貨)の計算エラー");
            }
        } else {
            bean.setConfirmUnderlyingCcy(BigDecimal.ZERO);
        }
    }

    /** 累積確定PL(原通貨)を設定。 */
    private void applySumPlUnderlyingCcy(TPositionSpotSumDataBean bean, TPositionSpotSumDataBean prev,
            TPosSumSourceDataBean item, String evaluationRateKbn, TPositionSpotSumDataBean plMatch,
            String evaluationRateName) {
        if (prev == null && plMatch != null && isClosing(evaluationRateKbn)) {
            bean.setSumPlUnderlyingCcy(plMatch.getSumPlUnderlyingCcy());
            // [Fixed P1] x.equals(null) → x == null
            if (bean.getSumPlUnderlyingCcy() == null) {
                bean.setSumPlUnderlyingCcy(BigDecimal.ZERO);
            }
        } else if (prev != null) {
            // [Fixed P1] BigDecimal == 比較を compareTo に統一
            if (bean.getConfirmPosition().compareTo(BigDecimal.ZERO) == 0) {
                bean.setSumPlUnderlyingCcy(prev.getSumPlUnderlyingCcy());
            } else if (bean.getConfirmUnderlyingCcy() != null) {
                bean.setSumPlUnderlyingCcy(prev.getSumPlUnderlyingCcy().add(bean.getConfirmUnderlyingCcy()));
            } else {
                bean.setSumPlUnderlyingCcy(null);
                warnCalc(evaluationRateName, item, "今回の確定PL(原通貨)が取得できなかったため、累積確定PL(原通貨)の計算エラー");
            }
        } else {
            bean.setSumPlUnderlyingCcy(BigDecimal.ZERO);
        }
    }

    /** 累積確定PL(円換算)を設定。 */
    private void applySumPlYenConversion(TPositionSpotSumDataBean bean, TPositionSpotSumDataBean prev,
            TPosSumSourceDataBean item, String evaluationRateKbn, TPositionSpotSumDataBean plMatch,
            String evaluationRateName) {
        if (prev == null && plMatch != null && isClosing(evaluationRateKbn)) {
            if (BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency())) {
                bean.setSumPlYenConversion(plMatch.getSumPlUnderlyingCcy());
            } else if (plMatch.getClosingYenRate() != null) {
                bean.setSumPlYenConversion(plMatch.getSumPlUnderlyingCcy()
                        .multiply(plMatch.getClosingYenRate()).setScale(SCALE, RoundingMode.HALF_UP));
            } else {
                bean.setSumPlYenConversion(null);
                warnCalc(evaluationRateName, item.getDealerBook(), item.getSettleCurrency() + "JPY",
                        "引値円転レートが取得できなかったため、累積確定PL(円換算)の計算エラー");
            }
            return;
        }
        if (bean.getSumPlUnderlyingCcy() == null) {
            bean.setSumPlYenConversion(null);
            warnCalc(evaluationRateName, item, "累積確定PL(原通貨)が取得できなかったため、累積確定PL(円換算)の計算エラー");
            return;
        }
        if (BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency())) {
            bean.setSumPlYenConversion(bean.getSumPlUnderlyingCcy());
            return;
        }
        BigDecimal yenRate = isRealOrAfter(evaluationRateKbn) ? item.getRealYenRate() : item.getClosingYenRate();
        if (yenRate == null) {
            bean.setSumPlYenConversion(null);
            warnCalc(evaluationRateName, item.getDealerBook(), item.getSettleCurrency() + "JPY",
                    (isRealOrAfter(evaluationRateKbn) ? "Real" : "引値") + "円転レートが取得できなかったため、累積確定PL(円換算)の計算エラー");
            return;
        }
        bean.setSumPlYenConversion(bean.getSumPlUnderlyingCcy().multiply(yenRate).setScale(SCALE, RoundingMode.HALF_UP));
    }

    /** 前日繰越・ネット増減を設定。 */
    private void applyBeforeEvalAndNet(TPositionSpotSumDataBean bean, TPositionSpotSumDataBean prev,
            TPosSumSourceDataBean item) {
        if (prev != null) {
            bean.setBeforeEvaluationPosition(prev.getBeforeEvaluationPosition());
        } else {
            bean.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
        }
        if (bean.getBeforeEvaluationPosition() != null && bean.getEvaluationPosition() != null) {
            bean.setNetIncreaseOrDecrease(bean.getEvaluationPosition().subtract(bean.getBeforeEvaluationPosition()));
        } else {
            bean.setNetIncreaseOrDecrease(bean.getEvaluationPosition());
        }
    }

    /** ヘッダ項目とレート群・合計PL額を設定（例外時も実行される＝旧コード踏襲）。 */
    private void applyHeaderAndTotal(TPositionSpotSumDataBean bean, TPosSumSourceDataBean item, Date targetDate,
            String[] split, String evaluationRateKbn, String evaluationRateName) {
        bean.setExchangeDivision(item.getExchangeDivision());
        bean.setProcessBaseDate(targetDate);
        bean.setDealerBook(split[0]);
        bean.setEvaluationRateDivision(evaluationRateKbn);
        bean.setDealCurrency(item.getDealCurrency());
        bean.setSettleCurrency(item.getSettleCurrency());
        bean.setCurrencyPair(split[1]);
        bean.setDealDivision(item.getDealDivision());
        bean.setAc(item.getAc());
        bean.setRateSource(item.getRateSource());
        bean.setBbgRate(item.getBbgRate());
        if (BatchConstants.RATE_SOURCE_BBG.equals(item.getRateSource())) {
            bean.setRealRate(item.getBbgRate());
        } else {
            bean.setRealRate(item.getRealRate());
        }
        bean.setClosingRate(item.getClosingRate());
        bean.setManualDailyRate(item.getManualDailyRate());
        bean.setManualClosingTtmRate(item.getManualClosingTtmRate());
        bean.setRealYenRate(item.getRealYenRate());
        bean.setClosingYenRate(item.getClosingYenRate());
        if (bean.getEvaluationPlYenConversion() != null && bean.getSumPlYenConversion() != null) {
            bean.setSumPlYen(bean.getEvaluationPlYenConversion().add(bean.getSumPlYenConversion()));
        } else {
            bean.setSumPlYen(null);
            warnCalc(evaluationRateName, item, "NULLのデータが存在したため、合計PL額の計算エラー");
        }
        bean.setRegisterUser(JobConstants.Jbpos1000);
        bean.setRegisterDatetime(null);
        bean.setUpdateUser(JobConstants.Jbpos1000);
        bean.setUpdateDatetime(null);
    }

    private String evalRateMissingMessage(String evaluationRateKbn, TPosSumSourceDataBean item) {
        if (isRealOrAfter(evaluationRateKbn)) {
            if (BatchConstants.RATE_SOURCE_BBG.equals(item.getRateSource())) {
                return "BBGレートが取得できなかったため、評価PL(原通貨)の計算エラー";
            }
            return "Real評価レートが取得できなかったため、評価PL(原通貨)の計算エラー";
        }
        return "引値評価レートが取得できなかったため、評価PL(原通貨)の計算エラー";
    }

    private boolean isBuy(TPosSumSourceDataBean item) {
        return BatchConstants.DEAL_DIVISION_BUY.equals(item.getDealDivision());
    }

    private boolean isReal(String kbn) {
        return kbn.equals(EvaluationRateKbn.REAL.getCode());
    }

    private boolean isPreClosing(String kbn) {
        return kbn.equals(EvaluationRateKbn.PRE_CLOSING.getCode());
    }

    private boolean isClosing(String kbn) {
        return kbn.equals(EvaluationRateKbn.CLOSING_PRICE.getCode());
    }

    private boolean isRealOrAfter(String kbn) {
        return kbn.equals(EvaluationRateKbn.REAL.getCode())
                || kbn.equals(EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode());
    }

    private void warnCalc(String evaluationRateName, TPosSumSourceDataBean item, String reason) {
        warnCalc(evaluationRateName, item.getDealerBook(), item.getCurrencyPair(), reason);
    }

    private void warnCalc(String evaluationRateName, String dealerBook, String pairOrCcy, String reason) {
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", LABEL,
                "評価レート区分:" + evaluationRateName + "," + dealerBook + "," + pairOrCcy + ":" + reason);
    }
}
