package jp.co.daiwa.dto;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code jp.co.daiwa.dto.PosBaseRateDto}（ベースレート/ST）。
 * jbpos1100 が参照するアクセサのみ定義（レートは文字列で保持し利用側で BigDecimal 化）。
 */
public class PosBaseRateDto {

    private String currencyPair;
    private String mdEntrySize;
    private String bidRate;
    private String askRate;

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getMdEntrySize() {
        return mdEntrySize;
    }

    public void setMdEntrySize(String mdEntrySize) {
        this.mdEntrySize = mdEntrySize;
    }

    public String getBidRate() {
        return bidRate;
    }

    public void setBidRate(String bidRate) {
        this.bidRate = bidRate;
    }

    public String getAskRate() {
        return askRate;
    }

    public void setAskRate(String askRate) {
        this.askRate = askRate;
    }
}
