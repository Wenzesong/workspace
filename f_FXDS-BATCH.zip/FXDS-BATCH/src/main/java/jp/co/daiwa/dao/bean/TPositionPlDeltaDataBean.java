package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPositionPlDeltaDataBean}
 * （決済通貨外貨 PL デルタ生成情報）。jbpos1100 が参照するアクセサのみ定義。
 */
public class TPositionPlDeltaDataBean {

    private Date processBaseDate;
    private String dealerBook;
    private String ac;
    private String dealCurrency;
    private String settleCurrency;
    private String currencyPair;
    private String exchangeDivision;
    private String dealDivision;
    private BigDecimal dealAmount;
    private BigDecimal tradeRate;
    private BigDecimal settleAmount;
    private BigDecimal closingRate;
    private BigDecimal manualClosingTtmRate;
    private BigDecimal closingYenRate;
    private String registerUser;
    private Timestamp registerDatetime;
    private String updateUser;
    private Timestamp updateDatetime;

    public Date getProcessBaseDate() {
        return processBaseDate;
    }

    public void setProcessBaseDate(Date processBaseDate) {
        this.processBaseDate = processBaseDate;
    }

    public String getDealerBook() {
        return dealerBook;
    }

    public void setDealerBook(String dealerBook) {
        this.dealerBook = dealerBook;
    }

    public String getAc() {
        return ac;
    }

    public void setAc(String ac) {
        this.ac = ac;
    }

    public String getDealCurrency() {
        return dealCurrency;
    }

    public void setDealCurrency(String dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    public String getSettleCurrency() {
        return settleCurrency;
    }

    public void setSettleCurrency(String settleCurrency) {
        this.settleCurrency = settleCurrency;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getExchangeDivision() {
        return exchangeDivision;
    }

    public void setExchangeDivision(String exchangeDivision) {
        this.exchangeDivision = exchangeDivision;
    }

    public String getDealDivision() {
        return dealDivision;
    }

    public void setDealDivision(String dealDivision) {
        this.dealDivision = dealDivision;
    }

    public BigDecimal getDealAmount() {
        return dealAmount;
    }

    public void setDealAmount(BigDecimal dealAmount) {
        this.dealAmount = dealAmount;
    }

    public BigDecimal getTradeRate() {
        return tradeRate;
    }

    public void setTradeRate(BigDecimal tradeRate) {
        this.tradeRate = tradeRate;
    }

    public BigDecimal getSettleAmount() {
        return settleAmount;
    }

    public void setSettleAmount(BigDecimal settleAmount) {
        this.settleAmount = settleAmount;
    }

    public BigDecimal getClosingRate() {
        return closingRate;
    }

    public void setClosingRate(BigDecimal closingRate) {
        this.closingRate = closingRate;
    }

    public BigDecimal getManualClosingTtmRate() {
        return manualClosingTtmRate;
    }

    public void setManualClosingTtmRate(BigDecimal manualClosingTtmRate) {
        this.manualClosingTtmRate = manualClosingTtmRate;
    }

    public BigDecimal getClosingYenRate() {
        return closingYenRate;
    }

    public void setClosingYenRate(BigDecimal closingYenRate) {
        this.closingYenRate = closingYenRate;
    }

    public String getRegisterUser() {
        return registerUser;
    }

    public void setRegisterUser(String registerUser) {
        this.registerUser = registerUser;
    }

    public Timestamp getRegisterDatetime() {
        return registerDatetime;
    }

    public void setRegisterDatetime(Timestamp registerDatetime) {
        this.registerDatetime = registerDatetime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Timestamp getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(Timestamp updateDatetime) {
        this.updateDatetime = updateDatetime;
    }
}
