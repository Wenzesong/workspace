package jp.co.daiwa.jbpos1100.common;

import java.util.List;

/**
 * 一括 INSERT 操作を表す関数型インタフェース。
 *
 * <p>{@link TransactionalBatchExecutor#bulkInsertWithRetry} に
 * 「リストを受け取って INSERT する処理」だけを渡せるようにする
 * （例: {@code list -> repository.insert(list)}）。</p>
 *
 * @param <T> 登録対象 Bean の型
 */
@FunctionalInterface
public interface BatchInsert<T> {

    /**
     * 指定リストを一括 INSERT する。
     *
     * @param items 登録対象リスト
     * @throws Exception DB アクセス等で発生する任意の例外
     */
    void insert(List<T> items) throws Exception;
}
