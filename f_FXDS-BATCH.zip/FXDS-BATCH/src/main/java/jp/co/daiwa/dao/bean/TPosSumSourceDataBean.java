package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPosSumSourceDataBean}（ポジション集計元情報）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TPosSumSourceDataBean {

    private BigDecimal seqNo;
    private Date processBaseDate;
    private Date tradeDatetime;
    private String dealerBook;
    private String inputDataSource;
    private String ac;
    private String dealCurrency;
    private String settleCurrency;
    private String currencyPair;
    private String exchangeDivision;
    private Date deliveryDate;
    private String dealDivision;
    private BigDecimal dealAmount;
    private BigDecimal tradeRate;
    private BigDecimal settleAmount;
    private String evaluationRateDivision;
    private BigDecimal realRate;
    private BigDecimal closingRate;
    private BigDecimal manualDailyRate;
    private BigDecimal manualClosingTtmRate;
    private String rateSource;
    private BigDecimal bbgRate;
    private BigDecimal realYenRate;
    private BigDecimal closingYenRate;
    private BigDecimal beforeEvaluationPosition;
    private BigDecimal beforeTradeAmountPvCls;
    private BigDecimal beforeTradeAmountPvClsYen;
    private String registerUser;
    private Timestamp registerDatetime;
    private String updateUser;
    private Timestamp updateDatetime;

    public BigDecimal getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(BigDecimal seqNo) {
        this.seqNo = seqNo;
    }

    public Date getProcessBaseDate() {
        return processBaseDate;
    }

    public void setProcessBaseDate(Date processBaseDate) {
        this.processBaseDate = processBaseDate;
    }

    public Date getTradeDatetime() {
        return tradeDatetime;
    }

    public void setTradeDatetime(Date tradeDatetime) {
        this.tradeDatetime = tradeDatetime;
    }

    public String getDealerBook() {
        return dealerBook;
    }

    public void setDealerBook(String dealerBook) {
        this.dealerBook = dealerBook;
    }

    public String getInputDataSource() {
        return inputDataSource;
    }

    public void setInputDataSource(String inputDataSource) {
        this.inputDataSource = inputDataSource;
    }

    public String getAc() {
        return ac;
    }

    public void setAc(String ac) {
        this.ac = ac;
    }

    public String getDealCurrency() {
        return dealCurrency;
    }

    public void setDealCurrency(String dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    public String getSettleCurrency() {
        return settleCurrency;
    }

    public void setSettleCurrency(String settleCurrency) {
        this.settleCurrency = settleCurrency;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getExchangeDivision() {
        return exchangeDivision;
    }

    public void setExchangeDivision(String exchangeDivision) {
        this.exchangeDivision = exchangeDivision;
    }

    public Date getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getDealDivision() {
        return dealDivision;
    }

    public void setDealDivision(String dealDivision) {
        this.dealDivision = dealDivision;
    }

    public BigDecimal getDealAmount() {
        return dealAmount;
    }

    public void setDealAmount(BigDecimal dealAmount) {
        this.dealAmount = dealAmount;
    }

    public BigDecimal getTradeRate() {
        return tradeRate;
    }

    public void setTradeRate(BigDecimal tradeRate) {
        this.tradeRate = tradeRate;
    }

    public BigDecimal getSettleAmount() {
        return settleAmount;
    }

    public void setSettleAmount(BigDecimal settleAmount) {
        this.settleAmount = settleAmount;
    }

    public String getEvaluationRateDivision() {
        return evaluationRateDivision;
    }

    public void setEvaluationRateDivision(String evaluationRateDivision) {
        this.evaluationRateDivision = evaluationRateDivision;
    }

    public BigDecimal getRealRate() {
        return realRate;
    }

    public void setRealRate(BigDecimal realRate) {
        this.realRate = realRate;
    }

    public BigDecimal getClosingRate() {
        return closingRate;
    }

    public void setClosingRate(BigDecimal closingRate) {
        this.closingRate = closingRate;
    }

    public BigDecimal getManualDailyRate() {
        return manualDailyRate;
    }

    public void setManualDailyRate(BigDecimal manualDailyRate) {
        this.manualDailyRate = manualDailyRate;
    }

    public BigDecimal getManualClosingTtmRate() {
        return manualClosingTtmRate;
    }

    public void setManualClosingTtmRate(BigDecimal manualClosingTtmRate) {
        this.manualClosingTtmRate = manualClosingTtmRate;
    }

    public String getRateSource() {
        return rateSource;
    }

    public void setRateSource(String rateSource) {
        this.rateSource = rateSource;
    }

    public BigDecimal getBbgRate() {
        return bbgRate;
    }

    public void setBbgRate(BigDecimal bbgRate) {
        this.bbgRate = bbgRate;
    }

    public BigDecimal getRealYenRate() {
        return realYenRate;
    }

    public void setRealYenRate(BigDecimal realYenRate) {
        this.realYenRate = realYenRate;
    }

    public BigDecimal getClosingYenRate() {
        return closingYenRate;
    }

    public void setClosingYenRate(BigDecimal closingYenRate) {
        this.closingYenRate = closingYenRate;
    }

    public BigDecimal getBeforeEvaluationPosition() {
        return beforeEvaluationPosition;
    }

    public void setBeforeEvaluationPosition(BigDecimal beforeEvaluationPosition) {
        this.beforeEvaluationPosition = beforeEvaluationPosition;
    }

    public BigDecimal getBeforeTradeAmountPvCls() {
        return beforeTradeAmountPvCls;
    }

    public void setBeforeTradeAmountPvCls(BigDecimal beforeTradeAmountPvCls) {
        this.beforeTradeAmountPvCls = beforeTradeAmountPvCls;
    }

    public BigDecimal getBeforeTradeAmountPvClsYen() {
        return beforeTradeAmountPvClsYen;
    }

    public void setBeforeTradeAmountPvClsYen(BigDecimal beforeTradeAmountPvClsYen) {
        this.beforeTradeAmountPvClsYen = beforeTradeAmountPvClsYen;
    }

    public String getRegisterUser() {
        return registerUser;
    }

    public void setRegisterUser(String registerUser) {
        this.registerUser = registerUser;
    }

    public Timestamp getRegisterDatetime() {
        return registerDatetime;
    }

    public void setRegisterDatetime(Timestamp registerDatetime) {
        this.registerDatetime = registerDatetime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Timestamp getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(Timestamp updateDatetime) {
        this.updateDatetime = updateDatetime;
    }
}
