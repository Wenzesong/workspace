package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPositionSpotSumDataBean}（ポジションスポット集計結果）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TPositionSpotSumDataBean {

    private Date processBaseDate;
    private String dealerBook;
    private String evaluationRateDivision;
    private String dealCurrency;
    private String settleCurrency;
    private String currencyPair;
    private String exchangeDivision;
    private BigDecimal dealAmount;
    private BigDecimal settleAmount;
    private String ac;
    private String dealDivision;
    private String rateSource;
    private BigDecimal bbgRate;
    private BigDecimal realRate;
    private BigDecimal closingRate;
    private BigDecimal avgCostRate;
    private BigDecimal manualDailyRate;
    private BigDecimal manualClosingTtmRate;
    private BigDecimal realYenRate;
    private BigDecimal closingYenRate;
    private BigDecimal evaluationPosition;
    private BigDecimal evaluationPlUnderlyingCcy;
    private BigDecimal evaluationPlYenConversion;
    private BigDecimal pendingSettleAmount;
    private BigDecimal confirmPosition;
    private BigDecimal confirmUnderlyingCcy;
    private BigDecimal sumPlUnderlyingCcy;
    private BigDecimal sumPlYenConversion;
    private BigDecimal sumPlYen;
    private BigDecimal beforeEvaluationPosition;
    private BigDecimal netIncreaseOrDecrease;
    private String registerUser;
    private Timestamp registerDatetime;
    private String updateUser;
    private Timestamp updateDatetime;

    public Date getProcessBaseDate() {
        return processBaseDate;
    }

    public void setProcessBaseDate(Date processBaseDate) {
        this.processBaseDate = processBaseDate;
    }

    public String getDealerBook() {
        return dealerBook;
    }

    public void setDealerBook(String dealerBook) {
        this.dealerBook = dealerBook;
    }

    public String getEvaluationRateDivision() {
        return evaluationRateDivision;
    }

    public void setEvaluationRateDivision(String evaluationRateDivision) {
        this.evaluationRateDivision = evaluationRateDivision;
    }

    public String getDealCurrency() {
        return dealCurrency;
    }

    public void setDealCurrency(String dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    public String getSettleCurrency() {
        return settleCurrency;
    }

    public void setSettleCurrency(String settleCurrency) {
        this.settleCurrency = settleCurrency;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getExchangeDivision() {
        return exchangeDivision;
    }

    public void setExchangeDivision(String exchangeDivision) {
        this.exchangeDivision = exchangeDivision;
    }

    public BigDecimal getDealAmount() {
        return dealAmount;
    }

    public void setDealAmount(BigDecimal dealAmount) {
        this.dealAmount = dealAmount;
    }

    public BigDecimal getSettleAmount() {
        return settleAmount;
    }

    public void setSettleAmount(BigDecimal settleAmount) {
        this.settleAmount = settleAmount;
    }

    public String getAc() {
        return ac;
    }

    public void setAc(String ac) {
        this.ac = ac;
    }

    public String getDealDivision() {
        return dealDivision;
    }

    public void setDealDivision(String dealDivision) {
        this.dealDivision = dealDivision;
    }

    public String getRateSource() {
        return rateSource;
    }

    public void setRateSource(String rateSource) {
        this.rateSource = rateSource;
    }

    public BigDecimal getBbgRate() {
        return bbgRate;
    }

    public void setBbgRate(BigDecimal bbgRate) {
        this.bbgRate = bbgRate;
    }

    public BigDecimal getRealRate() {
        return realRate;
    }

    public void setRealRate(BigDecimal realRate) {
        this.realRate = realRate;
    }

    public BigDecimal getClosingRate() {
        return closingRate;
    }

    public void setClosingRate(BigDecimal closingRate) {
        this.closingRate = closingRate;
    }

    public BigDecimal getAvgCostRate() {
        return avgCostRate;
    }

    public void setAvgCostRate(BigDecimal avgCostRate) {
        this.avgCostRate = avgCostRate;
    }

    public BigDecimal getManualDailyRate() {
        return manualDailyRate;
    }

    public void setManualDailyRate(BigDecimal manualDailyRate) {
        this.manualDailyRate = manualDailyRate;
    }

    public BigDecimal getManualClosingTtmRate() {
        return manualClosingTtmRate;
    }

    public void setManualClosingTtmRate(BigDecimal manualClosingTtmRate) {
        this.manualClosingTtmRate = manualClosingTtmRate;
    }

    public BigDecimal getRealYenRate() {
        return realYenRate;
    }

    public void setRealYenRate(BigDecimal realYenRate) {
        this.realYenRate = realYenRate;
    }

    public BigDecimal getClosingYenRate() {
        return closingYenRate;
    }

    public void setClosingYenRate(BigDecimal closingYenRate) {
        this.closingYenRate = closingYenRate;
    }

    public BigDecimal getEvaluationPosition() {
        return evaluationPosition;
    }

    public void setEvaluationPosition(BigDecimal evaluationPosition) {
        this.evaluationPosition = evaluationPosition;
    }

    public BigDecimal getEvaluationPlUnderlyingCcy() {
        return evaluationPlUnderlyingCcy;
    }

    public void setEvaluationPlUnderlyingCcy(BigDecimal evaluationPlUnderlyingCcy) {
        this.evaluationPlUnderlyingCcy = evaluationPlUnderlyingCcy;
    }

    public BigDecimal getEvaluationPlYenConversion() {
        return evaluationPlYenConversion;
    }

    public void setEvaluationPlYenConversion(BigDecimal evaluationPlYenConversion) {
        this.evaluationPlYenConversion = evaluationPlYenConversion;
    }

    public BigDecimal getPendingSettleAmount() {
        return pendingSettleAmount;
    }

    public void setPendingSettleAmount(BigDecimal pendingSettleAmount) {
        this.pendingSettleAmount = pendingSettleAmount;
    }

    public BigDecimal getConfirmPosition() {
        return confirmPosition;
    }

    public void setConfirmPosition(BigDecimal confirmPosition) {
        this.confirmPosition = confirmPosition;
    }

    public BigDecimal getConfirmUnderlyingCcy() {
        return confirmUnderlyingCcy;
    }

    public void setConfirmUnderlyingCcy(BigDecimal confirmUnderlyingCcy) {
        this.confirmUnderlyingCcy = confirmUnderlyingCcy;
    }

    public BigDecimal getSumPlUnderlyingCcy() {
        return sumPlUnderlyingCcy;
    }

    public void setSumPlUnderlyingCcy(BigDecimal sumPlUnderlyingCcy) {
        this.sumPlUnderlyingCcy = sumPlUnderlyingCcy;
    }

    public BigDecimal getSumPlYenConversion() {
        return sumPlYenConversion;
    }

    public void setSumPlYenConversion(BigDecimal sumPlYenConversion) {
        this.sumPlYenConversion = sumPlYenConversion;
    }

    public BigDecimal getSumPlYen() {
        return sumPlYen;
    }

    public void setSumPlYen(BigDecimal sumPlYen) {
        this.sumPlYen = sumPlYen;
    }

    public BigDecimal getBeforeEvaluationPosition() {
        return beforeEvaluationPosition;
    }

    public void setBeforeEvaluationPosition(BigDecimal beforeEvaluationPosition) {
        this.beforeEvaluationPosition = beforeEvaluationPosition;
    }

    public BigDecimal getNetIncreaseOrDecrease() {
        return netIncreaseOrDecrease;
    }

    public void setNetIncreaseOrDecrease(BigDecimal netIncreaseOrDecrease) {
        this.netIncreaseOrDecrease = netIncreaseOrDecrease;
    }

    public String getRegisterUser() {
        return registerUser;
    }

    public void setRegisterUser(String registerUser) {
        this.registerUser = registerUser;
    }

    public Timestamp getRegisterDatetime() {
        return registerDatetime;
    }

    public void setRegisterDatetime(Timestamp registerDatetime) {
        this.registerDatetime = registerDatetime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Timestamp getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(Timestamp updateDatetime) {
        this.updateDatetime = updateDatetime;
    }
}
