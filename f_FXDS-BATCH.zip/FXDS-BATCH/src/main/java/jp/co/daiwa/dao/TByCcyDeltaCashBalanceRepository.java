package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TByCcyDeltaCashBalanceRepository}。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TByCcyDeltaCashBalanceRepository {

    void delete(TByCcyDeltaCashBalanceBean condition);

    void insert(List<TByCcyDeltaCashBalanceBean> items);

    List<TByCcyDeltaCashBalanceBean> getByCcyDeltaCashBalanceList(TByCcyDeltaCashBalanceBean condition);
}
