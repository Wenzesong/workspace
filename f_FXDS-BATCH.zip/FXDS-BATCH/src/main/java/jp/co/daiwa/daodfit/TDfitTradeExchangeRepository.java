package jp.co.daiwa.daodfit;

import java.util.Date;
import java.util.List;

import jp.co.daiwa.dao.bean.TDfitTradeExchangeBean;
import jp.co.daiwa.dto.PosSumSourceDto;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code jp.co.daiwa.daodfit.TDfitTradeExchangeRepository}
 * （DFIT 為替トレードデータ）。jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TDfitTradeExchangeRepository {

    /** ポジション集計元フォーマット（DTO）での DFIT 為替トレードデータ取得。 */
    List<PosSumSourceDto> getTDfitTradeExchange(String previousBusinessDate);

    /**
     * 突合用の DFIT 為替トレードデータ（生 Bean）取得。
     * 旧 {@code Jbpos1000PosSumTasklet#init} の
     * {@code dbOperation.getDfitTradeExchangeFxdsData(STATUS_LIST, busiDaysBefore)} に対応。
     * 取得 SQL は実 DAO（MyBatis マッパー）側に存在する。
     */
    List<TDfitTradeExchangeBean> getDfitTradeExchangeFxdsData(List<String> statusList, Date previousBusinessDate);

    List<TDfitTradeExchangeBean> getFxdsDataByCond(String fxds, List<String> statusList, TDfitTradeExchangeBean bean);

}
