package jp.co.daiwa.jbpos1100.delta;

import java.util.List;

import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.jbpos1100.common.TransactionalBatchExecutor;

/**
 * 通貨別デルタ・キャッシュ残情報テーブルの永続化（中間コミット）クラス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#byCcyDeltaCashDataDelete} / insert（一括＋1 件リトライ）を
 * {@link TransactionalBatchExecutor} へ委譲したもの。</p>
 */
public class CurrencyDeltaCashStore {

    private static final String LABEL_DELETE = "通貨別デルタ・キャッシュ残情報削除処理";
    private static final String LABEL_INSERT = "通貨別デルタ・キャッシュ残情報登録処理";

    private final TByCcyDeltaCashBalanceRepository repository;
    private final TransactionalBatchExecutor executor;
    private final int bulkInsertUnit;

    public CurrencyDeltaCashStore(TByCcyDeltaCashBalanceRepository repository, TransactionalBatchExecutor executor,
            int bulkInsertUnit) {
        this.repository = repository;
        this.executor = executor;
        this.bulkInsertUnit = bulkInsertUnit;
    }

    public void delete(TByCcyDeltaCashBalanceBean condition) throws Exception {
        executor.runInNewTransaction(LABEL_DELETE, () -> repository.delete(condition));
    }

    public void insert(List<TByCcyDeltaCashBalanceBean> items) throws Exception {
        executor.bulkInsertWithRetry(LABEL_INSERT, items, bulkInsertUnit, repository::insert);
    }
}
