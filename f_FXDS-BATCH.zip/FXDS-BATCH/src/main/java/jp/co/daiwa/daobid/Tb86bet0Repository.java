package jp.co.daiwa.daobid;

import jp.co.daiwa.dao.bean.TB86BET0Bean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code jp.co.daiwa.daobid.Tb86bet0Repository}（営業日マスタ）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface Tb86bet0Repository {

    TB86BET0Bean getBusinessDay(TB86BET0Bean condition);

    TB86BET0Bean getLastBusinessDay(TB86BET0Bean condition);

    TB86BET0Bean getWorkingDayPlus(String baseYmd, int offset);
}
