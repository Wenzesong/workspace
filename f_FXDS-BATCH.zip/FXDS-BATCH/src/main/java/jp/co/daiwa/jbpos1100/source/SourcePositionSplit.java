package jp.co.daiwa.jbpos1100.source;

import java.util.List;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;

/**
 * 集計元データをスポット／スワップに振り分けた結果の不変ホルダ。
 */
public final class SourcePositionSplit {

    private final List<TPosSumSourceDataBean> spotList;
    private final List<TPosSumSourceDataBean> swapList;

    /**
     * @param spotList スポット対象
     * @param swapList スワップ対象
     */
    public SourcePositionSplit(List<TPosSumSourceDataBean> spotList, List<TPosSumSourceDataBean> swapList) {
        this.spotList = spotList;
        this.swapList = swapList;
    }

    public List<TPosSumSourceDataBean> getSpotList() {
        return spotList;
    }

    public List<TPosSumSourceDataBean> getSwapList() {
        return swapList;
    }
}
