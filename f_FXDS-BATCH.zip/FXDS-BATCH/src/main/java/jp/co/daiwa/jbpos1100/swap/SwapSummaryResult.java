package jp.co.daiwa.jbpos1100.swap;

import java.util.List;

import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;

/**
 * スワップ集計（1 評価レート区分）の計算結果をまとめた不変ホルダ。
 *
 * <p>旧 {@code mkPositionSwapSumData} が逐次変数で保持していた 3 つの成果物
 * （通貨単位纏め結果・通貨別デルタ／キャッシュ残・スワップPL合計）を 1 つにまとめ、
 * ファイル出力や永続化へまとめて渡せるようにする。</p>
 */
public final class SwapSummaryResult {

    private final List<TPositionSwapSumDataBean> currencySumList;
    private final List<TByCcyDeltaCashBalanceBean> deltaCashList;
    private final List<TSwapPlSumDateBean> plSumList;

    /**
     * @param currencySumList 通貨単位纏め済みスワップ集計
     * @param deltaCashList   通貨別デルタ・キャッシュ残情報
     * @param plSumList       スワップPL合計値情報
     */
    public SwapSummaryResult(List<TPositionSwapSumDataBean> currencySumList,
            List<TByCcyDeltaCashBalanceBean> deltaCashList, List<TSwapPlSumDateBean> plSumList) {
        this.currencySumList = currencySumList;
        this.deltaCashList = deltaCashList;
        this.plSumList = plSumList;
    }

    public List<TPositionSwapSumDataBean> getCurrencySumList() {
        return currencySumList;
    }

    public List<TByCcyDeltaCashBalanceBean> getDeltaCashList() {
        return deltaCashList;
    }

    public List<TSwapPlSumDateBean> getPlSumList() {
        return plSumList;
    }
}
