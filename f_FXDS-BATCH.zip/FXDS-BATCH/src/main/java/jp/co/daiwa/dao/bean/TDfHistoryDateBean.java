package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TDfHistoryDateBean}（DF 履歴情報）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TDfHistoryDateBean {

    private Date baseDate;
    private String currency;
    private Date gridDate;
    private BigDecimal discountFactor;

    public Date getBaseDate() {
        return baseDate;
    }

    public void setBaseDate(Date baseDate) {
        this.baseDate = baseDate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Date getGridDate() {
        return gridDate;
    }

    public void setGridDate(Date gridDate) {
        this.gridDate = gridDate;
    }

    public BigDecimal getDiscountFactor() {
        return discountFactor;
    }

    public void setDiscountFactor(BigDecimal discountFactor) {
        this.discountFactor = discountFactor;
    }
}
