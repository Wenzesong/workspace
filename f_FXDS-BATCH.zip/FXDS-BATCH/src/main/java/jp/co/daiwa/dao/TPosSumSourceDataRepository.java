package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPosSumSourceDataRepository}（ポジション集計元情報）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TPosSumSourceDataRepository {

    void delete(TPosSumSourceDataBean condition);

    void insert(List<TPosSumSourceDataBean> items);

    void update(List<TPosSumSourceDataBean> items);

    List<TPosSumSourceDataBean> getPosSumSourceDataAll(TPosSumSourceDataBean condition);

    List<TPosSumSourceDataBean> getPosSumSourceData();

}
