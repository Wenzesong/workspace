package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPositionSpotSumDataRepository}（スポット集計結果）。
 * jbpos1100 が呼び出すメソッドのみ定義（取得メソッド名の "geT" は旧コードの綴りを踏襲）。
 */
public interface TPositionSpotSumDataRepository {

    void delete(TPositionSpotSumDataBean condition);

    void insert(List<TPositionSpotSumDataBean> items);

    List<TPositionSpotSumDataBean> geTPositionSpotSumDataBeanAll(TPositionSpotSumDataBean condition);
}
