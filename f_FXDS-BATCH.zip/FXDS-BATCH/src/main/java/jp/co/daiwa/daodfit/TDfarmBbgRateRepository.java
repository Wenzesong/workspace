package jp.co.daiwa.daodfit;

import java.util.List;

import jp.co.daiwa.dao.bean.TDfarmBbgRateBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code jp.co.daiwa.daodfit.TDfarmBbgRateRepository}
 * （BBG レート情報）。旧 {@code Jbpos1000PosSumTasklet#getDfarmBbgRateBean} が
 * {@code getTDfarmBbgRateBeanAll(bean)} を呼ぶため定義。
 */
public interface TDfarmBbgRateRepository {

    List<TDfarmBbgRateBean> getTDfarmBbgRateBeanAll(TDfarmBbgRateBean condition);
}
