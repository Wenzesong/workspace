package jp.co.daiwa.jbpos1100.rate;

import java.util.List;

import jp.co.daiwa.dao.bean.TCurrencyMstBean;
import jp.co.daiwa.dao.bean.TDfarmBbgRateBean;
import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.dto.PosBaseRateDto;

/**
 * ポジション集計元のレート割当に必要な照会データ一式をまとめた不変ホルダ。
 *
 * <p>旧 {@code posSumSourceDataMapping} はメソッド内でベースレート・引値レート・通貨マスタ等を
 * 個別に取得していたが、移植版ではこれらを 1 つのコンテキストにまとめてマッパーへ渡し、
 * マッパーをデータ取得から切り離してテスト容易にする。</p>
 */
public final class RateLookupContext {

    private final String baseDate;
    private final List<PosBaseRateDto> baseRateList;
    private final List<CloseRateDto> closeRateList;
    private final List<TCurrencyMstBean> currencyMstList;
    private final List<TCurrencyMstBean> jpySettleCurrencyMstList;
    private final List<TPosSumManualRateBean> manualRateList;
    private final List<TDfarmBbgRateBean> bbgRateList;

    /**
     * @param baseDate                 基準日（yyyy/MM/dd）
     * @param baseRateList             ベースレート（ST）情報
     * @param closeRateList            引値レートファイル情報
     * @param currencyMstList          通貨マスタ
     * @param jpySettleCurrencyMstList 決済通貨=JPY の通貨マスタ
     * @param manualRateList           マニュアルレート情報
     * @param bbgRateList              BBG レート情報
     */
    public RateLookupContext(String baseDate, List<PosBaseRateDto> baseRateList, List<CloseRateDto> closeRateList,
            List<TCurrencyMstBean> currencyMstList, List<TCurrencyMstBean> jpySettleCurrencyMstList,
            List<TPosSumManualRateBean> manualRateList, List<TDfarmBbgRateBean> bbgRateList) {
        this.baseDate = baseDate;
        this.baseRateList = baseRateList;
        this.closeRateList = closeRateList;
        this.currencyMstList = currencyMstList;
        this.jpySettleCurrencyMstList = jpySettleCurrencyMstList;
        this.manualRateList = manualRateList;
        this.bbgRateList = bbgRateList;
    }

    public String getBaseDate() {
        return baseDate;
    }

    public List<PosBaseRateDto> getBaseRateList() {
        return baseRateList;
    }

    public List<CloseRateDto> getCloseRateList() {
        return closeRateList;
    }

    public List<TCurrencyMstBean> getCurrencyMstList() {
        return currencyMstList;
    }

    public List<TCurrencyMstBean> getJpySettleCurrencyMstList() {
        return jpySettleCurrencyMstList;
    }

    public List<TPosSumManualRateBean> getManualRateList() {
        return manualRateList;
    }

    public List<TDfarmBbgRateBean> getBbgRateList() {
        return bbgRateList;
    }
}
