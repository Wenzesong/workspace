package jp.co.daiwa.dao.bean;

import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TCurrencyMstBean}（通貨マスタ）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TCurrencyMstBean {

    private String dealCurrency;
    private String settleCurrency;
    private String rateSource;
    private Date spotDate;

    public String getDealCurrency() {
        return dealCurrency;
    }

    public void setDealCurrency(String dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    public String getSettleCurrency() {
        return settleCurrency;
    }

    public void setSettleCurrency(String settleCurrency) {
        this.settleCurrency = settleCurrency;
    }

    public String getRateSource() {
        return rateSource;
    }

    public void setRateSource(String rateSource) {
        this.rateSource = rateSource;
    }

    public Date getSpotDate() {
        return spotDate;
    }

    public void setSpotDate(Date spotDate) {
        this.spotDate = spotDate;
    }
}
