package jp.co.daiwa.jbpos1100.spot;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.common.BatchConstants;

/**
 * 引値以降集計向け：スポットの引値集計結果を、コスト持ち替えのうえ集計元情報へ変換するクラス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setSpotCloseSumCostReplace} の移植版。
 * 引値時点の評価ポジションを売買金額（絶対値）とし、マニュアル(引値TTM)＞引値レートの優先で
 * 取引レートを決定、決済金額＝売買金額×取引レートとして再構成する。計算式・符号は変更しない。</p>
 */
public class SpotCloseCostReplacer {

    /**
     * スポット引値集計結果をコスト持ち替えして集計元情報へ変換する。
     *
     * @param spotCloseSumList スポット引値集計結果
     * @param targetDate       基準日
     * @return 集計元情報リスト
     */
    public List<TPosSumSourceDataBean> replace(List<TPositionSpotSumDataBean> spotCloseSumList, Date targetDate) {
        List<TPosSumSourceDataBean> result = new ArrayList<>();
        for (TPositionSpotSumDataBean item : spotCloseSumList) {
            result.add(toSourceBean(item, targetDate));
        }
        return result;
    }

    private TPosSumSourceDataBean toSourceBean(TPositionSpotSumDataBean item, Date targetDate) {
        TPosSumSourceDataBean pos = new TPosSumSourceDataBean();
        pos.setProcessBaseDate(targetDate);
        pos.setDealerBook(item.getDealerBook());
        pos.setTradeDatetime(new Timestamp(targetDate.getTime()));
        pos.setAc(BatchConstants.AC_FLAG_IN_TIME);
        pos.setDealCurrency(item.getDealCurrency());
        pos.setSettleCurrency(item.getSettleCurrency());
        pos.setCurrencyPair(item.getCurrencyPair());
        pos.setExchangeDivision(item.getExchangeDivision());

        // 売買区分（評価ポジションの符号）
        pos.setDealDivision(item.getEvaluationPosition().compareTo(BigDecimal.ZERO) >= 0
                ? BatchConstants.DEAL_DIVISION_BUY : BatchConstants.DEAL_DIVISION_SELL);
        // 売買金額（評価ポジションの絶対値）
        pos.setDealAmount(item.getEvaluationPosition().abs());

        // 取引レート（マニュアル引値TTM 優先、なければ引値レート）
        BigDecimal tradeRate = item.getManualClosingTtmRate() != null
                ? item.getManualClosingTtmRate() : item.getClosingRate();
        pos.setTradeRate(tradeRate);
        // 決済金額（売買金額×取引レート、レートなしは null）
        pos.setSettleAmount(tradeRate != null ? pos.getDealAmount().multiply(tradeRate) : null);

        pos.setEvaluationRateDivision(item.getEvaluationRateDivision());
        pos.setRealRate(item.getRealRate());
        pos.setClosingRate(item.getClosingRate());
        pos.setManualDailyRate(item.getManualDailyRate());
        pos.setManualClosingTtmRate(item.getManualClosingTtmRate());
        pos.setRateSource(item.getRateSource());
        pos.setBbgRate(item.getBbgRate());
        pos.setRealYenRate(item.getRealYenRate());
        pos.setClosingYenRate(item.getClosingYenRate());
        pos.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
        return pos;
    }
}
