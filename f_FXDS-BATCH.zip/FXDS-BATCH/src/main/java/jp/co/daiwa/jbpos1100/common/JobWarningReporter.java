package jp.co.daiwa.jbpos1100.common;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.base.LogBatchBasedLogger;
import jp.co.daiwa.common.constant.FxdConstants;
import jp.co.daiwa.common.constant.JobConstants;

/**
 * ジョブ警告状態の設定と警告ログ出力を一元化するクラス。
 *
 * <p>旧コードでは各メソッドが例外時に
 * {@code logger.warn(...)} と
 * {@code contribution.getStepExecution().getJobExecution().getExecutionContext()
 *  .put(CONTEXT_K_JOB_STATUS, CONTEXT_V_JOB_STATUS_WARN)}
 * を毎回コピペしていた（数十箇所）。この 2 操作を 1 メソッドにまとめる。</p>
 *
 * <p>1 バッチ実行（execute）あたり 1 インスタンス生成し、各サービスへ
 * コンストラクタ注入で渡す想定。</p>
 */
public class JobWarningReporter {

    private static final LogBatchBasedLogger logger = LogBatchBasedLogger.getLogger(JobWarningReporter.class);

    private final StepContribution contribution;

    /**
     * @param contribution 現在のステップ実行コンテキスト
     */
    public JobWarningReporter(StepContribution contribution) {
        this.contribution = contribution;
    }

    /**
     * 警告ログを出力し、ジョブを警告終了状態にする。
     *
     * @param processLabel 処理名（ログ用）
     * @param cause        発生した例外
     */
    public void warn(String processLabel, Throwable cause) {
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", processLabel, cause);
        markJobWarning();
    }

    /**
     * 警告ログ（明細メッセージ）を出力し、ジョブを警告終了状態にする。
     *
     * @param processLabel 処理名（ログ用）
     * @param detail       明細メッセージ
     */
    public void warn(String processLabel, String detail) {
        logger.warn(JobConstants.Jbpos1000, JobConstants.Jbpos1000_Name, "MSG_J_W001", processLabel, detail);
        markJobWarning();
    }

    /**
     * ジョブ実行コンテキストに警告ステータスを設定する。
     */
    public void markJobWarning() {
        contribution.getStepExecution().getJobExecution().getExecutionContext()
                .put(FxdConstants.CONTEXT_K_JOB_STATUS, FxdConstants.CONTEXT_V_JOB_STATUS_WARN);
    }
}
