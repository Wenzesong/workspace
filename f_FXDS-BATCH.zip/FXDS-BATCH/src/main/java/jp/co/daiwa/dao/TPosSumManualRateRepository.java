package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TPosSumManualRateBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPosSumManualRateRepository}
 * （ポジション集計マニュアルレート情報）。旧 {@code Jbpos1000PosSumTasklet#getPosSumManualRate}
 * が {@code getTPosSumManualRateBeanAll(bean)} を呼ぶため定義。
 */
public interface TPosSumManualRateRepository {

    List<TPosSumManualRateBean> getTPosSumManualRateBeanAll(TPosSumManualRateBean condition);
}
