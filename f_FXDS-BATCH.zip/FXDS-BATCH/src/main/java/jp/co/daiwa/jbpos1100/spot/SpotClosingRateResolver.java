package jp.co.daiwa.jbpos1100.spot;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;

/**
 * 集計対象データに引値レート（closingRate）と引値円転レート（closingYenRate）を再設定するリゾルバ。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setClosingRate} の移植版。旧コードは原本破損で
 * コンパイル不能だったため jbpos1000 側で修正のうえ、ここでは純粋変換クラスとして再構成し、
 * レート判定を小メソッドへ分割してテスト容易にする（DB・トランザクション非依存）。</p>
 *
 * <h2>移植時の整理</h2>
 * <ul>
 *   <li>未使用だったローカル変数 {@code manualYenRate}（デッドコード）を除去。</li>
 *   <li>引値レート／引値円転レートの選択を {@link #resolveClosingRate} /
 *       {@link #resolveClosingYenRate} に分離。</li>
 *   <li>Bean のフィールドコピーを {@link #copyWithRates} に分離。</li>
 * </ul>
 *
 * <p><b>注意:</b> 引値円転レートの (a)保持 / (b)JPYは1.0 / (c)ファイル参照 の振り分けは、
 * 原本破損により意図が特定できず標準パターンで推定復元したもの（jbpos1000 側コメント参照）。
 * 実データでの検証を推奨。</p>
 */
public class SpotClosingRateResolver {

    /**
     * 各集計対象データに引値レート・引値円転レートを再設定した新リストを返す。
     *
     * @param targetDate     基準日
     * @param sourceList     集計対象データ
     * @param closeRateList  引値レートファイル情報
     * @param manualRateList ポジション集計マニュアルレート情報（引値円転レートのマニュアル分岐で使用）
     * @return 引値レート・円転レートを再設定した新リスト
     */
    public List<TPosSumSourceDataBean> resolve(Date targetDate, List<TPosSumSourceDataBean> sourceList,
            List<CloseRateDto> closeRateList, List<TPosSumManualRateBean> manualRateList) {
        String baseDate = new SimpleDateFormat(BatchConstants.DATE_PATTERN_SLASH).format(targetDate);
        List<TPosSumSourceDataBean> result = new ArrayList<>();
        for (TPosSumSourceDataBean item : sourceList) {
            BigDecimal closingRate = resolveClosingRate(item, baseDate, closeRateList);
            BigDecimal closingYenRate = resolveClosingYenRate(item, baseDate, closeRateList, manualRateList);
            result.add(copyWithRates(item, closingRate, closingYenRate));
        }
        return result;
    }

    /**
     * 引値レートを決定する。
     *
     * <p>既に値を持つ場合は保持。NULL の場合、売買通貨・決済通貨が共に JPY なら 1.0、
     * それ以外は引値レートファイルの (売買通貨, 決済通貨) ペアから取得する。</p>
     *
     * @param item          対象データ
     * @param baseDate      基準日（yyyy/MM/dd）
     * @param closeRateList 引値レートファイル情報
     * @return 引値レート（取得できない場合 null）
     */
    private BigDecimal resolveClosingRate(TPosSumSourceDataBean item, String baseDate,
            List<CloseRateDto> closeRateList) {
        if (item.getClosingRate() != null) {
            return item.getClosingRate();
        }
        if (BatchConstants.CURRENCY_JPY.equals(item.getDealCurrency())
                && BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency())) {
            return BigDecimal.ONE;
        }
        CloseRateDto closeRate = closeRateList.stream()
                .filter(b -> baseDate.equals(b.getBaseDate()))
                .filter(b -> b.getDealCurrency().equals(item.getDealCurrency().trim()))
                .filter(b -> b.getSettleCurrency().equals(item.getSettleCurrency().trim()))
                .findFirst().orElse(null);
        return closeRate != null ? closeRate.getCloseRate() : null;
    }

    /**
     * 引値円転レート（決済通貨→JPY の換算レート）を決定する。旧 {@code setClosingRate}（L458-503）を忠実移植。
     *
     * <p>引値円転レートが既に設定済みなら保持。NULL の場合、以下の優先順で決定する:</p>
     * <ol>
     *   <li><b>マニュアル(引値レート、TTM)が NULL でない場合</b>: 決済通貨が JPY なら 1.0、
     *       それ以外はマニュアルレート（決済通貨→JPY）の TTM を取得。</li>
     *   <li><b>為替区分が約定済CF以外の場合</b>: 決済通貨が JPY なら 1.0、それ以外は引値レートファイルの
     *       (決済通貨, JPY) から取得。</li>
     *   <li><b>為替区分が約定済CFの場合</b>: 売買通貨が JPY なら 1.0、それ以外は引値レートファイルの
     *       (売買通貨, JPY) から取得。</li>
     * </ol>
     *
     * @param item           対象データ
     * @param baseDate       基準日（yyyy/MM/dd）
     * @param closeRateList  引値レートファイル情報
     * @param manualRateList マニュアルレート情報
     * @return 引値円転レート（取得できない場合 null）
     */
    private BigDecimal resolveClosingYenRate(TPosSumSourceDataBean item, String baseDate,
            List<CloseRateDto> closeRateList, List<TPosSumManualRateBean> manualRateList) {
        // (a) 既に値を持つ → 保持
        if (item.getClosingYenRate() != null) {
            return item.getClosingYenRate();
        }
        // ① マニュアル(引値レート、TTM)が NULL でない場合
        if (item.getManualClosingTtmRate() != null) {
            if (BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency().trim())) {
                return BigDecimal.ONE;
            }
            TPosSumManualRateBean manualYenRate = manualRateList.stream()
                    .filter(c -> c.getDealCurrency().equals(item.getSettleCurrency().trim()))
                    .filter(c -> BatchConstants.CURRENCY_JPY.equals(c.getSettleCurrency()))
                    .findFirst().orElse(null);
            return manualYenRate != null ? manualYenRate.getManualClosingTtmRate() : null;
        }
        // ② 為替区分が約定済CF以外の場合（決済通貨→JPY）
        if (!BatchConstants.EXCHANGE_DIVISION_TRADED_CF.equals(item.getExchangeDivision())) {
            // 旧コードの判定は空白除去後の決済通貨で行う（item.getSettleCurrency().replaceAll(" ", "")）
            if (BatchConstants.CURRENCY_JPY.equals(item.getSettleCurrency().replaceAll(" ", ""))) {
                return BigDecimal.ONE;
            }
            CloseRateDto closeYenRate = closeRateList.stream()
                    .filter(b -> baseDate.equals(b.getBaseDate()))
                    // 旧コードのファイル照合は無加工の決済通貨（replaceAll("", "") は恒等変換）
                    .filter(b -> b.getDealCurrency().equals(item.getSettleCurrency()))
                    .filter(b -> BatchConstants.CURRENCY_JPY.equals(b.getSettleCurrency()))
                    .findFirst().orElse(null);
            return closeYenRate != null ? closeYenRate.getCloseRate() : null;
        }
        // ③ 為替区分が約定済CFの場合（売買通貨→JPY）
        if (BatchConstants.CURRENCY_JPY.equals(item.getDealCurrency().trim())) {
            return BigDecimal.ONE;
        }
        CloseRateDto closeYenRate = closeRateList.stream()
                .filter(b -> baseDate.equals(b.getBaseDate()))
                // 旧コードのファイル照合は無加工の売買通貨（replaceAll("", "") は恒等変換）
                .filter(b -> b.getDealCurrency().equals(item.getDealCurrency()))
                .filter(b -> BatchConstants.CURRENCY_JPY.equals(b.getSettleCurrency()))
                .findFirst().orElse(null);
        return closeYenRate != null ? closeYenRate.getCloseRate() : null;
    }

    /**
     * 元データを複製し、引値レート・引値円転レートのみ差し替えた新 Bean を返す（不変的更新）。
     *
     * @param item           元データ
     * @param closingRate    引値レート
     * @param closingYenRate 引値円転レート
     * @return 新 Bean
     */
    private TPosSumSourceDataBean copyWithRates(TPosSumSourceDataBean item, BigDecimal closingRate,
            BigDecimal closingYenRate) {
        TPosSumSourceDataBean pos = new TPosSumSourceDataBean();
        pos.setSeqNo(item.getSeqNo());
        pos.setProcessBaseDate(item.getProcessBaseDate());
        // 旧 setClosingRate L397 に合わせ約定日時は参照コピー（new Timestamp(...) でラップしない＝NULL でも NPE にしない）
        pos.setTradeDatetime(item.getTradeDatetime());
        pos.setDealerBook(item.getDealerBook());
        pos.setInputDataSource(item.getInputDataSource());
        pos.setAc(item.getAc());
        pos.setDealCurrency(item.getDealCurrency());
        pos.setSettleCurrency(item.getSettleCurrency());
        pos.setCurrencyPair(item.getCurrencyPair());
        pos.setExchangeDivision(item.getExchangeDivision());
        pos.setDeliveryDate(item.getDeliveryDate());
        pos.setDealDivision(item.getDealDivision());
        pos.setDealAmount(item.getDealAmount());
        pos.setTradeRate(item.getTradeRate());
        pos.setSettleAmount(item.getSettleAmount());
        pos.setEvaluationRateDivision(item.getEvaluationRateDivision());
        pos.setRealRate(item.getRealRate());
        pos.setClosingRate(closingRate);
        pos.setManualDailyRate(item.getManualDailyRate());
        pos.setManualClosingTtmRate(item.getManualClosingTtmRate());
        pos.setRateSource(item.getRateSource());
        pos.setBbgRate(item.getBbgRate());
        pos.setRealYenRate(item.getRealYenRate());
        pos.setClosingYenRate(closingYenRate);
        pos.setBeforeEvaluationPosition(item.getBeforeEvaluationPosition());
        pos.setBeforeTradeAmountPvCls(item.getBeforeTradeAmountPvCls());
        pos.setBeforeTradeAmountPvClsYen(item.getBeforeTradeAmountPvClsYen());
        pos.setRegisterUser(item.getRegisterUser());
        pos.setRegisterDatetime(item.getRegisterDatetime());
        pos.setUpdateUser(item.getUpdateUser());
        pos.setUpdateDatetime(item.getUpdateDatetime());
        return pos;
    }
}
