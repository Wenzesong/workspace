package jp.co.daiwa.dao;

import java.util.List;

import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPositionSwapSumDataRepository}（スワップ集計結果）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TPositionSwapSumDataRepository {

    void delete(TPositionSwapSumDataBean condition);

    void insert(List<TPositionSwapSumDataBean> items);

    List<TPositionSwapSumDataBean> getPositionSwapSumDataList(TPositionSwapSumDataBean condition);
}
