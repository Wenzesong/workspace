package jp.co.daiwa.common;

import java.util.List;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code jp.co.daiwa.common.FileUtil}。
 *
 * <p>jbpos1100 からは {@link #writeTsvFile(String, List)} のみ使用される。
 * 実ファイル書き込みの挙動は実プロジェクトの実装に従う。</p>
 */
public final class FileUtil {

    private FileUtil() {
    }

    /** TSV ファイルを出力する（スタブ）。 */
    public static void writeTsvFile(String filePath, List<List<String>> data) throws Exception {
        // 実体は実プロジェクトの FileUtil が担う。
    }
}
