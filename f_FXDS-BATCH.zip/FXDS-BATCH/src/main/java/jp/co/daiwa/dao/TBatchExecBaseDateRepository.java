package jp.co.daiwa.dao;

import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TBatchExecBaseDateRepository}（バッチ実行基準日）。
 * jbpos1100 が呼び出すメソッドのみ定義。
 */
public interface TBatchExecBaseDateRepository {

    Date getExecBaseDate();
}
