package jp.co.daiwa.jbpos1100.tasklet;

import java.util.Date;
import java.util.List;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.TByCcyDeltaCashBalanceRepository;
import jp.co.daiwa.dao.TPositionSpotSumDataRepository;
import jp.co.daiwa.dao.TPositionSwapSumDataRepository;
import jp.co.daiwa.dao.TSwapPlSumDateRepository;
import jp.co.daiwa.dao.bean.TByCcyDeltaCashBalanceBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dao.bean.TPositionSwapSumDataBean;
import jp.co.daiwa.dao.bean.TSwapPlSumDateBean;
import jp.co.daiwa.jbpos1100.common.EndOfDayClosingDuplicator;
import jp.co.daiwa.jbpos1100.delta.CurrencyDeltaCashStore;
import jp.co.daiwa.jbpos1100.spot.SpotSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapPlSumStore;
import jp.co.daiwa.jbpos1100.swap.SwapSumStore;

/**
 * 引値集計結果を日締め（評価レート区分 03＝END_OF_DAY_CLOSING）として複製・登録するサービス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet} の各永続化メソッド（{@code setSpotSumDate} ほか）に
 * 織り込まれていた日締めデータ生成（{@code setClosingData} 等で複製→登録）を、引値集計の
 * 後処理として 1 箇所へ集約したもの。スポット／スワップ／通貨別デルタ・キャッシュ残／
 * スワップ PL 合計の 4 種を対象とする。</p>
 *
 * <h2>登録条件（旧コードを忠実移植）</h2>
 * <ul>
 *   <li>システム時刻が日締め時刻以降（{@code afterDayClose}）かつ評価レート区分が引値のときのみ実行
 *       （実行可否の判定は呼び出し側＝{@link ClosingEvaluationService}）。</li>
 *   <li>各種別で、引値集計結果が非空 <b>かつ</b> 当該基準日の日締めデータ（03）が未登録の場合のみ複製を登録する
 *       （日締めデータの削除は行わない＝既存があればスキップ）。</li>
 * </ul>
 */
public class EndOfDayClosingService {

    private static final String END_OF_DAY = EvaluationRateKbn.END_OF_DAY_CLOSING.getCode();

    private final EndOfDayClosingDuplicator duplicator;
    private final SpotSumStore spotSumStore;
    private final SwapSumStore swapSumStore;
    private final CurrencyDeltaCashStore deltaCashStore;
    private final SwapPlSumStore swapPlSumStore;
    private final TPositionSpotSumDataRepository spotRepository;
    private final TPositionSwapSumDataRepository swapRepository;
    private final TByCcyDeltaCashBalanceRepository deltaCashRepository;
    private final TSwapPlSumDateRepository swapPlSumRepository;

    public EndOfDayClosingService(EndOfDayClosingDuplicator duplicator, SpotSumStore spotSumStore,
            SwapSumStore swapSumStore, CurrencyDeltaCashStore deltaCashStore, SwapPlSumStore swapPlSumStore,
            TPositionSpotSumDataRepository spotRepository, TPositionSwapSumDataRepository swapRepository,
            TByCcyDeltaCashBalanceRepository deltaCashRepository, TSwapPlSumDateRepository swapPlSumRepository) {
        this.duplicator = duplicator;
        this.spotSumStore = spotSumStore;
        this.swapSumStore = swapSumStore;
        this.deltaCashStore = deltaCashStore;
        this.swapPlSumStore = swapPlSumStore;
        this.spotRepository = spotRepository;
        this.swapRepository = swapRepository;
        this.deltaCashRepository = deltaCashRepository;
        this.swapPlSumRepository = swapPlSumRepository;
    }

    /**
     * 引値集計結果を日締め（03）として複製・登録する。
     *
     * @param targetDate 基準日
     * @param result     引値集計の結果（スポット／スワップ各成果物）
     * @throws Exception DB 切断由来の例外
     */
    public void duplicateClosingToEndOfDay(Date targetDate, PositionEvaluationResult result) throws Exception {
        // スポット
        if (!result.getSpotSumList().isEmpty() && !existsSpotEndOfDay(targetDate)) {
            spotSumStore.insert(duplicator.duplicateSpot(result.getSpotSumList()));
        }
        // スワップ
        if (!result.getSwapSumList().isEmpty() && !existsSwapEndOfDay(targetDate)) {
            swapSumStore.insert(duplicator.duplicateSwap(result.getSwapSumList()));
        }
        // 通貨別デルタ・キャッシュ残
        if (!result.getDeltaCashList().isEmpty() && !existsDeltaCashEndOfDay(targetDate)) {
            deltaCashStore.insert(duplicator.duplicateDeltaCash(result.getDeltaCashList()));
        }
        // スワップ PL 合計
        if (!result.getSwapPlSumList().isEmpty() && !existsSwapPlSumEndOfDay(targetDate)) {
            swapPlSumStore.insert(duplicator.duplicateSwapPlSum(result.getSwapPlSumList()));
        }
    }

    private boolean existsSpotEndOfDay(Date targetDate) {
        TPositionSpotSumDataBean condition = new TPositionSpotSumDataBean();
        condition.setProcessBaseDate(targetDate);
        condition.setEvaluationRateDivision(END_OF_DAY);
        List<TPositionSpotSumDataBean> existing = spotRepository.geTPositionSpotSumDataBeanAll(condition);
        return existing != null && !existing.isEmpty();
    }

    private boolean existsSwapEndOfDay(Date targetDate) {
        TPositionSwapSumDataBean condition = new TPositionSwapSumDataBean();
        condition.setProcessBaseDate(targetDate);
        condition.setEvaluationRateDivision(END_OF_DAY);
        List<TPositionSwapSumDataBean> existing = swapRepository.getPositionSwapSumDataList(condition);
        return existing != null && !existing.isEmpty();
    }

    private boolean existsDeltaCashEndOfDay(Date targetDate) {
        TByCcyDeltaCashBalanceBean condition = new TByCcyDeltaCashBalanceBean();
        condition.setProcessBaseDate(targetDate);
        condition.setEvaluationRateDivision(END_OF_DAY);
        List<TByCcyDeltaCashBalanceBean> existing = deltaCashRepository.getByCcyDeltaCashBalanceList(condition);
        return existing != null && !existing.isEmpty();
    }

    private boolean existsSwapPlSumEndOfDay(Date targetDate) {
        TSwapPlSumDateBean condition = new TSwapPlSumDateBean();
        condition.setProcessBaseDate(targetDate);
        condition.setEvaluationRateDivision(END_OF_DAY);
        List<TSwapPlSumDateBean> existing = swapPlSumRepository.getSwapPlSumDateList(condition);
        return existing != null && !existing.isEmpty();
    }
}
