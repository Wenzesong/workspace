package jp.co.daiwa.jbpos1100.common;

import jp.co.daiwa.common.constant.FxdConstants;

/**
 * DB 切断（接続断）の判定ヘルパ。
 *
 * <p>旧コードでは各メソッドが
 * {@code e.getMessage() != null && e.getMessage().contains(FxdConstants.DB_IO_EXCEPTION)}
 * を直接書き、DB 切断時は処理終了・それ以外は警告継続、という分岐を重複させていた。
 * 判定ロジックを 1 箇所に集約する。</p>
 *
 * <p>注意（P2/設計指摘の引継ぎ）: 例外メッセージの文字列照合による DB 切断判定は脆い。
 * 本来は専用例外型（DataAccessResourceFailureException など）での判定が望ましいが、
 * 既存挙動を変えないため文字列照合を踏襲している。将来的な改善対象。</p>
 */
public final class DbConnectionFailures {

    private DbConnectionFailures() {
    }

    /**
     * 例外が DB 切断（I/O 断）由来かどうかを判定する。
     *
     * @param t 判定対象の例外（null 可）
     * @return DB 切断由来なら true
     */
    public static boolean isDisconnect(Throwable t) {
        return t != null
                && t.getMessage() != null
                && t.getMessage().contains(FxdConstants.DB_IO_EXCEPTION);
    }
}
