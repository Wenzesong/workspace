package jp.co.daiwa.common.constant;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code TradeKbnEnum}。
 *
 * <p>jbpos1100 は内包 enum {@link TradeKbn}（証券）と {@code getCode()} を使用する。
 * コード値は推定の既定値であり、実プロジェクトの正規コードで検証すること。</p>
 */
public final class TradeKbnEnum {

    private TradeKbnEnum() {
    }

    public enum TradeKbn {
        SECURITY("1");

        private final String code;

        TradeKbn(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }
    }
}
