package jp.co.daiwa.jbpos1100.delta;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.common.constant.JobConstants;
import jp.co.daiwa.dao.bean.TPosSumManualRateBean;
import jp.co.daiwa.dao.bean.TPositionPlDeltaDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.dto.CloseRateDto;
import jp.co.daiwa.jbpos1100.common.BatchConstants;
import jp.co.daiwa.jbpos1100.common.BigDecimalSummer;
import jp.co.daiwa.jbpos1100.common.JobWarningReporter;

/**
 * 決済通貨外貨の PL デルタ生成情報（スポットのみ）を算出するクラス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setPosPlDeltaValueData}（L1314-1475）の計算部分を、
 * DB 取得・永続化（既存 PL デルタの取得／削除／登録）から切り離した純粋関数として移植する。
 * 取得・削除・登録は呼び出し側（{@link PlDeltaStore} とサイクル合成ルート）が担う。</p>
 *
 * <h2>処理概要（旧コードを忠実移植）</h2>
 * <ol>
 *   <li>当該基準日・評価レート区分=プレ引値・決済通貨≠JPY・評価PL(原通貨)≠NULL のスポット集計結果を抽出。</li>
 *   <li>ディーラブック・決済通貨でグルーピングし、グループごとに評価PL(原通貨)を合計。</li>
 *   <li>引値レートファイル（決済通貨→JPY）／マニュアルレート（決済通貨→JPY, TTM 非NULL）を取得。</li>
 *   <li>いずれかが存在すれば PL デルタ Bean を生成。両方とも無ければ警告（ジョブ警告状態）。</li>
 * </ol>
 *
 * <p>取引レートはマニュアルレート優先（無ければ引値レート）。決済金額＝売買金額(絶対値)×取引レート。
 * 売買区分は評価PL(原通貨)の符号で買い/売りを決定する。計算式・符号・丸めは旧コードから変更しない。</p>
 */
public class PlDeltaCalculator {

    private static final String LABEL = "決済通貨外貨PLデルタ生成情報処理";

    private final JobWarningReporter warningReporter;

    /**
     * @param warningReporter 警告レポータ
     */
    public PlDeltaCalculator(JobWarningReporter warningReporter) {
        this.warningReporter = warningReporter;
    }

    /**
     * 決済通貨外貨 PL デルタ生成情報を算出する。
     *
     * @param targetDate     基準日
     * @param spotSumList    ポジションスポット集計結果（当該基準日分を含む）
     * @param closeRateList  引値レートファイル情報
     * @param manualRateList ポジション集計マニュアルレート情報
     * @return PL デルタ生成情報リスト（対象なしの場合は空リスト）
     */
    public List<TPositionPlDeltaDataBean> calculate(Date targetDate, List<TPositionSpotSumDataBean> spotSumList,
            List<CloseRateDto> closeRateList, List<TPosSumManualRateBean> manualRateList) {

        List<TPositionPlDeltaDataBean> result = new ArrayList<>();

        // 当該基準日・プレ引値・決済通貨外貨・評価PL(原通貨)非NULL のスポット集計結果のみ対象
        List<TPositionSpotSumDataBean> targetSpot = spotSumList.stream()
                .filter(d -> d.getProcessBaseDate().equals(targetDate))
                .filter(d -> d.getEvaluationRateDivision().equals(EvaluationRateKbn.PRE_CLOSING.getCode()))
                .filter(d -> !BatchConstants.CURRENCY_JPY.equals(d.getSettleCurrency()))
                .filter(d -> d.getEvaluationPlUnderlyingCcy() != null)
                .collect(Collectors.toList());
        if (targetSpot.isEmpty()) {
            return result;
        }

        String baseDate = new SimpleDateFormat(BatchConstants.DATE_PATTERN_SLASH).format(targetDate);

        // 集計キー: ディーラブック, 決済通貨
        Map<String, List<TPositionSpotSumDataBean>> sumMap = targetSpot.stream()
                .collect(Collectors.groupingBy(g -> g.getDealerBook() + "," + g.getSettleCurrency()));

        for (Map.Entry<String, List<TPositionSpotSumDataBean>> entry : sumMap.entrySet()) {
            String[] split = entry.getKey().split(",");
            String dealerBook = split[0];
            String settleCurrency = split[1];

            // 引値レート（決済通貨→JPY）
            CloseRateDto closeRate = closeRateList.stream()
                    .filter(b -> b.getBaseDate().equals(baseDate))
                    .filter(b -> b.getDealCurrency().equals(settleCurrency))
                    .filter(b -> BatchConstants.CURRENCY_JPY.equals(b.getSettleCurrency()))
                    .findFirst().orElse(null);

            // マニュアルレート（決済通貨→JPY, TTM 非NULL）
            TPosSumManualRateBean manualRate = manualRateList.stream()
                    .filter(c -> c.getDealCurrency().equals(settleCurrency))
                    .filter(m -> m.getManualClosingTtmRate() != null)
                    .filter(c -> BatchConstants.CURRENCY_JPY.equals(c.getSettleCurrency()))
                    .findFirst().orElse(null);

            // 評価PL(原通貨)合計（フィルタ済みのため NULL は含まれない＝旧 sumBigDecimal と同一）
            BigDecimal totalDealAmount = BigDecimalSummer.sum(entry.getValue(),
                    TPositionSpotSumDataBean::getEvaluationPlUnderlyingCcy);

            if (closeRate != null || manualRate != null) {
                result.add(buildBean(targetDate, dealerBook, settleCurrency, totalDealAmount, closeRate, manualRate));
            } else {
                // 該当通貨ペアの引値レート・マニュアルレートが存在しない場合は警告（ジョブ警告状態）
                warningReporter.warn(LABEL, dealerBook + "," + settleCurrency.concat(BatchConstants.CURRENCY_JPY)
                        + "の引値レート、マニュアルレートが存在しません。");
            }
        }
        return result;
    }

    /**
     * 1 グループ分の PL デルタ生成情報 Bean を組み立てる。
     */
    private TPositionPlDeltaDataBean buildBean(Date targetDate, String dealerBook, String settleCurrency,
            BigDecimal totalDealAmount, CloseRateDto closeRate, TPosSumManualRateBean manualRate) {
        TPositionPlDeltaDataBean bean = new TPositionPlDeltaDataBean();
        bean.setProcessBaseDate(targetDate);
        bean.setDealerBook(dealerBook);
        bean.setDealCurrency(settleCurrency);
        bean.setSettleCurrency(BatchConstants.CURRENCY_JPY);
        bean.setCurrencyPair(settleCurrency.concat(BatchConstants.CURRENCY_JPY));
        bean.setExchangeDivision(BatchConstants.EXCHANGE_DIVISION_SPOT);
        bean.setAc(BatchConstants.AC_FLAG_IN_TIME);
        // 売買区分: 評価PL(原通貨)がプラスなら買い、マイナスなら売り
        bean.setDealDivision(totalDealAmount.compareTo(BigDecimal.ZERO) >= 0
                ? BatchConstants.DEAL_DIVISION_BUY : BatchConstants.DEAL_DIVISION_SELL);
        bean.setDealAmount(totalDealAmount.abs());
        bean.setClosingRate(closeRate != null ? closeRate.getCloseRate() : null);
        bean.setManualClosingTtmRate(manualRate != null ? manualRate.getManualClosingTtmRate() : null);
        // 取引レート: マニュアルレート優先、無ければ引値レート
        BigDecimal tradeRate = manualRate != null ? manualRate.getManualClosingTtmRate() : closeRate.getCloseRate();
        bean.setTradeRate(tradeRate);
        // 決済金額 = 売買金額(絶対値) × 取引レート
        bean.setSettleAmount(bean.getDealAmount().multiply(tradeRate));
        bean.setClosingYenRate(BigDecimal.ONE);
        bean.setRegisterUser(JobConstants.Jbpos1000);
        bean.setRegisterDatetime(null);
        bean.setUpdateUser(JobConstants.Jbpos1000);
        bean.setUpdateDatetime(null);
        return bean;
    }
}
