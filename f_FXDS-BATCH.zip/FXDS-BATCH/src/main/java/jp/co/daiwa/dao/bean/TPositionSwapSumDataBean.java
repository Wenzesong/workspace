package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPositionSwapSumDataBean}（ポジションスワップ集計結果）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TPositionSwapSumDataBean {

    private Date processBaseDate;
    private String dealerBook;
    private String evaluationRateDivision;
    private String currency;
    private String exchangeDivision;
    private Date deliveryDate;
    private BigDecimal dealAmount;
    private BigDecimal settleAmount;
    private BigDecimal realRate;
    private BigDecimal closingRate;
    private BigDecimal realYenRate;
    private BigDecimal closingYenRate;
    private BigDecimal dealYenRate;
    private BigDecimal dealYenClosingRate;
    private BigDecimal tradeAmountPvCls;
    private BigDecimal tradeAmountPvClsYen;
    private BigDecimal tradeAmountPv;
    private BigDecimal tradeAmountPvYen;
    private BigDecimal tradeAmountPvEva;
    private BigDecimal tradeAmountPvEvaYen;
    private BigDecimal settleYenRate;
    private BigDecimal settleAmountPv;
    private BigDecimal settleAmountPvYen;
    private BigDecimal cashAmount;
    private BigDecimal sumPlYen;
    private String registerUser;
    private Timestamp registerDatetime;
    private String updateUser;
    private Timestamp updateDatetime;

    public Date getProcessBaseDate() {
        return processBaseDate;
    }

    public void setProcessBaseDate(Date processBaseDate) {
        this.processBaseDate = processBaseDate;
    }

    public String getDealerBook() {
        return dealerBook;
    }

    public void setDealerBook(String dealerBook) {
        this.dealerBook = dealerBook;
    }

    public String getEvaluationRateDivision() {
        return evaluationRateDivision;
    }

    public void setEvaluationRateDivision(String evaluationRateDivision) {
        this.evaluationRateDivision = evaluationRateDivision;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getExchangeDivision() {
        return exchangeDivision;
    }

    public void setExchangeDivision(String exchangeDivision) {
        this.exchangeDivision = exchangeDivision;
    }

    public Date getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public BigDecimal getDealAmount() {
        return dealAmount;
    }

    public void setDealAmount(BigDecimal dealAmount) {
        this.dealAmount = dealAmount;
    }

    public BigDecimal getSettleAmount() {
        return settleAmount;
    }

    public void setSettleAmount(BigDecimal settleAmount) {
        this.settleAmount = settleAmount;
    }

    public BigDecimal getRealRate() {
        return realRate;
    }

    public void setRealRate(BigDecimal realRate) {
        this.realRate = realRate;
    }

    public BigDecimal getClosingRate() {
        return closingRate;
    }

    public void setClosingRate(BigDecimal closingRate) {
        this.closingRate = closingRate;
    }

    public BigDecimal getRealYenRate() {
        return realYenRate;
    }

    public void setRealYenRate(BigDecimal realYenRate) {
        this.realYenRate = realYenRate;
    }

    public BigDecimal getClosingYenRate() {
        return closingYenRate;
    }

    public void setClosingYenRate(BigDecimal closingYenRate) {
        this.closingYenRate = closingYenRate;
    }

    public BigDecimal getDealYenRate() {
        return dealYenRate;
    }

    public void setDealYenRate(BigDecimal dealYenRate) {
        this.dealYenRate = dealYenRate;
    }

    public BigDecimal getDealYenClosingRate() {
        return dealYenClosingRate;
    }

    public void setDealYenClosingRate(BigDecimal dealYenClosingRate) {
        this.dealYenClosingRate = dealYenClosingRate;
    }

    public BigDecimal getTradeAmountPvCls() {
        return tradeAmountPvCls;
    }

    public void setTradeAmountPvCls(BigDecimal tradeAmountPvCls) {
        this.tradeAmountPvCls = tradeAmountPvCls;
    }

    public BigDecimal getTradeAmountPvClsYen() {
        return tradeAmountPvClsYen;
    }

    public void setTradeAmountPvClsYen(BigDecimal tradeAmountPvClsYen) {
        this.tradeAmountPvClsYen = tradeAmountPvClsYen;
    }

    public BigDecimal getTradeAmountPv() {
        return tradeAmountPv;
    }

    public void setTradeAmountPv(BigDecimal tradeAmountPv) {
        this.tradeAmountPv = tradeAmountPv;
    }

    public BigDecimal getTradeAmountPvYen() {
        return tradeAmountPvYen;
    }

    public void setTradeAmountPvYen(BigDecimal tradeAmountPvYen) {
        this.tradeAmountPvYen = tradeAmountPvYen;
    }

    public BigDecimal getTradeAmountPvEva() {
        return tradeAmountPvEva;
    }

    public void setTradeAmountPvEva(BigDecimal tradeAmountPvEva) {
        this.tradeAmountPvEva = tradeAmountPvEva;
    }

    public BigDecimal getTradeAmountPvEvaYen() {
        return tradeAmountPvEvaYen;
    }

    public void setTradeAmountPvEvaYen(BigDecimal tradeAmountPvEvaYen) {
        this.tradeAmountPvEvaYen = tradeAmountPvEvaYen;
    }

    public BigDecimal getSettleYenRate() {
        return settleYenRate;
    }

    public void setSettleYenRate(BigDecimal settleYenRate) {
        this.settleYenRate = settleYenRate;
    }

    public BigDecimal getSettleAmountPv() {
        return settleAmountPv;
    }

    public void setSettleAmountPv(BigDecimal settleAmountPv) {
        this.settleAmountPv = settleAmountPv;
    }

    public BigDecimal getSettleAmountPvYen() {
        return settleAmountPvYen;
    }

    public void setSettleAmountPvYen(BigDecimal settleAmountPvYen) {
        this.settleAmountPvYen = settleAmountPvYen;
    }

    public BigDecimal getCashAmount() {
        return cashAmount;
    }

    public void setCashAmount(BigDecimal cashAmount) {
        this.cashAmount = cashAmount;
    }

    public BigDecimal getSumPlYen() {
        return sumPlYen;
    }

    public void setSumPlYen(BigDecimal sumPlYen) {
        this.sumPlYen = sumPlYen;
    }

    public String getRegisterUser() {
        return registerUser;
    }

    public void setRegisterUser(String registerUser) {
        this.registerUser = registerUser;
    }

    public Timestamp getRegisterDatetime() {
        return registerDatetime;
    }

    public void setRegisterDatetime(Timestamp registerDatetime) {
        this.registerDatetime = registerDatetime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Timestamp getUpdateDatetime() {
        return updateDatetime;
    }

    public void setUpdateDatetime(Timestamp updateDatetime) {
        this.updateDatetime = updateDatetime;
    }
}
