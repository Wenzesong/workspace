package jp.co.daiwa.common;

import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS 共通の {@code jp.co.daiwa.common.DateUtil}。
 *
 * <p>jbpos1100 から使用されるのは下記の 3 メソッドのみ。日付書式変換の本来の挙動は
 * 実プロジェクトの実装に従う（本スタブはコンパイルを通すためのもので、戻り値はダミー）。</p>
 */
public final class DateUtil {

    private DateUtil() {
    }

    /** Date → "yyyy/MM/dd" 文字列。 */
    public static String convertDateToStrYmdSlash(Date date) {
        return new java.text.SimpleDateFormat("yyyy/MM/dd").format(date);
    }

    /** Date → "yyyyMMdd" 文字列。 */
    public static String convertDateToStrYmd(Date date) {
        return new java.text.SimpleDateFormat("yyyyMMdd").format(date);
    }

    /** "yyyyMMdd" 文字列 → Date。 */
    public static Date parsDate(String ymd) {
        try {
            return new java.text.SimpleDateFormat("yyyyMMdd").parse(ymd);
        } catch (java.text.ParseException e) {
            throw new IllegalArgumentException("invalid date: " + ymd, e);
        }
    }
}
