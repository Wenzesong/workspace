package jp.co.daiwa.jbpos1100.common;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;

/**
 * 評価レート区分コード → 表示名の変換ヘルパ。
 *
 * <p>旧コードでは各所に {@code switch (evaluationRateKbn)} が散在していた（しかも
 * メソッドにより 99(プレ引値) を扱う/扱わないが不統一）。ログ表示用の名称解決を 1 箇所に集約する。</p>
 */
public final class EvaluationRateNames {

    private EvaluationRateNames() {
    }

    /**
     * 評価レート区分コードに対応する名称を返す。
     *
     * @param code 評価レート区分コード（00/01/02/99）
     * @return 名称（未知コードは null）
     */
    public static String of(String code) {
        if (EvaluationRateKbn.REAL.getCode().equals(code)) {
            return EvaluationRateKbn.REAL.getName();
        }
        if (EvaluationRateKbn.CLOSING_PRICE.getCode().equals(code)) {
            return EvaluationRateKbn.CLOSING_PRICE.getName();
        }
        if (EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode().equals(code)) {
            return EvaluationRateKbn.AFTER_CLOSING_PRICE.getName();
        }
        if (EvaluationRateKbn.PRE_CLOSING.getCode().equals(code)) {
            return EvaluationRateKbn.PRE_CLOSING.getName();
        }
        return null;
    }
}
