package jp.co.daiwa.dao.bean;

import java.math.BigDecimal;
import java.util.Date;

/**
 * コンパイル補足用スタブ。実体は FXDS の {@code TPosSumManualRateBean}（マニュアルレート情報）。
 * jbpos1100 が参照するアクセサのみ定義。
 */
public class TPosSumManualRateBean {

    private Date baseDate;
    private String dealCurrency;
    private String settleCurrency;
    private BigDecimal manualDailyRate;
    private BigDecimal manualClosingTtmRate;

    public Date getBaseDate() {
        return baseDate;
    }

    public void setBaseDate(Date baseDate) {
        this.baseDate = baseDate;
    }

    public String getDealCurrency() {
        return dealCurrency;
    }

    public void setDealCurrency(String dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    public String getSettleCurrency() {
        return settleCurrency;
    }

    public void setSettleCurrency(String settleCurrency) {
        this.settleCurrency = settleCurrency;
    }

    public BigDecimal getManualDailyRate() {
        return manualDailyRate;
    }

    public void setManualDailyRate(BigDecimal manualDailyRate) {
        this.manualDailyRate = manualDailyRate;
    }

    public BigDecimal getManualClosingTtmRate() {
        return manualClosingTtmRate;
    }

    public void setManualClosingTtmRate(BigDecimal manualClosingTtmRate) {
        this.manualClosingTtmRate = manualClosingTtmRate;
    }
}
