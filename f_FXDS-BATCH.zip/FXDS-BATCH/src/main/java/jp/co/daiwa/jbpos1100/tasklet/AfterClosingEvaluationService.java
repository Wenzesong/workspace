package jp.co.daiwa.jbpos1100.tasklet;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.batch.core.StepContribution;

import jp.co.daiwa.common.constant.EvaluationRateKbnEnum.EvaluationRateKbn;
import jp.co.daiwa.dao.bean.TDfCalcResultBean;
import jp.co.daiwa.dao.bean.TDfHistoryDateBean;
import jp.co.daiwa.dao.bean.TPosSumSourceDataBean;
import jp.co.daiwa.dao.bean.TPositionSpotSumDataBean;
import jp.co.daiwa.jbpos1100.rate.RateLookupContext;
import jp.co.daiwa.jbpos1100.source.PositionSourceRateMapper;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplit;
import jp.co.daiwa.jbpos1100.source.SourcePositionSplitter;
import jp.co.daiwa.jbpos1100.spot.SpotCloseCostReplacer;
import jp.co.daiwa.jbpos1100.swap.SwapItTradeUnitAggregator;

/**
 * 引値以降（After）集計の前処理を組み立て、共通の評価サービスへ委譲するオーケストレーションサービス。
 *
 * <p>旧 {@code Jbpos1000PosSumTasklet#setClosingAfterValueData} の複合フローを移植・結線したもの。
 * 引値以降は単純な振り分けではなく、以下の前処理で集計対象（スポット／スワップ）を組み立てる:</p>
 * <ol>
 *   <li>当日 AC=1 のスポット／スワップ（AC 分）を抽出（{@link SourcePositionSplitter#splitForAfterAc}）。</li>
 *   <li>引値ウィンドウのスワップ（IT 分）を抽出し、通貨単位にネット
 *       （{@link SwapItTradeUnitAggregator}）→ レート再割当（{@link PositionSourceRateMapper}）。</li>
 *   <li>スポットの引値集計結果（DB 由来）をコスト持ち替え（{@link SpotCloseCostReplacer}）
 *       → レート再割当。</li>
 *   <li>スポット＝AC 分＋持ち替え分、スワップ＝AC 分＋IT 分をまとめ、
 *       {@link PositionEvaluationService} で集計＋永続化する。</li>
 * </ol>
 */
public class AfterClosingEvaluationService {

    private final SourcePositionSplitter splitter;
    private final SwapItTradeUnitAggregator swapItAggregator;
    private final SpotCloseCostReplacer spotCloseCostReplacer;
    private final PositionSourceRateMapper rateMapper;
    private final PositionEvaluationService evaluationService;

    /**
     * @param splitter              振り分け
     * @param swapItAggregator      スワップ IT 分の通貨単位ネット
     * @param spotCloseCostReplacer スポット引値コスト持ち替え
     * @param rateMapper            レート再割当
     * @param evaluationService     スポット／スワップ集計＋永続化（共通）
     */
    public AfterClosingEvaluationService(SourcePositionSplitter splitter, SwapItTradeUnitAggregator swapItAggregator,
            SpotCloseCostReplacer spotCloseCostReplacer, PositionSourceRateMapper rateMapper,
            PositionEvaluationService evaluationService) {
        this.splitter = splitter;
        this.swapItAggregator = swapItAggregator;
        this.spotCloseCostReplacer = spotCloseCostReplacer;
        this.rateMapper = rateMapper;
        this.evaluationService = evaluationService;
    }

    /**
     * 引値以降集計を実行・永続化する。
     *
     * @param contribution      ステップ実行コンテキスト
     * @param targetDate        基準日
     * @param busiDaysBefore    前営業日
     * @param allSourceList     当該基準日の全集計元
     * @param spotClosingFromDb スポット引値集計結果（DB 由来、評価レート区分=引値）
     * @param rateContext       レート再割当用の照会データ
     * @param dfCalcResult      DF 算出結果
     * @param dfHistory         DF 履歴情報
     * @param preClosingPlList  プレ引値の確定PL参照用リスト（スポット集計の共有状態）
     * @throws Exception DB 切断由来の例外
     */
    public void evaluate(StepContribution contribution, Date targetDate, Date busiDaysBefore,
            List<TPosSumSourceDataBean> allSourceList, List<TPositionSpotSumDataBean> spotClosingFromDb,
            RateLookupContext rateContext, List<TDfCalcResultBean> dfCalcResult,
            List<TDfHistoryDateBean> dfHistory, List<TPositionSpotSumDataBean> preClosingPlList) throws Exception {

        // 1. AC 分（当日 AC=1）のスポット／スワップ
        SourcePositionSplit acSplit = splitter.splitForAfterAc(allSourceList, targetDate);

        // 2. IT 分スワップ（引値ウィンドウ）→ 通貨単位ネット → レート再割当
        List<TPosSumSourceDataBean> itSwap = splitter
                .splitForClosingSwap(allSourceList, targetDate, busiDaysBefore).getSwapList();
        List<TPosSumSourceDataBean> itNetted = swapItAggregator.aggregate(itSwap);
        List<TPosSumSourceDataBean> itMapped = rateMapper.map(targetDate, itNetted, rateContext);

        // 3. スポット引値集計結果（DB 由来）→ コスト持ち替え → レート再割当
        List<TPosSumSourceDataBean> spotReplaced = spotCloseCostReplacer.replace(spotClosingFromDb, targetDate);
        List<TPosSumSourceDataBean> spotMapped = rateMapper.map(targetDate, spotReplaced, rateContext);

        // 4. スポット＝AC 分＋持ち替え分、スワップ＝AC 分＋IT 分
        List<TPosSumSourceDataBean> combinedSpot = new ArrayList<>(acSplit.getSpotList());
        combinedSpot.addAll(spotMapped);
        List<TPosSumSourceDataBean> combinedSwap = new ArrayList<>(acSplit.getSwapList());
        combinedSwap.addAll(itMapped);

        SourcePositionSplit split = new SourcePositionSplit(combinedSpot, combinedSwap);
        evaluationService.evaluate(contribution, targetDate, split, allSourceList, dfCalcResult, dfHistory,
                EvaluationRateKbn.AFTER_CLOSING_PRICE.getCode(), preClosingPlList);
    }
}
