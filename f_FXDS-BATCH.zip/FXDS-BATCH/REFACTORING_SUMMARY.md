# jbpos1000 → jbpos1100 リファクタリング サマリー

対象: 大和証券 FX ポジション集計常駐バッチ（Spring Batch + MyBatis）
方針: **既存 `jp.co.daiwa.jbpos1000` は一切変更せず**、改善版を新パッケージ
`jp.co.daiwa.jbpos1100` として作成。

---

## 現在のステータス（2026-07-02 時点）

jbpos1000 の原本破損が修復され**権威リファレンス**となったことを受け、jbpos1100 を再検証・修正した。
さらに 2026-07-02 に jbpos1000 の**全メソッド棚卸し（6 クラス・71 メソッド）による全数突合**を実施した。

- ✅ **全数突合完了・未移行機能ゼロ**。突合表は MIGRATION_MAPPING.md §3（全メソッド網羅）。
  「対応なし（意図的）」は setter→コンストラクタ注入化など設計刷新によるもので、機能欠落ではない。
- ✅ **jbpos1100 単体でコンパイル可**（JDK 11 + Maven）。
- ✅ **全 58 テストがパス**（再検証前は 50 中 41 パス／9 失敗）。
- ✅ **`runOnce` は権威 `posSumTask` と 1 対 1 で結線完了**。文書化された結線ギャップ（T-1〜T-4、G-A〜G-I）は**すべて解消**。jbpos1100 内に未解決 TODO/FIXME は無い。
- ✅ **既知不具合 4 種（Map.put 戻り値／BigDecimal `==`／文字列・enum `!=`／throws 句）の残存ゼロ**を
  jbpos1100 全体に対して機械検査で確認（§3 参照）。
- ✅ **サイズ基準充足**: 全クラス 500 行未満（最大 479 行）、80 行超メソッドは `runOnce`（100 行）のみ
  だったため工程単位（`refreshSourceTable` ／ `evaluateClosingPhases`）に分割し解消。結線順序・挙動不変
  （分割後も 58/58 テストパス）。
- ✅ jbpos1000 は一切未変更（変更はすべて jbpos1100 とコンパイル補足用スタブのみ）。

### 再検証で判明・修正した移植不忠実（旧 §6.4 の「テスト失敗」は仕様未確定ではなく実装バグと確定）

| ID | 対象 | 内容 |
|---|---|---|
| C-1 | `PositionSummaryComposition` | `buildRateLookupContext` 未定義によるコンパイルエラー → 実装（旧 `posSumSourceDataMapping` の取得＋`getPosSumManualRate`/`getDfarmBbgRateBean` を集約） |
| H-1 | `SpotClosingRateResolver#copyWithRates` | 約定日時を `new Timestamp(getTime())` でラップ → 旧 `setClosingRate` L397 に合わせ**参照コピー**へ（NULL 時 NPE を解消） |
| H-2 | `SpotClosingRateResolver#resolveClosingYenRate` | 旧 L458-503 の**3分岐**（①マニュアルTTM ②約定済CF以外 ③約定済CF）のうち②のみの不完全移植 → 3分岐を忠実再現（`resolve` に `manualRateList` 追加） |
| H-3 | `CurrencyDeltaCashCalculator` | PV 集計を先行実行し非 null-safe `sum` で NPE → 旧は null チェックで集計をゲート。`sumNullSafe` へ変更（観測挙動同一・NPE 回避） |
| H-4 | テスト | `SourceDataMapperTest`（有効条件は `tradeRate!=null && dealerBook!=null && deliveryDate!=null`。実装が正・テストが誤り）、`AfterClosingEvaluationServiceTest`（final な `RateLookupContext` を実インスタンス化） |

詳細は §5.13 / §6.4 / §6.5 を参照。

---

## 0. 前提（重要）

旧コードには以下の制約があり、本成果物は「機械的に確実な改善は完全実装」「金融計算の
破損箇所は捏造せず明示」という方針を採る（自社 CLAUDE.md の「破損箇所を推測で埋めない」に準拠）。

1. **外部依存型が本リポジトリに存在しない**（約 40 種: `TPosSumSourceDataBean` /
   各 `*Repository` / `FxdConstants` / `EvaluationRateKbn` / `DBUtil` など）。
   → 新コードは実プロジェクトに戻して初めてコンパイル可能。
2. **原本破損により業務ロジックが復元不能な箇所がある**
   （`setClosingRate` / `setSourceData` / `posSumSourceDataMapping` /
   `mkSwapPlSumDate` の型不整合・制御構造崩壊・文字化け）。
   → Real/プレ引値/引値/引値以降のスポット・スワップ集計本体は、原本（非破損版）と
   突き合わせて移植する前提とし、FIXME で明示している。

---

## 1. 新パッケージ構成（①責務分割）

```
jp.co.daiwa.jbpos1100
├── common   … 横断的共通処理
│   ├── BatchConstants               定数集約（二重定義・隠蔽の排除）
│   ├── TransactionalBatchExecutor   中間コミット＋1件リトライのテンプレート（②の中核）
│   ├── DbWork / BatchInsert         実行する DB 操作を渡す関数型 IF
│   ├── JobWarningReporter           ジョブ警告状態＋警告ログの一元化
│   ├── DbConnectionFailures         DB 切断判定の一元化
│   ├── ListPartitioner              リスト分割（DBUtil 非依存・テスト容易化）
│   └── BigDecimalSummer             BigDecimal 合計
├── source   … 集計元（ポジション集計元情報）
│   ├── PositionSourceRepositoryGateway   取得（旧 JbPositionDbOperation）
│   ├── PositionSourceMatcher             突合・ディーラブック（旧 JpPositionDataOperation）
│   └── PositionSourceStore               中間コミット永続化
├── rate     … レート取得
│   ├── BaseRateFileReader
│   └── CloseRateFileReader
├── spot     … スポット集計
│   └── SpotSumStore
├── swap     … スワップ集計
│   ├── SwapSumStore
│   └── SwapPlSumStore
├── delta    … 通貨別デルタ・キャッシュ残／PL デルタ
│   ├── CurrencyDeltaCashCalculator       集計（P0 バグ修正済み）
│   ├── CurrencyDeltaCashStore
│   ├── PlDeltaCalculator                 決済通貨外貨 PL デルタ生成（旧 setPosPlDeltaValueData／T-2）
│   └── PlDeltaStore
└── tasklet  … オーケストレーション
    ├── PositionSummaryTasklet            常駐ループのみ
    ├── PositionSummaryCycle              1 サイクルの境界 IF
    ├── PositionSummaryComposition        合成ルート（runOnce＝権威 posSumTask と 1 対 1）
    ├── PositionEvaluationService         1 区分の集計＋永続化（結果を PositionEvaluationResult で返す）
    ├── PositionEvaluationResult          集計成果物ホルダ（日締め複製で再利用）
    ├── ClosingEvaluationService          引値集計＋日締めゲート
    ├── EndOfDayClosingService            引値結果の日締め（03）複製・登録（T-4）
    └── PositionSummaryJobListener
```

> 補足: 1 サイクルのワークフローは `PositionSummaryComposition#runOnce` が直接定義する（§5.12）。
> （旧ドキュメントが挙げていた `PositionSummaryOrchestrator` / `PositionSourcePipelineFactory` は
> 設計検討の段階的構想で、**実コードには存在しない**。）

---

## 2. 設計判断

### ①継承 → 委譲（コンポジション）
- 旧 `Jbpos1000SwapSummary extends Jbpos1000PosSumTasklet` は is-a 関係ではなく
  「`transactionManager`・`logger`・各 Repository をコード共有目的で流用」する誤った継承だった。
  → 各クラスは**自分が必要とする依存だけ**をコンストラクタ注入で受け取る設計に変更。
  例: `PositionSourceRepositoryGateway` は取得に不要な Repository（旧 17 個）を持たず 5 個のみ。
- 「データ取得／突合／集計／永続化／ファイル I/O」を 1 クラスに混在させていた箇所を、
  Gateway / Matcher / Aggregator(Calculator) / Store / FileReader に分離。
- Tasklet は常駐ループのみに薄くし、1 サイクルのワークフロー定義は `PositionSummaryComposition#runOnce` が担う。

### ②中間コミットの共通化
- 旧コードは delete/insert/update の各メソッドで
  「定義生成 → `getTransaction` → 処理 → `commit` → 例外時 `rollback`＋警告」を
  **約 14 箇所コピペ**していた。`TransactionalBatchExecutor` に集約し、各 Store は 1 行委譲に。
- 「一括 INSERT 失敗時に 1 件ずつ再 INSERT」リトライも `bulkInsertWithRetry` に共通化。
- 関数型 IF（`DbWork` / `BatchInsert`）で「実行する DB 操作」だけを渡す設計。

### ③変数名・④クラス名
- 綴り崩れ（`Sopt`/`Lsit`/`ge...`）、"0"/"O" 混在、`Jb`/`Jp` 接頭辞、
  変数なのに PascalCase（`Delta`/`SwapSumData`）などを是正。詳細は `MIGRATION_MAPPING.md`。
- クラス名は「対象＋処理内容＋役割（Gateway/Matcher/Store/Calculator/Reader/Orchestrator）」で命名。

### ⑤クラスサイズ・テスト容易性
- 全新規クラスは 500 行未満（最大 `SpotPositionAggregator` 479 行）、メソッドは 50〜80 行以内。
  唯一 80 行を超えていた `PositionSummaryComposition#runOnce`（100 行）は、集計元テーブル整備
  （`refreshSourceTable` = G-A/G-B/G-C）と引値ガード配下の評価工程群（`evaluateClosingPhases` =
  G-D/G-E 配下）に工程分割した（2026-07-02、結線順序・挙動不変）。
- 依存はすべてコンストラクタ注入。`static` 多用を避け、`PlatformTransactionManager` 等を
  モックに差し替えて JUnit 検証可能（テスト 4 本同梱）。
- 旧コードの**可変 static フィールド**（`static Date targetDate/busiDaysBefore`）を廃止し、
  基準日はサイクル内ローカル変数化（`@Scope("step")` Bean での状態リーク・スレッド安全性を改善）。

---

## 3. 修正したバグ（注意事項対応）

### [P0] `Map.put` の戻り値（旧値）を計算に使用
`Jbpos1000SwapSummary#mkByCcyDeltaCashBalance`（旧 L975-989, L1017-1018, L1287 ほか）:
```java
// 旧（誤り）: put は「直前の値」を返す。各 Map はループ内で都度 new → 初回 put は null → NPE
delta = totaldealAmountPvClsMap.put(key, sumTradeAmountPvCls)
          .add(totaldealAmountPvMap.put(key, sumTradeAmountPv))
          .add(totalsettleAmountPvMap.put(key, sumSettleAmountPv));
```
→ `CurrencyDeltaCashCalculator` で**集計済みローカル値を直接加算**するよう修正:
```java
// 新（正）
delta = sumTradeAmountPvCls.add(sumTradeAmountPv).add(sumSettleAmountPv);
cashBalance = sumDealAmount.add(sumSettleAmount);
```
書き込み専用で読まれなくなった一時 Map 群は不要となるため削除。回帰テスト同梱
（`CurrencyDeltaCashCalculatorTest`）。

### [P1] BigDecimal の `==` 比較 → `compareTo`
`setSpotSumDate` に `getConfirmPosition() == BigDecimal.ZERO`（**参照比較**）が 2 箇所あった。
`subtract` 等で生成された新インスタンスは `== ZERO` が常に false となり、確定PL／累積確定PL の
分岐が誤る不具合。`compareTo(BigDecimal.ZERO) == 0` に修正（jbpos1000 / jbpos1100 双方）。

### [P1] `x.equals(null)` → `x == null`
`setSpotSumDate` の累積確定PL NULL 判定が `getSumPlUnderlyingCcy().equals(null)` だった。
`equals(null)` は常に false（かつ対象が null なら NPE）。`== null` に修正。

### [P1] 文字列/enum コードの `!=` 比較 → `.equals()`
`setSpotSumDate` のファイル作成判定 `evaluationRateKbn != EvaluationRateKbn.PRE_CLOSING.getCode()`
（**文字列の参照比較**）を `!evaluationRateKbn.equals(...)` に修正。その他コード値比較も `.equals()` に統一。

### [調査済み] メソッド宣言の throws 句の位置が不正な箇所

既知不具合として挙げられていた「throws 句の位置不正」を jbpos1000 全 6 クラスで走査した結果:

- **宣言部の不正は現存しない**（原本修復時に解消済み。jbpos1100 はコンパイル可のため構文上も担保）。
- 残っていたのは **Javadoc の誤記**: `Jbpos1000SwapSummary#sumPositionSwapData`（L608）の
  `@throws positionSwapSumDataList` — 例外型ではなく**戻り値の変数名**を記載しており、かつ当該メソッドは
  throws 宣言を持たない。ほか `)throws`（空白欠落、L1080）などの体裁崩れ。
- jbpos1100 では該当メソッドの移植先（`SwapCurrencyAggregator#aggregate` ほか）で Javadoc を正しく整備し、
  誤った `@throws` タグが残存しないことを機械検査で確認済み。

### その他（旧レビューで適用済みの堅牢化を踏襲）
- 常駐ループ内の明示的 `Runtime.getRuntime().gc()` 廃止（GC 阻害）。
- `InterruptedException` 握り潰しを廃止し割り込みフラグ復元。
- 全トランザクションの `rollback(status)` を `status != null` ガード（`TransactionalBatchExecutor` に集約）。
- `printStackTrace()` 廃止 → ロガー出力（`JobWarningReporter`）。
- ファイル I/O の try-with-resources 化、`listFiles()` の null/空ガード、列数・ファイル名長チェック。

---

## 4. テスト（同梱）

`JUnit5 + AssertJ + Mockito`。**本リポジトリ単体で実行可・全 58 テストがパス**（§6 のスタブ＋`pom.xml` 整備による）。
主なもの:

| テスト | 検証内容 |
|---|---|
| `ListPartitionerTest` / `BigDecimalSummerTest` | リスト分割／合計（端数・null セーフ）※外部依存なし |
| `TransactionalBatchExecutorTest` | コミット／ロールバック＋警告／DB 切断再スロー／チャンク分割／1 件リトライ（Mockito） |
| `CurrencyDeltaCashCalculatorTest` | **P0 バグ回帰**（デルタ＝3 PV 合計、キャッシュ残＝売買＋決済、NULL 時 null＝行は生成） |
| `SpotClosingRateResolverTest` | 引値レート／円転レート 3 分岐（H-1/H-2 修正の回帰） |
| `SourceDataMapperTest` | 有効条件（取引レート／ディーラブック／受渡日 必須）の検証ガード |
| `PlDeltaCalculatorTest` | **T-2**：マニュアル優先・決済金額＝売買×取引レート・売買区分・両レート不在の警告 |
| `EndOfDayClosingServiceTest` / `ClosingEvaluationServiceTest` | **T-4**：日締め複製の登録条件（未登録時のみ）と `afterDayClose` ゲート |
| `SwapSummaryServiceTest` / `PositionEvaluationServiceTest` / `AfterClosingEvaluationServiceTest` 等 | 結線（呼出順・委譲）の検証 |

> 注: `runOnce`（合成ルート）は Spring を要するため単体テストは持たず、部品（Store/Mapper/Calculator/Service）を
> それぞれ単体検証する方針。

---

## 5. 破損メソッドの修正・移植状況（追補）

当初「6メソッドが原本破損」としていたが、精査の結果**実際に破損していたのは 4 メソッド**だった。

### 5.1 jbpos1000 側で修正済み（原本修正）

| メソッド | ファイル | 修正概要 |
|---|---|---|
| `setClosingRate` | Tasklet | getDeaiCurrency→getDealCurrency、findFirst補完、括弧不整合、円転レート選択の制御構造を標準パターンで復元 |
| `setSourceData` | Tasklet | continue後の制御構造崩壊をガード節へ再構成、DATA_SOURCE_BID→BIDR、未定義変数修正 |
| `posSumSourceDataMapping` | Tasklet | 型不整合(Currency/ICurrency→TCurrencyMstBean)、collect誤用、未定義変数、findFirst補完、baseRateMap型修正 |
| `mkSwapPlSumDate` | SwapSummary | 呼出側に合わせ Dto→Bean に型統一 |

### 5.2 破損していなかった（訂正）

- `getTPosCashSumData` / `sumPositionSwapData` は**破損なし**。`map.put(k,v)` 直後に
  `map.get(k)` で読んでおり put 戻り値の誤用ではない（冗長なだけ）。問題は変数名
  （`posdata`/`Delta`/`totaldealAmount...Map`）のみで、これは jbpos1100 移植時の
  リネーム対象であり破損修正対象ではない。

### 5.3 jbpos1100 へ移植済み（修正後ロジックの移植）

| 移植先クラス | 元メソッド | テスト |
|---|---|---|
| `spot.SpotClosingRateResolver` | `setClosingRate` | `SpotClosingRateResolverTest` |
| `source.SourceDataMapper` | `setSourceData` | `SourceDataMapperTest` |
| `swap.SwapPlSumCalculator` | `mkSwapPlSumDate` | `SwapPlSumCalculatorTest` |
| `delta.CurrencyDeltaCashCalculator` | `mkByCcyDeltaCashBalance` | `CurrencyDeltaCashCalculatorTest` |
| `source.PositionSourceRateMapper` | `posSumSourceDataMapping` | （`RateLookupContext` 経由でデータ取得を外出し） |
| `rate.YenRateResolver` | `getRealJpyRate` / `getClosingJpyRate` | `YenRateResolverTest` |
| `rate.RateLookupContext` | （レート照会データの不変ホルダ・新規） | — |
| `swap.SwapCashSumAssembler` | `getTPosCashSumData` | （PV項目ごとに段階分割・ロジック不変） |
| `swap.SwapCurrencyAggregator` | `sumPositionSwapData` | （通貨単位纏め・冗長Map除去で挙動不変） |
| `spot.SpotPositionAggregator` | `setSpotSumDate` | （逐次状態を保持しつつ段階分割・== / equals(null) バグ修正反映）／`SpotPositionAggregatorTest` |

> `getTPosCashSumData` / `sumPositionSwapData` は破損していなかったため、計算式・符号・
> 丸め（HALF_UP, scale=2）・NULL チェック時の既定値を一切変えず、500行制約のための
> 段階メソッド分割と変数リネームのみ行った。項目単位の計算エラーは警告ログのみ
> （ジョブ警告状態を立てない＝旧挙動）、例外時のみジョブ警告状態を設定する点も踏襲。

### 5.4 結線（オーケストレーション）

- **スワップ集計パイプラインを結線済み**: `swap.SwapSummaryService` が旧 `mkPositionSwapSumData` の
  計算工程を移植済み部品へ委譲し、同一順序で実行する:
  `SwapCashSumAssembler → SwapCurrencyAggregator → CurrencyDeltaCashCalculator → SwapPlSumCalculator`。
  結果は `SwapSummaryResult` に集約。結線テスト `SwapSummaryServiceTest`（Mockito で呼出順を検証）同梱。
- 集計元パイプライン（取得→突合→削除→変換→レート割当→中間コミット登録）は
  `PositionSummaryComposition#runOnce`（＋`collectSource`/`buildMatcher`）で結線済み。

### 5.5 評価レート区分の結線

1 評価レート区分（Real/プレ引値/引値/引値以降）のスポット・スワップ集計を
`tasklet.PositionEvaluationService` に集約・結線済み:

- `source.SourcePositionSplitter` … 集計元をスポット／スワップに振り分け（Real 版 `splitForReal`）
- `spot.SpotSummaryService` … スポット集計（`SpotPositionAggregator`）＋永続化（`SpotSumStore`）
- `swap.SwapSummaryService` … スワップ計算パイプライン
- `SwapSumStore` / `CurrencyDeltaCashStore` / `SwapPlSumStore` … 中間コミット永続化（delete→insert）

結線テスト `PositionEvaluationServiceTest`（Mockito で spot/swap 実行と3成果物の delete→insert を検証）同梱。

### 5.6 振り分け（Splitter）の状況

`source.SourcePositionSplitter` に評価レート区分別の振り分けを実装済み（`SourcePositionSplitterTest` 同梱）:

| メソッド | 旧 | 対象 |
|---|---|---|
| `splitForReal` | `setPosRealData` | スポット＋スワップ |
| `splitForPreClosing` | `setPosPreClosingData` | スポットのみ |
| `splitForClosingSwap` | `setClosingValueData`（スワップ抽出） | スワップのみ（スポットは DB 集計結果由来） |

Pre/Closing の「引値ウィンドウ判定」（当日00:00-20:59&AC=0／休日作成／スタート／前営業日以前AC）は
`isWithinClosingWindow` に共通化。

### 5.7 引値以降（After）補助メソッドの移植

旧 `setClosingAfterValueData` の複合フローのうち、自己完結する補助ロジックを移植済み:

| 移植先クラス | 旧 | テスト |
|---|---|---|
| `swap.SwapItTradeUnitAggregator` | `setPosSwapItData` ＋ `setTradeUnitTransaction` | `SwapItTradeUnitAggregatorTest` |
| `spot.SpotCloseCostReplacer` | `setSpotCloseSumCostReplace` | `SpotCloseCostReplacerTest` |

`SwapItTradeUnitAggregator` には **Map.put 戻り値バグの修正**（NULL金額通貨での NPE 回避）を反映。

#### jbpos1000 側で追加修正した Map.put バグ（同パターン・複数箇所）
- `setTradeUnitTransaction`（売買区分・売買金額の算出）
- `mkByCcyDeltaCashBalance`（デルタ／キャッシュ残の算出。jbpos1100 では `CurrencyDeltaCashCalculator` で修正済みだったが、原本側も修正し整合）

### 5.8 引値以降（After）全体オーケストレーション

`tasklet.AfterClosingEvaluationService` に旧 `setClosingAfterValueData` の複合フローを結線済み:

1. `SourcePositionSplitter.splitForAfterAc` … 当日 AC=1 のスポット／スワップ（AC 分）抽出
2. `SourcePositionSplitter.splitForClosingSwap` → `SwapItTradeUnitAggregator` → `PositionSourceRateMapper`
   … IT 分スワップの通貨ネット＋レート再割当
3. `SpotCloseCostReplacer` → `PositionSourceRateMapper` … スポット引値結果のコスト持ち替え＋レート再割当
4. スポット＝AC分＋持ち替え分、スワップ＝AC分＋IT分 を組み立て、`PositionEvaluationService` へ委譲
   （集計＋永続化を共通利用）

結線テスト `AfterClosingEvaluationServiceTest`（結合リストと引値以降区分での委譲を検証）同梱。
これで Real／プレ引値／引値／引値以降の **4 区分すべて**が部品・結線まで揃った。

### 5.9 DB 由来スポットの取得・変換と引値サービス

- `source.ClosingSpotSourceLoader` … 旧 `setSpotSumData`（プレ引値スポット結果→集計元）／
  `setDeltaData`（PL デルタ→集計元）／引値スポット結果取得（引値以降の入力）を集約。
- `tasklet.ClosingEvaluationService` … 旧 `setClosingValueData` を結線。スポット＝プレ引値結果＋PL デルタ、
  スワップ＝引値ウィンドウ抽出、を引値区分で `PositionEvaluationService` へ委譲。
  結線テスト `ClosingEvaluationServiceTest` 同梱。

これで Real／プレ引値／引値／引値以降の **4 区分すべて**が、集計元の構築から集計・永続化まで
専用サービスで結線済みとなった。

### 5.10 ファイル出力の抽象化

- `file.PositionSumFileWriter`（IF）／`file.DefaultPositionSumFileWriter`（既定実装）を追加。
  外部ユーティリティ `Jbpos1000PositionSumDateFileUtil` の static 呼び出しを**注入可能な境界**に置き換え
  （要件: static 多用を避けモック可能に）。実ファイル書き込みは外部ユーティリティへ委譲（再実装しない）。
- `PositionEvaluationService` にファイル出力を集約: スポットはプレ引値以外（旧 `setSpotSumDate` のガード踏襲）、
  スワップは結果ありの場合のみ出力。`PositionEvaluationServiceTest` でファイル出力呼び出しも検証。

### 5.11 日締めデータ複製

- `common.EndOfDayClosingDuplicator` … 旧 `setClosingData` / `setSwapClosingData` /
  `setCcyDeltaCashClosingData` / `setSwapPlSumClosingData` を 1 クラス（4 メソッド）に集約。
  各項目を複製し評価レート区分のみ日締め（03）へ差し替える。綴り誤り `closingDataLsit` を是正。
  テスト `EndOfDayClosingDuplicatorTest` 同梱。
- 適用条件（システム日時が日締め時刻以降かつ引値区分のとき END_OF_DAY を delete→insert）の
  呼び出しは、最終 Spring 配線（次項）で `ClosingEvaluationService` から行う。

### 5.12 最終 Spring 配線

- `src/main/resources/META-INF/jobs/jbpos1100.xml` … 旧 `jbpos1000.xml` 相当。`jp.co.daiwa.jbpos1100` の
  component-scan、mybatis スキャン、ステートレス Bean（gateway/各 resolver/loader/splitter/duplicator/fileWriter）、
  job/step/tasklet/listener を宣言。
- `tasklet.PositionSummaryComposition`（`@Component @Scope("step")`、`PositionSummaryCycle` 実装）… 合成ルート。
  サイクル単位で `JobWarningReporter`／`TransactionalBatchExecutor`／各 Aggregator・Calculator・Store・評価サービスを
  構築し、集計元の収集→検証/変換→登録、Real／プレ引値／引値／引値以降の各評価工程へ委譲する。
  `PositionSummaryTasklet` には本クラスが注入される（唯一の `PositionSummaryCycle` Bean）。
- 実行時の合成ルートは `PositionSummaryComposition` のみ（`PositionSummaryCycle` の唯一の実装 Bean）。
  旧ドキュメントが挙げていた `PositionSummaryOrchestrator` ／ `PositionSourcePipelineFactory`（抽象ファクトリ版）は
  構想のみで**実コードには存在しない**ため、本リファクタリングでは採用していない。

#### 配線で残る整備ポイント（`PositionSummaryComposition` 内に TODO 明示）
- ✅ **解決済み**：集計元マッチャへ供給するマスタ／トレードデータ取得（gateway の取得 API 整備）。
  旧 `Jbpos1000PosSumTasklet#init`（取得→`JpPositionDataOperation` へセット）を `collectSource` /
  `buildMatcher` へ忠実移植。gateway に `getCurrencyMstData` / `getDfitTradeExchangeRawData` を追加。詳細は §6.3。
- ✅ **解決済み**：DF 算出結果／DF 履歴の取得（`dfCalcResultRepository` / `dfHistoryRepository` から取得・適用）。
- ✅ **解決済み T-1（=G-C）**：`buildRateLookupContext` で `RateLookupContext`（ベース/引値/通貨マスタ/
  マニュアル/BBG）を構築し、`PositionSourceRateMapper.map` を登録前に適用。
- ✅ **解決済み T-2（=G-H）**：決済通貨外貨 PL デルタ生成（旧 `setPosPlDeltaValueData`）を `PlDeltaCalculator`
  ＋`generatePlDelta()` で移植・適用。
- ✅ **解決済み T-3（=G-G）**：引値以降の再マッピング用 `RateLookupContext` を `afterService` へ実供給。
- ✅ **解決済み T-4（=G-I）**：日締めデータ複製を `EndOfDayClosingService`（`EndOfDayClosingDuplicator`＋各 Store）
  ＋時刻ゲート（`afterDayClose`）で適用。

### 5.13 残課題

- ✅ **解決済み**：§5.12 の残 TODO（**T-1〜T-4**）はすべて結線完了（§6.5 参照）。
  - T-1（レート割当適用＝G-C）／T-3（引値以降再マッピング＝G-G）／T-2（PL デルタ生成）／T-4（日締め複製）。
- ✅ **解決済み**：円転レート選択 (a)(b)(c) は推定復元ではなく、修復済み jbpos1000 `setClosingRate` L458-503 の
  3分岐を忠実移植（§現在のステータス H-2）。ただし業務観点での**実データ検証は引き続き推奨**。
- ⏳ **実プロジェクト復帰時の確認事項（コードバグではない）**:
  - 例外メッセージ文字列照合による DB 切断判定（`DbConnectionFailures`）は専用例外型へ置換が望ましい。
  - 外部依存型スタブの**推定値**（評価レート区分/為替区分コード・`FxdConstants` の各値）は正規値で要検証（§6.2）。
  - `daodfit.TDfitTradeExchangeRepository#getDfitTradeExchangeFxdsData` は旧コードで呼び出しのみ＝実 DAO 側に存在。
    シグネチャ移植に留めている（§6.3）。
  - コンパイル補足用スタブ（`jp.co.daiwa.*`）は実型へ差し替えのうえ削除する（§6.1、§6.6）。

---

## 6. ビルド基盤の整備と単体コンパイル可能化（追補）

§0 で「本リポジトリ単体ではコンパイル不可（外部型が約 40 種未配置）」としていたが、
**コンパイル補足用スタブと Maven ビルド定義を追加し、jbpos1100 を単体でコンパイル可能**にした
（JDK 11 + Maven で `main` / `test` とも `BUILD SUCCESS` を確認）。

### 6.1 追加したビルド定義 / スタブ

- **`pom.xml`**（新規）… JDK 11・`javax.*` 系に合わせて選定。
  - `spring-batch-core` 4.3.10（`StepContribution` / `Tasklet` / `RepeatStatus` 等）、
    `spring-context` / `spring-tx` 5.3.39、`javax.inject` 1、`mybatis` / `mybatis-spring`、
    テストに JUnit5 / Mockito / AssertJ。
  - `maven-compiler-plugin` で **旧 `jbpos1000` をビルド対象から除外**（原本破損でコンパイル不能のため。
    jbpos1100 は jbpos1000 に非依存）。
- **外部依存型のスタブ**（約 45 ファイル, `jp.co.daiwa.{base,common,common.constant,dao,dao.bean,daobid,daodfit,dto}`）…
  jbpos1100 が参照するメンバのみを持つ最小定義。実プロジェクトへ戻す際は**削除**し本物の型でビルドする。
  - **Spring / javax.inject 等の第三者ライブラリはスタブ化せず**、`pom.xml` の依存として解決する。

### 6.2 注意（スタブの推定値）

スタブの enum コード値（`EvaluationRateKbn`=00/01/02/03/99、`ExchangeKbn`、`ProductEnum`）と
`FxdConstants`（`DB_IO_EXCEPTION` / `CONTEXT_*` / `KEY_TAB` / `COMMA`）は、jbpos1100 内のコメント・分岐から
**推定した暫定値**。コンパイルには十分だが**実行時の業務判定に影響**するため、実プロジェクトの正規値で要検証。

### 6.3 `collectSource()` TODO の解決（集計元マッチャ供給）

旧 `Jbpos1000PosSumTasklet#init`（L3384–3404）の取得・セット処理を `PositionSummaryComposition`
（`collectSource` / `buildMatcher`）へ忠実移植し、`PositionSourceMatcher` の 7 入力を gateway 経由で供給する。

- `PositionSourceRepositoryGateway` に **`getCurrencyMstData()`**（`TCurrencyMstRepository.getTCurrencyMstAll()`）と
  **`getDfitTradeExchangeRawData(STATUS_LIST, 前営業日)`** を追加（コンストラクタに `TCurrencyMstRepository` を追加、
  `jbpos1100.xml` の bean 定義に `tCurrencyMstRepository` を追記）。
- `PositionSummaryComposition` に `@Value("${job.jbpos1000.time}") dayCloseTime` と
  `STATUS_LIST = ["2","3"]`（旧定数）を追加。
- **限界**：`getDfitTradeExchangeFxdsData`（DFIT 為替トレード生 Bean 取得）は旧コードで定義が見当たらず、
  実 DAO（MyBatis マッパー）側にのみ存在するため**シグネチャ移植（通過）に留める**。

### 6.4 テスト初回実行で顕在化した不具合 → **全件解決済み（58/58 パス）**

本リポジトリで初めてテストが実行可能になった時点では **50 件中 41 件成功・9 件失敗**だった。
修復済み jbpos1000 と突き合わせた結果、失敗の根因は「仕様未確定」ではなく**jbpos1100 側の移植不忠実**と
確定し、すべて修正した（権威に一致させる形で実装またはテストを是正）。

| 失敗テスト | 根因 | 対応（権威基準） |
|---|---|---|
| `SpotClosingRateResolverTest`（5） | `copyWithRates` が約定日時を `new Timestamp(getTime())` でラップ → NULL で NPE | 旧 `setClosingRate` L397 の**参照コピー**へ修正（H-1）。これに伴い `import java.sql.Timestamp;` は不要となり除去 |
| `SourceDataMapperTest`（2） | 実装は正（有効条件 `tradeRate!=null && dealerBook!=null && deliveryDate!=null`＝旧 L542）。**テストが誤り**（有効データに `tradeRate` 未設定） | テストを修正（有効 dto に `tradeRate` を設定）（H-4） |
| `CurrencyDeltaCashCalculatorTest`（1） | PV 集計を先行実行し非 null-safe `sum` で NPE → catch で行が生成されず空 | `sumNullSafe` へ変更。旧は null チェックで集計をゲートし行は必ず生成（H-3） |
| `AfterClosingEvaluationServiceTest`（1） | `mock(RateLookupContext.class)`：`final` クラスで Mockito 不可 | 実インスタンス生成へ変更（H-4） |

> コンパイル補助で残置している軽微なスタブ補完:
> - `dto.PosSumSourceDto` の `getTradeDate`/`setTradeDate`（`tradeDatetime` と同一フィールドの別名）。
>   本体は `getTradeDatetime`、テストは `setTradeDate` を使用する不一致への対応。

### 6.5 オーケストレーション（`runOnce`）— **全結線完了（権威 `posSumTask` と 1 対 1）**

修復済み jbpos1000（`posSumTask` L250–344）を権威リファレンスとして `PositionSummaryComposition#runOnce`
と突き合わせ、判明した差分（G-A〜G-I）を**すべて結線した**。下表は最終状態。

| ID | 旧 `posSumTask` の工程 | jbpos1100 の結線（解決済み） |
|---|---|---|
| **G-A** | 集計元の事前 DELETE（`posSumSourceDataDelete`、基準日） | ✅ runOnce 冒頭で `sourceStore.delete(condition: 基準日)` |
| **G-B** | 日締め生成スタートポジションの再マッピング＋`posSumSourceDataUpdate` | ✅ 削除後に再取得 → `rateMapper.map` → `sourceStore.update`（非空時） |
| **G-C**（=T-1） | `posSumSourceDataMapping`（レート割当）を登録前に適用 | ✅ `rateMapper.map(targetDate, sourceBeans, rateContext)` を insert 前に適用 |
| **G-D** | `setClosingRate`（引値レート再設定）→ Pre/Closing/After へ供給 | ✅ `spotClosingRateResolver.resolve(...)`＝`closingResolved` を Pre/Closing/After に供給 |
| **G-E** | `closeRateList.size()>0` を Pre/PLデルタ/Closing/After の実行ガードに使用 | ✅ `if (!rateContext.getCloseRateList().isEmpty())` 配下で実行 |
| **G-F** | レート照会データ取得（`BaseRateFileReader`/`CloseRateFileReader`） | ✅ `buildRateLookupContext` で両 Reader を実行し `RateLookupContext` に集約 |
| **G-G**（=T-3） | 引値以降の再マッピング用 `RateLookupContext` | ✅ `afterService.evaluate(..., rateContext, ...)` に実コンテキストを供給 |
| **G-H**（=T-2） | `setPosPlDeltaValueData`（決済通貨外貨 PL デルタ登録） | ✅ `PlDeltaCalculator`＋`generatePlDelta()`（既存削除→生成→登録）。§5.13/§現在のステータス |
| **G-I**（=T-4） | 日締めデータ複製（システム時刻≥`dayCloseTime`＆引値時） | ✅ `EndOfDayClosingService`＋`afterDayClose` 時刻ゲート（引値後に 4 種を複製・登録） |

**孤立クラスは解消**：`BaseRateFileReader` / `CloseRateFileReader` / `SpotClosingRateResolver` /
`PlDeltaStore` / `EndOfDayClosingDuplicator`、`PositionSourceStore.delete` / `.update` はすべて `runOnce`
から呼ばれている。新規追加: `delta.PlDeltaCalculator`（T-2）、`tasklet.EndOfDayClosingService` /
`tasklet.PositionEvaluationResult`（T-4）。

> **総括**：個々の部品（集計・永続化・突合・レート選択）の移植（§5）に加え、**結線層（`runOnce`）も完成**。
> `runOnce` は権威 `posSumTask` の工程順（DELETE→スタートポジション更新→収集・登録→Real→\[引値レート有り\]
> 引値レート再設定→プレ引値→PL デルタ→引値→引値以降→日締め複製）と 1 対 1 で対応する。

### 6.6 再検証（T-2/T-4 結線）で行ったスタブ補完

実型は実プロジェクトに存在するが、コンパイル補足用スタブに不足していたメンバを追加した（実型復帰時は不要）。

| 追加先（スタブ） | 追加メンバ | 用途 |
|---|---|---|
| `dao.bean.TPositionPlDeltaDataBean` | `registerUser`/`registerDatetime`/`updateUser`/`updateDatetime` の getter/setter | PL デルタ生成（T-2、旧 `setPosPlDeltaValueData` が設定する項目） |
| `dao.TPositionSwapSumDataRepository` | `getPositionSwapSumDataList(condition)` | 日締め（03）既存有無の照会（T-4） |
| `dao.TByCcyDeltaCashBalanceRepository` | `getByCcyDeltaCashBalanceList(condition)` | 同上（T-4） |
| `dao.TSwapPlSumDateRepository` | `getSwapPlSumDateList(condition)` | 同上（T-4） |
| `common.BatchConstants` | `EXCHANGE_DIVISION_SPOT = "0"` | PL デルタの為替区分（スポット）。旧 `setExchangeDivision("0")` の定数化 |

---

## 7. 今後の改善方針（機能移植完了後の品質向上）

> 前提: 集計ロジックの移植・結線は完了済み（**コンパイル可・全 58 テストパス・jbpos1000 準拠**）。
> 本章は**機能を変えずに**保守性・テスト容易性・堅牢性を高めるための方針で、いずれも任意・段階適用可。
> 着手時は各項目とも「リファクタ前後でテスト緑を維持」を必須条件とする。

### 7.1 優先度サマリー

| # | 区分 | 改善項目 | 優先度 | 挙動変更 |
|---|---|---|---|---|
| I-1 | 保守性 | `BigDecimalSummer.sum`（非 null-safe）の footgun 解消 | 高 | 無 |
| I-2 | 保守性 | Store 構築の重複排除（`PositionSummaryComposition`） | 高 | 無 |
| I-3 | 可読性 | `runOnce` の工程分割（長メソッド解消） | 中 | 無 |
| I-4 | 保守性 | `EndOfDayClosingService` の存在確認 4 メソッドの定型重複解消 | 中 | 無 |
| I-5 | テスト | 合成ルート（`runOnce`）の結線スモークテスト追加 | 中 | 無 |
| I-6 | テスト | カバレッジ計測（JaCoCo）導入・80% 目標 | 中 | 無 |
| I-7 | 堅牢性 | `DbConnectionFailures` の例外メッセージ照合 → 専用例外型 | 中 | 小 |
| I-8 | 移行 | コンパイル補足スタブの削除・実型ビルド・CI 化 | 高 | 無 |
| I-9 | 設計 | `PositionEvaluationService` の delete を「存在時のみ」へ（権威準拠） | 低 | 小 |

### 7.2 詳細

#### I-1. `BigDecimalSummer.sum` の footgun 解消（高）
- 問題: `sum` は要素 NULL で NPE（実際に H-3＝`CurrencyDeltaCashCalculator` の不具合を誘発）。`sumNullSafe` と紛らわしい。
- 方針: ①`sum` の Javadoc に「NULL 非許容」を明示済みだが、さらに呼び出し側を棚卸しし、NULL を取り得る集計は
  すべて `sumNullSafe` に統一。②将来的には `sum` を非推奨化し、用途を「NULL を許容しない確定値の合計」に限定。
- 検証: 既存 `BigDecimalSummerTest` / `CurrencyDeltaCashCalculatorTest` を維持。

#### I-2. Store 構築の重複排除（高）
- 問題: `SpotSumStore`/`SwapSumStore`/`CurrencyDeltaCashStore`/`SwapPlSumStore` を `buildEvaluationService` と
  `buildEndOfDayClosingService` の **2 箇所で重複生成**している。
- 方針: サイクル単位の `StoreBundle`（4 Store を保持）を 1 度だけ構築し、両サービスへ渡す小さなファクトリへ集約。
- 効果: 生成箇所の一元化・引数の取り違え防止。挙動は不変（Store はステートレス）。

#### I-3. `runOnce` の工程分割（中）
- 問題: `runOnce` が「協調オブジェクト構築 → G-A/G-B → 収集・登録 → DF 取得 → Real → 引値チェーン」と長い。
- 方針: 工程を private メソッドへ抽出（例: `preDeleteAndRemapStartPositions(...)` /
  `collectAndRegisterSource(...)` / `evaluateRealAndClosingChain(...)`）。権威 `posSumTask` との 1 対 1 対応の
  コメントは維持し、各メソッド冒頭に対応工程を明記。
- 注意: 合成ルートの依存はフィールドインジェクションのままでよい（配線層の制約）。抽出は純粋な可読性向上。

#### I-4. `EndOfDayClosingService` の存在確認の重複解消（中）
- 問題: `existsSpotEndOfDay`/`existsSwapEndOfDay`/… の 4 メソッドが「条件 Bean 生成 → 区分=03 → 照会 → 空判定」
  という定型を繰り返している（型のみ異なる）。
- 方針: `Function<Date, List<?>>`（区分 03 の照会）と複製・登録を組にしたジェネリックヘルパ
  もしくは各種別の小さな関数オブジェクトに集約。冗長度を下げつつ「未登録時のみ INSERT」の不変条件を 1 箇所に。

#### I-5. 合成ルートの結線スモークテスト（中）
- 問題: `runOnce`（合成ルート）は Spring 依存のため単体テストが無い（部品は個別検証済み）。
- 方針: ①軽量な統合テスト（`@SpringJUnitConfig` でモック DAO を注入し、1 サイクルの呼出順・各 Store 呼出を検証）、
  または ②`runOnce` の工程を協調オブジェクト（I-3 で抽出）として切り出し、Mockito で呼出順をユニット検証。
- 目的: 結線回帰（工程の抜け・順序逆転）を CI で検出可能にする。

#### I-6. カバレッジ計測の導入（中）
- 方針: `pom.xml` に JaCoCo を追加し、`jp.co.daiwa.jbpos1100` を対象にライン/分岐カバレッジを計測。自社規約の
  **80% 最低**を閾値に設定（合成ルート等の測定除外は最小限に）。

#### I-7. DB 切断判定の型安全化（中）
- 問題: `DbConnectionFailures` は例外メッセージ文字列（`FxdConstants.DB_IO_EXCEPTION`）の `contains` 照合で
  DB 切断を判定しており、メッセージ変更に脆い。
- 方針: 実プロジェクトの DB 例外型（`DataAccessResourceFailureException` 等）での判定に置換、もしくは専用例外で
  ラップ。`PositionSummaryTasklet` / 各 Calculator の切断時 break/rethrow ロジックは現状の挙動を維持。

#### I-8. スタブ削除・実型ビルド・CI 化（高・実プロジェクト復帰時）
- 方針: §6 の補足用スタブ（`jp.co.daiwa.{base,common,dao,dao.bean,daobid,daodfit,dto}`）を実型へ差し替えて削除し、
  実プロジェクトでビルド。スタブの推定 enum/定数値（評価レート区分・為替区分・`FxdConstants`）を正規値で確定。
  あわせて `node`/CI ではなく実プロジェクトの CI（Maven）で `jbpos1100` のテストを常時実行。

#### I-9. 既存有無による削除要否判定（低・任意）
- 現状: `SpotSummaryService` / `PositionEvaluationService` は毎回無条件で delete→insert（存在しなければ no-op）。
- 権威: 旧コードは事前 SELECT で存在時のみ delete。挙動差は無いが、無駄な DELETE を避けたい場合は
  「件数 0 のとき delete をスキップ」を追加してもよい（性能最適化目的・任意）。

### 7.3 非対象（意図的に変更しない）

- jbpos1000 の修正（**変更禁止**＝権威リファレンス）。
- 移植済みロジックの計算式・符号・丸め・NULL 既定値（jbpos1000 準拠を維持）。
- `runOnce` と権威 `posSumTask` の 1 対 1 対応（工程の順序・ガード条件）。
