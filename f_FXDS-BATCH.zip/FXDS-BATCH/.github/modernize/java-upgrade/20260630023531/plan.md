# Upgrade Plan: FXDS-BATCH (20260630023531)

- **Generated**: 2026-06-30 02:35:31
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 11: not available (baseline will be skipped)
- JDK 25: **<TO_BE_INSTALLED>** (required by the target runtime)

**Build Tools**
- Maven: available via system Maven
- Maven Wrapper: not present

## Guidelines

- Upgrade the Java runtime to the latest LTS version.
- Keep the change focused on the build/runtime configuration and preserve existing application behavior.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260630023531
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| ---------------------- | ------- | ---------------------- | ---------------- |
| Java | 11 | 25 | User requested |
| Maven Compiler Plugin | 3.13.0 | 3.11.0 | Recommended for better Java 21+ support |
| Surefire Plugin | 3.2.5 | 3.0.0 | Recommended for modern JDKs |

## Derived Upgrades

- Java 25 requires a newer compiler target and modern toolchain support.
- Maven compiler settings should be aligned with the target JDK via `maven.compiler.release`.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | maven.compiler.release | 11 | upgrade | 25 | User requested Java 25 target |
| pom.xml | maven-compiler-plugin | 3.13.0 | upgrade | 3.13.0 | Already compatible with modern JDKs |
| pom.xml | maven-surefire-plugin | 3.2.5 | upgrade | 3.2.5 | Already compatible |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| None expected | - | - | No source changes required for the compiler target change | Runtime target is configured in Maven |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| pom.xml | maven.compiler.release | 11 | 25 | Target newer LTS JDK |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None detected | - | - | No CI/CD files found |

### Risks & Warnings

- The project may need a compatible JDK installed locally before verification can run.
- If source incompatibilities appear under the newer JDK, they should be addressed minimally.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install the required JDK so Maven can compile with the requested runtime.
  - **Changes to Make**: Install JDK 25 and confirm availability.
  - **Verification**: `java -version` and `mvn -version`

- Step 2: Setup Baseline
  - **Rationale**: Capture the current build state before changing the target runtime.
  - **Changes to Make**: Run the existing Maven build to establish a baseline.
  - **Verification**: `mvn clean test-compile -q && mvn clean test -q`

- Step 3: Upgrade Java Target Runtime
  - **Rationale**: Switch the project compiler target to Java 25 and align Maven build settings.
  - **Changes to Make**: Apply the pom.xml compiler target change.
  - **Verification**: `mvn clean test-compile -q`

- Step 4: Final Validation
  - **Rationale**: Verify the project compiles and tests pass with the upgraded runtime.
  - **Changes to Make**: Resolve any compatibility issues revealed by the build.
  - **Verification**: `mvn clean test -q`
