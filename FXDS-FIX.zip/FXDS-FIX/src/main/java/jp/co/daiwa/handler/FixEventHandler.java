package jp.co.daiwa.handler;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Value;

import com.fujitsu.fxsvc.FXEventHandler;
import com.fujitsu.fxsvc.FXField;
import com.fujitsu.fxsvc.FXMessage;
import com.fujitsu.fxsvc.FXParam;
import com.fujitsu.fxsvc.FXReason;
import com.fujitsu.fxsvc.FXSequenceNumber;
import com.fujitsu.fxsvc.FXServiceException;
import com.fujitsu.fxsvc.FXTagList;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.FixDateUtils;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.common.parser.FixSessionMsgParser;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dto.ExecutionReportDto;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.FixLogonStatusInfoDto;
import jp.co.daiwa.dto.FixSessionInfoDto;
import jp.co.daiwa.dto.UserNotificationDto;
import jp.co.daiwa.enums.FixEnums.ReceiverResult;
import jp.co.daiwa.enums.FixSessionEnum.FixSession;
import jp.co.daiwa.enums.FixUserNotificationEnum.NotificationType;
import jp.co.daiwa.service.FixEngineService;


/**
 * 富士通FIXエンジンのイベントハンドラ
 *
 * @author
 *
 */
public class FixEventHandler implements FXEventHandler {
    /** 受信電文出力パス1 */
    private String messageReceivedMainPath;

    /** 受信電文出力パス2 */
    private String messageReceivedSubPath;

    /** 受信電文ファイル名 */
    private String receivedFileName;

    /** ログオン状態 */
    private FixLogonStatusInfoDto logonStatusInfo;

    /** セッション情報ファイルパス */
    private String sessionInfoFilePath;

    /** ユーザ通知ファイルパス */
    private String usernotificationFilePath;

    /** セッション区分 */
    private String sessionKbn;

    /** 区切り文字 */
    private String delimitr;

    /** ジョブ処理結果 */
    private FixJobStatusInfoDto fixJobStatusInfo;

    private static long cnt = 0;

    /** 受信処理の異常（受信スレッドで設定し、イベントスレッドで参照するため volatile） */
    private static volatile boolean hasMessageReceivedError = false;

    /** 受信処理スレッドプール（再接続時に差し替えるため volatile） */
    private volatile ExecutorService receiveMsgpool = null;

    /** システム内部エラー時に、クライアントに連携コード */
    private final static Integer INTERNAL_ERROR = 99999;

    @Inject
    @Named("fixEngineService")
    private FixEngineService fixEngineService;

    @Value("#{${fix.tag}}")
    private Map<String, String> fixTagMap;

    /**
     * Logger定義
     */
    private static final FixLogger logger = FixLogger.getLogger(FixEventHandler.class);

    /**
     * コンストラクタ
     *
     * @param logArea ログ出力エリア
     * @return
     */
    public FixEventHandler(FixLogonStatusInfoDto logonStatusInfo, FixJobStatusInfoDto fixJobStatusInfo) {
        this.logonStatusInfo = logonStatusInfo;
        this.fixJobStatusInfo = fixJobStatusInfo;
        receiveMsgpool = Executors.newFixedThreadPool(FixConstants.DEFAULT_THREAD_POOL_SIZE);
        // 処理中止を防止の為、例外ハンドラーを設定する
        Thread.setDefaultUncaughtExceptionHandler(new FixUncaughtExceptionHandler());
    }

    /**
     * 相手側FIXシステムによるFIXセッション切断通知受信時の処理
     *
     * @param param  通知情報
     * @param reason 理由情報
     */
    @Override
    public void disconnectedByPeer(FXParam param, FXReason reason) {
        try {
            // セッション切断警告
            String reasonMsg = reason == null ? null : reason.getReasonTextString();
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W012",
                    FixSession.getByCode(sessionKbn).getName(), Thread.currentThread().getStackTrace()[1].getMethodName() + " Reason:" + reasonMsg);
            // 通知系ファイル更新
            updateNotification(param);
            // 通信パス解放
            fixEngineService.closeSession(FixSession.getByCode(sessionKbn));
        } catch (Exception e) {
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
        }
    }

    /**
     * FIXエンジン停止受信時の処理
     *
     * @param param 通知情報
     */
    @Override
    public void engineStopped(FXParam param) {
        try {
            // セッション切断警告
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W012",
                    FixSession.getByCode(sessionKbn).getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
            // 通知系ファイル更新
            updateNotification(param);
            // 通信パス解放
            fixEngineService.closeSession(FixSession.getByCode(sessionKbn));
        } catch (Exception e) {
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
        }
    }

    /**
     * 例外発生時の処理
     *
     * @param param  通知情報
     * @param reason 理由情報
     */
    @Override
    public void exceptionOccurred(FXParam param, FXReason reason) {
        try {
            // セッション切断警告
            String reasonMsg = reason == null ? null : reason.getReasonTextString();
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W012",
                    FixSession.getByCode(sessionKbn).getName(), Thread.currentThread().getStackTrace()[1].getMethodName() + " Reason:" + reasonMsg);
            // 通知系ファイル更新
            updateNotification(param);
            // 通信パス解放
            fixEngineService.closeSession(FixSession.getByCode(sessionKbn));
        } catch (Exception e) {
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
        }
    }

    /**
     * システム内部エラー発生時の処理
     *
     * @param ex 例外情報
     */
    @Override
    public void internalErrorOccurred(FXServiceException ex) {
        try {
            // セッション切断警告
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W012",
                    FixSession.getByCode(sessionKbn).getName(), Thread.currentThread().getStackTrace()[1].getMethodName() + " Exception:" + ex);
            // 通知系ファイル更新(内部エラー時、FXParamがない為nullを渡す)
            updateNotification(null);
            // 通信パス解放
            fixEngineService.closeSession(FixSession.getByCode(sessionKbn));
        } catch (Exception e) {
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
        }
    }

    /**
     * Logonメソッド結果受信時の処理
     *
     * @param param 通知情報
     */
    @Override
    public void logonCompleted(FXParam param) {
        try {
            if (param != null && param.eventretc == FXParam.FX_NORMAL) {
                logger.info(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I028",
                        Thread.currentThread().getStackTrace()[1].getMethodName(), FixSession.getByCode(sessionKbn).getName());
            } else {
                // FX_NORMAL以外警告ログを出力する
                logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W012",
                        FixSession.getByCode(sessionKbn).getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
            }
            // 通知系ファイル更新
            updateNotification(param);
        } catch (Exception e) {
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
        }
    }

    /**
     * Logoutメソッド結果受信時の処理
     *
     * @param param  通知情報
     * @param reason 理由情報
     */
    @Override
    public void logoutCompleted(FXParam param, FXReason reason) {
        try {
            if (param != null && param.eventretc == FXParam.FX_NORMAL) {
                // セッション切断警告
                String reasonMsg = reason == null ? null : reason.getReasonTextString();
                logger.info(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I028",
                        Thread.currentThread().getStackTrace()[1].getMethodName(), FixSession.getByCode(sessionKbn).getName() + " Reason:" + reasonMsg);
            } else {
                // FX_NORMAL以外警告ログを出力する
                logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W012",
                        FixSession.getByCode(sessionKbn).getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
            }
            // 通知系ファイル更新
            updateNotification(param);
            // 通信パス解放
            fixEngineService.closeSession(FixSession.getByCode(sessionKbn));
        } catch (Exception e) {
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
        }
    }

    /**
     * メッセージ受信時の処理
     *
     * @param message メッセージ
     * @param reason  理由情報
     */
    @Override
    public void messageReceived(FXMessage message, FXParam reason) {
        try {
            MessageReceiver receiver = new MessageReceiver(message, messageReceivedMainPath, messageReceivedSubPath,
                    receivedFileName, delimitr, fixJobStatusInfo, fixTagMap, usernotificationFilePath);
            receiveMsgpool.submit(receiver);
            if (hasMessageReceivedError) {
                // 受信異常の場合、異常終了する
                logger.error(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_E008",
                        FixSession.getByCode(sessionKbn).getName() + " 受信電文の出力に失敗したため異常終了します");
                receiveMsgpool.shutdown();
                System.exit(2);
            }
        } catch (Exception e) {
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
        }
    }

    /**
     * 相手側FIXシステムによるFIX セッションのリセット受信時の処理
     *
     * @param param 通知情報
     */
    @Override
    public void resetByPeer(FXParam param) {
        logger.info(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I028",
                Thread.currentThread().getStackTrace()[1].getMethodName(), FixSession.getByCode(sessionKbn).getName());
    }

    /**
     * sessionResetメソッド結果受信時の処理
     *
     * @param param  通知情報
     * @param reason 理由情報
     */
    @Override
    public void resetCompleted(FXParam param, FXReason reason) {
        try {
            if (param != null && param.eventretc == FXParam.FX_NORMAL) {
                // セッション切断警告
                String reasonMsg = reason == null ? null : reason.getReasonTextString();
                logger.info(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I028",
                        Thread.currentThread().getStackTrace()[1].getMethodName(), FixSession.getByCode(sessionKbn).getName() + " Reason:" + reasonMsg);
            } else {
                // FX_NORMAL以外警告ログを出力する
                logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W012",
                        FixSession.getByCode(sessionKbn).getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
            }
            // 通知系ファイル更新
            updateNotification(param);
        } catch (Exception e) {
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                    Thread.currentThread().getStackTrace()[1].getMethodName(), e);
        }
    }

    /**
     * 通知系ファイル更新処理
     *
     * @see セッション情報ファイル・ユーザ通知ログ
     *
     * @param param
     */
    private void updateNotification(FXParam param) {
        logger.info(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I016",
                param != null ? param.event : null, param != null ? param.eventretc : null, param != null ? param.eventdetail : null);
        // 接続状態を変えないイベントは何もしない。
        // 従来は先にログオン状態を false にしてから判定していたため、sessionReset 正常終了などで
        // 接続中なのにログオン状態が false になり、発注が止まっていた。
        if (isIgnoredEvent(param)) {
            return;
        }
        boolean isLogonSucceeded = param != null && param.event == FXParam.FX_EV_LOGON && param.eventretc == FXParam.FX_NORMAL;
        boolean isLogoutSucceeded = param != null && param.event == FXParam.FX_EV_LOGOUT && param.eventretc == FXParam.FX_NORMAL;

        // ログオン状態（シーケンス番号の取得失敗に影響されないよう先に更新する）
        logonStatusInfo.setLogonStatus(isLogonSucceeded);
        logonStatusInfo.setLogonParam(param);
        logonStatusInfo.setLastLogonDate(new Date());

        // セッション情報
        FixSessionInfoDto sessionInfoDto = new FixSessionInfoDto();
        sessionInfoDto.setConnectionFlg(isLogonSucceeded);
        sessionInfoDto.setFixConnectionStatusCd(param == null ? INTERNAL_ERROR : param.eventdetail);
        sessionInfoDto.setFixSession(sessionKbn);
        sessionInfoDto.setMsgSeqNum(currentSendSeqNum());

        // ユーザ通知（既定：FIXセッションエラー）
        UserNotificationDto userNotificationDto = new UserNotificationDto();
        if (isLogonSucceeded) {
            // 手動接続
            userNotificationDto.setText(NotificationType.TWENTYONE.getName());
            userNotificationDto.setType(NotificationType.TWENTYONE.value());
        } else if (isLogoutSucceeded) {
            // 手動切断
            userNotificationDto.setText(NotificationType.TWENTYTWO.getName());
            userNotificationDto.setType(NotificationType.TWENTYTWO.value());
        } else {
            userNotificationDto.setType(NotificationType.ZERO.value());
            userNotificationDto.setText(FixSession.getByCode(sessionKbn).getName() + "の切断を検知しました。");
        }
        // セッション情報ファイルの出力
        FixFileUtils.writeFixSessionInfoFile(sessionInfoFilePath, sessionInfoDto);
        // ユーザ通知ログファイルの出力
        FixFileUtils.writeUserNotificationLogFile(usernotificationFilePath, userNotificationDto);
    }

    /**
     * 接続状態を変えないイベントか（メッセージ受信、相手側のセッションリセット、sessionReset 正常終了）。
     * システム内部エラー（param == null）は対象外。
     */
    private static boolean isIgnoredEvent(FXParam param) {
        if (param == null) {
            return false;
        }
        switch (param.event) {
        case FXParam.FX_EV_MESSAGE: // メッセージ受信通知
        case FXParam.FX_EV_RCVSESRESET: // 相手側FIX システムによるFIX セッションのリセット
            return true;
        case FXParam.FX_EV_SESRESET: // sessionResetメソッド通知
            return param.eventretc == FXParam.FX_NORMAL;
        default:
            return false;
        }
    }

    /**
     * 送信シーケンス番号。取得できない場合は null（従来は取得失敗でログオン成功の反映まで止まっていた）。
     */
    private Integer currentSendSeqNum() {
        try {
            if (fixEngineService.getFxService() == null) {
                return null;
            }
            FXSequenceNumber seq = fixEngineService.getFxService().getFIXSeqNum(new FXParam());
            return seq != null ? seq.getSendSeqNum() : null;
        } catch (Exception e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001", "シーケンス番号取得", e);
            return null;
        }
    }

    /**
     * @return delimitr
     */
    public String getDelimitr() {
        return delimitr;
    }

    /**
     * @param delimitr セットする delimitr
     */
    public void setDelimitr(String delimitr) {
        this.delimitr = delimitr;
    }

    /**
     * @return sessionInfoFilePath
     */
    public String getSessionInfoFilePath() {
        return sessionInfoFilePath;
    }

    /**
     * @param sessionInfoFilePath セットする sessionInfoFilePath
     */
    public void setSessionInfoFilePath(String sessionInfoFilePath) {
        this.sessionInfoFilePath = sessionInfoFilePath;
    }

    /**
     * @return usernotificationFilePath
     */
    public String getUsernotificationFilePath() {
        return usernotificationFilePath;
    }

    /**
     * @param usernotificationFilePath セットする usernotificationFilePath
     */
    public void setUsernotificationFilePath(String usernotificationFilePath) {
        this.usernotificationFilePath = usernotificationFilePath;
    }

    /**
     * @return messageReceivedMainPath
     */
    public String getMessageReceivedMainPath() {
        return messageReceivedMainPath;
    }

    /**
     * @param messageReceivedMainPath セットする messageReceivedMainPath
     */
    public void setMessageReceivedMainPath(String messageReceivedMainPath) {
        this.messageReceivedMainPath = messageReceivedMainPath;
    }

    /**
     * @return messageReceivedSubPath
     */
    public String getMessageReceivedSubPath() {
        return messageReceivedSubPath;
    }

    /**
     * @param messageReceivedSubPath セットする messageReceivedSubPath
     */
    public void setMessageReceivedSubPath(String messageReceivedSubPath) {
        this.messageReceivedSubPath = messageReceivedSubPath;
    }

    /**
     * @return receivedFileName
     */
    public String getReceivedFileName() {
        return receivedFileName;
    }

    /**
     * @param receivedFileName セットする receivedFileName
     */
    public void setReceivedFileName(String receivedFileName) {
        this.receivedFileName = receivedFileName;
    }

    /**
     * @return sessionKbn
     */
    public String getSessionKbn() {
        return sessionKbn;
    }

    /**
     * @param sessionKbn セットする sessionKbn
     */
    public void setSessionKbn(String sessionKbn) {
        this.sessionKbn = sessionKbn;
    }

    /**
     * 受信処理インナークラス
     *
     * @author MatsuFumizawa
     *
     */
    private static class MessageReceiver implements Callable<ReceiverResult> {
        /** 区切り文字 */
        private String delimitr;
        /** FIX電文 */
        private FXMessage message;
        /** 出力ファイルパス1 */
        private String messageReceivedMainPath;
        /** 出力ファイルパス2 */
        private String messageReceivedSubPath;
        /** 出力ファイル名 */
        private String receivedFileName;
        /** ジョブ処理結果 */
        private FixJobStatusInfoDto fixJobStatusInfo;
        /** FIX Tag */
        private Map<String, String> fixTagMap;
        /** 5秒 */
        private final static long FIVE_SECONDS = 5000L;
        /** ユーザ通知ファイルパス */
        private String usernotificationFilePath;

        MessageReceiver(FXMessage message, String messageReceivedMainPath, String messageReceivedSubPath,
                String receivedFileName, String delimitr, FixJobStatusInfoDto fixJobStatusInfo,
                Map<String, String> fixTagMap, String usernotificationFilePath) {
            this.message = message;
            this.messageReceivedMainPath = messageReceivedMainPath;
            this.messageReceivedSubPath = messageReceivedSubPath;
            this.receivedFileName = receivedFileName;
            this.delimitr = delimitr;
            this.fixJobStatusInfo = fixJobStatusInfo;
            this.fixTagMap = fixTagMap;
            this.usernotificationFilePath = usernotificationFilePath;
        }

        @Override
        public ReceiverResult call() throws Exception {
            try {
                mkReceivedMsg(message);
                return ReceiverResult.SUCCESS;
            } catch (FXServiceException e) {
                logger.error(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_E008", e);
                hasMessageReceivedError = true;
                return ReceiverResult.FX_SERVICE_EXECTION;
            } catch (IOException e) {
                // ファイルIOエラーが発生する場合、バッチ異常終了する
                logger.error(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_E008", e);
                hasMessageReceivedError = true;
                return ReceiverResult.IO_EXECTION;
            } catch (RuntimeException e) {
                // 従来は捕捉されず、スレッドプールに握りつぶされてログも残らなかった
                logger.error(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_E008", e);
                fixJobStatusInfo.setWarn(true);
                return ReceiverResult.UNEXPECTED_EXCEPTION;
            }
        }

        /**
         * 受信電文ファイル作成
         *
         * @param message
         * @throws FXServiceException
         * @throws IOException
         */
        private String mkReceivedMsg(FXMessage message) throws FXServiceException, IOException {
            Date now1 = new Date();
            logger.trace(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I018",
                    Thread.currentThread().getId(), now1.getTime());

            FixFileUtils fileUtil = new FixFileUtils();
            FXTagList headList = message.getListOfHeader(FXMessage.FX_PRM_LIST_HB_ALL);
            FXTagList bodyList = message.getListOfBody(FXMessage.FX_PRM_LIST_HB_ALL);
            headList.getTagNoList();

            StringBuilder msgSb = new StringBuilder();
            int hIdList[] = headList.getFieldIdList();
            int bIdList[] = bodyList.getFieldIdList();
            for (int id : hIdList) {
                FXField fXField = message.getFieldById(id);
                int tag = fXField.getTagNo();
                String val = fXField.getValue();
                msgSb.append(tag);
                msgSb.append(FixConstants.EQUAL);
                msgSb.append(val);
                msgSb.append(delimitr);
            }
            for (int id : bIdList) {
                FXField fXField = message.getFieldById(id);
                int tag = fXField.getTagNo();
                String val = fXField.getValue();
                msgSb.append(tag);
                msgSb.append(FixConstants.EQUAL);
                msgSb.append(val);
                msgSb.append(delimitr);
            }
            // 最後の区切り文字削除する（区切り文字が2文字以上でも正しく削除する）
            String str = msgSb.toString();
            if (str.endsWith(delimitr)) {
                str = str.substring(0, str.length() - delimitr.length());
            }

            if (str.contains(FixConstants.CLORD_DEALER) || isNoreplyOrderSafely(str)) {
                // ディーラー注文、または無応答注文の場合、「../FIX2nd」に出力しない
                fileUtil.writeFixMsgFile(messageReceivedMainPath, null, receivedFileName, str, FixEventHandler.addCount());
            } else {
                fileUtil.writeFixMsgFile(messageReceivedMainPath, messageReceivedSubPath, receivedFileName, str, FixEventHandler.addCount());
            }

            Date now2 = new Date();
            logger.trace(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I019",
                    Thread.currentThread().getId(), now2.getTime(), (now2.getTime() - now1.getTime()));

            return str;
        }

        /**
         * 無応答注文チェック。判定中の想定外エラーで受信電文の出力まで止めない（通常応答として扱う）。
         * 従来は例外になると受信電文ファイルが出力されず、約定などの応答が失われていた。
         */
        private boolean isNoreplyOrderSafely(String fixStr) {
            try {
                return isNoreplyOrder(fixStr);
            } catch (RuntimeException e) {
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_W001",
                        "無応答注文チェック（通常応答として出力します）" + fixStr, e);
                return false;
            }
        }

        /**
         * 無応答注文チェック処理
         *
         * <p>reqOrdMap は送信側（FixEngineService・jbord0001）と共有しているため、
         * 参照・更新は同じロック（map 自身）で行う。</p>
         *
         * @param fixStr
         * @return
         */
        private boolean isNoreplyOrder(String fixStr) {
            if (messageReceivedSubPath == null || messageReceivedSubPath.isEmpty()) {
                return false;
            }
            // 電文ファイルマッピング
            FixSessionMsgParser parser = new FixSessionMsgParser(delimitr, fixTagMap);
            parser.parse(fixStr);
            ExecutionReportDto fixMsg = parser.extractData(ExecutionReportDto.class);
            String clOrdId = fixMsg.getClOrdID();
            if (clOrdId == null || clOrdId.isEmpty()) {
                // ClOrdID の無い電文（BusinessMessageReject 等）は無応答判定の対象外
                return false;
            }
            Map<String, Date> reqOrdMap = fixJobStatusInfo.getReqOrdMap();
            boolean isPending;
            Date sendTime;
            synchronized (reqOrdMap) {
                isPending = reqOrdMap.containsKey(clOrdId);
                sendTime = reqOrdMap.get(clOrdId);
            }
            if (clOrdId.contains(FixConstants.CLORD_LV) && isPending && !"0".equals(fixMsg.getOrdStatus())) {
                // リーブオーダー：メモリ管理している、注文中以外の物は、無応答判定後とする
                return true;
            }
            if (!isPending) {
                // 上記メモリ管理してない物は、正常応答とする
                return false;
            }
            // 送受信の時間差をミリ秒で取得。
            // 送信日時が無い（起動時に無応答として登録された注文）は、判定済みとして経過時間を最大とする
            // （従来は NPE になり、受信電文が出力されなかった）
            long diff = sendTime == null ? Long.MAX_VALUE : System.currentTimeMillis() - sendTime.getTime();
            // 無応答判定
            if (clOrdId.contains(FixConstants.CLORD_RFQ)) {
                if ("0".equals(fixMsg.getOrdStatus())) {
                    // スタンダードの確認対象外：「注文中」
                    return true;
                } else {
                    // スタンダードの確認対象：「注文中」以外
                    return isNoreply(fixMsg, diff, sendTime);
                }
            }
            if (clOrdId.contains(FixConstants.CLORD_LV)) {
                if (!"0".equals(fixMsg.getOrdStatus())) {
                    // リーブオーダーの確認対象外：「注文中」以外
                    return false;
                } else {
                    // リーブオーダーの確認対象：「注文中」
                    return isNoreply(fixMsg, diff, sendTime);
                }
            }
            if (clOrdId.contains(FixConstants.CLORD_LV_CANCEL)) {
                return isNoreply(fixMsg, diff, sendTime);
            }
            return false;
        }

        /**
         * 無応答注文チェックsub処理
         *
         * @param fixMsg
         * @param diff 送信からの経過ミリ秒
         * @param sendTime 送信日時（不明な場合 null）
         * @return
         */
        private boolean isNoreply(ExecutionReportDto fixMsg, long diff, Date sendTime) {
            String clOrdId = fixMsg.getClOrdID();
            String ordNum = orderNumberOf(clOrdId);
            if (diff >= FIVE_SECONDS) {
                // 発注送信後5秒以上経過の為、無応答注文とする
                logger.info(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I028", "Unknownステータス判定後に応答がありました。", ordNum);
                // ユーザ通知ログファイル出力
                UserNotificationDto userNotificationDto = new UserNotificationDto();
                userNotificationDto.setText(MessageFormat.format(NotificationType.TWENTYEIGHT.getName(), ordNum, clOrdId));
                userNotificationDto.setType(NotificationType.TWENTYEIGHT.value());
                FixFileUtils.writeUserNotificationLogFile(usernotificationFilePath, userNotificationDto);
                return true;
            }
            logger.info(FixConstants.FixEventHandler, FixConstants.FixEventHandler_Name, "MSG_J_I028", "時間内応答電文",
                    clOrdId + FixConstants.COMMA + FixDateUtils.convertDateToStrYmdHms(sendTime));
            Map<String, Date> reqOrdMap = fixJobStatusInfo.getReqOrdMap();
            synchronized (reqOrdMap) {
                reqOrdMap.remove(clOrdId);
            }
            return false;
        }

        /** ClOrdID（例：DAIWA_D-1-100）の注文番号部分。形式が違う場合は ClOrdID 全体 */
        private static String orderNumberOf(String clOrdId) {
            String[] parts = clOrdId.split(FixConstants.HYPHEN);
            return parts.length > 2 ? parts[2] : clOrdId;
        }
    }

    private synchronized static long addCount() {
        return ++cnt;
    }

    /**
     * 受信処理スレッドプールを差し替える。旧プールは受付済みの処理を終えてから停止する
     * （従来は停止せずに作り直していたため、再接続のたびにスレッドが増えていた）。
     */
    public void setReceiveMsgPool(Integer receiveMsgPoolSize) {
        ExecutorService old = receiveMsgpool;
        receiveMsgpool = Executors.newFixedThreadPool(receiveMsgPoolSize);
        if (old != null) {
            old.shutdown();
        }
    }
}
