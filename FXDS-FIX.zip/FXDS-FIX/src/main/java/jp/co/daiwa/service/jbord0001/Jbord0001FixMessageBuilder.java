package jp.co.daiwa.service.jbord0001;

import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.CL_ORD_ID;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.CURRENCY;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.EXPIRE_TIME;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORDER_QTY;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.ORD_TYPE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.PRICE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.SIDE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.STOP_PX;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.SYMBOL;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.TIME_IN_FORCE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderRow.TRANSACT_TIME;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.UnaryOperator;

/**
 * 改修で追加した注文（成行・損切り・OCO）のFIX電文（タブ区切り）を組み立てる（仕様書 §6.2・§6.3）。
 *
 * <p>既存の注文（注文区分2の単独注文・単独キャンセル）は既存動作を変えないため、ここでは扱わない
 * （OrdSendDto の既存組立をそのまま使う）。</p>
 */
public class Jbord0001FixMessageBuilder {

    /** 電文に使うタグ */
    public enum Tag {
        MSG_TYPE, CL_ORD_ID, SYMBOL, SIDE, TRANSACT_TIME, ORDER_QTY, SETTL_TYPE, ORD_TYPE, PRICE, TIME_IN_FORCE,
        CURRENCY, EXPIRE_TIME,
        /** 以下は改修で追加（FIX標準のタグ番号を既定値とする） */
        STOP_PX("99"), LIST_ID("66"), CONTINGENCY_TYPE("1385"), TOT_NO_ORDERS("68"), NO_ORDERS("73"),
        LIST_SEQ_NO("67");

        private final String standardNumber;

        Tag() {
            this(null);
        }

        Tag(String standardNumber) {
            this.standardNumber = standardNumber;
        }
    }

    /** OCO の電文形式（TBD-10） */
    public enum OcoFormat {
        /** NewOrderList（35=E）1通 */
        A,
        /** NewOrderSingle（35=D）2通、66・1385 付き */
        B
    }

    private static final String TAB = "\t";
    private static final String MSG_NEW_ORDER_SINGLE = "D";
    private static final String MSG_NEW_ORDER_LIST = "E";
    private static final String CONTINGENCY_OCO = "1";
    private static final String OCO_ORDER_COUNT = "2";

    private final Map<Tag, String> tagNumbers;
    private final UnaryOperator<String> symbolConverter;
    private final String settleType;

    /**
     * @param existingTagNumbers 既存タグのタグ番号（fix-tag.properties の定義）。追加タグは省略可
     * @param symbolConverter 通貨ペアの変換（既存の CNY→CNH 変換）
     * @param settleType 63 の値（既存どおり SPOT）
     */
    public Jbord0001FixMessageBuilder(Map<Tag, String> existingTagNumbers, UnaryOperator<String> symbolConverter,
            String settleType) {
        Map<Tag, String> m = new EnumMap<>(Tag.class);
        for (Tag t : Tag.values()) {
            String number = existingTagNumbers.containsKey(t) ? existingTagNumbers.get(t) : t.standardNumber;
            if (number == null) {
                throw new IllegalArgumentException("tag number undefined: " + t);
            }
            m.put(t, number);
        }
        this.tagNumbers = m;
        this.symbolConverter = symbolConverter;
        this.settleType = settleType;
    }

    /**
     * 単独の成行・損切り（§6.1・§6.2、§10.4）。
     */
    public String newOrderSingle(Jbord0001OrderRow row) {
        Fields f = new Fields();
        f.put(Tag.MSG_TYPE, MSG_NEW_ORDER_SINGLE);
        f.put(Tag.CL_ORD_ID, row.get(CL_ORD_ID));
        appendOrderBody(f, row);
        return f.join();
    }

    /**
     * OCO（§6.3）。
     *
     * @return パターンA は1通、パターンB は2通（1通目＝損切り）
     */
    public List<String> oco(Jbord0001SendUnit unit, OcoFormat format) {
        if (unit.getKind() != Jbord0001SendUnit.Kind.OCO) {
            throw new IllegalArgumentException("not OCO: " + unit.getKind());
        }
        return format == OcoFormat.A ? Arrays.asList(newOrderList(unit)) : ocoAsSingles(unit);
    }

    private String newOrderList(Jbord0001SendUnit unit) {
        Fields f = new Fields();
        f.put(Tag.MSG_TYPE, MSG_NEW_ORDER_LIST);
        f.put(Tag.LIST_ID, unit.getListId());
        f.put(Tag.CONTINGENCY_TYPE, CONTINGENCY_OCO);
        f.put(Tag.TOT_NO_ORDERS, OCO_ORDER_COUNT);
        f.put(Tag.NO_ORDERS, OCO_ORDER_COUNT);
        int seq = 1;
        for (Jbord0001OrderRow row : unit.getRows()) {
            f.put(Tag.CL_ORD_ID, row.get(CL_ORD_ID));
            f.put(Tag.LIST_SEQ_NO, String.valueOf(seq++));
            appendOrderBody(f, row);
        }
        return f.join();
    }

    private List<String> ocoAsSingles(Jbord0001SendUnit unit) {
        List<String> messages = new ArrayList<>();
        for (Jbord0001OrderRow row : unit.getRows()) {
            Fields f = new Fields();
            f.put(Tag.MSG_TYPE, MSG_NEW_ORDER_SINGLE);
            f.put(Tag.CL_ORD_ID, row.get(CL_ORD_ID));
            f.put(Tag.LIST_ID, unit.getListId());
            f.put(Tag.CONTINGENCY_TYPE, CONTINGENCY_OCO);
            appendOrderBody(f, row);
            messages.add(f.join());
        }
        return messages;
    }

    /**
     * 注文の本体（§10.2〜10.4 の並び）。44 は注文区分2のみ、99 は注文区分3のみ、126・15 は値があるときのみ。
     * TODO(S08) 38 の小数部の扱いは仕様書で未確定のため、既存どおり入力値をそのまま送る。
     */
    private void appendOrderBody(Fields f, Jbord0001OrderRow row) {
        String ordType = row.get(ORD_TYPE);
        f.put(Tag.SYMBOL, symbolConverter.apply(row.get(SYMBOL)));
        f.put(Tag.SIDE, row.get(SIDE));
        f.put(Tag.ORDER_QTY, row.get(ORDER_QTY));
        f.put(Tag.ORD_TYPE, ordType);
        if (Jbord0001OrderRow.ORD_TYPE_LIMIT.equals(ordType)) {
            f.put(Tag.PRICE, row.get(PRICE));
        }
        if (Jbord0001OrderRow.ORD_TYPE_STOP.equals(ordType)) {
            f.put(Tag.STOP_PX, row.get(STOP_PX));
        }
        f.put(Tag.TIME_IN_FORCE, row.get(TIME_IN_FORCE));
        f.putIfPresent(Tag.EXPIRE_TIME, row.get(EXPIRE_TIME));
        f.put(Tag.TRANSACT_TIME, row.get(TRANSACT_TIME));
        f.put(Tag.SETTL_TYPE, settleType);
        f.putIfPresent(Tag.CURRENCY, row.get(CURRENCY));
    }

    /** タグ=値 の並び */
    private final class Fields {
        private final List<String> items = new ArrayList<>();

        void put(Tag tag, String value) {
            items.add(tagNumbers.get(tag) + "=" + value);
        }

        void putIfPresent(Tag tag, String value) {
            if (value != null && !value.trim().isEmpty()) {
                put(tag, value);
            }
        }

        String join() {
            return String.join(TAB, items);
        }
    }
}
