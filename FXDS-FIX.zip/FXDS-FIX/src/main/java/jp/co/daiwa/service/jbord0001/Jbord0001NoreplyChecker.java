package jp.co.daiwa.service.jbord0001;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.bean.TradeMng;
import jp.co.daiwa.bean.TradeOpeHistory;
import jp.co.daiwa.common.FixDateUtils;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dao.TradeMngRepository;
import jp.co.daiwa.dao.TradeOpeHistoryRepository;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.UserNotificationDto;
import jp.co.daiwa.enums.FixDealDivisionEnum;
import jp.co.daiwa.enums.FixEnums.WriterResult;
import jp.co.daiwa.enums.FixOrderDivisionEnum;
import jp.co.daiwa.enums.FixUserNotificationEnum.NotificationType;

/**
 * 送信後一定時間応答の無い注文を無応答と判定し、履歴登録・ユーザ通知・クライアント連携を行う。
 */
@Component
@Scope("step")
public class Jbord0001NoreplyChecker {

    private static final String NOREPLY_CODE = "W";
    private static final String NOREPLY_FILE = "unknown_";
    private static final String NOREPLY_OPERATION = "無応答注文";
    private static final int ORDER_NUMBER_INDEX = 2;
    private static final int ORDER_DIVISION_INDEX = 1;
    private static final FixLogger logger = FixLogger.getLogger(Jbord0001NoreplyChecker.class);

    // Jbord0001Settings は step スコーププロキシで、プールスレッドからは解決できないため値を保持する
    private final int noreplySeconds;
    private final String usernotificationPath;
    private final String clientPath;
    private final String clientFile;
    private final FixJobStatusInfoDto fixJobStatusInfo;
    private final TradeMngRepository tradeMngRepository;
    private final TradeOpeHistoryRepository tradeOpeHistoryRepository;
    private final TransactionTemplate transactionTemplate;

    @Inject
    public Jbord0001NoreplyChecker(Jbord0001Settings settings,
            @Named("fixjobstatus_order") FixJobStatusInfoDto fixJobStatusInfo,
            TradeMngRepository tradeMngRepository,
            TradeOpeHistoryRepository tradeOpeHistoryRepository,
            @Named("jobTransactionManager") PlatformTransactionManager transactionManager) {
        this.noreplySeconds = settings.getNoreplySeconds();
        this.usernotificationPath = settings.getUsernotificationPath();
        this.clientPath = settings.getClientPath();
        this.clientFile = settings.getClientFile();
        this.fixJobStatusInfo = fixJobStatusInfo;
        this.tradeMngRepository = tradeMngRepository;
        this.tradeOpeHistoryRepository = tradeOpeHistoryRepository;
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    /**
     * 無応答判定タスクを作る。
     *
     * @param clOrdId 送信した注文の発注番号
     * @return スレッドプールへ投入するタスク
     */
    public Callable<WriterResult> taskFor(String clOrdId) {
        return () -> check(clOrdId);
    }

    WriterResult check(String clOrdId) {
        try {
            String ordNumStr = clOrdIdPart(clOrdId, ORDER_NUMBER_INDEX);
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028",
                    noreplySeconds + "秒後無応答注文判定を行います。", clOrdId);
            TimeUnit.SECONDS.sleep(noreplySeconds);

            PendingState pending = lookupPending(clOrdId);
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", clOrdId,
                    pending.isPending ? "無応答" : "応答済");
            if (!pending.isPending) {
                return WriterResult.SUCCESS;
            }
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", clOrdId,
                    pending.sentAt != null ? FixDateUtils.convertDateToStrYmdHms(pending.sentAt) : "-");

            TradeMng tradeMng = tradeMngRepository.findMaxRevision(new BigDecimal(ordNumStr));
            if (tradeMng == null) {
                throw new IllegalStateException("取引管理が存在しません: " + ordNumStr);
            }
            // 履歴登録に失敗してもユーザ通知は行う（無応答をユーザが把握できることを優先）
            boolean registered = registTradeOpeHistory(tradeMng);
            transferFile(clOrdId, ordNumStr, tradeMng);
            return registered ? WriterResult.SUCCESS : WriterResult.FAILED;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", "無応答判定中断: " + clOrdId);
            return WriterResult.FAILED;
        } catch (Exception e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "無応答判定処理 " + clOrdId, e);
            return WriterResult.FAILED;
        }
    }

    /**
     * containsKey と get を同一ロック内で行う。
     * FixEventHandler 側は同期していないため完全ではないが、本クラス内の不整合は防ぐ。
     */
    private PendingState lookupPending(String clOrdId) {
        Map<String, Date> map = fixJobStatusInfo.getReqOrdMap();
        synchronized (map) {
            return new PendingState(map.containsKey(clOrdId), map.get(clOrdId));
        }
    }

    private boolean registTradeOpeHistory(TradeMng tradeMng) {
        try {
            transactionTemplate.execute(status -> {
                TradeOpeHistory bean = new TradeOpeHistory();
                bean.setOrderNumber(tradeMng.getOrderNumber());
                bean.setRevisionNumber(tradeMng.getRevisionNumber());
                bean.setExchangeDivision(tradeMng.getExchangeDivision());
                bean.setHistoryNumber(tradeOpeHistoryRepository.findMaxHistoryNumber(bean));
                bean.setOperation(NOREPLY_OPERATION);
                bean.setOperationUser(FixConstants.Jbord0000);
                tradeOpeHistoryRepository.registTradeOpeHistory(bean);
                return null;
            });
            return true;
        } catch (RuntimeException e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W001", "registTradeOpeHistory", e);
            return false;
        }
    }

    private void transferFile(String clOrdId, String ordNumStr, TradeMng tradeMng) throws IOException {
        boolean sameCurrency = tradeMng.getDealCurrency() != null
                && tradeMng.getDealCurrency().equals(tradeMng.getOrderCurrency());
        BigDecimal amount = sameCurrency ? tradeMng.getDealAmount() : tradeMng.getSettleAmount();
        String msg = MessageFormat.format(NotificationType.TWENTYSEVEN.getName(),
                ordNumStr, clOrdId,
                FixOrderDivisionEnum.getNameByCode(clOrdIdPart(clOrdId, ORDER_DIVISION_INDEX)),
                ordNumStr,
                tradeMng.getDealCurrency() + "/" + tradeMng.getSettleCurrency(),
                FixDealDivisionEnum.getByCode(tradeMng.getDealDivision()).getName(),
                amount != null ? amount : 0,
                FixDateUtils.convertDateToStrYmdSlash(tradeMng.getDeliveryDate()),
                tradeMng.getFxRate() != null ? tradeMng.getFxRate() : 0);
        // ユーザ通知ログファイル出力
        UserNotificationDto userNotificationDto = new UserNotificationDto();
        userNotificationDto.setText(msg);
        userNotificationDto.setType(NotificationType.TWENTYSEVEN.value());
        FixFileUtils.writeUserNotificationLogFile(usernotificationPath, userNotificationDto);
        // クライアント連携用ファイル出力
        List<List<String>> fileData = new ArrayList<>();
        fileData.add(Collections.singletonList(clOrdId + FixConstants.KEY_TAB + NOREPLY_CODE));
        String outputPath = Paths.get(clientPath + File.separatorChar
                + clientFile + NOREPLY_FILE + ordNumStr + ".tsv").toString();
        FixFileUtils.writeTsvFile(outputPath, fileData);
    }

    private static String clOrdIdPart(String clOrdId, int index) {
        String[] parts = clOrdId == null ? new String[0] : clOrdId.split(FixConstants.HYPHEN);
        if (parts.length <= index) {
            throw new IllegalArgumentException("ClOrdIDの形式不正: " + clOrdId);
        }
        return parts[index];
    }

    private static final class PendingState {
        private final boolean isPending;
        private final Date sentAt;

        private PendingState(boolean isPending, Date sentAt) {
            this.isPending = isPending;
            this.sentAt = sentAt;
        }
    }
}
