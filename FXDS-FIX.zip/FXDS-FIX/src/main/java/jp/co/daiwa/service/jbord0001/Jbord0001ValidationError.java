package jp.co.daiwa.service.jbord0001;

import java.util.Objects;

/**
 * 入力チェックのエラー1件（理由ファイルの1行、仕様書 §7）。
 */
public final class Jbord0001ValidationError {

    /** 該当項目なし（E104 等） */
    public static final int NO_ITEM = 0;

    private final int lineNo;
    private final Jbord0001ErrorCode code;
    private final int itemId;

    public Jbord0001ValidationError(int lineNo, Jbord0001ErrorCode code, int itemId) {
        this.lineNo = lineNo;
        this.code = Objects.requireNonNull(code, "code");
        this.itemId = itemId;
    }

    public int getLineNo() {
        return lineNo;
    }

    public Jbord0001ErrorCode getCode() {
        return code;
    }

    public int getItemId() {
        return itemId;
    }

    /**
     * @return {@code <行番号>\t<エラーコード>\t<項目ID>\t<項目名>\t<メッセージ>}
     */
    public String toReportLine() {
        return lineNo + "\t" + code.name() + "\t" + itemId + "\t" + Jbord0001OrderRow.itemName(itemId) + "\t" + code.getMessage();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Jbord0001ValidationError)) {
            return false;
        }
        Jbord0001ValidationError other = (Jbord0001ValidationError) o;
        return lineNo == other.lineNo && itemId == other.itemId && code == other.code;
    }

    @Override
    public int hashCode() {
        return Objects.hash(lineNo, code, itemId);
    }

    @Override
    public String toString() {
        return toReportLine();
    }
}
