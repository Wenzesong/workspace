package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 理由ファイルの出力（仕様書 §7）。
 *
 * <p>TODO(S01) ファイル名・出力先は仕様書で未定義のため、エラーファイルと同じフォルダに
 * {@code <エラーファイル名から .tsv を除いたもの><suffix>.tsv} で出力する
 * （例：err_req_order_100.tsv → err_req_order_100_reason.tsv）。</p>
 */
public class Jbord0001ErrorReportWriter {

    private static final String TSV = ".tsv";

    private final String suffix;
    private final Charset charset;

    public Jbord0001ErrorReportWriter(String suffix, Charset charset) {
        if (suffix == null || suffix.isEmpty()) {
            throw new IllegalArgumentException("suffix must not be empty");
        }
        this.suffix = suffix;
        this.charset = charset;
    }

    /** 理由ファイルのパス */
    public Path reportPathFor(Path errorFile) {
        String name = errorFile.getFileName().toString();
        String base = name.endsWith(TSV) ? name.substring(0, name.length() - TSV.length()) : name;
        return errorFile.resolveSibling(base + suffix + TSV);
    }

    /**
     * @param errorFile エラーファイル
     * @param errors エラー
     * @return 出力した理由ファイル
     */
    public Path write(Path errorFile, List<Jbord0001ValidationError> errors) throws IOException {
        List<String> lines = new ArrayList<>(errors.size());
        for (Jbord0001ValidationError e : errors) {
            lines.add(e.toReportLine());
        }
        return Files.write(reportPathFor(errorFile), lines, charset);
    }
}
