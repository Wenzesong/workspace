package jp.co.daiwa.service;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.fujitsu.fxsvc.FXEventHandler;
import com.fujitsu.fxsvc.FXField;
import com.fujitsu.fxsvc.FXMessage;
import com.fujitsu.fxsvc.FXParam;
import com.fujitsu.fxsvc.FXService;
import com.fujitsu.fxsvc.FXServiceCB;
import com.fujitsu.fxsvc.FXServiceException;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.bean.FixMessageDefinitionMst;
import jp.co.daiwa.common.FixBeanUtils;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.config.FixTagConfig;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dao.FixMessageDefinitionMstRepository;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.FixLogonStatusInfoDto;
import jp.co.daiwa.dto.FixTagDataInfo;
import jp.co.daiwa.enums.FixEnums;
import jp.co.daiwa.enums.FixEnums.MsgName;
import jp.co.daiwa.enums.FixEnums.MsgType;
import jp.co.daiwa.enums.FixEnums.SettleType;
import jp.co.daiwa.enums.FixSessionEnum.FixSession;
import jp.co.daiwa.handler.FixEventHandler;

/**
 * 富士通FIXエンジンAPI
 *
 * @author
 *
 */
@Service
public class FixEngineService {

    @Value("#{${fix.tag}}")
    private Map<String, String> fixTagMap;

    @Value("${fix.msg.delimitr}")
    private String delimitr;

    @Autowired
    private FixMessageDefinitionMstRepository tFixMessageDefinitionMstRepository;

    @Value("${fix.engine.host}")
    private String host;

    @Value("${fix.engine.str.port}")
    private Integer strPort;

    @Value("${fix.engine.ord.port}")
    private Integer ordPort;

    @Value("${fix.engine.stp.port}")
    private Integer stpPort;

    @Value("${fix.engine.str.path}")
    private String strPath;

    @Value("${fix.engine.ord.path}")
    private String ordPath;

    @Value("${fix.engine.stp.path}")
    private String stpPath;

    @Value("${job.jbstr0000.output.path}")
    private String strOutFilePath;

    @Value("${job.jbstr0000.output.file.name}")
    private String strOutFileName;

    @Value("${fix.session.info.output.path}")
    private String sessionInfoFilePath;

    @Inject
    @Named("logonstatus_order")
    private FixLogonStatusInfoDto orderLogonStatus;
    @Inject
    @Named("logonstatus_rate")
    private FixLogonStatusInfoDto rateLogonStatus;
    @Inject
    @Named("logonstatus_trade")
    private FixLogonStatusInfoDto tradeLogonStatus;

    private Map<Integer, FXField> logonMsgMap;

    @Inject
    @Named("fixEventHandler_order")
    private FixEventHandler ordEventHandler;

    @Inject
    @Named("fixEventHandler_rate")
    private FixEventHandler strEventHandler;

    @Inject
    @Named("fixEventHandler_trade")
    private FixEventHandler stpEventHandler;

    /** ユーザー通知ログファイル出力場所 */
    @Value("${usernotification.file.path}")
    private String notificationPath;

    private FXService fxService;

    @Inject
    @Named("fixjobstatus_order")
    private FixJobStatusInfoDto ordJbStatus;
    @Inject
    @Named("fixjobstatus_rate")
    private FixJobStatusInfoDto strJbStatus;
    @Inject
    @Named("fixjobstatus_trade")
    private FixJobStatusInfoDto stpJbStatus;

    /**
     * Logger定義
     */
    private static final FixLogger logger = FixLogger.getLogger(FixEngineService.class);

    public FixEngineService() {

    }

    /**
     * FIXエンジンログオン・MSG送信処理
     *
     * <p>戻り値は「ログオン要求を送れたか」。ログオン完了（受理）は FixEventHandler 側で
     * ログオン状態に反映される。従来は失敗しても正常終了と区別できなかったため戻り値を追加した
     * （戻り値を使わない呼び出し元の動作は従来どおり）。</p>
     *
     * @param session           接続対象セッション
     * @param receiveMsgPoolSize スレッド数
     * @param logonResetFlg     ログオンリセットフラグ
     * @return ログオン要求を送れた場合 true（失敗時は警告終了設定・通信パス解放済み）
     * @throws FXServiceException
     */
    public boolean init(FixSession session, Integer receiveMsgPoolSize, boolean logonResetFlg) throws FXServiceException {
        if (FixSession.RATE.equals(session)) {
            if (!ObjectUtils.isEmpty(receiveMsgPoolSize)) {
                strEventHandler.setReceiveMsgPool(receiveMsgPoolSize);
            }
            return fixLogon(session, rateLogonStatus, receiveMsgPoolSize, host, strPath, strPort, strEventHandler, true);
        }
        if (FixSession.ORDER.equals(session)) {
            if (!ObjectUtils.isEmpty(receiveMsgPoolSize)) {
                ordEventHandler.setReceiveMsgPool(receiveMsgPoolSize);
            }
            return fixLogon(session, orderLogonStatus, receiveMsgPoolSize, host, ordPath, ordPort, ordEventHandler,
                    logonResetFlg);
        }
        if (FixSession.TRADE.equals(session)) {
            if (!ObjectUtils.isEmpty(receiveMsgPoolSize)) {
                stpEventHandler.setReceiveMsgPool(receiveMsgPoolSize);
            }
            return fixLogon(session, tradeLogonStatus, receiveMsgPoolSize, host, stpPath, stpPort, stpEventHandler,
                    logonResetFlg);
        }
        return false;
    }

    /**
     * FIXログオン処理
     *
     * @param session
     * @param fixLogonStatusInfo
     * @param receiveMsgPoolSize
     * @param host
     * @param path
     * @param port
     * @param fXEventHandler
     * @param logonResetFlg
     * @return ログオン要求を送れた場合 true
     */
    private boolean fixLogon(FixSession session, FixLogonStatusInfoDto fixLogonStatusInfo, Integer receiveMsgPoolSize,
            String host, String path, Integer port, FXEventHandler fXEventHandler, boolean logonResetFlg) {
        // 再接続時は前回の通信パスを解放してから作り直す（従来は解放せずに作り直していた）
        if (fxService != null) {
            closeSession(session);
        }
        FXParam fxParam = new FXParam();
        try {
            fxService = new FXServiceCB(host, port, path, fxParam, fXEventHandler);
            logger.info(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_I014",
                    session.getName());
            if (logonResetFlg) {
                logger.info(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_I008",
                        session.getName(), logonResetFlg);
                // SEQNUMをリセットで、ログオン
                fxService.logon(FXServiceCB.FX_PRM_INITIATER, 0, FXServiceCB.FX_PRM_RESET, fxParam);
            } else {
                // SEQNUMをリセットしないで、ログオン
                fxService.logon(FXServiceCB.FX_PRM_INITIATER, 0, FXServiceCB.FX_PRM_NOT_RESET, fxParam);
            }
            return true;
        } catch (Exception ex) {
            // バッチログを出力する
            logger.warn(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W007",
                    session.getName(), ex);
            // 警告終了設定
            setWarn(session);
            // 通信パス解放後に再接続する
            closeSession(session);
            return false;
        }
    }

    /**
     * 通貨ペア送信 <br>
     * ストリーミングレートセッション
     *
     * @param session
     * @param fixDataList
     */
    public void sendMsgCurrencyPairs(FixSession session, List<FixTagDataInfo> fixDataList) {
        FixFileUtils fileUtil = new FixFileUtils();
        int cnt = 1;
        for (FixTagDataInfo d : fixDataList) {
            sendMsg(d, session, null);
            StringBuilder layerInfo = new StringBuilder();
            String layerAry[] = d.getRequestedsize().split(",");
            for (String layer : layerAry) {
                layerInfo.append("9001=");
                layerInfo.append(layer);
                layerInfo.append(delimitr);
            }
            String msgStr = String.format(FixConstants.FIX_SEND_MSG_FORMAT_STR, d.getMdreqid(), d.getSymbol(),
                    d.getNorequestedsize(), layerInfo.toString());
            try {
                fileUtil.writeFixMsgFile(strOutFilePath, null, strOutFileName, msgStr, cnt);
            } catch (IOException e) {
                // ファイルIOエラーが発生する場合
                logger.error(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W001",
                        new Object() {
                        }.getClass().getEnclosingMethod().getName(), e);
                // 警告終了設定
                strJbStatus.setWarn(true);
            }
            cnt++;
        }
    }

    /**
     * FIX電文送信処理
     *
     * <p>ORDER セッションでは、送信前に reqOrdMap へ送信日時を登録する（応答が送信完了より先に届く場合に備える）。
     * 送信できなかった場合は、例外の種類によらず登録を取り消す（従来は FXServiceException 以外だと残り、
     * 未送信の注文が無応答と判定されていた）。</p>
     *
     * @param <T>
     * @param bean
     * @param session
     * @param clOrdId
     * @return 送信した場合 true。未接続・未対応の電文・送信失敗は false
     * @throws RuntimeException 送信処理中の想定外エラー（送信されたか不明）
     */
    public <T> boolean sendMsg(T bean, FixSession session, String clOrdId) {
        MessageBean messageMap = FixBeanUtils.createMessageBean(bean, fixTagMap);
        if (messageMap.getBody().isEmpty()) {
            return false;
        }
        if (fxService == null) {
            logger.warn(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W008",
                    session.getName() + "（未接続）" + messageMap.getBody());
            setWarn(session);
            return false;
        }
        FXMessage message;
        try {
            message = setFxMessageBySession(session, messageMap);
        } catch (FXServiceException e) {
            logger.warn(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W008",
                    session.getName() + messageMap.getBody(), e);
            setWarn(session);
            return false;
        }
        if (message == null) {
            // 未対応の電文。従来は中身の無い電文がそのまま送信されていた
            logger.warn(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W008",
                    session.getName() + "（未対応の電文のため送信しません）" + messageMap.getBody());
            setWarn(session);
            return false;
        }
        registerRequest(session, clOrdId);
        try {
            fxService.write(message, new FXParam());
            // バッチログを出力する
            logger.info(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_I026",
                    session.getName(), messageMap.getBody());
            return true;
        } catch (FXServiceException e) {
            logger.warn(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W008",
                    session.getName() + messageMap.getBody(), e);
            setWarn(session);
            unregisterRequest(session, clOrdId);
            return false;
        } catch (RuntimeException e) {
            logger.warn(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W008",
                    session.getName() + "（想定外エラー。送信有無不明）" + messageMap.getBody(), e);
            setWarn(session);
            unregisterRequest(session, clOrdId);
            throw e;
        }
    }

    /**
     * 応答待ちとして送信日時を登録する（ORDER セッションのみ）。
     *
     * <p>reqOrdMap は FixEventHandler（受信スレッド）とも共有している。型（HashMap）は共通DTOのため変えず、
     * 本クラスからの更新はロックを取って行う。TODO FixEventHandler 側も同じロックで参照・更新すること。</p>
     */
    private void registerRequest(FixSession session, String clOrdId) {
        if (!FixSession.ORDER.equals(session) || clOrdId == null) {
            return;
        }
        Map<String, Date> map = ordJbStatus.getReqOrdMap();
        synchronized (map) {
            map.put(clOrdId, new Date());
        }
    }

    /** 送信できなかった注文の応答待ち登録を取り消す */
    private void unregisterRequest(FixSession session, String clOrdId) {
        if (!FixSession.ORDER.equals(session) || clOrdId == null) {
            return;
        }
        Map<String, Date> map = ordJbStatus.getReqOrdMap();
        synchronized (map) {
            map.remove(clOrdId);
        }
    }

    /** 警告終了設定 */
    private void setWarn(FixSession session) {
        switch (session) {
        case ORDER:
            ordJbStatus.setWarn(true);
            break;
        case RATE:
            strJbStatus.setWarn(true);
            break;
        case TRADE:
            stpJbStatus.setWarn(true);
            break;
        default:
        }
    }

    /**
     * FIX送信電文設定処理
     *
     * @param session
     * @return
     * @throws FXServiceException
     */
    private FXMessage setFxMessageBySession(FixSession session, MessageBean messageMap) throws FXServiceException {
        FXMessage message = new FXMessage(FXServiceCB.FX_VER_FIX44);
        message.resetMessage();
        message.setMsgType(messageMap.getBody().get(Integer.valueOf(fixTagMap.get(FixTagConfig.getMsgType()))));
        switch (session) {
        case RATE:
            message = setRateMsg(messageMap, message);
            break;
        case ORDER:
            message = setOrderMsg(message, messageMap);
            break;
        default:
        }
        return message;
    }

    /**
     * ストリーミングレート送信電文
     *
     * @param messageMap
     * @param message
     * @throws FXServiceException
     */
    private FXMessage setRateMsg(MessageBean messageMap, FXMessage message) throws FXServiceException {
        FXField field262 = new FXField();
        field262.setTagNo(262);
        field262.setValue(messageMap.getBody().get(262));
        message.addField(field262);

        FXField field263 = new FXField();
        field263.setTagNo(263);
        field263.setValue("1");
        message.addField(field263);

        FXField field264 = new FXField();
        field264.setTagNo(264);
        field264.setValue("0");
        message.addField(field264);

        FXField field265 = new FXField();
        field265.setTagNo(265);
        field265.setValue("0");
        message.addField(field265);

        FXField field146 = new FXField();
        field146.setTagNo(146);
        field146.setValue("1");
        message.addField(field146);

        FXField field55 = new FXField();
        field55.setTagNo(55);
        field55.setValue(messageMap.getBody().get(55));
        message.addField(field55);

        FXField field9000 = new FXField();
        field9000.setTagNo(9000);
        field9000.setValue(messageMap.getBody().get(9000));
        message.addField(field9000);

        String layerAry[] = messageMap.getBody().get(9001).split(",");
        for (String layer : layerAry) {
            FXField field9001 = new FXField();
            field9001.setTagNo(9001);
            field9001.setValue(layer);
            message.addField(field9001);
        }

        FXField field267 = new FXField();
        field267.setTagNo(267);
        field267.setValue("1");
        message.addField(field267);

        FXField field269 = new FXField();
        field269.setTagNo(269);
        field269.setValue("1");
        message.addField(field269);

        return message;
    }

    /**
     * 注文送信電文
     *
     * <p>NewOrderSingle（35=D）は、値の無いタグを送らない（空値のタグは smartTrade が拒否する）。
     * 既存の注文（スタンダード・リーブ）は 44・110 に必ず値があるため、送信内容は従来と同じ。</p>
     * <ul>
     *   <li>44 Price：成行（40=1）・逆指値（40=3）では送らない（発注TSV仕様書 §6.2、改修1）</li>
     *   <li>99 StopPx：逆指値で送る（改修2）</li>
     *   <li>66 ListID・1385 ContingencyType：OCO パターンB で送る（改修3）</li>
     * </ul>
     * <p>NewOrderList（35=E）・ListCancelRequest（35=K）は FXMessage での繰り返しグループの扱いが未確認のため未対応。
     * TODO(TBD-07, TBD-10) 富士通FIXエンジンの API を確認して対応する。</p>
     *
     * @param message
     * @param messageMap
     * @return 電文。未対応の MsgType の場合は null
     * @throws FXServiceException
     */
    private FXMessage setOrderMsg(FXMessage message, MessageBean messageMap) throws FXServiceException {
        String msgType = messageMap.getBodyValue(35);
        if (MsgType.D.value().equals(msgType)) {
            addField(message, 11, messageMap.getBodyValue(11));
            addFieldIfPresent(message, 66, messageMap.getBodyValue(66));
            addFieldIfPresent(message, 1385, messageMap.getBodyValue(1385));
            addField(message, 55, messageMap.getBodyValue(55));
            addField(message, 54, messageMap.getBodyValue(54));
            addField(message, 60, messageMap.getBodyValue(60));
            addField(message, 38, messageMap.getBodyValue(38));
            addField(message, 63, SettleType.SPOT.value());
            addField(message, 40, messageMap.getBodyValue(40));
            addFieldIfPresent(message, 15, messageMap.getBodyValue(15));
            addFieldIfPresent(message, 44, messageMap.getBodyValue(44));
            addFieldIfPresent(message, 99, messageMap.getBodyValue(99));
            addField(message, 59, messageMap.getBodyValue(59));
            addFieldIfPresent(message, 110, messageMap.getBodyValue(110));
            addFieldIfPresent(message, 126, messageMap.getBodyValue(126));
            return message;
        }
        if (MsgType.F.value().equals(msgType)) {
            addField(message, 11, messageMap.getBodyValue(11));
            addField(message, 41, messageMap.getBodyValue(41));
            addField(message, 55, messageMap.getBodyValue(55));
            addField(message, 60, messageMap.getBodyValue(60));
            return message;
        }
        if (MsgType.G.value().equals(msgType)) {
            addField(message, 41, messageMap.getBodyValue(41));
            addField(message, 11, messageMap.getBodyValue(11));
            addField(message, 55, messageMap.getBodyValue(55));
            addField(message, 60, messageMap.getBodyValue(60));
            addFieldIfPresent(message, 38, messageMap.getBodyValue(38));
            addFieldIfPresent(message, 44, messageMap.getBodyValue(44));
            addFieldIfPresent(message, 126, messageMap.getBodyValue(126));
            return message;
        }
        return null;
    }

    private static void addField(FXMessage message, int tagNo, String value) throws FXServiceException {
        FXField field = new FXField();
        field.setTagNo(tagNo);
        field.setValue(value);
        message.addField(field);
    }

    private static void addFieldIfPresent(FXMessage message, int tagNo, String value) throws FXServiceException {
        if (!ObjectUtils.isEmpty(value)) {
            addField(message, tagNo, value);
        }
    }

    /**
     * FIXログアウト
     *
     * @param session 対象セッション
     */
    public void closeConnect(FixSession session) {
        if (fxService != null) {
            FXParam param = new FXParam();
            try {
                fxService.logout(param);
            } catch (FXServiceException ex) {
                logger.warn(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W001", "FIXログアウト",
                        ex);
            }
        }
    }

    /**
     * 通信パス解放
     *
     * @param session 対象セッション
     */
    public void closeSession(FixSession session) {
        try {
            FXParam param = new FXParam();
            fxService.close(param);
            logger.info(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_I029", session.getName());
        } catch (Exception e) {
            logger.warn(FixConstants.FixEngineService, FixConstants.FixEngineService_Name, "MSG_J_W001", "FIX通信パス解放",
                    e);
        }
    }

    /**
     * @return fxService
     */
    public FXService getFxService() {
        return fxService;
    }

    /**
     * @param fxService セットする fxService
     */
    public void setFxService(FXService fxService) {
        this.fxService = fxService;
    }

    /**
     * @return host
     */
    public String getHost() {
        return host;
    }

    /**
     * @param host セットする host
     */
    public void setHost(String host) {
        this.host = host;
    }

    /**
     * @return strPort
     */
    public Integer getStrPort() {
        return strPort;
    }

    /**
     * @param strPort セットする strPort
     */
    public void setStrPort(Integer strPort) {
        this.strPort = strPort;
    }

    /**
     * @return ordPort
     */
    public Integer getOrdPort() {
        return ordPort;
    }

    /**
     * @param ordPort セットする ordPort
     */
    public void setOrdPort(Integer ordPort) {
        this.ordPort = ordPort;
    }

    /**
     * @return stpPort
     */
    public Integer getStpPort() {
        return stpPort;
    }

    /**
     * @param stpPort セットする stpPort
     */
    public void setStpPort(Integer stpPort) {
        this.stpPort = stpPort;
    }

    /**
     * @return strPath
     */
    public String getStrPath() {
        return strPath;
    }

    /**
     * @param strPath セットする strPath
     */
    public void setStrPath(String strPath) {
        this.strPath = strPath;
    }

    /**
     * @return ordPath
     */
    public String getOrdPath() {
        return ordPath;
    }

    /**
     * @param ordPath セットする ordPath
     */
    public void setOrdPath(String ordPath) {
        this.ordPath = ordPath;
    }

    /**
     * @return stpPath
     */
    public String getStpPath() {
        return stpPath;
    }

    /**
     * @param stpPath セットする stpPath
     */
    public void setStpPath(String stpPath) {
        this.stpPath = stpPath;
    }

    public Map<Integer, FXField> getLogonMsgMap() {
        return getLogonMsgMap(false);
    }

    public Map<Integer, FXField> getLogonMsgMap(boolean isRefresh) {
        if (logonMsgMap == null || isRefresh) {
            logonMsgMap = getMessageMap(FixEnums.MsgName.Logon);
        }
        return logonMsgMap;
    }

    /**
     * 指定されたMSG_NAMEの「タグNo：設定値」のMapを返す
     *
     * @param msgName
     * @return
     */
    private Map<Integer, FXField> getMessageMap(MsgName msgName) {
        if (ObjectUtils.isEmpty(msgName)) {
            return null;
        }
        Map<Integer, FXField> msgMap = new HashMap<Integer, FXField>();
        FixMessageDefinitionMst bean = new FixMessageDefinitionMst();
        bean.setMsgName(msgName.value());
        List<FixMessageDefinitionMst> result = tFixMessageDefinitionMstRepository.findStFixMessageDefinitionMst(bean);

        if (CollectionUtils.isEmpty(result)) {
            return null;
        }
        result.forEach(v -> {
            FXField field = new FXField();
            field.setTagNo(v.getTagNo());
            field.setValue(v.getTagNo() + v.getTagValue());
            msgMap.put(v.getTagNo(), field);
        });

        return msgMap;
    }

    public static class MessageBean {
        private Map<Integer, String> body;

        public String getBodyValue(Integer no) {
            if (no == null) {
                return "";
            }
            String value = body.get(no);
            if (value == null) {
                value = "";
            }
            return value;
        }

        public Map<Integer, String> getBody() {
            return body;
        }

        public void setBody(Map<Integer, String> body) {
            this.body = body;
        }
        // ※ 写真は722行目（setBody）で終了。以降は未撮影
    }
}
