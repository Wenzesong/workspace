package jp.co.daiwa.service.jbord0001;

import java.util.Map;
import java.util.Optional;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.parser.FixSessionMsgParser;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dto.ExecutionReportDto;
import jp.co.daiwa.enums.FixEnums.MsgType;
import jp.co.daiwa.enums.FixSessionEnum.FixSession;
import jp.co.daiwa.service.FixEngineService;
import jp.co.daiwa.service.jbord0001.Jbord0001FixMessages.NewOrderSingle;
import jp.co.daiwa.service.jbord0001.Jbord0001FixMessages.OrderCancelReplaceRequestBody;
import jp.co.daiwa.service.jbord0001.Jbord0001FixMessages.OrderCancelRequest;

/**
 * FIX電文（タブ区切り）をFIXエンジンへ送信する。
 */
public class Jbord0001Processor {

    private static final String TAB = "\t";
    private static final String MSG_TYPE_NEW_ORDER_LIST = "E";
    private static final FixLogger logger = FixLogger.getLogger(Jbord0001Processor.class);

    private final FixEngineService fixEngineService;
    private final Map<String, String> fixTagMap;
    private final String delimiter;

    public Jbord0001Processor(FixEngineService fixEngineService, Map<String, String> fixTagMap, String delimiter) {
        this.fixEngineService = fixEngineService;
        this.fixTagMap = fixTagMap;
        this.delimiter = delimiter;
    }

    /**
     * 電文を送信する。
     *
     * @param msg タブ区切りFIX電文
     * @return 送信できた場合は出力用電文（区切り文字変換済み）、送信できなかった場合は empty
     */
    public Optional<String> process(final String msg) {
        FixSessionMsgParser parser = new FixSessionMsgParser(TAB, fixTagMap);
        parser.parse(msg);
        ExecutionReportDto header = parser.extractData(ExecutionReportDto.class);
        String msgType = header.getMsgType();
        boolean sent;
        if (MsgType.D.value().equals(msgType)) {
            sent = fixEngineService.sendMsg(parser.extractData(NewOrderSingle.class), FixSession.ORDER, header.getClOrdID());
        } else if (MsgType.G.value().equals(msgType)) {
            sent = fixEngineService.sendMsg(parser.extractData(OrderCancelReplaceRequestBody.class), FixSession.ORDER, header.getClOrdID());
        } else if (MsgType.F.value().equals(msgType)) {
            sent = fixEngineService.sendMsg(parser.extractData(OrderCancelRequest.class), FixSession.ORDER, header.getClOrdID());
        } else if (MSG_TYPE_NEW_ORDER_LIST.equals(msgType)) {
            // TODO(TBD-10) NewOrderList（繰り返しグループ）を FixEngineService で送れるか未確認（修正一覧 F02）。
            // 確認できるまでは送信せず、未送信（err_）とする。
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                    "OCOパターンA（35=E）は未対応のため送信しません。oco.message_format=B を検討してください: " + header.getClOrdID());
            sent = false;
        } else {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", "未対応のMsgType: " + msgType);
            sent = false;
        }
        return sent ? Optional.of(Jbord0001TsvSupport.toDelimited(msg, delimiter)) : Optional.empty();
    }
}
