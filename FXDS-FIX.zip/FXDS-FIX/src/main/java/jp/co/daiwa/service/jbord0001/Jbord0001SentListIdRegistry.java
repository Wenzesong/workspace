package jp.co.daiwa.service.jbord0001;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * 送信済みの組番号（E304 の重複チェック用）。
 *
 * <p>TODO(S10) 対象範囲（当日／基準日／全期間）と保存先が仕様書で未確定のため、
 * 現状はプロセス内のメモリで保持する（再起動すると忘れる）。</p>
 */
public class Jbord0001SentListIdRegistry {

    private final Set<String> sent = Collections.synchronizedSet(new HashSet<>());

    public boolean isSent(String listId) {
        return sent.contains(listId);
    }

    public void register(String listId) {
        sent.add(listId);
    }
}
