package jp.co.daiwa.service.jbord0001;

/**
 * 入力チェックのエラーコード（発注TSVインタフェース仕様書 §5.2・§5.3）。
 */
public enum Jbord0001ErrorCode {
    E101("必須項目が未設定です"),
    E102("桁数を超えています"),
    E103("データ型またはコード値が不正です"),
    E104("項目数が不正です"),
    E201("逆指値価格がありません"),
    E202("逆指値価格は注文区分3のみ指定できます"),
    E203("為替レートがありません"),
    E204("成行・損切りに為替レートは指定できません"),
    E205("有効期間がありません"),
    E206("損切りの有効期間区分は6にしてください"),
    E207("逆指値価格が不正です"),
    E301("組の相手がありません"),
    E302("組の内容が一致しません"),
    E303("組は損切りと利確の組み合わせにしてください"),
    E304("組番号が重複しています");

    private final String message;

    Jbord0001ErrorCode(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
