package jp.co.daiwa.service.jbord0001;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * jbord0001 の設定値。
 *
 * <p>ファイルパス等は jbord0000 と同じプロパティキーを使う（FixEventHandler_order と共有しているため）。
 * jbord0001 で追加した項目のみ {@code job.jbord0001.*} キーとし、既定値を持たせている。
 * 発注TSVの入力チェック・電文形式に関する設定は {@link Jbord0001OrderSettings}。</p>
 */
@Component
@Scope("step")
public class Jbord0001Settings {

    private final String stopFile;
    private final String inputPath;
    private final String salesOrderPath;
    private final String dealerOrderPath;
    private final String connectFile;
    private final String disconnectFile;
    private final String connectResFile;
    private final String disconnectResFile;
    private final String resetConnectFile;
    private final Integer receiveMsgPoolSize;
    private final String outputPath;
    private final String outputFileName;
    private final int beforeStopWaitSeconds;
    private final int noreplyPoolSize;
    private final int noreplySeconds;
    private final String usernotificationPath;
    private final String clientPath;
    private final String clientFile;
    private final Map<String, String> fixTagMap;
    private final long pollIntervalMillis;
    private final int shutdownMarginSeconds;

    @javax.inject.Inject
    public Jbord0001Settings(
            @Value("${job.jbord0000.stop.file}") String stopFile,
            @Value("${job.jbord0000.input.path}") String inputPath,
            @Value("${sales.order.input.path}") String salesOrderPath,
            @Value("${dealer.order.input.path}") String dealerOrderPath,
            @Value("${job.jbord0000.connect.file}") String connectFile,
            @Value("${job.jbord0000.disconnect.file}") String disconnectFile,
            @Value("${job.jbord0000.connect.res.file}") String connectResFile,
            @Value("${job.jbord0000.disconnect.res.file}") String disconnectResFile,
            @Value("${job.jbord0000.connect.reset.file}") String resetConnectFile,
            @Value("#{jobParameters['receiveMsgPoolSize']}") Integer receiveMsgPoolSize,
            @Value("${job.jbord0000.output.path}") String outputPath,
            @Value("${job.jbord0000.output.file.name}") String outputFileName,
            @Value("${before.stop.wait.seconds}") int beforeStopWaitSeconds,
            @Value("${order.noreply.thread.pool.size}") int noreplyPoolSize,
            @Value("${order.noreply.seconds}") int noreplySeconds,
            @Value("${usernotification.file.path}") String usernotificationPath,
            @Value("${resorder.client.file.path}") String clientPath,
            @Value("${resorder.client.file}") String clientFile,
            @Value("#{${fix.tag}}") Map<String, String> fixTagMap,
            @Value("${job.jbord0001.poll.interval.millis:200}") long pollIntervalMillis,
            @Value("${job.jbord0001.shutdown.margin.seconds:10}") int shutdownMarginSeconds) {
        requirePositive("order.noreply.thread.pool.size", noreplyPoolSize);
        requirePositive("job.jbord0001.poll.interval.millis", pollIntervalMillis);
        requireNotNegative("order.noreply.seconds", noreplySeconds);
        requireNotNegative("before.stop.wait.seconds", beforeStopWaitSeconds);
        requireNotNegative("job.jbord0001.shutdown.margin.seconds", shutdownMarginSeconds);
        this.stopFile = stopFile;
        this.inputPath = inputPath;
        this.salesOrderPath = salesOrderPath;
        this.dealerOrderPath = dealerOrderPath;
        this.connectFile = connectFile;
        this.disconnectFile = disconnectFile;
        this.connectResFile = connectResFile;
        this.disconnectResFile = disconnectResFile;
        this.resetConnectFile = resetConnectFile;
        this.receiveMsgPoolSize = receiveMsgPoolSize;
        this.outputPath = outputPath;
        this.outputFileName = outputFileName;
        this.beforeStopWaitSeconds = beforeStopWaitSeconds;
        this.noreplyPoolSize = noreplyPoolSize;
        this.noreplySeconds = noreplySeconds;
        this.usernotificationPath = usernotificationPath;
        this.clientPath = clientPath;
        this.clientFile = clientFile;
        this.fixTagMap = Collections.unmodifiableMap(new HashMap<>(fixTagMap));
        this.pollIntervalMillis = pollIntervalMillis;
        this.shutdownMarginSeconds = shutdownMarginSeconds;
    }

    private static void requirePositive(String key, long value) {
        if (value <= 0) {
            throw new IllegalArgumentException(key + " must be positive: " + value);
        }
    }

    private static void requireNotNegative(String key, long value) {
        if (value < 0) {
            throw new IllegalArgumentException(key + " must not be negative: " + value);
        }
    }

    public String getStopFile() {
        return stopFile;
    }

    public String getInputPath() {
        return inputPath;
    }

    public String getSalesOrderPath() {
        return salesOrderPath;
    }

    public String getDealerOrderPath() {
        return dealerOrderPath;
    }

    public String getConnectFile() {
        return connectFile;
    }

    public String getDisconnectFile() {
        return disconnectFile;
    }

    public String getConnectResFile() {
        return connectResFile;
    }

    public String getDisconnectResFile() {
        return disconnectResFile;
    }

    public String getResetConnectFile() {
        return resetConnectFile;
    }

    public Integer getReceiveMsgPoolSize() {
        return receiveMsgPoolSize;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public String getOutputFileName() {
        return outputFileName;
    }

    public int getBeforeStopWaitSeconds() {
        return beforeStopWaitSeconds;
    }

    public int getNoreplyPoolSize() {
        return noreplyPoolSize;
    }

    public int getNoreplySeconds() {
        return noreplySeconds;
    }

    public String getUsernotificationPath() {
        return usernotificationPath;
    }

    public String getClientPath() {
        return clientPath;
    }

    public String getClientFile() {
        return clientFile;
    }

    public Map<String, String> getFixTagMap() {
        return fixTagMap;
    }

    public long getPollIntervalMillis() {
        return pollIntervalMillis;
    }

    public int getShutdownMarginSeconds() {
        return shutdownMarginSeconds;
    }
}
