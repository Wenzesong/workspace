package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * 発注要求ファイルの収集・状態遷移を扱う。
 *
 * <p>ファイルは次の状態を遷移する（いずれも同一ディレクトリ内のリネーム）。</p>
 * <pre>
 *   req_xxx ──claim──▶ prc_req_xxx ──complete──▶ (削除)
 *                           │
 *                           └──markError──▶ err_req_xxx
 * </pre>
 * <p>送信前に {@code req_} 以外の名前へ移すため、送信後にファイル操作が失敗しても
 * 次回ポーリングで同じ注文が再送されることはない。</p>
 */
public class Jbord0001OrderFiles {

    /** 発注要求ファイルのプレフィックス */
    public static final String REQUEST_PREFIX = "req_";

    /** 処理中ファイルのプレフィックス */
    public static final String PROCESSING_PREFIX = "prc_";

    private final List<Path> orderDirectories;
    private final String errorPrefix;

    /**
     * @param orderDirectories 発注要求ファイルを監視するディレクトリ（優先順）
     * @param errorPrefix エラーファイルのプレフィックス
     */
    public Jbord0001OrderFiles(List<Path> orderDirectories, String errorPrefix) {
        Objects.requireNonNull(orderDirectories, "orderDirectories");
        if (errorPrefix == null || errorPrefix.isEmpty()) {
            throw new IllegalArgumentException("errorPrefix must not be empty");
        }
        this.orderDirectories = Collections.unmodifiableList(new ArrayList<>(orderDirectories));
        this.errorPrefix = errorPrefix;
    }

    /**
     * 存在しない監視ディレクトリを返す。
     *
     * @return 存在しないディレクトリ（全て存在すれば空）
     */
    public List<Path> findMissingDirectories() {
        List<Path> missing = new ArrayList<>();
        for (Path dir : orderDirectories) {
            if (!Files.isDirectory(dir)) {
                missing.add(dir);
            }
        }
        return Collections.unmodifiableList(missing);
    }

    /**
     * 未処理の発注要求ファイルを、更新日時の古い順（同時刻はファイル名順）で返す。
     *
     * <p>同一注文の新規と取消が同時に置かれた場合でも、作成順に送信するため。</p>
     *
     * @return 発注要求ファイル
     * @throws IOException ディレクトリを読めない場合
     */
    public List<Path> collectRequests() throws IOException {
        List<TimedPath> found = new ArrayList<>();
        for (Path dir : orderDirectories) {
            for (Path file : listByPrefix(dir, REQUEST_PREFIX)) {
                FileTime time = lastModifiedOrNull(file);
                if (time != null) {
                    found.add(new TimedPath(file, time));
                }
            }
        }
        found.sort(Comparator.comparing((TimedPath t) -> t.time)
                .thenComparing(t -> t.path.getFileName().toString()));
        List<Path> result = new ArrayList<>(found.size());
        for (TimedPath t : found) {
            result.add(t.path);
        }
        return Collections.unmodifiableList(result);
    }

    /**
     * 前回実行で処理中のまま残ったファイルを返す（送信済みか不明なため再送しない）。
     *
     * @return 処理中ファイル
     * @throws IOException ディレクトリを読めない場合
     */
    public List<Path> findLeftoverClaims() throws IOException {
        List<Path> result = new ArrayList<>();
        for (Path dir : orderDirectories) {
            result.addAll(listByPrefix(dir, PROCESSING_PREFIX));
        }
        return Collections.unmodifiableList(result);
    }

    /**
     * 発注要求ファイルを処理中状態へ移す。
     *
     * <p>作成元がまだ書き込み中でロックされている場合は失敗し、次回ポーリングで再試行される。</p>
     *
     * @param request {@code req_} ファイル
     * @return 処理中ファイル
     * @throws IOException リネームに失敗した場合
     */
    public Path claim(Path request) throws IOException {
        String name = request.getFileName().toString();
        if (!name.startsWith(REQUEST_PREFIX)) {
            throw new IllegalArgumentException("not a request file: " + request);
        }
        Path claimed = uniqueSibling(request, PROCESSING_PREFIX + name);
        return Files.move(request, claimed, StandardCopyOption.ATOMIC_MOVE);
    }

    /**
     * 処理済みファイルを削除する。
     *
     * @param claimed 処理中ファイル
     * @throws IOException 削除に失敗した場合
     */
    public void complete(Path claimed) throws IOException {
        Files.delete(claimed);
    }

    /**
     * 処理中ファイルをエラーファイルへ移す。元の {@code req_} 名に errorPrefix を付けた名前になる。
     *
     * @param claimed 処理中ファイル
     * @return エラーファイル
     * @throws IOException リネームに失敗した場合
     */
    public Path markError(Path claimed) throws IOException {
        String name = claimed.getFileName().toString();
        String original = name.startsWith(PROCESSING_PREFIX) ? name.substring(PROCESSING_PREFIX.length()) : name;
        Path error = uniqueSibling(claimed, errorPrefix + original);
        return Files.move(claimed, error);
    }

    /**
     * 指定ディレクトリの {@code req_} ファイルを削除する（再接続時の古い電文破棄）。
     *
     * @param dir 対象ディレクトリ
     * @return 削除件数
     * @throws IOException ディレクトリを読めない、または削除に失敗した場合
     */
    public static int deleteRequests(Path dir) throws IOException {
        int count = 0;
        for (Path file : listByPrefix(dir, REQUEST_PREFIX)) {
            if (Files.deleteIfExists(file)) {
                count++;
            }
        }
        return count;
    }

    /**
     * 同名ファイルが既にある場合（前回の prc_/err_ が残っている等）は上書きせず、連番を付けた名前にする。
     */
    private static Path uniqueSibling(Path base, String name) {
        Path candidate = base.resolveSibling(name);
        for (int i = 1; Files.exists(candidate); i++) {
            candidate = base.resolveSibling(name + "." + i);
        }
        return candidate;
    }

    private static List<Path> listByPrefix(Path dir, String prefix) throws IOException {
        List<Path> result = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, prefix + "*")) {
            for (Path p : stream) {
                if (Files.isRegularFile(p)) {
                    result.add(p);
                }
            }
        }
        return result;
    }

    private static FileTime lastModifiedOrNull(Path file) throws IOException {
        try {
            return Files.getLastModifiedTime(file);
        } catch (NoSuchFileException e) {
            // 一覧取得後に消えたファイルは対象外
            return null;
        }
    }

    private static final class TimedPath {
        private final Path path;
        private final FileTime time;

        private TimedPath(Path path, FileTime time) {
            this.path = path;
            this.time = time;
        }
    }
}
