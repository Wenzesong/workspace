package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Provider;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.config.FixTagConfig;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dao.BatchExecBaseDateRepository;
import jp.co.daiwa.dao.TradeOpeHistoryRepository;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.FixLogonStatusInfoDto;
import jp.co.daiwa.dto.OrdSendDto;
import jp.co.daiwa.enums.FixEnums;
import jp.co.daiwa.enums.FixSessionEnum.FixSession;
import jp.co.daiwa.service.FixEngineService;

/**
 * FIX接続通信（jbord0000 改善版）。
 *
 * <p>停止ファイルを検知するまで、一定間隔で「セッション接続/切断要求」と「発注要求ファイル」を監視する。</p>
 */
@Component
@Scope("step")
public class Jbord0001Tasklet implements Tasklet {

    private static final FixLogger logger = FixLogger.getLogger(Jbord0001Tasklet.class);

    private final Jbord0001Settings settings;
    private final FixLogonStatusInfoDto orderLogonStatus;
    private final FixJobStatusInfoDto fixJobStatusInfo;
    private final FixEngineService fixEngineService;
    private final Jbord0001OrderFileProcessor orderFileProcessor;
    private final TradeOpeHistoryRepository tradeOpeHistoryRepository;
    private final BatchExecBaseDateRepository batchExecBaseDateRepository;
    private final Jbord0001OrderFiles orderFiles;

    @Inject
    public Jbord0001Tasklet(Jbord0001Settings settings,
            @Named("logonstatus_order") FixLogonStatusInfoDto orderLogonStatus,
            @Named("fixjobstatus_order") FixJobStatusInfoDto fixJobStatusInfo,
            @Named("fixEngineService") FixEngineService fixEngineService,
            @Named("jbord0001Processor") Jbord0001Processor processor,
            @Named("jbord0001SuffixCreator") Jbord0001ResourceSuffixCreator suffixCreator,
            Jbord0001NoreplyChecker noreplyChecker,
            @Named("jbord0001OrdSendDto") Provider<OrdSendDto> ordSendDtoProvider,
            Jbord0001OrderSettings orderSettings,
            @Named("jbord0001SentListIdRegistry") Jbord0001SentListIdRegistry sentListIds,
            TradeOpeHistoryRepository tradeOpeHistoryRepository,
            BatchExecBaseDateRepository batchExecBaseDateRepository) {
        this.settings = settings;
        this.orderLogonStatus = orderLogonStatus;
        this.fixJobStatusInfo = fixJobStatusInfo;
        this.fixEngineService = fixEngineService;
        this.tradeOpeHistoryRepository = tradeOpeHistoryRepository;
        this.batchExecBaseDateRepository = batchExecBaseDateRepository;
        // ディーラー注文を先に並べる（同時刻の場合の優先順は jbord0000 と同じ）
        this.orderFiles = new Jbord0001OrderFiles(
                Arrays.asList(Paths.get(settings.getDealerOrderPath()), Paths.get(settings.getSalesOrderPath())),
                FixConstants.ERR_PREFIX);
        // TODO(S11) E207 の通貨ペア別小数桁数の取得元が未確定のため、項目定義の上限（8桁）でチェックする
        Jbord0001ValidationRules rules = orderSettings.toValidationRules(symbol -> null);
        Jbord0001OrderPlanner planner = new Jbord0001OrderPlanner(rules,
                new Jbord0001GroupValidator(rules, sentListIds::isSent), orderSettings.isAllow14Columns());
        Jbord0001FixMessageBuilder builder = new Jbord0001FixMessageBuilder(
                existingTagNumbers(settings.getFixTagMap()), FixFileUtils::convertCnyToCnh,
                String.valueOf(FixEnums.SettleType.SPOT));
        this.orderFileProcessor = new Jbord0001OrderFileProcessor(orderFiles, planner, builder,
                orderSettings.getOcoFormat(), processor, ordSendDtoProvider, noreplyChecker, suffixCreator,
                sentListIds, fixJobStatusInfo, orderSettings.getTsvCharset(), settings.getOutputPath(), settings.getOutputFileName());
    }

    /** 既存タグのタグ番号（OrdSendDto と同じ定義を使う）。追加タグ（99 等）は FIX 標準の番号 */
    private static Map<Jbord0001FixMessageBuilder.Tag, String> existingTagNumbers(Map<String, String> fixTagMap) {
        Map<Jbord0001FixMessageBuilder.Tag, String> m = new EnumMap<>(Jbord0001FixMessageBuilder.Tag.class);
        m.put(Jbord0001FixMessageBuilder.Tag.MSG_TYPE, fixTagMap.get(FixTagConfig.getMsgType()));
        m.put(Jbord0001FixMessageBuilder.Tag.CL_ORD_ID, fixTagMap.get(FixTagConfig.getClOrdId()));
        m.put(Jbord0001FixMessageBuilder.Tag.SYMBOL, fixTagMap.get(FixTagConfig.getSymbol()));
        m.put(Jbord0001FixMessageBuilder.Tag.SIDE, fixTagMap.get(FixTagConfig.getSide()));
        m.put(Jbord0001FixMessageBuilder.Tag.TRANSACT_TIME, fixTagMap.get(FixTagConfig.getTransactTime()));
        m.put(Jbord0001FixMessageBuilder.Tag.ORDER_QTY, fixTagMap.get(FixTagConfig.getOrderQty()));
        m.put(Jbord0001FixMessageBuilder.Tag.SETTL_TYPE, fixTagMap.get(FixTagConfig.getSettlType3()));
        m.put(Jbord0001FixMessageBuilder.Tag.ORD_TYPE, fixTagMap.get(FixTagConfig.getOrdType()));
        m.put(Jbord0001FixMessageBuilder.Tag.PRICE, fixTagMap.get(FixTagConfig.getPrice()));
        m.put(Jbord0001FixMessageBuilder.Tag.TIME_IN_FORCE, fixTagMap.get(FixTagConfig.getTimeInforce()));
        m.put(Jbord0001FixMessageBuilder.Tag.CURRENCY, fixTagMap.get(FixTagConfig.getCurrency()));
        m.put(Jbord0001FixMessageBuilder.Tag.EXPIRE_TIME, fixTagMap.get(FixTagConfig.getExpireTime()));
        return m;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        verifyOrderDirectories();
        warnLeftoverClaims();
        registerLeftoverNoreplyOrders(new Date());
        ExecutorService noreplyPool = Executors.newFixedThreadPool(settings.getNoreplyPoolSize());
        try {
            runMonitorLoop(noreplyPool);
        } finally {
            shutdownNoreplyPool(noreplyPool);
        }
        return RepeatStatus.FINISHED;
    }

    private void runMonitorLoop(ExecutorService noreplyPool) {
        while (true) {
            try {
                if (handleStopRequest()) {
                    return;
                }
                monitorSessionOnOff();
                if (orderLogonStatus.isLogonStatus()) {
                    processOrderFiles(noreplyPool);
                }
                TimeUnit.MILLISECONDS.sleep(settings.getPollIntervalMillis());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", "監視処理が割り込みにより停止しました");
                closeConnectQuietly();
                return;
            } catch (Exception e) {
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "送信電文作成処理。例外エラー", e);
                sleepAfterError();
            }
        }
    }

    // ---------------------------------------------------------------- 起動時処理

    private void verifyOrderDirectories() {
        List<Path> missing = orderFiles.findMissingDirectories();
        if (!missing.isEmpty()) {
            throw new IllegalStateException("発注要求ディレクトリが存在しません: " + missing);
        }
    }

    private void warnLeftoverClaims() throws IOException {
        for (Path leftover : orderFiles.findLeftoverClaims()) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                    "前回処理中のまま残った発注要求（送信有無不明のため再送しません。要確認）：" + leftover);
        }
    }

    /**
     * 起動時に無応答リーブオーダーを応答待ちとして登録する。
     *
     * <p>jbord0000 は送信日時に null を登録しており、FixEventHandler の時間差計算で NPE になっていた。
     * 送信日時は不明なため起動日時を入れる（応答が来れば「無応答判定後の応答」として扱われる）。</p>
     */
    private void registerLeftoverNoreplyOrders(Date startedAt) {
        List<String> ordList = tradeOpeHistoryRepository.findLvNoRplyOrdNum(batchExecBaseDateRepository.getExecBaseDate());
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", "起動時無応答注文", ordList);
        if (ordList == null || ordList.isEmpty()) {
            return;
        }
        Map<String, Date> map = fixJobStatusInfo.getReqOrdMap();
        synchronized (map) {
            for (String clOrdId : ordList) {
                map.put(clOrdId, new Date(startedAt.getTime()));
            }
        }
    }

    // ---------------------------------------------------------------- 停止・接続制御

    /**
     * @return 停止要求を処理した場合 true
     */
    private boolean handleStopRequest() throws InterruptedException {
        Path stop = Paths.get(settings.getStopFile());
        if (!Files.exists(stop)) {
            return false;
        }
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I001", stop);
        try {
            closeConnectQuietly();
            // Logout 結果の受信処理完了待ち
            TimeUnit.SECONDS.sleep(settings.getBeforeStopWaitSeconds());
        } finally {
            // 削除しないと次回起動時に即停止してしまう
            deleteQuietly(stop);
        }
        return true;
    }

    private void monitorSessionOnOff() throws Exception {
        Path resetConnect = Paths.get(settings.getResetConnectFile());
        Path connect = Paths.get(settings.getConnectFile());
        Path disconnect = Paths.get(settings.getDisconnectFile());
        if (Files.exists(resetConnect)) {
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I012", FixSession.ORDER.getName(), resetConnect);
            deleteOldRequestFiles();
            initOrQuarantine(resetConnect, true);
            Files.deleteIfExists(resetConnect);
        } else if (Files.exists(connect)) {
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I012", FixSession.ORDER.getName(), connect);
            deleteOldRequestFiles();
            initOrQuarantine(connect, false);
            Files.move(connect, Paths.get(settings.getConnectResFile()), StandardCopyOption.REPLACE_EXISTING);
        } else if (Files.exists(disconnect)) {
            logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I013", FixSession.ORDER.getName(), disconnect);
            fixEngineService.closeConnect(FixSession.ORDER);
            Files.move(disconnect, Paths.get(settings.getDisconnectResFile()), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    /**
     * FIX接続を初期化する。失敗時（ログオン要求を送れなかった場合）は要求ファイルを err_ へ退避して例外とする。
     * 退避しないと、毎ポーリングで「古い電文削除＋再接続」が繰り返されて新着注文が消える。
     * また、失敗したのに応答ファイルが作られて運用者が接続済みと誤解するのを防ぐ。
     */
    private void initOrQuarantine(Path trigger, boolean resetSeq) throws Exception {
        boolean requested;
        try {
            requested = fixEngineService.init(FixSession.ORDER, settings.getReceiveMsgPoolSize(), resetSeq);
        } catch (Exception e) {
            quarantine(trigger);
            throw e;
        }
        if (!requested) {
            quarantine(trigger);
            throw new IllegalStateException("FIXログオン要求に失敗しました: " + trigger);
        }
    }

    private void quarantine(Path trigger) throws IOException {
        Path quarantined = trigger.resolveSibling(FixConstants.ERR_PREFIX + trigger.getFileName());
        Files.move(trigger, quarantined, StandardCopyOption.REPLACE_EXISTING);
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                "FIX接続失敗。要求ファイルを退避しました（再接続は要求ファイルを再配置）：" + quarantined);
    }

    private void deleteOldRequestFiles() throws IOException {
        int deleted = Jbord0001OrderFiles.deleteRequests(Paths.get(settings.getInputPath()));
        logger.info(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_I028", "古い送信電文削除", deleted);
    }

    // ---------------------------------------------------------------- 発注処理

    private void processOrderFiles(ExecutorService noreplyPool) throws IOException {
        for (Path request : orderFiles.collectRequests()) {
            orderFileProcessor.process(request, noreplyPool);
        }
    }

    // ---------------------------------------------------------------- 終了処理・補助

    private void shutdownNoreplyPool(ExecutorService pool) {
        pool.shutdown();
        long timeout = (long) settings.getNoreplySeconds() + settings.getShutdownMarginSeconds();
        try {
            if (pool.awaitTermination(timeout, TimeUnit.SECONDS)) {
                return;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        fixJobStatusInfo.setWarn(true);
        List<Runnable> dropped = pool.shutdownNow();
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                "無応答判定を打ち切りました（タイムアウトまたは割り込み）。未実行件数=" + dropped.size());
    }

    private void closeConnectQuietly() {
        try {
            fixEngineService.closeConnect(FixSession.ORDER);
        } catch (Exception e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "FIX切断", e);
        }
    }

    private void deleteQuietly(Path path) {
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "ファイル削除：" + path, e);
        }
    }

    /** 例外が続く場合のログ洪水を防ぐ */
    private void sleepAfterError() {
        try {
            TimeUnit.MILLISECONDS.sleep(settings.getPollIntervalMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

}
