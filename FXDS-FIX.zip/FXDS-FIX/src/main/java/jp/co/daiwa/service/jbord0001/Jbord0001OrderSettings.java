package jp.co.daiwa.service.jbord0001;

import java.nio.charset.Charset;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.Function;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 発注TSV（仕様書 §11 の TBD）に関する設定値。値は起動時にチェックする。
 */
@Component
public class Jbord0001OrderSettings {

    private static final String ERROR = "ERROR";
    private static final String IGNORE = "IGNORE";

    private final String newSendType;
    private final Set<String> cancelSendTypes;
    private final boolean allow14Columns;
    private final int clOrdIdMaxLength;
    private final int listIdMaxLength;
    private final String listIdPattern;
    private final String marketTimeInForce;
    private final boolean extraPriceIsError;
    private final Jbord0001FixMessageBuilder.OcoFormat ocoFormat;
    private final Charset tsvCharset;
    private final String reasonFileSuffix;

    @Inject
    public Jbord0001OrderSettings(
            @Value("${job.jbord0001.send.type.new:0}") String newSendType,
            @Value("${job.jbord0001.send.type.cancel:2}") String cancelSendTypes,
            @Value("${job.jbord0001.tsv.allow.14.columns:false}") boolean allow14Columns,
            @Value("${job.jbord0001.clordid.max.length:22}") int clOrdIdMaxLength,
            @Value("${job.jbord0001.listid.max.length:20}") int listIdMaxLength,
            @Value("${job.jbord0001.listid.pattern:^[A-Za-z0-9]+$}") String listIdPattern,
            @Value("${job.jbord0001.market.timeinforce:4}") String marketTimeInForce,
            @Value("${job.jbord0001.validation.extra.price:ERROR}") String extraPricePolicy,
            @Value("${oco.message_format:A}") String ocoFormat,
            @Value("${job.jbord0001.tsv.charset:UTF-8}") String tsvCharset,
            @Value("${job.jbord0001.reason.file.suffix:_reason}") String reasonFileSuffix) {
        this.newSendType = requireText("job.jbord0001.send.type.new", newSendType);
        this.cancelSendTypes = parseCodes(cancelSendTypes);
        this.allow14Columns = allow14Columns;
        this.clOrdIdMaxLength = requirePositive("job.jbord0001.clordid.max.length", clOrdIdMaxLength);
        this.listIdMaxLength = requirePositive("job.jbord0001.listid.max.length", listIdMaxLength);
        this.listIdPattern = requireText("job.jbord0001.listid.pattern", listIdPattern);
        this.marketTimeInForce = requireText("job.jbord0001.market.timeinforce", marketTimeInForce);
        this.extraPriceIsError = parseExtraPricePolicy(extraPricePolicy);
        this.ocoFormat = Jbord0001FixMessageBuilder.OcoFormat.valueOf(requireText("oco.message_format", ocoFormat).trim());
        // TODO(TBD-01) 文字コードは「既存どおり」。既存（FixFileUtils）の文字コードを確認して既定値を合わせる
        this.tsvCharset = Charset.forName(requireText("job.jbord0001.tsv.charset", tsvCharset));
        this.reasonFileSuffix = requireText("job.jbord0001.reason.file.suffix", reasonFileSuffix);
        if (this.cancelSendTypes.contains(this.newSendType)) {
            throw new IllegalArgumentException("send.type.new と send.type.cancel が重複しています: " + newSendType);
        }
    }

    /**
     * @param symbolScaleResolver 通貨ペア→小数桁数（不明なら null）
     */
    public Jbord0001ValidationRules toValidationRules(Function<String, Integer> symbolScaleResolver) {
        return new Jbord0001ValidationRules(newSendType, cancelSendTypes, clOrdIdMaxLength, listIdMaxLength,
                listIdPattern, marketTimeInForce, extraPriceIsError, symbolScaleResolver);
    }

    private static boolean parseExtraPricePolicy(String value) {
        String v = requireText("job.jbord0001.validation.extra.price", value).trim();
        if (ERROR.equals(v)) {
            return true;
        }
        if (IGNORE.equals(v)) {
            return false;
        }
        throw new IllegalArgumentException("job.jbord0001.validation.extra.price は ERROR か IGNORE: " + value);
    }

    private static Set<String> parseCodes(String csv) {
        Set<String> codes = new LinkedHashSet<>();
        for (String code : requireText("job.jbord0001.send.type.cancel", csv).split(",")) {
            if (!code.trim().isEmpty()) {
                codes.add(code.trim());
            }
        }
        if (codes.isEmpty()) {
            throw new IllegalArgumentException("job.jbord0001.send.type.cancel must not be empty");
        }
        return Collections.unmodifiableSet(codes);
    }

    private static String requireText(String key, String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(key + " must not be empty");
        }
        return value;
    }

    private static int requirePositive(String key, int value) {
        if (value <= 0) {
            throw new IllegalArgumentException(key + " must be positive: " + value);
        }
        return value;
    }

    public boolean isAllow14Columns() {
        return allow14Columns;
    }

    public Jbord0001FixMessageBuilder.OcoFormat getOcoFormat() {
        return ocoFormat;
    }

    public Charset getTsvCharset() {
        return tsvCharset;
    }

    public String getReasonFileSuffix() {
        return reasonFileSuffix;
    }
}
