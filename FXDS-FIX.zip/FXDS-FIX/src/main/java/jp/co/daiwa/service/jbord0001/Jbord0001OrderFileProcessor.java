package jp.co.daiwa.service.jbord0001;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;

import javax.inject.Provider;

import jp.co.daiwa.base.FixLogger;
import jp.co.daiwa.common.FixFileUtils;
import jp.co.daiwa.constant.FixConstants;
import jp.co.daiwa.dto.FixJobStatusInfoDto;
import jp.co.daiwa.dto.OrdSendDto;

/**
 * 発注要求ファイル1つを処理する（仕様書 §5.1）。
 *
 * <ol>
 *   <li>req_ → prc_ へ移す（二重送信防止）</li>
 *   <li>全行を解析・チェック。1件でもエラーなら全行送信せず err_ ＋理由ファイル</li>
 *   <li>送信単位ごとに送信。途中で失敗した場合、未送信なら err_、一部送信済みなら prc_ のまま警告</li>
 * </ol>
 */
public class Jbord0001OrderFileProcessor {

    private static final FixLogger logger = FixLogger.getLogger(Jbord0001OrderFileProcessor.class);

    private final Jbord0001OrderFiles orderFiles;
    private final Jbord0001OrderPlanner planner;
    private final Jbord0001FixMessageBuilder builder;
    private final Jbord0001FixMessageBuilder.OcoFormat ocoFormat;
    private final Jbord0001Processor processor;
    private final Provider<OrdSendDto> ordSendDtoProvider;
    private final Jbord0001NoreplyChecker noreplyChecker;
    private final Jbord0001ResourceSuffixCreator suffixCreator;
    private final Jbord0001SentListIdRegistry sentListIds;
    private final Jbord0001ErrorReportWriter reportWriter;
    private final FixJobStatusInfoDto fixJobStatusInfo;
    private final Charset tsvCharset;
    private final String outputPath;
    private final String outputFileName;

    public Jbord0001OrderFileProcessor(Jbord0001OrderFiles orderFiles, Jbord0001OrderPlanner planner,
            Jbord0001FixMessageBuilder builder, Jbord0001FixMessageBuilder.OcoFormat ocoFormat,
            Jbord0001Processor processor, Provider<OrdSendDto> ordSendDtoProvider,
            Jbord0001NoreplyChecker noreplyChecker, Jbord0001ResourceSuffixCreator suffixCreator,
            Jbord0001SentListIdRegistry sentListIds, Jbord0001ErrorReportWriter reportWriter,
            FixJobStatusInfoDto fixJobStatusInfo, Charset tsvCharset, String outputPath, String outputFileName) {
        this.orderFiles = orderFiles;
        this.planner = planner;
        this.builder = builder;
        this.ocoFormat = ocoFormat;
        this.processor = processor;
        this.ordSendDtoProvider = ordSendDtoProvider;
        this.noreplyChecker = noreplyChecker;
        this.suffixCreator = suffixCreator;
        this.sentListIds = sentListIds;
        this.reportWriter = reportWriter;
        this.fixJobStatusInfo = fixJobStatusInfo;
        this.tsvCharset = tsvCharset;
        this.outputPath = outputPath;
        this.outputFileName = outputFileName;
    }

    /**
     * @param request req_ ファイル
     * @param noreplyPool 無応答判定のスレッドプール
     */
    public void process(Path request, ExecutorService noreplyPool) {
        Path claimed;
        try {
            claimed = orderFiles.claim(request);
        } catch (IOException e) {
            // 作成元が書き込み中等。次回ポーリングで再試行する
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "発注要求ファイル取得：" + request, e);
            return;
        }
        Jbord0001OrderPlanner.Plan plan;
        try {
            plan = planner.plan(Files.readAllLines(claimed, tsvCharset));
        } catch (IOException | RuntimeException e) {
            fixJobStatusInfo.setWarn(true);
            moveToError(claimed, "発注要求読込：" + e.getMessage(), Collections.<Jbord0001ValidationError>emptyList());
            return;
        }
        if (plan.hasErrors()) {
            fixJobStatusInfo.setWarn(true);
            moveToError(claimed, "入力チェックエラー " + plan.getErrors().size() + "件", plan.getErrors());
            return;
        }
        sendAll(claimed, plan.getUnits(), noreplyPool);
    }

    private void sendAll(Path claimed, List<Jbord0001SendUnit> units, ExecutorService noreplyPool) {
        List<String> sentClOrdIds = new ArrayList<>();
        for (Jbord0001SendUnit unit : units) {
            List<OutgoingMessage> messages;
            try {
                messages = toMessages(unit);
            } catch (RuntimeException e) {
                failBeforeSend(claimed, sentClOrdIds, "電文組立：" + e.getMessage());
                return;
            }
            for (OutgoingMessage m : messages) {
                Optional<String> output;
                try {
                    output = processor.process(m.fixStr);
                } catch (RuntimeException e) {
                    // FIXエンジンへ渡った可能性があるため err_ にせず prc_ のまま残す
                    fixJobStatusInfo.setWarn(true);
                    logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002",
                            "送信状態不明（再送しません。要確認）：" + claimed + " 送信済み=" + sentClOrdIds, e);
                    return;
                }
                if (!output.isPresent()) {
                    failBeforeSend(claimed, sentClOrdIds, "発注要求未送信：" + m.fixStr);
                    return;
                }
                afterSent(m, output.get(), noreplyPool);
                sentClOrdIds.addAll(m.clOrdIds);
            }
            if (unit.getKind() == Jbord0001SendUnit.Kind.OCO) {
                sentListIds.register(unit.getListId());
            }
        }
        complete(claimed);
    }

    /** 送信単位 → 電文。既存の注文種類は既存の組立（OrdSendDto）をそのまま使う */
    private List<OutgoingMessage> toMessages(Jbord0001SendUnit unit) {
        switch (unit.getKind()) {
            case NEW_EXISTING:
                return single(unit.getRow(), toOrdSendDto(unit.getRow()).toNewOrderSingle());
            case CANCEL:
                return single(unit.getRow(), toOrdSendDto(unit.getRow()).toOrderCancelRequest());
            case NEW_EXTENDED:
                return single(unit.getRow(), builder.newOrderSingle(unit.getRow()));
            case OCO:
                return ocoMessages(unit);
            default:
                throw new IllegalStateException("unknown kind: " + unit.getKind());
        }
    }

    private List<OutgoingMessage> ocoMessages(Jbord0001SendUnit unit) {
        List<String> fixStrs = builder.oco(unit, ocoFormat);
        List<String> clOrdIds = new ArrayList<>();
        for (Jbord0001OrderRow row : unit.getRows()) {
            clOrdIds.add(row.get(Jbord0001OrderRow.CL_ORD_ID));
        }
        List<OutgoingMessage> messages = new ArrayList<>();
        if (fixStrs.size() == 1) {
            // パターンA：1通に2注文
            messages.add(new OutgoingMessage(clOrdIds, fixStrs.get(0)));
        } else {
            // パターンB：1注文1通（1通目＝損切り）
            for (int i = 0; i < fixStrs.size(); i++) {
                messages.add(new OutgoingMessage(Collections.singletonList(clOrdIds.get(i)), fixStrs.get(i)));
            }
        }
        return messages;
    }

    private static List<OutgoingMessage> single(Jbord0001OrderRow row, String fixStr) {
        return Collections.singletonList(
                new OutgoingMessage(Collections.singletonList(row.get(Jbord0001OrderRow.CL_ORD_ID)), fixStr));
    }

    private OrdSendDto toOrdSendDto(Jbord0001OrderRow row) {
        OrdSendDto dto = ordSendDtoProvider.get();
        dto.setClOrdID(row.get(Jbord0001OrderRow.CL_ORD_ID));
        dto.setSymbol(row.get(Jbord0001OrderRow.SYMBOL));
        dto.setSide(row.get(Jbord0001OrderRow.SIDE));
        dto.setTransactTime(row.get(Jbord0001OrderRow.TRANSACT_TIME));
        dto.setOrderQty(row.get(Jbord0001OrderRow.ORDER_QTY));
        dto.setOrdType(row.get(Jbord0001OrderRow.ORD_TYPE));
        dto.setPrice(row.get(Jbord0001OrderRow.PRICE));
        dto.setTimeInForce(row.get(Jbord0001OrderRow.TIME_IN_FORCE));
        dto.setExpireTime(row.get(Jbord0001OrderRow.EXPIRE_TIME));
        dto.setSendType(row.get(Jbord0001OrderRow.SEND_TYPE));
        dto.setUserId(row.get(Jbord0001OrderRow.USER_ID));
        dto.setClOrdIDChange(row.get(Jbord0001OrderRow.ORIG_CL_ORD_ID));
        dto.setCurrency(row.get(Jbord0001OrderRow.CURRENCY));
        return dto;
    }

    /** 送信済み後処理。どれが失敗しても再送・エラー扱いにはしない */
    private void afterSent(OutgoingMessage m, String output, ExecutorService noreplyPool) {
        for (String clOrdId : m.clOrdIds) {
            if (clOrdId.contains(FixConstants.CLORD_DEALER)) {
                continue;
            }
            try {
                noreplyPool.submit(noreplyChecker.taskFor(clOrdId));
            } catch (RuntimeException e) {
                fixJobStatusInfo.setWarn(true);
                logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "無応答判定の登録失敗：" + clOrdId, e);
            }
        }
        try {
            new FixFileUtils().writeFixMsgFile(outputPath, null, outputFileName, output, suffixCreator.getSuffixIndex());
        } catch (Exception e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "送信済み電文の出力失敗：" + output, e);
        }
    }

    /** 送信できなかった場合。1通も送っていなければ err_、送信済みがあれば prc_ のまま警告 */
    private void failBeforeSend(Path claimed, List<String> sentClOrdIds, String reason) {
        fixJobStatusInfo.setWarn(true);
        if (sentClOrdIds.isEmpty()) {
            moveToError(claimed, reason, Collections.<Jbord0001ValidationError>emptyList());
            return;
        }
        // TODO(S09) 一部送信済み（OCOパターンBの2通目失敗など）の扱いは仕様書で未確定。自動取消はせず手動対応とする
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013",
                "一部のみ送信済み（要手動対応）：" + claimed + " 送信済み=" + sentClOrdIds + " " + reason);
    }

    private void complete(Path claimed) {
        try {
            orderFiles.complete(claimed);
        } catch (IOException e) {
            fixJobStatusInfo.setWarn(true);
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "送信済みファイル削除失敗（再送はされません）：" + claimed, e);
        }
    }

    private void moveToError(Path claimed, String reason, List<Jbord0001ValidationError> errors) {
        Path error;
        try {
            error = orderFiles.markError(claimed);
        } catch (IOException e) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "エラーファイル移動失敗：" + claimed + " " + reason, e);
            return;
        }
        logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", error.getFileName() + " " + reason);
        for (Jbord0001ValidationError e : errors) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W013", error.getFileName() + " " + e.toReportLine());
        }
        if (errors.isEmpty()) {
            return;
        }
        try {
            reportWriter.write(error, errors);
        } catch (IOException e) {
            logger.warn(FixConstants.Jbord0000, FixConstants.Jbord0000_Name, "MSG_J_W002", "理由ファイル出力失敗：" + error, e);
        }
    }

    /** 送信する電文1通と、含まれる発注番号 */
    private static final class OutgoingMessage {
        private final List<String> clOrdIds;
        private final String fixStr;

        private OutgoingMessage(List<String> clOrdIds, String fixStr) {
            this.clOrdIds = clOrdIds;
            this.fixStr = fixStr;
        }
    }
}
