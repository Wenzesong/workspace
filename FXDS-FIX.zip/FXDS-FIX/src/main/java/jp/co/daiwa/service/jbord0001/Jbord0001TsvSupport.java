package jp.co.daiwa.service.jbord0001;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 発注要求TSVの解析（仕様書 §2）と、FIX電文の区切り文字変換。
 */
public final class Jbord0001TsvSupport {

    /** 既存形式の列数 */
    public static final int LEGACY_COLUMN_COUNT = 13;
    /** 改修後の列数 */
    public static final int FULL_COLUMN_COUNT = 15;

    private static final String TAB = "\t";
    private static final int COLUMNS_WITHOUT_LIST_ID = 14;

    private Jbord0001TsvSupport() {
    }

    /**
     * ファイルの全行を解析する。
     *
     * <p>列数は 13・15 のみ受け付け、それ以外は E104 とする（§2.1）。
     * 空行は読み飛ばす（行番号は元ファイルの行番号のまま）。</p>
     *
     * @param lines ファイルの全行
     * @param allow14Columns 列数14（項目15のみ省略）を許可するか（TBD-02）
     * @return 解析結果
     */
    public static ParseResult parseOrderFile(List<String> lines, boolean allow14Columns) {
        List<Jbord0001OrderRow> rows = new ArrayList<>();
        List<Jbord0001ValidationError> errors = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            int lineNo = i + 1;
            String line = stripLineEnd(lines.get(i));
            if (line.trim().isEmpty()) {
                continue;
            }
            String[] columns = line.split(TAB, -1);
            if (!isAcceptedColumnCount(columns.length, allow14Columns)) {
                errors.add(new Jbord0001ValidationError(lineNo, Jbord0001ErrorCode.E104, Jbord0001ValidationError.NO_ITEM));
                continue;
            }
            rows.add(Jbord0001OrderRow.of(lineNo, Arrays.asList(columns)));
        }
        if (rows.isEmpty() && errors.isEmpty()) {
            // 空ファイル
            errors.add(new Jbord0001ValidationError(1, Jbord0001ErrorCode.E104, Jbord0001ValidationError.NO_ITEM));
        }
        return new ParseResult(rows, errors);
    }

    /**
     * タブ区切りのFIX電文を、出力用の区切り文字に置き換える。
     *
     * <p>jbord0000 の挙動（末尾の空項目は除去）を維持する。</p>
     */
    public static String toDelimited(String tabSeparated, String delimiter) {
        return String.join(delimiter, tabSeparated.split(TAB));
    }

    private static boolean isAcceptedColumnCount(int count, boolean allow14Columns) {
        return count == LEGACY_COLUMN_COUNT || count == FULL_COLUMN_COUNT
                || (allow14Columns && count == COLUMNS_WITHOUT_LIST_ID);
    }

    private static String stripLineEnd(String line) {
        int end = line.length();
        while (end > 0 && (line.charAt(end - 1) == '\n' || line.charAt(end - 1) == '\r')) {
            end--;
        }
        return line.substring(0, end);
    }

    /** 解析結果 */
    public static final class ParseResult {
        private final List<Jbord0001OrderRow> rows;
        private final List<Jbord0001ValidationError> errors;

        private ParseResult(List<Jbord0001OrderRow> rows, List<Jbord0001ValidationError> errors) {
            this.rows = Collections.unmodifiableList(rows);
            this.errors = Collections.unmodifiableList(errors);
        }

        public List<Jbord0001OrderRow> getRows() {
            return rows;
        }

        public List<Jbord0001ValidationError> getErrors() {
            return errors;
        }
    }
}
