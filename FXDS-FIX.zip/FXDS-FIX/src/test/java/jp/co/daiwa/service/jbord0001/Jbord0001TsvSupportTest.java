package jp.co.daiwa.service.jbord0001;

import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.EXPIRE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.newLine;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.to13Columns;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class Jbord0001TsvSupportTest {

    private static final String LINE15 = newLine("3", "", "6", EXPIRE, "154.50");

    private static Jbord0001ValidationError e104(int lineNo) {
        return new Jbord0001ValidationError(lineNo, Jbord0001ErrorCode.E104, Jbord0001ValidationError.NO_ITEM);
    }

    @Test
    @DisplayName("15列の行を解析できる")
    void parseOrderFile_15Columns() {
        Jbord0001TsvSupport.ParseResult r = Jbord0001TsvSupport.parseOrderFile(Collections.singletonList(LINE15), false);

        assertThat(r.getErrors()).isEmpty();
        assertThat(r.getRows()).hasSize(1);
        assertThat(r.getRows().get(0).get(Jbord0001OrderRow.STOP_PX)).isEqualTo("154.50");
        assertThat(r.getRows().get(0).get(Jbord0001OrderRow.PRICE)).isEmpty();
    }

    @Test
    @DisplayName("T03: 13列の行は項目14・15を空として受け付ける")
    void parseOrderFile_13Columns_paddedWithBlank() {
        String line13 = to13Columns(newLine("2", "155.20", "4", "", ""));

        Jbord0001TsvSupport.ParseResult r = Jbord0001TsvSupport.parseOrderFile(Collections.singletonList(line13), false);

        assertThat(r.getErrors()).isEmpty();
        Jbord0001OrderRow row = r.getRows().get(0);
        assertThat(row.isBlank(Jbord0001OrderRow.STOP_PX)).isTrue();
        assertThat(row.hasListId()).isFalse();
        assertThat(row.get(Jbord0001OrderRow.CURRENCY)).isEqualTo("USD");
    }

    @Test
    @DisplayName("T17: 列数14は既定でE104、設定で許可できる（TBD-02）")
    void parseOrderFile_14Columns() {
        String line14 = LINE15.substring(0, LINE15.lastIndexOf('\t'));

        assertThat(Jbord0001TsvSupport.parseOrderFile(Collections.singletonList(line14), false).getErrors())
                .containsExactly(e104(1));
        assertThat(Jbord0001TsvSupport.parseOrderFile(Collections.singletonList(line14), true).getErrors()).isEmpty();
    }

    @Test
    @DisplayName("列数が13・15以外はE104（行番号付き）")
    void parseOrderFile_otherColumnCounts_E104() {
        String line12 = String.join("\t", Arrays.copyOf(LINE15.split("\t", -1), 12));
        String line16 = LINE15 + "\textra";

        Jbord0001TsvSupport.ParseResult r = Jbord0001TsvSupport.parseOrderFile(Arrays.asList(LINE15, line12, line16), false);

        assertThat(r.getRows()).hasSize(1);
        assertThat(r.getErrors()).containsExactly(e104(2), e104(3));
    }

    @Test
    @DisplayName("空行は読み飛ばし、行番号は元ファイルのまま。行末の改行は除去する")
    void parseOrderFile_blankLinesSkipped() {
        Jbord0001TsvSupport.ParseResult r = Jbord0001TsvSupport.parseOrderFile(Arrays.asList("", LINE15 + "\r", "  "), false);

        assertThat(r.getErrors()).isEmpty();
        assertThat(r.getRows().get(0).getLineNo()).isEqualTo(2);
        assertThat(r.getRows().get(0).get(Jbord0001OrderRow.LIST_ID)).isEmpty();
    }

    @Test
    @DisplayName("空ファイルはE104")
    void parseOrderFile_empty_E104() {
        assertThat(Jbord0001TsvSupport.parseOrderFile(Collections.<String>emptyList(), false).getErrors())
                .containsExactly(e104(1));
    }

    @Test
    @DisplayName("タブを出力区切り文字に置換し、末尾の空項目は除く（jbord0000互換）")
    void toDelimited_replacesTabs() {
        assertThat(Jbord0001TsvSupport.toDelimited("35=D\t11=A\t55=USD/JPY", "|")).isEqualTo("35=D|11=A|55=USD/JPY");
        assertThat(Jbord0001TsvSupport.toDelimited("35=D\t11=A\t\t", "|")).isEqualTo("35=D|11=A");
        assertThat(Jbord0001TsvSupport.toDelimited("35=D\t\t11=A", "|")).isEqualTo("35=D||11=A");
    }
}
