package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class Jbord0001OrderFilesTest {

    private static final String ERR = "err_";

    @TempDir
    Path tmp;

    private Path dealer;
    private Path sales;
    private Jbord0001OrderFiles orderFiles;

    @BeforeEach
    void setUp() throws IOException {
        dealer = Files.createDirectory(tmp.resolve("dealer"));
        sales = Files.createDirectory(tmp.resolve("sales"));
        orderFiles = new Jbord0001OrderFiles(Arrays.asList(dealer, sales), ERR);
    }

    @Test
    @DisplayName("両ディレクトリのreq_ファイルを更新日時順に返し、それ以外は無視する")
    void collectRequests_sortsByLastModifiedAcrossDirectories() throws IOException {
        Path salesOld = file(sales, "req_b.tsv", 1_000);
        Path dealerNew = file(dealer, "req_a.tsv", 3_000);
        Path dealerMid = file(dealer, "req_c.tsv", 2_000);
        file(dealer, "err_req_x.tsv", 500);
        file(sales, "prc_req_y.tsv", 500);
        file(sales, "other.tsv", 500);

        List<Path> result = orderFiles.collectRequests();

        assertThat(result).containsExactly(salesOld, dealerMid, dealerNew);
    }

    @Test
    @DisplayName("同時刻のファイルはファイル名順になる")
    void collectRequests_sameTime_sortedByName() throws IOException {
        Path b = file(dealer, "req_2.tsv", 1_000);
        Path a = file(sales, "req_1.tsv", 1_000);

        assertThat(orderFiles.collectRequests()).containsExactly(a, b);
    }

    @Test
    @DisplayName("ディレクトリが無い場合は例外（jbord0000はNPEだった）")
    void collectRequests_missingDirectory_throws() throws IOException {
        Files.delete(sales);

        assertThat(orderFiles.findMissingDirectories()).containsExactly(sales);
        assertThatThrownBy(() -> orderFiles.collectRequests()).isInstanceOf(NoSuchFileException.class);
    }

    @Test
    @DisplayName("claim後は収集対象外になり、再送されない")
    void claim_removesFileFromCollection() throws IOException {
        Path req = file(dealer, "req_1.tsv", 1_000);

        Path claimed = orderFiles.claim(req);

        assertThat(claimed.getFileName().toString()).isEqualTo("prc_req_1.tsv");
        assertThat(claimed).exists();
        assertThat(req).doesNotExist();
        assertThat(orderFiles.collectRequests()).isEmpty();
        assertThat(orderFiles.findLeftoverClaims()).containsExactly(claimed);
    }

    @Test
    @DisplayName("req_以外のファイルはclaimできない")
    void claim_nonRequest_throws() throws IOException {
        Path other = file(dealer, "other.tsv", 1_000);

        assertThatThrownBy(() -> orderFiles.claim(other)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("markErrorは元のreq_名にエラープレフィックスを付ける（jbord0000と同じ名前）")
    void markError_restoresOriginalNameWithPrefix() throws IOException {
        Path claimed = orderFiles.claim(file(sales, "req_9.tsv", 1_000));

        Path error = orderFiles.markError(claimed);

        assertThat(error).isEqualTo(sales.resolve("err_req_9.tsv"));
        assertThat(error).exists();
        assertThat(claimed).doesNotExist();
    }

    @Test
    @DisplayName("前回のprc_が残っていても上書きせず別名でclaimする")
    void claim_existingLeftover_isNotOverwritten() throws IOException {
        Path leftover = file(dealer, "prc_req_1.tsv", 500);
        Path req = file(dealer, "req_1.tsv", 1_000);

        Path claimed = orderFiles.claim(req);

        assertThat(claimed.getFileName().toString()).isEqualTo("prc_req_1.tsv.1");
        assertThat(leftover).exists();
    }

    @Test
    @DisplayName("同名のerr_が既にあっても上書きせず別名にする")
    void markError_existingError_isNotOverwritten() throws IOException {
        Path oldError = file(sales, "err_req_9.tsv", 500);
        Path claimed = orderFiles.claim(file(sales, "req_9.tsv", 1_000));

        Path error = orderFiles.markError(claimed);

        assertThat(error.getFileName().toString()).isEqualTo("err_req_9.tsv.1");
        assertThat(oldError).exists();
    }

    @Test
    @DisplayName("completeで処理中ファイルが削除される")
    void complete_deletesClaimedFile() throws IOException {
        Path claimed = orderFiles.claim(file(dealer, "req_1.tsv", 1_000));

        orderFiles.complete(claimed);

        assertThat(claimed).doesNotExist();
        assertThat(orderFiles.findLeftoverClaims()).isEmpty();
    }

    @Test
    @DisplayName("deleteRequestsはreq_ファイルだけを削除し件数を返す")
    void deleteRequests_deletesOnlyRequestFiles() throws IOException {
        file(dealer, "req_1.tsv", 1_000);
        file(dealer, "req_2.tsv", 1_000);
        Path keep = file(dealer, "err_req_3.tsv", 1_000);

        int deleted = Jbord0001OrderFiles.deleteRequests(dealer);

        assertThat(deleted).isEqualTo(2);
        assertThat(keep).exists();
    }

    @Test
    @DisplayName("エラープレフィックス未指定はコンストラクタで拒否する")
    void constructor_emptyErrorPrefix_throws() {
        assertThatThrownBy(() -> new Jbord0001OrderFiles(Arrays.asList(dealer), ""))
                .isInstanceOf(IllegalArgumentException.class);
    }

    private static Path file(Path dir, String name, long modifiedMillis) throws IOException {
        Path p = Files.write(dir.resolve(name), "x".getBytes(StandardCharsets.UTF_8));
        Files.setLastModifiedTime(p, FileTime.fromMillis(modifiedMillis));
        return p;
    }
}
