package jp.co.daiwa.service.jbord0001;

import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.EXPIRE;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.line;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.row;
import static jp.co.daiwa.service.jbord0001.Jbord0001OrderFixtures.tabs;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Arrays;
import java.util.List;
import java.util.function.UnaryOperator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * 期待電文は仕様書 §10 のサンプル（| をタブに置換）。
 * 38 は TODO(S08) のため入力値（1000000.00）のまま、§10.4 で省略されている 60 は §6.1 に従い出力する。
 */
class Jbord0001FixMessageBuilderTest {

    private static final String STOP = line("DAIWA_D-1-106", "2", "3", "", "6", EXPIRE, "0", "154.50", "G0001");
    private static final String PROFIT = line("DAIWA_D-1-107", "2", "2", "156.00", "6", EXPIRE, "0", "", "G0001");

    private final Jbord0001FixMessageBuilder builder = new Jbord0001FixMessageBuilder(
            Jbord0001OrderFixtures.standardTags(), UnaryOperator.identity(), "SPOT");

    private static Jbord0001SendUnit oco() {
        return Jbord0001SendUnit.oco(row(1, STOP), row(2, PROFIT));
    }

    @Test
    @DisplayName("T04 成行：40=1、44 を出力しない（空値も不可）")
    void market_noPrice() {
        String msg = builder.newOrderSingle(row(1, line("DAIWA_D-0-102", "1", "1", "", "4", "", "0", "", "")));

        assertThat(msg).isEqualTo(tabs(
                "35=D|11=DAIWA_D-0-102|55=USD/JPY|54=1|38=1000000.00|40=1|59=4|60=20261119-01:00:00|63=SPOT|15=USD"));
        assertThat(msg).doesNotContain("44=");
    }

    @Test
    @DisplayName("T05 損切り：40=3、99=逆指値価格、44 を出力しない")
    void stop_stopPxWithoutPrice() {
        String msg = builder.newOrderSingle(row(1, line("DAIWA_D-1-104", "2", "3", "", "6", EXPIRE, "0", "154.50", "")));

        assertThat(msg).isEqualTo(tabs("35=D|11=DAIWA_D-1-104|55=USD/JPY|54=2|38=1000000.00|40=3|99=154.50|59=6"
                + "|126=20261120-21:00:00.000|60=20261119-01:00:00|63=SPOT|15=USD"));
        assertThat(msg).doesNotContain("44=");
    }

    @Test
    @DisplayName("T11 設定「無視」で成行に為替レートがあっても 44 は出力しない")
    void market_priceIgnored() {
        String msg = builder.newOrderSingle(row(1, line("DAIWA_D-0-102", "1", "1", "155.20", "4", "", "0", "", "")));

        assertThat(msg).doesNotContain("44=");
    }

    @Test
    @DisplayName("T07 OCO パターンA：35=E 1通（§10.2）")
    void oco_patternA() {
        List<String> msgs = builder.oco(oco(), Jbord0001FixMessageBuilder.OcoFormat.A);

        assertThat(msgs).containsExactly(tabs("35=E|66=G0001|1385=1|68=2|73=2|"
                + "11=DAIWA_D-1-106|67=1|55=USD/JPY|54=2|38=1000000.00|40=3|99=154.50|59=6|126=20261120-21:00:00.000|60=20261119-01:00:00|63=SPOT|15=USD|"
                + "11=DAIWA_D-1-107|67=2|55=USD/JPY|54=2|38=1000000.00|40=2|44=156.00|59=6|126=20261120-21:00:00.000|60=20261119-01:00:00|63=SPOT|15=USD"));
    }

    @Test
    @DisplayName("T08 OCO パターンB：35=D 2通、両方に 66・1385=1（§10.3）")
    void oco_patternB() {
        List<String> msgs = builder.oco(oco(), Jbord0001FixMessageBuilder.OcoFormat.B);

        assertThat(msgs).containsExactly(
                tabs("35=D|11=DAIWA_D-1-106|66=G0001|1385=1|55=USD/JPY|54=2|38=1000000.00|40=3|99=154.50|59=6"
                        + "|126=20261120-21:00:00.000|60=20261119-01:00:00|63=SPOT|15=USD"),
                tabs("35=D|11=DAIWA_D-1-107|66=G0001|1385=1|55=USD/JPY|54=2|38=1000000.00|40=2|44=156.00|59=6"
                        + "|126=20261120-21:00:00.000|60=20261119-01:00:00|63=SPOT|15=USD"));
    }

    @Test
    @DisplayName("T09 OCO の行が逆順のファイルでも T07 と同じ電文になる（計画で並べ替え）")
    void oco_reversedFile_sameAsT07() {
        Jbord0001OrderPlanner planner = new Jbord0001OrderPlanner(Jbord0001OrderFixtures.defaultRules(),
                new Jbord0001GroupValidator(Jbord0001OrderFixtures.defaultRules(), id -> false), false);
        Jbord0001SendUnit reversed = planner.plan(Arrays.asList(PROFIT, STOP)).getUnits().get(0);

        assertThat(builder.oco(reversed, Jbord0001FixMessageBuilder.OcoFormat.A))
                .isEqualTo(builder.oco(oco(), Jbord0001FixMessageBuilder.OcoFormat.A));
    }

    @Test
    @DisplayName("既存タグの定義（fix-tag.properties）があればその番号を使い、通貨ペアは既存の変換を通す")
    void usesConfiguredTagsAndConverter() {
        java.util.Map<Jbord0001FixMessageBuilder.Tag, String> tags = Jbord0001OrderFixtures.standardTags();
        tags.put(Jbord0001FixMessageBuilder.Tag.SYMBOL, "9055");
        Jbord0001FixMessageBuilder custom = new Jbord0001FixMessageBuilder(tags, s -> s.replace("CNY", "CNH"), "SPOT");

        String msg = custom.newOrderSingle(row(1, line("DAIWA_D-0-102", "1", "1", "", "4", "", "0", "", "")
                .replace("USD/JPY", "CNY/JPY")));

        assertThat(msg).contains("9055=CNH/JPY");
    }

    @Test
    @DisplayName("既存タグの定義が欠けていれば起動時に例外")
    void missingTag_throws() {
        java.util.Map<Jbord0001FixMessageBuilder.Tag, String> tags = Jbord0001OrderFixtures.standardTags();
        tags.remove(Jbord0001FixMessageBuilder.Tag.PRICE);

        assertThatThrownBy(() -> new Jbord0001FixMessageBuilder(tags, UnaryOperator.identity(), "SPOT"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("PRICE");
    }
}
