package jp.co.daiwa.service.jbord0001;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class Jbord0001ErrorReportWriterTest {

    @TempDir
    Path tmp;

    private final Jbord0001ErrorReportWriter writer = new Jbord0001ErrorReportWriter("_reason", StandardCharsets.UTF_8);

    @Test
    @DisplayName("理由ファイルはエラーファイルと同じフォルダに _reason.tsv で出力する")
    void reportPathFor_derivesName() {
        assertThat(writer.reportPathFor(tmp.resolve("err_req_order_100.tsv")))
                .isEqualTo(tmp.resolve("err_req_order_100_reason.tsv"));
        assertThat(writer.reportPathFor(tmp.resolve("err_req_order_100.tsv.1")))
                .isEqualTo(tmp.resolve("err_req_order_100.tsv.1_reason.tsv"));
    }

    @Test
    @DisplayName("§7 の形式（行番号・コード・項目ID・項目名・メッセージ）で出力し、項目なしは 0")
    void write_specFormat() throws IOException {
        Path error = tmp.resolve("err_req_order_100.tsv");

        Path report = writer.write(error, Arrays.asList(
                new Jbord0001ValidationError(1, Jbord0001ErrorCode.E102, Jbord0001OrderRow.CL_ORD_ID),
                new Jbord0001ValidationError(2, Jbord0001ErrorCode.E301, Jbord0001OrderRow.LIST_ID),
                new Jbord0001ValidationError(3, Jbord0001ErrorCode.E104, Jbord0001ValidationError.NO_ITEM)));

        assertThat(Files.readAllLines(report, StandardCharsets.UTF_8)).containsExactly(
                "1\tE102\t1\t発注番号\t桁数を超えています",
                "2\tE301\t15\t組番号\t組の相手がありません",
                "3\tE104\t0\t－\t項目数が不正です");
    }
}
