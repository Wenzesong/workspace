# Pythonスクリプト追加指示
- `logging` モジュールを使用してログを記録すること
- 型ヒント（Type Hints）を必ず使用すること
- `try/except` で例外処理を実装すること
- `if __name__ == "__main__":` を使用すること
