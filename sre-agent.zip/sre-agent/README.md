# Script Generator Agent

ChatGPT向けプロンプトを自動生成するPowerShellエージェント。

## フォルダ構成

```
sre-agent/
├── agent.ps1                 # メインエントリーポイント
├── skills/
│   ├── Skill-ParseSpec.ps1   # MD要件ファイル解析
│   ├── Skill-ReadFiles.ps1   # 参照ファイル読み込み
│   ├── Skill-Analyze.ps1     # スタイル分析
│   ├── Skill-BuildPrompt.ps1 # プロンプト生成
│   ├── Skill-RiskCheck.ps1   # リスク判断プロンプト生成
│   └── Skill-Output.ps1      # コンソール出力
├── templates/
│   ├── shell.md              # Shell追加指示テンプレート
│   ├── python.md             # Python追加指示テンプレート
│   └── java.md               # Java追加指示テンプレート
└── specs/
    └── requirement.md        # 要件ファイルサンプル
```

## 使用方法

### 第一フェーズ：コード生成プロンプト
```powershell
.\agent.ps1 -SpecFile "specs/requirement.md"
```
→ 出力されたプロンプトをChatGPTにコピー＆ペースト

### 第二フェーズ：リスクチェックプロンプト
```powershell
.\agent.ps1 -RiskCheck "generated-code.sh"
```
→ 出力されたプロンプトをChatGPTにコピー＆ペースト

## 新言語の追加方法

1. `templates/` に `{言語名}.md` を追加
2. `specs/requirement.md` の `# 言語` を変更するだけ

## requirement.md の書き方

```markdown
# 目標
作りたいスクリプトの説明

# 言語
shell / python / java / powershell など

# 要件
- 要件1
- 要件2

# 参照ファイル
- path/to/ref1.sh
- path/to/ref2.sh
```
