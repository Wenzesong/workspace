# MD要件ファイルを解析するスキル
function Skill-ParseSpec {
    param([string]$SpecFile)

    Write-Host "📄 要件ファイルを解析中..." -ForegroundColor Gray

    $content = Get-Content $SpecFile -Raw -Encoding UTF8
    $spec = @{
        Target         = ""
        Language       = "shell"
        Requirements   = @()
        ReferenceFiles = @()
    }

    if ($content -match '# 目標\s*\n([\s\S]*?)(?=\n#|$)') {
        $spec.Target = $Matches[1].Trim()
    }

    if ($content -match '# 言語\s*\n([\s\S]*?)(?=\n#|$)') {
        $spec.Language = $Matches[1].Trim()
    }

    if ($content -match '# 要件\s*\n([\s\S]*?)(?=\n#|$)') {
        $reqBlock = $Matches[1].Trim()
        $spec.Requirements = $reqBlock -split "`n" |
            Where-Object { $_ -match "^-" } |
            ForEach-Object { $_.TrimStart("-").Trim() }
    }

    if ($content -match '# 参照ファイル\s*\n([\s\S]*?)(?=\n#|$)') {
        $refBlock = $Matches[1].Trim()
        $spec.ReferenceFiles = $refBlock -split "`n" |
            Where-Object { $_ -match "^-" } |
            ForEach-Object { $_.TrimStart("-").Trim() }
    }

    Write-Host "✅ 解析完了" -ForegroundColor Green
    return $spec
}
