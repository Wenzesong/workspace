# 参照ファイルを読み込むスキル
function Skill-ReadFiles {
    param([string[]]$Files)

    Write-Host "📂 参照ファイルを読み込み中..." -ForegroundColor Gray

    $references = @()
    foreach ($file in $Files) {
        if (Test-Path $file) {
            $references += @{
                FileName = $file
                Content  = Get-Content $file -Raw -Encoding UTF8
            }
            Write-Host "  ✅ $file" -ForegroundColor Green
        } else {
            Write-Host "  ⚠️ ファイルが見つかりません：$file" -ForegroundColor Yellow
        }
    }

    return $references
}
