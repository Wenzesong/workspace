# プロンプトを組み立てるスキル
function Skill-BuildPrompt {
    param(
        [hashtable]$Spec,
        [hashtable]$Analysis,
        [string]$Language
    )

    Write-Host "🔨 プロンプトを生成中..." -ForegroundColor Gray

    # テンプレート読み込み
    $templatePath = "$PSScriptRoot\..\templates\$Language.md"
    if (Test-Path $templatePath) {
        $template = Get-Content $templatePath -Raw -Encoding UTF8
    } else {
        $template = ""
    }

    # 参照コードの整形
    $refContent = ""
    foreach ($ref in $Spec.ReferenceFiles) {
        if (Test-Path $ref) {
            $code = Get-Content $ref -Raw -Encoding UTF8
            $refContent += "=== $ref ===`n$code`n`n"
        }
    }

    # 要件の整形
    $reqList = ($Spec.Requirements | ForEach-Object { "- $_" }) -join "`n"

    $prompt = @"
あなたは $Language のスクリプト専門家です。

## 分析結果（参照ファイルより）
- 命名規則：$($Analysis.NamingStyle)
- エラー処理：$($Analysis.ErrorHandling)
- 構造：$($Analysis.Structure)

## 参照スクリプト
$refContent

## 新しいスクリプトの目標
$($Spec.Target)

## 要件
$reqList

## 追加指示
$template

## 出力ルール
- 参照スクリプトのスタイル・規則を踏襲すること
- コメントはすべて日本語で記述すること
- エラー処理を必ず実装すること
- コードのみを出力し、説明は不要です
"@

    Write-Host "✅ プロンプト生成完了" -ForegroundColor Green
    return $prompt
}
