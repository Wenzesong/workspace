# 参照ファイルのスタイルを分析するスキル
function Skill-Analyze {
    param([array]$References)

    Write-Host "🔍 スタイルを分析中..." -ForegroundColor Gray

    $analysis = @{
        NamingStyle   = ""
        ErrorHandling = ""
        Structure     = ""
    }

    $allContent = ($References | ForEach-Object { $_.Content }) -join "`n"

    # 命名規則の検出
    if ($allContent -match '[a-z]+_[a-z]+') {
        $analysis.NamingStyle = "スネークケース（snake_case）"
    } elseif ($allContent -match '[a-z]+[A-Z][a-z]+') {
        $analysis.NamingStyle = "キャメルケース（camelCase）"
    } else {
        $analysis.NamingStyle = "特定のパターンなし"
    }

    # エラー処理の検出
    if ($allContent -match 'set -e|trap|2>&1') {
        $analysis.ErrorHandling = "厳格なエラー処理あり"
    } else {
        $analysis.ErrorHandling = "基本的なエラー処理"
    }

    # 構造の検出
    if ($allContent -match 'function ') {
        $analysis.Structure = "関数ベースの構造"
    } else {
        $analysis.Structure = "手続き型の構造"
    }

    Write-Host "✅ 分析完了" -ForegroundColor Green
    return $analysis
}
