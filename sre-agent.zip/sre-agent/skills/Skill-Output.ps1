# プロンプトを出力するスキル
function Skill-Output {
    param([string]$Prompt)

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Magenta
    Write-Host "   ChatGPTにコピーしてください" -ForegroundColor Magenta
    Write-Host "========================================" -ForegroundColor Magenta
    Write-Host ""
    Write-Host $Prompt
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Magenta

    # クリップボードにコピー
    $Prompt | Set-Clipboard
    Write-Host "✅ クリップボードにコピーしました" -ForegroundColor Green
}
