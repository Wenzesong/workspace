# エージェントメインエントリーポイント
param(
    [string]$SpecFile,
    [string]$RiskCheck
)

# スキルの読み込み
. "$PSScriptRoot\skills\Skill-ParseSpec.ps1"
. "$PSScriptRoot\skills\Skill-ReadFiles.ps1"
. "$PSScriptRoot\skills\Skill-Analyze.ps1"
. "$PSScriptRoot\skills\Skill-BuildPrompt.ps1"
. "$PSScriptRoot\skills\Skill-RiskCheck.ps1"
. "$PSScriptRoot\skills\Skill-Output.ps1"

function Agent-Run {
    param(
        [string]$SpecFile,
        [string]$RiskCheck
    )

    if ($RiskCheck) {
        Write-Host "=== リスクチェックモード ===" -ForegroundColor Cyan
        $code = Get-Content $RiskCheck -Raw
        $prompt = Skill-RiskCheck -Code $code
        Skill-Output -Prompt $prompt

    } elseif ($SpecFile) {
        Write-Host "=== コード生成モード ===" -ForegroundColor Cyan

        $spec      = Skill-ParseSpec  -SpecFile $SpecFile
        $references = Skill-ReadFiles  -Files $spec.ReferenceFiles
        $analysis  = Skill-Analyze    -References $references
        $prompt    = Skill-BuildPrompt -Spec $spec -Analysis $analysis -Language $spec.Language

        Skill-Output -Prompt $prompt

    } else {
        Write-Host "使用方法：" -ForegroundColor Yellow
        Write-Host "  .\agent.ps1 -SpecFile 'specs/requirement.md'"
        Write-Host "  .\agent.ps1 -RiskCheck 'generated-code.sh'"
    }
}

Agent-Run -SpecFile $SpecFile -RiskCheck $RiskCheck
