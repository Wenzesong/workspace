# 目標
ディスク使用量を監視し、80%を超えたら通知する

# 言語
shell

# 要件
- ログは /var/log/monitor.log に書き込む
- エラー処理を完全に実装する
- 変数名は英語を使用する
- 通知はコンソール出力で行う

# 参照ファイル
- refs/sample1.sh
- refs/sample2.sh
