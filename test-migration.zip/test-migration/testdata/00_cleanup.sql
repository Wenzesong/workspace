--==============================================================================
-- 【共通】テスト前クリーンアップ
--
-- 対象: 基準日 2026/07/10(金)・前営業日 2026/07/09(木) のテストサイクル。
-- テストデータは ORDER_NUMBER / INPUT_DATA_ID / DEALER_BOOK に 'TST' プレフィックス
-- を付けているため、それを目印に削除する。
--
-- ※カラム名・テーブル名は Bean 定義からの推定。実 DDL に合わせて読み替えること。
--==============================================================================

-- ---- 出力テーブル（比較対象6テーブル）: 対象基準日分を全削除 ----
DELETE FROM T_POS_SUM_SOURCE_DATA      WHERE PROCESS_BASE_DATE >= TO_DATE('2026/07/09','YYYY/MM/DD');
DELETE FROM T_POSITION_SPOT_SUM_DATA   WHERE PROCESS_BASE_DATE >= TO_DATE('2026/07/09','YYYY/MM/DD');
DELETE FROM T_POSITION_SWAP_SUM_DATA   WHERE PROCESS_BASE_DATE >= TO_DATE('2026/07/09','YYYY/MM/DD');
DELETE FROM T_BY_CCY_DELTA_CASH_BALANCE WHERE PROCESS_BASE_DATE >= TO_DATE('2026/07/09','YYYY/MM/DD');
DELETE FROM T_SWAP_PL_SUM_DATE         WHERE PROCESS_BASE_DATE >= TO_DATE('2026/07/09','YYYY/MM/DD');
DELETE FROM T_POSITION_PL_DELTA_DATA   WHERE PROCESS_BASE_DATE >= TO_DATE('2026/07/09','YYYY/MM/DD');

-- ---- 入力テーブル: テストデータ(TSTプレフィックス)のみ削除 ----
-- FXDS 取引管理（実テーブル名は jbpos1001 マッパー参照）
DELETE FROM T_TRADE_MNG            WHERE ORDER_NUMBER LIKE 'TST%';
-- DFIT
DELETE FROM T_DFIT_TRADE_EXCHANGE  WHERE INPUT_DATA_ID LIKE 'TST%';
DELETE FROM T_DFIT_CUSTOMER_MST    WHERE CUSTOMER_CODE LIKE 'TST%';
DELETE FROM T_DFARM_BBG_RATE       WHERE CURRENCY_PAIR IN ('EURJPY');
-- BID
DELETE FROM TB86BYG0               WHERE ORDER_NUMBER LIKE 'TST%';
DELETE FROM TB86BYS0               WHERE ORDER_NUMBER LIKE 'TST%';
-- マニュアルレート（対象基準日分）
DELETE FROM T_POS_SUM_MANUAL_RATE  WHERE BASE_DATE = TO_DATE('2026/07/10','YYYY/MM/DD');

-- ※ T_BATCH_EXEC_BASE_DATE / TB86BET0 / T_CURRENCY_MST は運用マスタのため
--   ここでは削除しない。01_master_common.sql 側で MERGE/存在チェック付きで投入する。

COMMIT;
