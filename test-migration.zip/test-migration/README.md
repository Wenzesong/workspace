# jbpos1000 → jbpos1100 移行同一性テスト一式

移行前 (`jbpos1000`) と移行後 (`jbpos1100`) で処理結果が同一であることを、
同一入力・1サイクル単位の並行実行比較で確認するためのテストデータ・SQL・手順。

## 構成

```
test-migration/
├── README.md                          … 本ファイル（手順書）
├── testdata/
│   ├── 00_cleanup.sql                 … テスト前クリーンアップ（毎パターン実行）
│   ├── 01_master_common.sql           … 共通マスタ（基準日・営業日・通貨・レート）
│   ├── 10_pattern1_empty.sql          … P1: 対象データ0件
│   ├── 11_pattern2_normal.sql         … P2: 通常（複数通貨・スポット/スワップ/CF・複数データ源）
│   ├── 12_pattern3_rounding.sql       … P3: 丸め・端数・マイナス・同一キー多明細
│   ├── 13_pattern4_rate_missing.sql   … P4: レート欠損・必須項目欠損（WARN経路）
│   ├── 14_pattern5_end_of_day.sql     … P5: 日締め複製（データはP2共用、時刻設定で発動）
│   └── 15_pattern6_rerun.sql          … P6: 洗い替え・スタートポジション(SEQ_NO=0)
├── files/
│   ├── base_rate_20260710.tsv         … ベースレートファイル（タブ区切り4列）
│   └── close_rate_20260710.tsv        … 引値レートファイル（タブ区切り6列）
└── compare/
    ├── 10_snapshot_v1000.sql          … jbpos1000 実行結果の退避（期待値化）
    └── 20_compare.sql                 … 双方向MINUS比較（全クエリ0件＝合格）
```

## テスト設定値

| 項目 | 値 |
|---|---|
| 基準日 (T_BATCH_EXEC_BASE_DATE) | 2026/07/10（金） |
| 前営業日 | 2026/07/09（木） |
| 円転レート経路 | USD=ST仲値158.15 / EUR=BBG 172.345 / AUD=マニュアル105.5 / GBP=取得不可(WARN) |
| データ源 | FXDS取引管理 / DFIT為替トレード / BIDリアル / BID外M |

## ⚠ 実行前に必ず確認すること（読み替え）

本リポジトリの DAO/Bean は**コンパイル補足用スタブ**であり、実 SQL・実 DDL は FXDS 本体側にある。
INSERT 文のテーブル名・カラム名は Bean/DTO フィールド名の snake_case 変換による**推定値**。
実行前に以下を実テーブル定義と突き合わせて読み替えること。

| 信頼度 | 対象 |
|---|---|
| 高（Beanに全項目定義あり） | 出力6テーブル: `T_POS_SUM_SOURCE_DATA` / `T_POSITION_SPOT_SUM_DATA` / `T_POSITION_SWAP_SUM_DATA` / `T_BY_CCY_DELTA_CASH_BALANCE` / `T_SWAP_PL_SUM_DATE` / `T_POSITION_PL_DELTA_DATA` |
| 中 | `T_CURRENCY_MST` / `T_POS_SUM_MANUAL_RATE` / `T_DFARM_BBG_RATE` / `T_DFIT_CUSTOMER_MST` / `TB86BET0` |
| 低（**要読み替え**。実テーブルは jbpos1001 等のマッパーXML参照） | `T_TRADE_MNG`（仮名。取引管理の実テーブル） / `T_DFIT_TRADE_EXCHANGE` / `TB86BYG0` / `TB86BYS0` |

区分コード値もスタブの推定値（為替区分 1/2/3/4、売買区分 1/2、評価レート区分 00/01/02/03/99、
DFITステータス 2/3、RATE_SOURCE 0/1）。正規コード表と照合すること。

## レートファイルの配置

| ファイル | 配置先プロパティ | ファイル名の注意 |
|---|---|---|
| `base_rate_20260710.tsv` | `job.jbpos1000.output.path`（プレフィックス `job.jbpos1000.output.filename.prefix`） | プレフィックス一致でファイル名昇順の最大＝最新1件が読まれる |
| `close_rate_20260710.tsv` | `job.jbpos1000.input.path`（プレフィックス `job.jbpos1000.input.filename.prefix`） | **ファイル名の12〜19文字目（0始まりindex 11〜18）が基準日 `20260710`** である必要がある。実プレフィックスに合わせてリネームすること |

形式（タブ区切り）:
- ベースレート: `通貨ペア6桁 \t 数量 \t BID \t ASK`（円転仲値 = (BID+ASK)/2）
- 引値レート: `yyyy/MM/dd \t 売買通貨 \t 決済通貨 \t (未使用) \t (未使用) \t 引値レート`

## 実行手順（1パターンあたり）

両ジョブは常駐バッチのため、**1サイクル完了後に停止ファイル**（`job.jbpos1000.file.stop`）**を置いて停止**させる。
`job.jbpos1000.interval` を短く（例: 5秒）しておくと停止しやすい。

```
① testdata/00_cleanup.sql → 01_master_common.sql → 対象パターンSQL を実行
② レートファイル2つを所定ディレクトリへ配置
③ jbpos1000 を起動 → 1サイクル完了を確認 → 停止ファイルを置いて停止
④ compare/10_snapshot_v1000.sql で結果を CMP_*_V1000 へ退避
   出力ファイル（スポット/スワップ集計ファイル）も別名保存する
⑤ ①②を再実行（入力を完全に同一状態へ復元）
   ※P6のみ: 洗い替え用の事前データも再投入されることを確認
⑥ jbpos1100 を起動 → 1サイクル完了を確認 → 停止
⑦ compare/20_compare.sql を実行（全クエリ0件＝DB一致）
⑧ 出力ファイルを diff 比較（日時が入るヘッダ行等はマスクして比較）
⑨ ログの WARN 有無・件数、ジョブ終了ステータスを比較
```

### パターン別の追加設定

| パターン | 追加設定・確認 |
|---|---|
| P1 (0件) | トレード投入なし。空でも delete が走ること、ファイル出力有無の一致 |
| P2 (通常) | なし（標準） |
| P3 (丸め) | 差分が出たら金額カラムの丸め順序差を疑う（BigDecimalSummer / 集計順） |
| P4 (レート欠損) | 両版とも WARN 終了になること。除外/NULL登録の扱い一致 |
| P5 (日締め) | データはP2共用。`job.jbpos1000.time=000000` で複製発動、`235959` で非発動を両方確認 |
| P6 (洗い替え) | SEQ_NO=999901/999902 と TSTBOOK99 の目印行が消え、SEQ_NO=0 行が再マップ更新されること |
| 追加: 大量データ | `bulk.insert.unit` の件数境界（N件ちょうど/N+1件）で P3 の CONNECT BY 件数を調整して実施 |

## 比較ルール

- **除外カラム（非決定）**: `REGISTER_USER` / `REGISTER_DATETIME` / `UPDATE_USER` / `UPDATE_DATETIME`
- **`T_POS_SUM_SOURCE_DATA.SEQ_NO`**: 採番順序が実装・取得順に依存し得るため比較から除外
  （業務カラムの組で照合。件数は件数サマリで別途一致確認）
- 金額は DB 型での比較（MINUS）なので `0.10` vs `0.100` 問題は発生しない
- 出力ファイルは行順序が同一である前提で diff。順序不定なら sort してから比較

## 合格基準

1. `20_compare.sql` の件数サマリで新旧件数一致、全 MINUS クエリが 0 件
2. 出力ファイル2種（スポット/スワップ）が diff 一致（マスク箇所除く）
3. ジョブ終了ステータス・WARN 発生有無が一致（P4 は両版とも WARN）
4. P5/P6 の工程別確認ポイント（各SQLファイル末尾コメント）を満たす

## 同一にならなくて正しいもの（意図的変更）

以下は移行時の意図的な挙動変更のため、差異が出ても不合格としない（新実装仕様が期待値）:

- **トランザクション境界**: jbpos1100 は Store ごとに独立トランザクション
  （`TransactionalBatchExecutor.runInNewTransaction`）。異常中断時の中間コミット状態は旧版と異なり得る
- **割り込み処理**: 旧版は `InterruptedException` 握り潰し、新版はフラグ復元してループ終了
- **DB切断時**: 新版は `DbConnectionFailures.isDisconnect()` 判定でループ終了
- **明示的GCの廃止**: 処理結果には影響しない（長時間実行時のメモリ挙動のみ）
