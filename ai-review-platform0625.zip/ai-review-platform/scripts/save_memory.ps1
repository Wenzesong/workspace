# save_memory.ps1
# Review result -> structured JSON -> memory/reviews/

param(
    [Parameter(Mandatory = $true)][string]$Language,
    [Parameter(Mandatory = $true)][string]$Mode,
    [Parameter(Mandatory = $false)][string]$ProjectName = "default",
    [Parameter(Mandatory = $false)][string]$Developer   = "unknown",
    [Parameter(Mandatory = $false)][string]$TargetFile  = "",
    [Parameter(Mandatory = $false)][string]$RootDir     = "$PSScriptRoot\..",
    [Parameter(Mandatory = $false)][string]$ReviewResult = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$MEMORY_DIR  = Join-Path $RootDir "memory"
$REVIEWS_DIR = Join-Path $MEMORY_DIR "reviews"
$SUMMARY_FILE = Join-Path $MEMORY_DIR "summary.json"

# Ensure memory directories exist before any write (first-run safe).
foreach ($d in @($MEMORY_DIR, $REVIEWS_DIR)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

function Write-Log {
    param([string]$Level, [string]$Message)
    $ts = Get-Date -Format "HH:mm:ss"
    $color = switch ($Level) {
        "INFO" { "Cyan" } "OK" { "Green" } "WARN" { "Yellow" } "ERROR" { "Red" } default { "White" }
    }
    Write-Host "[$ts][$Level] $Message" -ForegroundColor $color
}

# ================================================================
# Extract risks from review result
# Priority: JSON block > regex fallback
# ================================================================
# Safe property accessor: returns $Default when the property is absent or null.
# Required because Set-StrictMode -Version Latest throws on missing PSCustomObject
# properties, and AI JSON output routinely omits optional fields (impact/fix/etc.).
function Get-Prop {
    param($Obj, [string]$Name, [string]$Default = "")
    if ($null -ne $Obj -and ($Obj.PSObject.Properties.Name -contains $Name)) {
        $v = $Obj.$Name
        if ($null -ne $v -and "$v" -ne "") { return $v }
    }
    return $Default
}

function Extract-Risks {
    param([string]$ReviewText)

    # --- Method 1: Extract from JSON block (high accuracy) ---
    # Capture the entire fenced block content (non-greedy up to the closing fence) so
    # nested objects/arrays survive. A brace-based pattern stops at the first "}" and
    # breaks on any nested JSON (risks is always an array of objects).
    if ($ReviewText -match '(?s)```json\s*(.+?)```') {
        $jsonText = $Matches[1].Trim()
        try {
            $parsed = $jsonText | ConvertFrom-Json
            $hasRisks = ($null -ne $parsed) -and ($parsed.PSObject.Properties.Name -contains 'risks') -and $parsed.risks
            if ($hasRisks) {
                $risks = [System.Collections.Generic.List[hashtable]]::new()
                foreach ($r in $parsed.risks) {
                    $level = Get-Prop $r 'level' 'P3'
                    $risks.Add(@{
                        id          = Get-Prop $r 'id' $level
                        level       = $level
                        title       = Get-Prop $r 'title'
                        description = Get-Prop $r 'description'
                        category    = Get-Prop $r 'category'
                        impact      = Get-Prop $r 'impact'
                        fix         = Get-Prop $r 'fix'
                    })
                }
                Write-Log "OK" "JSON extraction: $($risks.Count) risks found"
                return $risks.ToArray()
            }
        } catch {
            Write-Log "WARN" "JSON parse failed. Falling back to regex."
        }
    }

    # --- Method 2: Regex fallback (when JSON block is missing) ---
    Write-Log "WARN" "JSON block not found. Using regex extraction."
    $risks = [System.Collections.Generic.List[hashtable]]::new()
    $lines = $ReviewText -split "`n"
    $current = $null

    foreach ($line in $lines) {
        if ($line -match '\[(P[0-3])-?(\d+)?\]\s*(.+)') {
            if ($current) { $risks.Add($current) }
            $current = @{
                id          = if ($Matches[2]) { "$($Matches[1])-$($Matches[2])" } else { $Matches[1] }
                level       = $Matches[1]
                title       = $Matches[3].Trim()
                description = ""
                category    = ""
            }
        }
        elseif ($line -match 'Category[::]\s*(.+)' -and $current) {
            $current.category = $Matches[1].Trim()
        }
        elseif ($line -match 'Problem[::]\s*(.+)' -and $current) {
            $current.description = $Matches[1].Trim()
        }
    }
    if ($current) { $risks.Add($current) }

    Write-Log "INFO" "Regex extraction: $($risks.Count) risks found"
    return $risks.ToArray()
}

# ================================================================
# Count risk levels
# ================================================================
function Count-RiskLevels {
    param($risks)
    $counts = @{ P0 = 0; P1 = 0; P2 = 0; P3 = 0 }
    foreach ($r in $risks) {
        if ($counts.ContainsKey($r.level)) {
            $counts[$r.level]++
        }
    }
    return $counts
}

# ================================================================
# Aggregate by category
# ================================================================
function Get-Categories {
    param($risks)
    $categories = [System.Collections.Generic.List[string]]::new()
    foreach ($r in $risks) {
        if ($r.category -and -not $categories.Contains($r.category)) {
            $categories.Add($r.category)
        }
    }
    return $categories.ToArray()
}

# ================================================================
# Update summary
# ================================================================
function Update-Summary {
    param($newRecord)

    $summary = if (Test-Path $SUMMARY_FILE) {
        Get-Content $SUMMARY_FILE -Raw -Encoding UTF8 | ConvertFrom-Json
    } else {
        [pscustomobject]@{
            total_reviews  = 0
            total_p0       = 0
            total_p1       = 0
            total_p2       = 0
            total_p3       = 0
            projects       = @{}
            developers     = @{}
            languages      = @{}
            last_updated   = ""
        }
    }

    # Update totals
    $summary.total_reviews++
    $summary.total_p0 += $newRecord.risk_counts.P0
    $summary.total_p1 += $newRecord.risk_counts.P1
    $summary.total_p2 += $newRecord.risk_counts.P2
    $summary.total_p3 += $newRecord.risk_counts.P3
    $summary.last_updated = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")

    $summary | ConvertTo-Json -Depth 10 | Out-File -FilePath $SUMMARY_FILE -Encoding UTF8
    Write-Log "INFO" "Update summary: $SUMMARY_FILE"
}

# ================================================================
# Main
# ================================================================
Write-Log "INFO" "save_memory.ps1 started"

# Load review result when not passed explicitly.
# Reads the dedicated review-result file written by save_review_result.ps1.
# NOTE: never fall back to final_report.md - that file holds the generated prompt
# metadata, not the AI review output, and would silently extract 0 risks.
if (-not $ReviewResult) {
    $resultFile = Join-Path $RootDir "output\review_result.md"
    if (Test-Path $resultFile) {
        $ReviewResult = Get-Content $resultFile -Raw -Encoding UTF8
        Write-Log "INFO" "Review result loaded from: $resultFile"
    } else {
        Write-Log "WARN" "Review result not found: $resultFile"
        $ReviewResult = ""
    }
}

# Guard: refuse to save an empty review (avoids polluting memory with 0-risk records).
if (-not $ReviewResult -or $ReviewResult.Trim().Length -lt 10) {
    Write-Log "ERROR" "No review result to save. Run save_review_result.ps1 to capture the AI review first."
    exit 1
}

# Extract risks
$risks      = Extract-Risks -ReviewText $ReviewResult
$riskCounts = Count-RiskLevels -risks $risks
$categories = Get-Categories -risks $risks

Write-Log "INFO" "Risks detected: P0=$($riskCounts.P0) P1=$($riskCounts.P1) P2=$($riskCounts.P2) P3=$($riskCounts.P3)"

# Create record
$record = [ordered]@{
    id           = [System.Guid]::NewGuid().ToString("N").Substring(0, 8)
    date         = Get-Date -Format "yyyy-MM-dd"
    timestamp    = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    project      = $ProjectName
    developer    = $Developer
    language     = $Language
    mode         = $Mode
    target_file  = $TargetFile
    risk_counts  = $riskCounts
    categories   = $categories
    risks        = $risks
    review_text  = $ReviewResult.Substring(0, [Math]::Min($ReviewResult.Length, 2000))
}

# Save file
$fileName   = "$(Get-Date -Format 'yyyyMMdd_HHmmss')_${ProjectName}_${Language}.json"
$outputPath = Join-Path $REVIEWS_DIR $fileName
$record | ConvertTo-Json -Depth 10 | Out-File -FilePath $outputPath -Encoding UTF8

Write-Log "OK" "Saved: $outputPath"

# Update summary
Update-Summary -newRecord $record

# Display result
Write-Host ""
Write-Host "======================================" -ForegroundColor DarkGray
Write-Host " Memory Saved" -ForegroundColor White
Write-Host "======================================" -ForegroundColor DarkGray
Write-Host " Project : $ProjectName"
Write-Host " Developer       : $Developer"
Write-Host " Language         : $Language"
Write-Host " P0          : $($riskCounts.P0)  items"
Write-Host " P1          : $($riskCounts.P1)  items"
Write-Host " Saved to       : $outputPath"
Write-Host "======================================" -ForegroundColor DarkGray
