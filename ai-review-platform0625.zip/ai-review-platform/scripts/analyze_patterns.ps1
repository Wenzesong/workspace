# analyze_patterns.ps1
# Extract and analyze patterns from past review history

param(
    [Parameter(Mandatory = $false)][string]$RootDir     = "$PSScriptRoot\..",
    [Parameter(Mandatory = $false)][string]$ProjectName = "",
    [Parameter(Mandatory = $false)][string]$Developer   = "",
    [Parameter(Mandatory = $false)][string]$Language    = "",
    [Parameter(Mandatory = $false)][int]$RecentCount    = 10
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$MEMORY_DIR   = Join-Path $RootDir "memory"
$REVIEWS_DIR  = Join-Path $MEMORY_DIR "reviews"
$PATTERNS_DIR = Join-Path $MEMORY_DIR "patterns"
$SUMMARY_FILE = Join-Path $MEMORY_DIR "summary.json"

function Write-Log {
    param([string]$Level, [string]$Message)
    $ts = Get-Date -Format "HH:mm:ss"
    $color = switch ($Level) {
        "INFO" { "Cyan" } "OK" { "Green" } "WARN" { "Yellow" } "ERROR" { "Red" } default { "White" }
    }
    Write-Host "[$ts][$Level] $Message" -ForegroundColor $color
}

# ================================================================
# Load review history
# ================================================================
function Load-Reviews {
    if (-not (Test-Path $REVIEWS_DIR)) { return @() }

    $files = Get-ChildItem $REVIEWS_DIR -Filter "*.json" |
             Sort-Object LastWriteTime -Descending |
             Select-Object -First 50

    $reviews = [System.Collections.Generic.List[object]]::new()
    foreach ($f in $files) {
        try {
            $data = Get-Content $f.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            # Apply filter
            if ($ProjectName -and $data.project -ne $ProjectName) { continue }
            if ($Developer   -and $data.developer -ne $Developer)  { continue }
            if ($Language    -and $data.language -ne $Language)    { continue }
            $reviews.Add($data)
        } catch { }
    }
    return $reviews.ToArray()
}

# ================================================================
# Pattern analysis
# ================================================================
function Analyze-Patterns {
    param($reviews)

    $reviews = @($reviews)  # normalize: never let a single review unwrap to a scalar
    if ($reviews.Count -eq 0) {
        # Return the full schema (not just a message) so downstream display/consumers
        # never hit a missing key under Set-StrictMode -Version Latest. This is the
        # first-run path when no review history exists yet.
        return @{
            review_count   = 0
            total_p0       = 0
            total_p1       = 0
            total_p2       = 0
            p0_per_review  = 0
            top_categories = @()
            trend          = "Insufficient data"
            last_review    = ""
            message        = "No review history found"
        }
    }

    # Aggregate risk levels
    $totalP0 = ($reviews | ForEach-Object { $_.risk_counts.P0 } | Measure-Object -Sum).Sum
    $totalP1 = ($reviews | ForEach-Object { $_.risk_counts.P1 } | Measure-Object -Sum).Sum
    $totalP2 = ($reviews | ForEach-Object { $_.risk_counts.P2 } | Measure-Object -Sum).Sum

    # Aggregate category frequency
    $categoryCount = @{}
    foreach ($r in $reviews) {
        foreach ($cat in $r.categories) {
            if ($cat) {
                if (-not $categoryCount.ContainsKey($cat)) { $categoryCount[$cat] = 0 }
                $categoryCount[$cat]++
            }
        }
    }

    # Sort by frequency
    $topCategories = $categoryCount.GetEnumerator() |
                     Sort-Object Value -Descending |
                     Select-Object -First 5 |
                     ForEach-Object { "$($_.Key)($($_.Value)x)" }

    # P0 occurrence rate
    $p0Rate = if ($reviews.Count -gt 0) {
        [math]::Round($totalP0 / $reviews.Count, 1)
    } else { 0 }

    # Trend (last 3 vs prev 3)
    $trend = "Insufficient data"
    if ($reviews.Count -ge 6) {
        $recent3 = ($reviews[0..2] | ForEach-Object { $_.risk_counts.P0 + $_.risk_counts.P1 } | Measure-Object -Sum).Sum
        $prev3   = ($reviews[3..5] | ForEach-Object { $_.risk_counts.P0 + $_.risk_counts.P1 } | Measure-Object -Sum).Sum
        $trend = if ($recent3 -lt $prev3) { "Improving" }
                 elseif ($recent3 -gt $prev3) { "Worsening" }
                 else { "Stable" }
    }

    return @{
        review_count    = $reviews.Count
        total_p0        = $totalP0
        total_p1        = $totalP1
        total_p2        = $totalP2
        p0_per_review   = $p0Rate
        top_categories  = $topCategories
        trend           = $trend
        last_review     = $reviews[0].timestamp
    }
}

# ================================================================
# Generate memory context (text to add to Prompt)
# ================================================================
function Build-MemoryContext {
    param($reviews, $patterns)

    $reviews = @($reviews)  # normalize: never let a single review unwrap to a scalar
    if ($reviews.Count -eq 0) { return "" }

    $sb = [System.Text.StringBuilder]::new()
    $null = $sb.AppendLine("# Past Review History (Memory)")
    $null = $sb.AppendLine("")

    # Summary
    $null = $sb.AppendLine("## Statistics Summary")
    $null = $sb.AppendLine("- Review count : $($patterns.review_count)")
    $null = $sb.AppendLine("- P0 Total   $($patterns.total_p0)  items   per review $($patterns.p0_per_review)  items   ")
    $null = $sb.AppendLine("- P1 Total   $($patterns.total_p1)  items")
    $null = $sb.AppendLine("- Trend   $($patterns.trend)")
    $null = $sb.AppendLine("- Top categories   $($patterns.top_categories -join ' / ')")
    $null = $sb.AppendLine("")


    $null = $sb.AppendLine("## Recent Review Results")
    $recent = $reviews | Select-Object -First 3
    foreach ($r in $recent) {
        $null = $sb.AppendLine("- $($r.date) [$($r.language)] P0:$($r.risk_counts.P0) P1:$($r.risk_counts.P1) | $($r.target_file)")
    }
    $null = $sb.AppendLine("")

    # Repeatedly Detected Risks
    $repeatRisks = [System.Collections.Generic.Dictionary[string,int]]::new()
    foreach ($r in $reviews) {
        foreach ($risk in $r.risks) {
            if ($risk.title) {
                if (-not $repeatRisks.ContainsKey($risk.title)) {
                    $repeatRisks[$risk.title] = 0
                }
                $repeatRisks[$risk.title]++
            }
        }
    }

    $repeated = $repeatRisks.GetEnumerator() |
                Where-Object { $_.Value -ge 2 } |
                Sort-Object Value -Descending |
                Select-Object -First 5

    if ($repeated) {
        $null = $sb.AppendLine("## Repeatedly detected risks (attention required)")
        foreach ($item in $repeated) {
            $null = $sb.AppendLine("- $($item.Key)   $($item.Value)  times detected")
        }
        $null = $sb.AppendLine("")
    }

    $null = $sb.AppendLine("## Review Policy")
    $null = $sb.AppendLine("Check repeatedly occurring risks based on the above history.")
    $null = $sb.AppendLine("Improving                                                               ")

    return $sb.ToString()
}

# ================================================================

# ================================================================
Write-Log "INFO" "analyze_patterns.ps1       "

# @(...) forces an array so a single review file is not unwrapped to a scalar
# (which would break .Count / indexing under Set-StrictMode -Version Latest).
$reviews  = @(Load-Reviews)
$patterns = Analyze-Patterns -reviews $reviews
$context  = Build-MemoryContext -reviews $reviews -patterns $patterns

Write-Log "OK" "Analysis complete: $($reviews.Count)  items                        "

# Save to pattern file
$null = New-Item -ItemType Directory -Path $PATTERNS_DIR -Force
$patternFile = Join-Path $PATTERNS_DIR "latest_patterns.json"
$patterns | ConvertTo-Json -Depth 10 | Out-File -FilePath $patternFile -Encoding UTF8

# Save memory context file (read by build_prompt.ps1)
$contextFile = Join-Path $MEMORY_DIR "memory_context.txt"
$context | Out-File -FilePath $contextFile -Encoding UTF8

Write-Log "OK" "Memory context saved: $contextFile"


Write-Host ""
Write-Host "======================================" -ForegroundColor DarkGray
Write-Host " Pattern analysis      " -ForegroundColor White
Write-Host "======================================" -ForegroundColor DarkGray
Write-Host " Review count : $($patterns.review_count)"
Write-Host " P0 Total      : $($patterns.total_p0)"
Write-Host " Trend     : $($patterns.trend)"
if ($patterns.top_categories) {
    Write-Host " Top categories : $($patterns.top_categories -join ' / ')"
}
Write-Host "======================================" -ForegroundColor DarkGray

# Return value (when called from review.ps1)
return $context
