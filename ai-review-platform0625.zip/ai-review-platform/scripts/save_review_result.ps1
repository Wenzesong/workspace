# save_review_result.ps1
# Paste Claude/ChatGPT review result and save to memory

param(
    [Parameter(Mandatory = $false)][ValidateSet("java","csharp","sql","linux")][string]$Language = "java",
    [Parameter(Mandatory = $false)][string]$ProjectName = "default",
    [Parameter(Mandatory = $false)][string]$Developer   = "unknown",
    [Parameter(Mandatory = $false)][string]$TargetFile  = "",
    [Parameter(Mandatory = $false)][string]$RootDir     = "$PSScriptRoot\.."
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$OUTPUT_DIR = Join-Path $RootDir "output"
# Dedicated AI-review-result file. Kept separate from final_report.md (which holds the
# generated prompt metadata) so save_memory.ps1 always reads the real review output.
$RESULT_FILE = Join-Path $OUTPUT_DIR "review_result.md"

function Write-Log {
    param([string]$Level, [string]$Message)
    $ts = Get-Date -Format "HH:mm:ss"
    $color = switch ($Level) {
        "INFO"  { "Cyan" }
        "OK"    { "Green" }
        "WARN"  { "Yellow" }
        "ERROR" { "Red" }
        default { "White" }
    }
    Write-Host "[$ts][$Level] $Message" -ForegroundColor $color
}

# ================================================================
# Try clipboard
# ================================================================
function Get-ResultFromClipboard {
    try {
        $clip = Get-Clipboard -Raw
        if ($clip -and $clip.Length -gt 100) {
            Write-Host ""
            Write-Host "Clipboard content detected ($([math]::Round($clip.Length/1KB,1)) KB)" -ForegroundColor Cyan
            $confirm = Read-Host "Use clipboard content? (Y/N)"
            if ($confirm -match "^[Yy]") {
                return $clip
            }
        }
    } catch { }
    return $null
}

# ================================================================
# Receive multiline input
# ================================================================
function Get-MultilineInput {
    Write-Host ""
    Write-Host "================================================================" -ForegroundColor DarkGray
    Write-Host " Paste review result from Claude/ChatGPT" -ForegroundColor White
    Write-Host " Press Enter twice to finish" -ForegroundColor DarkGray
    Write-Host "================================================================" -ForegroundColor DarkGray
    Write-Host ""

    $lines  = [System.Collections.Generic.List[string]]::new()
    $empty  = 0

    while ($true) {
        $line = Read-Host
        if ($line -eq "") {
            $empty++
            if ($empty -ge 2) { break }
            $lines.Add("")
        } else {
            $empty = 0
            $lines.Add($line)
        }
    }

    return $lines -join "`n"
}

# ================================================================

# ================================================================
Write-Host ""
Write-Host "================================================================" -ForegroundColor DarkGray
Write-Host " Enterprise AI Review Platform" -ForegroundColor White
Write-Host " Save Review Result" -ForegroundColor White
Write-Host "================================================================" -ForegroundColor DarkGray
Write-Host " Project  : $ProjectName"
Write-Host " Developer: $Developer"
Write-Host " Language : $Language"
Write-Host "================================================================" -ForegroundColor DarkGray

# If TargetFile is not specified, Prompt for input
if (-not $TargetFile) {
    Write-Host ""
    $TargetFile = Read-Host "Target file name (Enter to skip)"
}

# Try clipboard
$reviewResult = Get-ResultFromClipboard

# Manual input fallback
if (-not $reviewResult) {
    $reviewResult = Get-MultilineInput
}

if (-not $reviewResult -or $reviewResult.Trim().Length -lt 10) {
    Write-Log "ERROR" "No content entered."
    exit 1
}

Write-Log "INFO" "Content received: $([math]::Round($reviewResult.Length/1KB,1)) KB"


if (-not (Test-Path $OUTPUT_DIR)) {
    New-Item -ItemType Directory -Path $OUTPUT_DIR | Out-Null
}

$reviewResult | Out-File -FilePath $RESULT_FILE -Encoding UTF8
Write-Log "OK" "Saved: $RESULT_FILE"

# Save with date backup
$backupDir  = Join-Path $OUTPUT_DIR "history"
if (-not (Test-Path $backupDir)) {
    New-Item -ItemType Directory -Path $backupDir | Out-Null
}
$backupName = "$(Get-Date -Format 'yyyyMMdd_HHmmss')_${ProjectName}_${Language}.md"
$backupPath = Join-Path $backupDir $backupName
$reviewResult | Out-File -FilePath $backupPath -Encoding UTF8
Write-Log "OK" "Backup: $backupPath"


$saveMemoryScript = Join-Path $PSScriptRoot "save_memory.ps1"
if (Test-Path $saveMemoryScript) {
    Write-Log "INFO" "Saving to memory..."
    & "$saveMemoryScript" `
        -Language     $Language `
        -Mode         "new-review" `
        -ProjectName  $ProjectName `
        -Developer    $Developer `
        -TargetFile   $TargetFile `
        -RootDir      $RootDir `
        -ReviewResult $reviewResult
} else {
    Write-Log "WARN" "save_memory.ps1 not found. Memory registration skipped."
}

# Completion
Write-Host ""
Write-Host "================================================================" -ForegroundColor DarkGray
Write-Host " Saved successfully" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor DarkGray
Write-Host " Result  : $RESULT_FILE"
Write-Host " Backup  : $backupPath"
Write-Host " Memory  : memory/reviews/ updated"
Write-Host "================================================================" -ForegroundColor DarkGray