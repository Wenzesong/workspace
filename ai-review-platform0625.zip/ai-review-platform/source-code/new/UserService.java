package com.example.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.CompletableFuture;

/**
 * ユーザサービス
 * ※ 動作確認用: 意図的にリスクを含んでいます
 */
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // ----------------------------------------------------------------
    // [Risk P1] @Async void → 例外が握りつぶされる
    // ----------------------------------------------------------------
    @Async
    public void sendWelcomeEmail(Long userId) {
        // 例外が発生しても呼び出し元に伝わらない
        // CompletableFuture<Void> にすべき
        User user = userRepository.findById(userId).get(); // Optional未処理
        emailService.send(user.getEmail(), "ようこそ");
    }

    @Autowired
    private EmailService emailService;

    // ----------------------------------------------------------------
    // [Risk P0] パスワードを平文で保存
    // ----------------------------------------------------------------
    @Transactional
    public User register(String email, String password) {
        User user = new User();
        user.setEmail(email);
        user.setPassword(password); // ← BCrypt等でハッシュ化すべき

        // [Risk P1] メールアドレスの重複チェックと INSERT が非アトミック
        // チェック後に別リクエストが同一メールで登録すると重複する
        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("メールアドレスが既に使われています");
        }

        return userRepository.save(user);
    }

    // ----------------------------------------------------------------
    // [Risk P1] JWTトークンの検証なし
    // ----------------------------------------------------------------
    public User getUserFromToken(String token) {
        // Base64デコードするだけで署名検証なし
        String userId = new String(
            java.util.Base64.getDecoder().decode(token.split("\\.")[1])
        );
        // 誰でも任意のuserIdをBase64エンコードして認証できる
        return userRepository.findById(Long.parseLong(userId)).orElse(null);
    }

    // ----------------------------------------------------------------
    // [Risk P1] CompletableFuture の例外ハンドリングなし
    // ----------------------------------------------------------------
    public CompletableFuture<User> findUserAsync(Long userId) {
        return CompletableFuture.supplyAsync(() -> {
            return userRepository.findById(userId).get(); // NoSuchElementException
            // exceptionally / handle なし
        });
        // タイムアウト設定なし
    }
}
