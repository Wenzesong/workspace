# Enterprise AI Review Platform

本番障害を未然に防ぐための AI コードレビュー基盤。
単純なコードチェックではなく、**Runtime Failure Prediction** を目的とした Enterprise グレードのレビューシステム。

---

## コンセプト

### Risk-Based Dynamic Loading
コードの内容に応じて必要な Agent・Skill だけを動的にロードする。
Language-Based（言語ごとに固定ロード）ではなく、検出されたリスクパターンに基づく。

```
@Transactional 検出
  → transaction_agent + deadlock_skill + rollback_skill を自動ロード
```

### AIにゼロから考えさせない
毎回大きな Prompt を渡すのではなく、必要な知識だけを組み合わせて渡す。
Token 効率とレビュー品質の安定化を両立する。

### Review Memory（過去学習）
レビュー結果を蓄積し、繰り返し検出されるリスクを次回プロンプトへ自動注入する。
チーム・プロジェクト固有の弱点を AI が記憶し、見落とし防止と精度向上を図る。

```
過去レビュー結果
  → リスク抽出・構造化保存（memory/reviews/）
  → パターン分析（繰り返しリスク・トレンド検出）
  → 次回プロンプトへ自動注入（memory/memory_context.txt）
```

---

## フォルダ構成

```
enterprise-ai-review-platform/
│
├── README.md
│
├── ai-review/
│   ├── platform/        # AI の思考基盤（全レビューで必ずロード）
│   ├── agents/          # 役割別 AI エージェント定義
│   │   ├── shared/      # 言語共通エージェント
│   │   ├── java/        # Java 専用エージェント
│   │   ├── csharp/      # C# 専用エージェント
│   │   ├── linux/       # Linux/Shell 専用エージェント
│   │   └── sql/         # SQL 専用エージェント
│   ├── skills/          # 専門知識ルール
│   │   ├── shared/      # 言語共通スキル（常時ロード）
│   │   ├── java/        # Java 専用スキル
│   │   ├── csharp/      # C# 専用スキル
│   │   ├── linux/       # Linux 専用スキル
│   │   └── sql/         # SQL 専用スキル（Tier1〜3）
│   ├── prompts/         # タスク定義
│   ├── templates/       # AI 出力フォーマット
│   └── routing/         # 動的ロードルール（YAML）
│
├── source-code/
│   ├── new/             # レビュー対象コード（必須）
│   └── old/             # 修正前コード（diff モード時）
│
├── output/              # 生成された Prompt・レポート
│   ├── agent_outputs/   # Agent 別出力（デバッグ用）
│   └── history/         # レビュー結果バックアップ（タイムスタンプ付き）
│
├── memory/              # レビュー履歴・パターン蓄積
│   ├── reviews/         # レビュー結果 JSON（1レビュー1ファイル）
│   ├── patterns/        # パターン分析結果
│   └── summary.json     # 累積統計（P0/P1 合計・プロジェクト別）
│
├── scripts/             # 実行スクリプト
│   ├── review.ps1           # エントリポイント（Windows）
│   ├── detect_context.ps1   # コンテキスト検出
│   ├── build_prompt.ps1     # Prompt 組み立て
│   ├── save_review_result.ps1  # レビュー結果の保存
│   ├── save_memory.ps1      # リスク抽出・メモリ書き込み
│   ├── analyze_patterns.ps1 # 過去履歴のパターン分析
│   └── review.sh            # エントリポイント（Linux/Mac）
│
└── config/
    └── platform.yaml    # プラットフォーム設定
```

---

## 使い方

### 1. コードを配置する

```
# 新規レビューの場合
source-code/new/ にファイルを配置

# 差分レビューの場合
source-code/old/ に修正前、source-code/new/ に修正後を配置
```

### 2. スクリプトを実行する

```powershell
# Windows
.\scripts\review.ps1 -Language java -Mode new-review
.\scripts\review.ps1 -Language java -Mode diff-review
.\scripts\review.ps1 -Language sql  -Mode new-review
.\scripts\review.ps1 -Language csharp -Mode diff-review

# Linux / Mac
bash scripts/review.sh -l java -m diff-review
```

### 3. 生成された Prompt を Claude に貼り付ける

```
output/final_review_prompt.txt を Claude に貼り付けてレビューを開始する
```

---

## 対応言語・モード

| 言語 | -Language |
|---|---|
| Java / Spring Boot | `java` |
| C# / ASP.NET Core | `csharp` |
| Linux / Shell / Docker / K8s | `linux` |
| SQL | `sql` |

| モード | -Mode | 説明 |
|---|---|---|
| 新規レビュー | `new-review` | 新規コードのレビュー |
| 差分レビュー | `diff-review` | 修正前後の差分レビュー |
| 新規テスト | `new-test` | テストケース生成 |
| 差分テスト | `diff-test` | 回帰テストケース生成 |

---

## Skill Tier について

SQL Skill は検出されたリスクの複雑度に応じて Tier を自動選択する。

| Tier | ロード条件 | 例 |
|---|---|---|
| Tier1 | 必須（常時） | transaction_skill, deadlock_skill, sql_injection_skill |
| Tier2 | コードで検出されたリスクに応じて | index_skill, slow_query_skill, migration_skill |
| Tier3 | 高度な分析が必要な場合 | join_optimization_skill, subquery_skill |

---

## メモリ機能

### 概要

レビュー結果を構造化 JSON として蓄積し、過去の傾向を次回レビューへフィードバックする機能。  
繰り返し発生するリスクや、チーム・プロジェクト固有の弱点を AI が記憶することで精度を向上させる。

### データフロー

```
Claude でレビュー実施
    ↓
save_review_result.ps1   ← 結果をクリップボードまたは手動ペーストで取得
    ↓
save_memory.ps1          ← P0〜P3 リスクを抽出・構造化して JSON 保存
    ↓
memory/reviews/          ← レビュー履歴を蓄積
    ↓
analyze_patterns.ps1     ← 過去データを分析（トレンド・繰り返しリスク）
    ↓
memory/memory_context.txt ← 次回レビュー時に build_prompt.ps1 がプロンプトへ注入
```

### 使い方

```powershell
# 1. レビュー結果を保存する（クリップボード自動取得 or 手動ペースト）
.\scripts\save_review_result.ps1 -Language java -ProjectName my-app -Developer ukben

# 2. 過去履歴を分析してメモリコンテキストを生成する
.\scripts\analyze_patterns.ps1 -Language java -ProjectName my-app

# 3. 次回レビュー時は通常通り実行（memory_context.txt が自動でプロンプトに含まれる）
.\scripts\review.ps1 -Language java -Mode diff-review
```

フィルタオプション：`-ProjectName`・`-Developer`・`-Language` で絞り込み可能。

### 保存形式

`memory/reviews/yyyyMMdd_HHmmss_{Project}_{Language}.json` に1レビュー1ファイルで保存。

```json
{
  "id": "a1b2c3d4",
  "date": "2026-06-02",
  "project": "my-app",
  "developer": "ukben",
  "language": "java",
  "risk_counts": { "P0": 1, "P1": 2, "P2": 3, "P3": 1 },
  "categories": ["transaction", "performance"],
  "risks": [
    { "level": "P0", "title": "トランザクション境界なしで複数テーブル更新", "description": "..." }
  ]
}
```

### パターン分析の内容

| 分析項目 | 説明 |
|---|---|
| P0/P1/P2 合計 | 累積リスク件数 |
| P0 発生率 | 1レビューあたりの平均 P0 件数 |
| トレンド | 直近3件 vs 前3件の比較（Improving / Stable / Worsening） |
| Top カテゴリ | 出現頻度が高いリスクカテゴリ Top5 |
| 繰り返しリスク | 2回以上検出されたリスクタイトル（要注意） |

### リスク抽出方式

AI 出力から P0〜P3 を2段階で自動抽出する。

| 優先度 | 方式 | 条件 |
|---|---|---|
| 1st | JSON ブロック抽出 | AI 出力に ` ```json ` ブロックがある場合 |
| 2nd | 正規表現フォールバック | JSON ブロックがない場合（`[P0]` 形式を解析） |

---

## リスクレベル

| Level | 意味 | 対応 |
|---|---|---|
| P0 | Critical: 本番障害・データ破壊 | 即時対応必須 |
| P1 | High: 高負荷時・特定条件で障害 | リリース前に対応 |
| P2 | Medium: 将来の保守・性能に影響 | 次スプリントで対応 |
| P3 | Suggestion: 改善推奨 | 任意対応 |
