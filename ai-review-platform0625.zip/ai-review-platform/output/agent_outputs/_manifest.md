﻿# Agent/Skill Manifest
Generated: 2026-05-17 16:23:41

## Loaded Agents
- performance_architect_agent
- security_architect_agent
- review_orchestrator_agent
- java_architect_agent

## Loaded Skills
- performance_skill
- security_skill
- spring_boot_skill
- java_skill

## Matched Rules

