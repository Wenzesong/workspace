﻿# Review Report

| Item | Value |
|---|---|
| Generated | 2026-05-17 16:23:41 |
| Language  | java |
| Mode      | new-review |
| Tier      | 1 |
| Prompt    | 21.4 KB |

## Loaded Agents (4)

- performance_architect_agent
- security_architect_agent
- review_orchestrator_agent
- java_architect_agent

## Loaded Skills (4)

- performance_skill
- security_skill
- spring_boot_skill
- java_skill

## Matched Risk Rules

- (none: base context used)

## Next Step

Paste output\final_review_prompt.txt into Claude or ChatGPT.

