@skill: logging_skill

# Purpose
ログ設計・機密情報保護・ログレベルに関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- log.info / log.error / logger
- Console.WriteLine / System.out.println
- password / token / secret を含む変数

---

# Risk Pattern

## 機密情報漏洩
- パスワード・APIキー・トークンのログ出力
- 個人情報（氏名・メールアドレス）のログ出力
- スタックトレースへの内部構造露出

## ログレベル不適切
- 本番環境での DEBUG ログ全出力
- エラーを INFO レベルで出力
- 例外を握りつぶして何もログしない

## 構造化ログ未使用
- 文字列結合による非構造化ログ
- 検索・集計不可のログ形式

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 機密情報ログ出力 | P1 | ログ基盤経由での情報漏洩 |
| 例外の無音握りつぶし | P1 | 障害発生時に原因追跡不能 |
| 本番 DEBUG ログ | P2 | 性能劣化・情報過多 |
