@skill: observability_skill

# Purpose
メトリクス・トレース・アラート設計に関する知識ルール。
本番障害の早期検知と原因追跡可能性を評価する。

---

# Auto Load Condition
以下を検出した場合にロード：
- Micrometer / Prometheus / OpenTelemetry
- Datadog / New Relic / CloudWatch
- traceId / spanId / correlationId

---

# Risk Pattern

## トレーサビリティ欠如
- 分散トレーシング未実装
- リクエスト ID の未伝播
- 非同期処理でのコンテキスト消失

## メトリクス不足
- エラーレート未計測
- レイテンシパーセンタイル未計測
- ビジネスメトリクス未定義

## アラート設計
- アラート未設定
- 誤検知率の高いアラート閾値
- 復旧確認の仕組みなし

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 分散トレーシング未実装 | P2 | 障害時の原因特定が困難 |
| エラーレート未計測 | P2 | 障害の早期検知不能 |
