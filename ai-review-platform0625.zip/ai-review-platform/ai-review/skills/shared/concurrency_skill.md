@skill: concurrency_skill

# Purpose
競合状態・デッドロック・Race Condition に関する知識ルール。
マルチスレッド・非同期処理のリスクを分析する。

---

# Auto Load Condition
以下を検出した場合にロード：
- Thread / async / await / synchronized
- @Async / Task / Promise
- static フィールドへの書き込み
- シングルトンへの状態保持

---

# Risk Pattern

## Race Condition
- 複数スレッドからの同一リソース無保護書き込み
- Check-Then-Act の非アトミック操作
- シングルトンへのリクエスト固有データ保持

## デッドロック
- 複数リソースの逆順ロック取得
- ロック保持中の外部API呼び出し
- トランザクション内でのロック待機

## 非同期問題
- async void（例外が握りつぶされる）
- await なしの非同期メソッド呼び出し
- キャンセレーショントークン未伝播

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| Race Condition（データ書き込み） | P0 | データ破壊につながる |
| デッドロック | P0 | サービス停止につながる |
| async void | P1 | 例外が検知されずサイレント障害 |
| シングルトンへの状態保持 | P1 | リクエスト間のデータ汚染 |
