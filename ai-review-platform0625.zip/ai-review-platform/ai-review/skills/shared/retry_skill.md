@skill: retry_skill

# Purpose
Retry・Exponential Backoff・冪等性に関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- retry / Retry / リトライ
- @Retryable / Polly / resilience
- catch 内での再実行ロジック

---

# Risk Pattern

## リトライ設計
- 固定間隔リトライによるサーバ集中負荷
- リトライ上限なし（無限ループリスク）
- 冪等でない処理のリトライ（重複処理）

## Backoff 未実装
- Exponential Backoff なしの高頻度リトライ
- Jitter なしによるリトライ集中（Thundering Herd）

## リトライ対象の誤設定
- 4xx エラー（クライアントエラー）のリトライ
- 冪等性のない POST のリトライ

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 冪等性なし処理のリトライ | P0 | 重複決済・重複登録 |
| リトライ上限なし | P1 | 無限ループによるリソース枯渇 |
| Thundering Herd | P1 | 障害復旧時の再度の過負荷 |
