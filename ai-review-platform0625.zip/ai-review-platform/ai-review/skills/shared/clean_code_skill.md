@skill: clean_code_skill

# Purpose
コードの可読性・保守性・責務分離に関する知識ルール。
コードスタイルの指摘に留まらず、保守性が本番品質に与える影響を分析する。

---

# Auto Load Condition
以下を検出した場合にロード：
- クラスが500行超
- メソッドが50行超
- 同一ロジックの重複
- God Class パターン

---

# Risk Pattern

## 責務過多
- 1クラスが複数のビジネスロジックを担当
- Controller に業務ロジックが混入
- Service が DB・外部API・ビジネスルールを全て持つ

## 命名問題
- 意図が不明な変数名（data, tmp, flag, obj）
- 否定形フラグ（isNotValid, disableFlag）
- 一貫性のない命名規則混在

## 重複コード
- 同一処理が3箇所以上に存在
- コピペによる微妙な差異が障害原因になるリスク

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 責務過多による変更影響範囲の不明確化 | P2 | 修正時の回帰リスク上昇 |
| 重複ロジックの片方だけ修正 | P1 | 本番での動作不整合 |
| 命名不整合による意図誤解 | P2 | バグ混入リスク |

---

# Forbidden Output
- 「命名を改善してください」だけの指摘
- 根拠なきリファクタリング要求

---

# Verbose Implementation Pattern（冗長な実装パターン）

動作には問題ないが、保守性・拡張性を下げる
冗長な実装パターンを検出し、改善版コード生成時に
プロアクティブに修正すること。指摘するだけでなく
改善版コードでは必ず簡潔な実装に置き換える。

## 手動 Bean / DTO コピー

### 検出条件
- 同一オブジェクトに対して setter を3回以上連続で呼んでいる
- getter → setter の組み合わせがフィールド数分繰り返されている
- 新しいフィールドが追加されるたびに同様のコピー処理が
  複数箇所に増えていく構造になっている

### 危険パターン
```java
OrderDTO dto = new OrderDTO();
dto.setId(order.getId());
dto.setUserId(order.getUserId());
dto.setStatus(order.getStatus());
dto.setTotalAmount(order.getTotalAmount());
dto.setCreatedAt(order.getCreatedAt());
return dto;
```

問題点：
- フィールド追加時にコピー処理の修正漏れが発生しやすい（P2）
- 同じコピー処理が複数箇所に存在し、修正漏れで不整合が起きる（P1）
- null チェックが省略されがちで NPE の温床になる（P1）

### 改善パターン（Java）

優先順位：
1. MapStruct（コンパイル時生成・型安全・パフォーマンス最良）
2. Builder + ファクトリメソッド（依存追加不可の場合）
3. コンストラクタでの一括マッピング（最低限の改善）

```java
// MapStruct を使う場合
@Mapper
public interface OrderMapper {
    OrderDTO toDto(Order order);
}

// 呼び出し側
OrderDTO dto = orderMapper.toDto(order);
```

依存追加ができない制約がある場合：
```java
// コンストラクタ一括マッピング（最低限の改善）
public OrderDTO(Order order) {
    this.id          = order.getId();
    this.userId      = order.getUserId();
    this.status      = order.getStatus();
    this.totalAmount = order.getTotalAmount();
    this.createdAt   = order.getCreatedAt();
}
```

### 改善パターン（C#）

```csharp
// AutoMapper を使う場合
public class OrderProfile : Profile {
    public OrderProfile() {
        CreateMap<Order, OrderDto>();
    }
}

// 呼び出し側
var dto = mapper.Map<OrderDto>(order);
```

## その他の冗長パターン

### 手動 null チェックの連鎖
```java
// 危険：ネストが深い手動nullチェック
if (order != null) {
    if (order.getUser() != null) {
        if (order.getUser().getAddress() != null) {
            return order.getUser().getAddress().getCity();
        }
    }
}
return null;
```

改善：
```java
return Optional.ofNullable(order)
    .map(Order::getUser)
    .map(User::getAddress)
    .map(Address::getCity)
    .orElse(null);
```

### 手動コレクション変換
```java
// 危険：手動でループしてList変換
List<OrderDTO> dtos = new ArrayList<>();
for (Order order : orders) {
    dtos.add(convertToDto(order));
}
```

改善：
```java
List<OrderDTO> dtos = orders.stream()
    .map(orderMapper::toDto)
    .collect(Collectors.toList());
```

---

# Severity Rule（追加）

| パターン | レベル | 理由 |
|---|---|---|
| 手動Beanコピー（5フィールド以上） | P2 | フィールド追加時の修正漏れリスク |
| 同一コピー処理が複数箇所に存在 | P1 | 修正漏れによるデータ不整合 |
| 手動Beanコピーでnullチェック省略 | P1 | NPEによる本番障害 |
| ネストした手動nullチェック | P3 | 可読性低下・保守コスト増 |
| 手動ループでのコレクション変換 | P3 | 可読性低下（バグリスクは低い） |

---

# Code Generation Rule

改善版コード生成時、上記パターンを検出した場合：
- 既存の依存（pom.xml / *.csproj）に MapStruct/AutoMapper があれば、それを使用する
- 依存がなく追加もできない制約がある場合は、コンストラクタ一括マッピングに留める
- 新規に依存を追加する提案をする場合は、改善版コードの分割理由欄にその旨を明記する
