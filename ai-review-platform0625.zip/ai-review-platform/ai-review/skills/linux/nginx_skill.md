@skill: nginx_skill

# Purpose
Nginx 設定のリスクパターンとパフォーマンス最適化の知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- nginx.conf / server { / location / proxy_pass

---

# Risk Pattern

## セキュリティヘッダ
- X-Frame-Options 未設定（Clickjacking）
- Content-Security-Policy 未設定
- Server トークン露出（nginx バージョン公開）

## パフォーマンス
- gzip 未設定
- keepalive_timeout の不適切な設定
- worker_processes の未チューニング

## プロキシ設定
- upstream へのヘルスチェック未設定
- proxy_read_timeout の未設定
- リクエストサイズ制限未設定

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| proxy_read_timeout 未設定 | P1 | 上流障害時のコネクション積み上がり |
| Server トークン露出 | P2 | バージョン情報による攻撃促進 |
