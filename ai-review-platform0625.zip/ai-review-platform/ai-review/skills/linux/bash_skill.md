@skill: bash_skill

# Purpose
Bash スクリプト固有のリスクパターンと安全な記述パターンの知識ルール。

---

# Auto Load Condition
Language=linux の場合に常時ロード

---

# Risk Pattern

## 基本的な安全設計
- set -euo pipefail 未使用（エラー無視での処理続行）
- 変数のダブルクォート未使用（Word Splitting）
- 未定義変数の無防備な使用

## エラー処理
- コマンド終了コードの未チェック
- パイプ内エラーの握りつぶし（PIPESTATUS 未使用）
- trap による終了処理未定義

## 危険なパターン
- eval の使用（コードインジェクション）
- rm -rf に変数を直接使用
- テンポラリファイルの競合（mktemp 未使用）

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| rm -rf $VAR（未検証変数） | P0 | 変数空文字でルート削除 |
| eval の使用 | P0 | コードインジェクション |
| set -e 未使用 | P1 | エラー後も処理が継続 |
