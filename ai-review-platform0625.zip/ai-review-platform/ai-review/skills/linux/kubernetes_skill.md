@skill: kubernetes_skill

# Purpose
Kubernetes Manifest のリスクパターンに関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- kind: Deployment / Pod / Service / Ingress
- kubectl / helm / kustomize

---

# Risk Pattern

## リソース設定
- requests / limits 未設定（ノード OOM のリスク）
- limits のみ設定（Throttling リスク）
- HPA 未設定での固定レプリカ

## 可用性
- PodDisruptionBudget 未設定
- readinessProbe / livenessProbe 未設定
- 単一 AZ への偏り（podAntiAffinity 未設定）

## セキュリティ
- privileged: true の使用
- hostNetwork / hostPID の使用
- secrets の ConfigMap への平文保存

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| privileged: true | P0 | ホストへの完全アクセス |
| secrets の平文保存 | P0 | 機密情報の露出 |
| readinessProbe 未設定 | P1 | 起動未完了 Pod へのトラフィック流入 |
