@skill: docker_skill

# Purpose
Dockerfile・Docker Compose のリスクパターンに関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- Dockerfile / docker-compose / FROM / RUN

---

# Risk Pattern

## イメージセキュリティ
- root ユーザでのプロセス実行
- latest タグの使用（再現性なし）
- 機密情報を ENV / ARG でイメージに焼き込み

## ビルド最適化
- レイヤキャッシュを無効化する COPY . . の早期実行
- 不要なパッケージの本番イメージ混入
- マルチステージビルド未使用

## リソース
- メモリ・CPU 制限未設定
- ヘルスチェック未定義
- ログローテーション未設定

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| root 実行 | P1 | コンテナ脱出時の影響最大化 |
| 機密情報の ENV 焼き込み | P0 | イメージ共有で機密漏洩 |
| latest タグ使用 | P1 | 意図しないバージョン変更 |
