@skill: validation_skill

# Purpose
Bean Validation・入力検証に関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- @Valid / @Validated / @NotNull / @Size
- BindingResult / ConstraintViolation

---

# Risk Pattern

## バリデーション欠如
- @Valid なしの @RequestBody 受取
- ネストオブジェクトへの @Valid 未付与
- カスタムバリデーションの副作用

## エラーハンドリング
- BindingResult 未チェックでの処理続行
- バリデーションエラーの詳細を外部に露出
- 国際化未対応のエラーメッセージ

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| @Valid 未付与での入力受取 | P1 | 不正データの業務処理流入 |
| エラー詳細の外部露出 | P2 | 内部構造の情報漏洩 |
