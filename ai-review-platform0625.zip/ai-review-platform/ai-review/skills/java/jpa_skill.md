@skill: jpa_skill

# Purpose
JPA/Hibernate 固有のリスクパターンに関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- @Entity / @Repository / JpaRepository
- EntityManager / @OneToMany / @ManyToOne

---

# Risk Pattern

## N+1問題
- @OneToMany の LAZY ロードをループ内で参照
- fetch = FetchType.EAGER の乱用
- JOIN FETCH 未使用

## 一次キャッシュ問題
- 長期間のトランザクションでの一次キャッシュ肥大化
- バッチ処理での flush/clear 未実行
- detached エンティティの意図しない更新

## スキーマ管理
- hbm2ddl.auto=update の本番使用
- 本番での hbm2ddl.auto=create
- マイグレーション管理なし

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| hbm2ddl.auto=create 本番使用 | P0 | 起動時にデータ全消去 |
| N+1（大量データ） | P1 | 高負荷時にDB接続枯渇 |
| バッチでの flush 未実行 | P1 | OOM によるプロセス停止 |
