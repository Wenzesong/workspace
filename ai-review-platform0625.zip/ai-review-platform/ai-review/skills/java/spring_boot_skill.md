@skill: spring_boot_skill

# Purpose
Spring Boot 固有のリスクパターンに関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- @SpringBootApplication / @RestController / @Service
- @Autowired / @Bean / @Configuration

---

# Risk Pattern

## Bean スコープ問題
- Singleton Bean へのリクエスト固有状態保持
- Prototype Bean の Singleton への注入
- @SessionScope の不適切な使用

## AOP・プロキシ問題
- 同一クラス内メソッド呼び出しで @Transactional が効かない
- @Async が同一クラス内呼び出しで効かない
- final メソッドへの AOP 適用不可

## 設定・プロパティ
- 環境変数のデフォルト値なし（起動失敗リスク）
- @Value での型不一致による起動エラー
- プロファイル設定の本番誤適用

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| Singleton への状態保持 | P0 | リクエスト間のデータ汚染 |
| @Transactional の無効化 | P0 | トランザクション境界の消失 |
| プロパティ未定義での起動 | P1 | 本番起動失敗 |
