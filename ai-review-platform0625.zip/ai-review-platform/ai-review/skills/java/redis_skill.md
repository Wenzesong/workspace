@skill: redis_skill

# Purpose
Redis Cache に関するリスクパターンの知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- RedisTemplate / @Cacheable / @CacheEvict
- Jedis / Lettuce / redisson

---

# Risk Pattern

## キャッシュ不整合
- DB 更新後のキャッシュ未削除
- @CacheEvict の key 指定ミス
- Cache-Aside パターンの実装漏れ

## TTL 設計
- TTL 未設定（キャッシュが永続化）
- 短すぎる TTL によるキャッシュヒット率低下
- Cache Stampede（同時期 TTL 切れ）

## 分散ロック
- Redisson 未使用での自前ロック実装
- ロック取得失敗時の処理未定義
- ロック TTL 未設定（デッドロック）

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| DB更新後のキャッシュ未削除 | P1 | 古いデータによる業務誤処理 |
| TTL 未設定 | P1 | メモリ枯渇リスク |
| 分散ロック TTL なし | P0 | デッドロックによるサービス停止 |
