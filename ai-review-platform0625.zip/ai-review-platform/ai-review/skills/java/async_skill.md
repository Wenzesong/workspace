@skill: async_skill

# Purpose
Java 非同期処理（CompletableFuture・@Async）のリスクパターン知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- CompletableFuture / @Async / ExecutorService
- Future / Callable / Thread

---

# Risk Pattern

## @Async 問題
- 同一クラス内呼び出しで @Async が無効
- 戻り値 void での例外握りつぶし
- スレッドプール未指定（デフォルトプール枯渇）

## CompletableFuture 問題
- exceptionally / handle 未設定
- join() でのデッドロック
- タイムアウト未設定

## ThreadPool 問題
- スレッド数の無制限設定
- スレッド名未設定（障害追跡困難）
- スレッドプール共有による優先度汚染

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| スレッドプール枯渇 | P0 | 非同期処理の全停止 |
| 例外握りつぶし | P1 | サイレント障害 |
| タイムアウト未設定 | P1 | スレッド無限占有 |
