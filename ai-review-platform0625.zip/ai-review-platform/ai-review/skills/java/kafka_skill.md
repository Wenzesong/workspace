@skill: kafka_skill

# Purpose
Kafka Producer/Consumer に関するリスクパターンの知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- KafkaProducer / KafkaConsumer / @KafkaListener
- kafkaTemplate / ConsumerRecord

---

# Risk Pattern

## Producer
- acks=0（メッセージロスト許容）
- 冪等性 Producer 未使用（重複送信リスク）
- エラー時のリトライなし

## Consumer
- 手動コミット未使用での at-least-once 未保証
- 処理失敗時のオフセットコミットによるメッセージロスト
- コンシューマグループ設定ミス

## 冪等性
- 重複メッセージ処理の未考慮
- 冪等キー未設計
- Dead Letter Queue（DLQ）未設定

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| メッセージ重複処理無防備 | P0 | 重複決済・重複登録 |
| DLQ 未設定 | P1 | 処理失敗メッセージの消失 |
| acks=0 | P1 | メッセージロストを許容 |
