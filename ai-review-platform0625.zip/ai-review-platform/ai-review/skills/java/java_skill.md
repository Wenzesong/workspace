@skill: java_skill

# Purpose
Java 固有のリスクパターンと本番障害につながるアンチパターンの知識ルール。

---

# Auto Load Condition
Language=java の場合に常時ロード

---

# Risk Pattern

## NullPointerException
- Optional 未使用での null 返却
- null チェックなしの外部入力使用
- Stream 操作での null 混入

## リソースリーク
- try-with-resources 未使用（Connection・Stream・File）
- finally での close 漏れ
- ThreadLocal の remove 未実行

## 型・変換問題
- 数値オーバーフロー（int → long 未変換）
- 浮動小数点での金額計算（BigDecimal 未使用）
- 文字列での日付比較

## 例外設計
- RuntimeException の握りつぶし
- 例外メッセージなし
- checked exception の無思慮な unchecked 変換

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 金額を float/double で計算 | P0 | 金額計算誤差による業務障害 |
| Connection リーク | P0 | 接続枯渇によるサービス停止 |
| ThreadLocal 未クリア | P1 | リクエスト間のデータ汚染 |
| NPE 無防備 | P1 | 本番での予期しない500エラー |
