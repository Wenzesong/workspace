@skill: efcore_skill

# Purpose
Entity Framework Core 固有のリスクパターンに関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- DbContext / DbSet / IQueryable
- .Include() / .ThenInclude() / migrations

---

# Risk Pattern

## クエリ問題
- IQueryable の意図しないクライアント評価
- AsNoTracking 未使用（読み取り専用でも変更追跡）
- Include の過剰ネストによる巨大クエリ

## マイグレーション
- 本番での Database.EnsureCreated() 使用
- マイグレーション未適用での本番デプロイ
- 破壊的マイグレーション（列削除・型変更）の無停止実行

## トランザクション
- SaveChanges 複数回呼び出しでのトランザクション分断
- 分散トランザクション未考慮

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| EnsureCreated 本番使用 | P0 | スキーマ破壊リスク |
| 破壊的マイグレーション無停止実行 | P0 | 本番データロスト |
| クライアント評価 | P1 | 全件取得後フィルタによるOOM |
