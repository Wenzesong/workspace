@skill: csharp_skill

# Purpose
C# 固有のリスクパターンと本番障害につながるアンチパターンの知識ルール。

---

# Auto Load Condition
Language=csharp の場合に常時ロード

---

# Risk Pattern

## null 安全
- null 参照例外（NullReferenceException）の無防備
- null 許容型（Nullable）の未活用
- null 条件演算子（?.）の未使用

## リソース管理
- IDisposable の using 未使用
- HttpClient の都度 new（ソケット枯渇）
- DbContext の Dispose 漏れ

## 型・変換
- 金額を decimal 未使用で計算
- DateTime.Now と DateTime.UtcNow の混用
- string.Format よりも危険な文字列結合 SQL

## 例外処理
- Exception の catch-all（全例外握りつぶし）
- throw ex（スタックトレース消失）
- 例外フィルタ未使用

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| HttpClient 都度 new | P0 | ソケット枯渇によるサービス停止 |
| 金額を float で計算 | P0 | 金額誤差による業務障害 |
| throw ex | P1 | 障害時の原因追跡不能 |
| using 未使用 | P1 | リソースリーク |
