@skill: middleware_skill

# Purpose
ASP.NET Core カスタムミドルウェアのリスクパターン知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- IMiddleware / Use / UseMiddleware
- RequestDelegate / HttpContext

---

# Risk Pattern

## 順序問題
- 認証より前に認可ミドルウェアを配置
- 例外ハンドラが最初に配置されていない
- CORS が認証の後に配置

## 状態管理
- ミドルウェアへのリクエスト固有状態保持（スレッド安全性）
- HttpContext へのスコープ外アクセス
- Items ディクショナリへの型安全でないアクセス

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 認証・認可の順序逆転 | P0 | 認証なしで認可が通る |
| ミドルウェアへの状態保持 | P1 | リクエスト間データ汚染 |
