@skill: dependency_injection_skill

# Purpose
DI・ライフタイム管理（Singleton/Scoped/Transient）に関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- AddSingleton / AddScoped / AddTransient
- IServiceCollection / IServiceProvider

---

# Risk Pattern

## ライフタイム不整合
- Singleton が Scoped サービスを直接注入（Captive Dependency）
- Scoped サービスをシングルトンに保持
- Transient の DbContext を Singleton から使用

## サービスロケータ
- IServiceProvider.GetService の直接呼び出し
- サービスロケータパターンによる依存関係の隠蔽
- コンストラクタ以外での依存解決

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| Captive Dependency | P1 | Scoped サービスがリクエスト間で共有される |
| Singleton から DbContext 使用 | P0 | 複数リクエスト間でのDB状態汚染 |
