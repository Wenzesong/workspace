@skill: aspnet_skill

# Purpose
ASP.NET Core 固有のリスクパターンに関する知識ルール。

---

# Auto Load Condition
以下を検出した場合にロード：
- [ApiController] / [HttpGet] / [HttpPost]
- IActionResult / ActionResult / Middleware

---

# Risk Pattern

## ルーティング・バインディング
- [FromBody] / [FromQuery] 指定なしの曖昧バインディング
- モデルバインディングエラーの未処理
- ルート重複による意図しないエンドポイント

## フィルタ・ミドルウェア
- 認証フィルタの適用漏れ
- 例外ハンドリングミドルウェアの順序誤り
- CancellationToken の未伝播

## レスポンス
- 内部例外の詳細をそのままレスポンス
- 適切な HTTP ステータスコード未使用
- 大容量レスポンスのストリーミング未使用

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 認証フィルタ漏れ | P0 | 未認証アクセスが成立 |
| 例外詳細のレスポンス露出 | P1 | 内部構造の情報漏洩 |
| CancellationToken 未伝播 | P2 | クライアント切断後もリソース消費 |
