@skill: subquery_skill
@tier: 3

# Purpose
サブクエリ・相関サブクエリ・CTE のリスクパターン知識ルール。Tier3。

---

# Auto Load Condition
以下を検出した場合にロード：
- SELECT 内の SELECT（サブクエリ）
- WITH 句（CTE）/ EXISTS / IN (SELECT ...)

---

# Risk Pattern

## 相関サブクエリ
- 外部クエリの各行に対してサブクエリ実行（N+1 相当）
- NOT IN (SELECT NULL を含む) による全件非該当

## IN vs EXISTS
- IN (SELECT ...) の大量リスト（パフォーマンス劣化）
- NOT IN vs NOT EXISTS の NULL 挙動の差異未考慮

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 相関サブクエリのループ | P1 | N+1 相当の DB 負荷 |
| NOT IN + NULL 混入 | P1 | 全件が条件不一致になる |
