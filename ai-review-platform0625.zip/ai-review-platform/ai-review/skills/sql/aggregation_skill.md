@skill: aggregation_skill
@tier: 3

# Purpose
集計・GROUP BY・HAVING・ウィンドウ関数の最適化知識ルール。Tier3。

---

# Auto Load Condition
以下を検出した場合にロード：
- GROUP BY / HAVING / COUNT / SUM / AVG
- OVER() / PARTITION BY（ウィンドウ関数）

---

# Risk Pattern

## GROUP BY 問題
- SELECT に GROUP BY 列以外を含む（非標準SQL）
- HAVING に WHERE で絞り込める条件を記述
- 大量データの GROUP BY によるメモリ使用

## ウィンドウ関数
- PARTITION BY の列にインデックスなし
- ROWS/RANGE 指定ミスによる意図しない集計範囲

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| HAVING で絞り込み可能な条件 | P2 | 集計後のフィルタで性能劣化 |
| 大量 GROUP BY のメモリ | P1 | OOM によるクエリ失敗 |
