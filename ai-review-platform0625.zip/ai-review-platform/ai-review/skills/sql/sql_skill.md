@skill: sql_skill
@tier: 1

# Purpose
SQL 全般の基礎リスクパターンとアンチパターンの知識ルール。
全 SQL レビューで必ずロードする Tier1 スキル。

---

# Auto Load Condition
Language=sql の場合に常時ロード（Tier1）

---

# Risk Pattern

## 基本的な危険パターン
- SELECT * の使用（列追加時の予期しない動作変化）
- WHERE 句なしの UPDATE / DELETE（全件更新・削除）
- ORDER BY なしの LIMIT（結果の非決定性）

## データ型
- 文字列での数値・日付比較（インデックス未使用）
- 暗黙の型変換による Full Scan
- NULL との比較に = を使用（= NULL は常に偽）

## 制約
- 外部キー制約なし（孤立データの蓄積）
- NOT NULL 制約の欠如
- UNIQUE 制約なしの重複防止をアプリ側のみで実施

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| WHERE なし UPDATE/DELETE | P0 | 全件データ破壊 |
| SELECT * | P2 | 列追加時の動作変化・帯域浪費 |
| NULL 比較誤り | P1 | 意図しない全件対象外 |
