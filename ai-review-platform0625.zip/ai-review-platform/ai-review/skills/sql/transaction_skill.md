@skill: transaction_skill
@tier: 1

# Purpose
トランザクション・分離レベル・コミット設計の知識ルール。Tier1。

---

# Auto Load Condition
以下を検出した場合にロード：
- BEGIN / COMMIT / ROLLBACK / TRANSACTION
- @Transactional / TransactionScope

---

# Risk Pattern

## 分離レベル
- READ UNCOMMITTED（ダーティリード許容）
- SERIALIZABLE の不必要な使用（デッドロック増加）
- 分離レベルの明示なし（DBデフォルト依存）

## トランザクション設計
- 長時間トランザクション（ロック保持時間の増大）
- トランザクション内での外部API呼び出し
- autocommit=true での複数UPDATE（原子性なし）

## コミット設計
- バッチ処理での1件ずつコミット（性能問題）
- 巨大トランザクションのロールバックコスト未考慮

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| READ UNCOMMITTED | P1 | コミット前データの読み取り |
| トランザクション内外部API | P1 | 外部障害でロック保持継続 |
| autocommit での複数UPDATE | P0 | 部分失敗時のデータ不整合 |
