@skill: join_optimization_skill
@tier: 3

# Purpose
JOIN 最適化・結合順序・結合種別選択の知識ルール。Tier3。

---

# Auto Load Condition
以下を検出した場合にロード：
- 3テーブル以上の JOIN
- CROSS JOIN / FULL OUTER JOIN

---

# Risk Pattern

## JOIN 設計
- CROSS JOIN による意図しない直積
- 不要な OUTER JOIN（INNER JOIN で十分なケース）
- 結合条件の漏れによる直積化

## 結合順序
- 小テーブルを先に結合しない（オプティマイザヒント未使用）
- 複合 JOIN 条件のインデックス未対応

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| CROSS JOIN による直積 | P1 | 数億件の結果セット生成 |
| 結合条件漏れ | P0 | 全件直積による DB 負荷爆発 |
