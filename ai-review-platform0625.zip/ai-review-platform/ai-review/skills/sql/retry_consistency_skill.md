@skill: retry_consistency_skill
@tier: 2

# Purpose
リトライ時のデータ整合性・冪等性設計の知識ルール。Tier2。

---

# Auto Load Condition
以下を検出した場合にロード：
- リトライ処理 + DB 更新
- 冪等キー / idempotency_key

---

# Risk Pattern

## 冪等性設計
- INSERT リトライによる重複レコード
- UPDATE リトライによる二重加算（amount = amount + 100）
- 冪等キーの未使用

## 整合性リスク
- リトライ成功後の前回失敗データの未クリーンアップ
- 部分成功後のリトライによる不整合

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 二重加算 UPDATE のリトライ | P0 | 金額・在庫の二重計上 |
| 冪等キー未使用 | P1 | 重複レコードの蓄積 |
