@skill: pagination_skill
@tier: 2

# Purpose
ページネーション・Offset 問題・カーソルベース設計の知識ルール。Tier2。

---

# Auto Load Condition
以下を検出した場合にロード：
- LIMIT OFFSET / ページング処理
- 大量データの一覧取得

---

# Risk Pattern

## OFFSET 問題
- 大 OFFSET による Full Scan（OFFSET 1000000 LIMIT 10）
- ページ数が増えるほど性能劣化
- COUNT(*) による総件数取得の性能問題

## カーソルベース
- カーソルページネーション未使用
- ソートキーの非一意性によるページング重複・欠損
- 無限スクロールでの OFFSET 使用

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 大 OFFSET ページング | P1 | データ増加で性能劣化が顕在化 |
