@skill: consistency_skill
@tier: 1

# Purpose
データ整合性・制約設計・参照整合性の知識ルール。Tier1。

---

# Auto Load Condition
以下を検出した場合にロード：
- FOREIGN KEY / CONSTRAINT / CHECK
- 複数テーブルの同時更新

---

# Risk Pattern

## 制約設計
- 外部キー制約なし（孤立レコードの蓄積）
- CHECK 制約なし（不正値の混入）
- UNIQUE 制約なしの重複防止アプリ依存

## 整合性リスク
- 複数テーブル更新の非トランザクション化
- 参照整合性なしの CASCADE DELETE
- ソフトデリートと外部キーの不整合

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 外部キー制約なし | P2 | 孤立データの長期蓄積 |
| 非トランザクションでの複数テーブル更新 | P0 | 部分失敗によるデータ不整合 |
