@skill: index_skill
@tier: 2

# Purpose
インデックス設計・効果測定・欠損インデックス検出の知識ルール。Tier2。

---

# Auto Load Condition
以下を検出した場合にロード：
- WHERE 句での列条件
- JOIN ON 条件
- ORDER BY / GROUP BY

---

# Risk Pattern

## インデックス欠損
- WHERE 条件列にインデックスなし
- JOIN 結合列にインデックスなし
- 複合インデックスの列順序ミス

## インデックス無効化
- WHERE 句での列への関数適用（WHERE YEAR(created_at) = 2024）
- 暗黙の型変換によるインデックス無効
- OR 条件によるインデックス未使用

## インデックス過剰
- 低カーディナリティ列への単独インデックス
- 重複インデックス
- 更新頻度の高い列への多数インデックス

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 高頻度クエリのインデックス欠損 | P1 | Full Scan による性能劣化 |
| 関数適用によるインデックス無効 | P1 | 意図しない Full Scan |
