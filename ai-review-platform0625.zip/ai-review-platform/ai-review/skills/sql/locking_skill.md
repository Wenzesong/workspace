@skill: locking_skill
@tier: 1

# Purpose
ロック種別・ロック競合・ロック待機タイムアウトの知識ルール。Tier1。

---

# Auto Load Condition
以下を検出した場合にロード：
- FOR UPDATE / LOCK IN SHARE MODE / WITH (UPDLOCK)
- SELECT ... FOR UPDATE

---

# Risk Pattern

## ロック種別の誤用
- SELECT FOR UPDATE の不必要な使用
- テーブルロック vs 行ロックの意図しない選択
- Gap Lock によるデッドロック（MySQL InnoDB）

## ロック競合
- 高頻度更新行への集中ロック
- インデックスなし列での FOR UPDATE（テーブルロック化）
- ロック待機タイムアウト未設定

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| インデックスなし列での FOR UPDATE | P0 | テーブルロックによるサービス停止 |
| ロック待機タイムアウト未設定 | P1 | ロック待ち行列の無制限増大 |
