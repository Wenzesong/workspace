@skill: query_optimization_skill
@tier: 2

# Purpose
クエリ最適化・リライト・実行計画改善の知識ルール。Tier2。

---

# Auto Load Condition
以下を検出した場合にロード：
- 複雑な SELECT / JOIN / サブクエリ
- DISTINCT / GROUP BY / HAVING

---

# Risk Pattern

## 非効率クエリ
- サブクエリを JOIN でリライト可能なケース
- DISTINCT の過剰使用（JOIN 見直しで解決可能）
- HAVING で WHERE に移動可能な条件

## 結果セット
- 不要列の SELECT（帯域・メモリ浪費）
- ソート後の全件取得（LIMIT 未使用）
- COUNT(*) より高速な EXISTS の未活用

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 全件取得後アプリ側フィルタ | P1 | データ増加でOOMリスク |
| 相関サブクエリのループ実行 | P1 | N+1 相当の性能劣化 |
