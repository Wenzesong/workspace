@skill: migration_skill
@tier: 2

# Purpose
スキーママイグレーション・無停止変更・ロールバック設計の知識ルール。Tier2。

---

# Auto Load Condition
以下を検出した場合にロード：
- ALTER TABLE / DROP COLUMN / CREATE INDEX
- Flyway / Liquibase / migration

---

# Risk Pattern

## 破壊的変更
- 列削除（旧アプリが参照中）
- NOT NULL 列の追加（デフォルト値なし）
- 列型変更（暗黙のデータ変換）

## ロック問題
- 大テーブルへの ALTER TABLE（テーブルロック）
- CREATE INDEX の無停止実行未考慮
- pt-online-schema-change / gh-ost 未使用

## ロールバック設計
- ロールバック用 DOWN マイグレーション未作成
- 非可逆マイグレーション（データ変換を伴う）
- ロールバック手順の未テスト

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 大テーブルへの無計画 ALTER | P0 | 本番サービス停止 |
| NOT NULL 列追加（デフォルトなし） | P0 | 既存レコードのINSERT失敗 |
| ロールバック未設計 | P1 | 障害時の復旧手段なし |
