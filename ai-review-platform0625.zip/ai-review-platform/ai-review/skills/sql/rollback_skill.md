@skill: rollback_skill
@tier: 1

# Purpose
ロールバック戦略・部分コミット・リカバリ設計の知識ルール。Tier1。

---

# Auto Load Condition
以下を検出した場合にロード：
- ROLLBACK / SAVEPOINT
- 大規模 UPDATE/DELETE/INSERT

---

# Risk Pattern

## ロールバック設計
- ロールバックコストの未考慮（大量データ変更）
- SAVEPOINT を使わない巨大トランザクション
- DDL の暗黙コミット（MySQL）によるロールバック不能

## リカバリ設計
- ロールバック失敗時の対処未定義
- 部分ロールバック後のデータ整合性未確認
- ロールバック手順書の未作成

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| DDL の暗黙コミット未考慮 | P0 | ロールバック不能なデータ変更 |
| ロールバックコスト未考慮 | P1 | 長時間のロールバックによるサービス影響 |
