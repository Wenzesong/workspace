@skill: execution_plan_skill
@tier: 2

# Purpose
実行計画読解・EXPLAIN 分析・統計情報の知識ルール。Tier2。

---

# Auto Load Condition
以下を検出した場合にロード：
- EXPLAIN / EXPLAIN ANALYZE
- 性能問題の疑いがあるクエリ

---

# Risk Pattern

## 実行計画の問題パターン
- type=ALL（Full Table Scan）
- Using filesort（ソートにインデックス未使用）
- Using temporary（一時テーブル生成）
- rows 推定値が実際と大幅乖離

## 統計情報問題
- ANALYZE TABLE 未実行（古い統計情報）
- 統計情報の偏りによる誤った実行計画選択
- インデックスヒントへの依存

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| type=ALL（大テーブル） | P1 | 高負荷時のDB応答遅延 |
| Using temporary + filesort | P1 | メモリ枯渇・性能劣化 |
