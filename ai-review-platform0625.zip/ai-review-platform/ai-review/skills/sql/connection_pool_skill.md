@skill: connection_pool_skill
@tier: 2

# Purpose
接続プール設計・接続枯渇防止・モニタリングの知識ルール。Tier2。

---

# Auto Load Condition
以下を検出した場合にロード：
- DataSource / HikariCP / connection pool
- max-pool-size / connectionTimeout

---

# Risk Pattern

## 接続枯渇
- プールサイズ不足（同時リクエスト数を下回る）
- 接続を長時間保持する処理
- 接続リーク（close 漏れ）

## 設定問題
- connectionTimeout が短すぎる（接続待ちエラー多発）
- maxLifetime 未設定（長時間接続の切断）
- idleTimeout の不適切設定

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 接続リーク | P0 | 接続枯渇によるサービス停止 |
| プールサイズ不足 | P1 | 高負荷時の接続待ちタイムアウト |
