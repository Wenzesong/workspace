@skill: sql_injection_skill
@tier: 1

# Purpose
SQL インジェクション・バインド変数・クエリ安全設計の知識ルール。Tier1。

---

# Auto Load Condition
常時ロード（Tier1・セキュリティ必須）

---

# Risk Pattern

## SQL インジェクション
- 文字列結合によるクエリ生成
- ユーザ入力の直接埋め込み
- エスケープ処理の自前実装

## バインド変数
- PreparedStatement 未使用
- ORM 経由での生クエリ文字列結合
- LIKE 句のエスケープ漏れ（% _ のエスケープ）

## ストアドプロシージャ
- 動的 SQL 内でのパラメータ未バインド
- EXEC / sp_executesql での文字列結合

---

# Severity Rule

| パターン | レベル | 理由 |
|---|---|---|
| 文字列結合クエリ | P0 | 全データ取得・削除・認証バイパス |
| LIKE エスケープ漏れ | P1 | 意図しない全件検索 |
