@template: test_case_template

# テストケース

## テスト対象

| 項目 | 内容 |
|---|---|
| 対象クラス・メソッド | {クラス名#メソッド名} |
| テストフレームワーク | {JUnit5 / xUnit / pytest など} |
| Mock ライブラリ | {Mockito / Moq など} |

---

## 正常系テスト

### TC-001: {テスト名}

**目的:** {何を確認するテストか}
**前提条件:** {テスト実行前の状態}
**入力:** {テスト入力値}
**期待結果:** {期待する出力・状態}

```java
@Test
void {testMethodName}() {
    // Arrange
    {セットアップコード}

    // Act
    {実行コード}

    // Assert
    {検証コード}
}
```

---

## 異常系テスト

### TC-002: {テスト名（異常系）}

**目的:** {何を確認するテストか}
**前提条件:** {異常状態の再現方法}
**入力:** {異常入力値}
**期待結果:** {期待する例外・エラーレスポンス}

```java
@Test
void {testMethodName}_shouldThrow_whenInvalidInput() {
    // Arrange
    {異常状態セットアップ}

    // Act & Assert
    assertThrows({ExceptionClass}.class, () -> {
        {実行コード}
    });
}
```

---

## リスクベーステスト

### TC-003: {リスク名に対応したテスト}

**対応リスク:** {R-001: リスク概要}
**テスト方針:** {どのようにリスクを検証するか}

```java
@Test
void {testMethodName}_shouldHandle_{riskScenario}() {
    {テストコード}
}
```
