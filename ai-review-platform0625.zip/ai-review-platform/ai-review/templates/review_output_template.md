@template: review_output_template

# レビュー結果レポート

## 概要

| 項目 | 内容 |
|---|---|
| レビュー対象 | {ファイル名・クラス名} |
| 言語・FW | {Java / Spring Boot など} |
| レビューモード | {new-review / diff-review} |
| レビュー日時 | {YYYY-MM-DD HH:mm} |
| 最高リスクレベル | {P0 / P1 / P2 / P3} |

---

## 検出リスク一覧

| # | リスク | レベル | カテゴリ | 影響範囲 |
|---|---|---|---|---|
| 1 | {リスク概要} | P0 | {トランザクション} | {API全体} |
| 2 | {リスク概要} | P1 | {性能} | {DB接続} |

---

## 詳細分析

### [{#}] {リスクタイトル}

**リスクレベル:** P{0-3}
**カテゴリ:** {トランザクション / セキュリティ / 性能 / 保守性}

**問題のコード:**
```
{問題箇所のコード}
```

**問題の説明:**
{具体的に何が問題か。抽象表現禁止。}

**本番での障害シナリオ:**
{高負荷時・特定条件下でどのような障害が発生するか}

**影響範囲:**
- {影響するテーブル・API・サービス}
- {影響する処理・ユーザ}

**修正推奨:**
```
{修正後のコード例}
```

**修正理由:**
{なぜこの修正で問題が解決されるか}

---

## 回帰リスク評価

| 観点 | 評価 | 詳細 |
|---|---|---|
| API 互換性 | {低 / 中 / 高} | {内容} |
| DB スキーマ影響 | {低 / 中 / 高} | {内容} |
| 外部サービス影響 | {低 / 中 / 高} | {内容} |
| 既存テストへの影響 | {低 / 中 / 高} | {内容} |

---

## テスト推奨

| # | テストケース | 優先度 | 種別 |
|---|---|---|---|
| 1 | {テスト内容} | 必須 | {単体 / 結合 / 負荷} |
| 2 | {テスト内容} | 推奨 | {単体 / 結合} |

---

## 総評

{全体的な品質評価と優先対応事項のサマリ。3〜5文で簡潔に。}

---

## STRUCTURED OUTPUT

After the review report above, output the following JSON block exactly.
Do NOT omit this section. Do NOT change the format.

```json
{
  "review_date": "YYYY-MM-DD",
  "target_file": "ファイル名",
  "language": "java",
  "mode": "new-review",
  "highest_level": "P0",
  "risk_counts": {
    "P0": 0,
    "P1": 0,
    "P2": 0,
    "P3": 0
  },
  "categories": [],
  "risks": [
    {
      "id": "P0-001",
      "level": "P0",
      "category": "transaction",
      "title": "リスクタイトル",
      "description": "問題の説明",
      "impact": "本番への影響",
      "fix": "修正推奨"
    }
  ],
  "regression_risk": "low",
  "summary": "総評を1文で"
}
```

Rules:
- level must be one of: P0 / P1 / P2 / P3
- category must be one of: transaction / security / performance / sql / redis / kafka / concurrency / maintainability
- regression_risk must be one of: low / medium / high
- risks array must contain ALL detected risks
- Do NOT output anything after the JSON block
