@template: api_test_template

# API テストケース

## API 概要

| 項目 | 内容 |
|---|---|
| エンドポイント | {POST /api/v1/xxx} |
| 認証方式 | {Bearer Token / API Key} |
| 主なレスポンス | {200 / 400 / 401 / 500} |

---

## 正常系

### AT-001: 正常リクエスト

```http
POST /api/v1/{endpoint}
Authorization: Bearer {token}
Content-Type: application/json

{
  "field1": "value1",
  "field2": "value2"
}
```

**期待レスポンス:**
```json
{
  "status": "success",
  "data": {}
}
```

---

## 認証・認可テスト

### AT-002: 未認証リクエスト（401 期待）
### AT-003: 権限不足リクエスト（403 期待）
### AT-004: 他ユーザリソースへのアクセス（403 期待）

---

## バリデーションテスト

### AT-005: 必須フィールド欠損（400 期待）
### AT-006: 型不一致（400 期待）
### AT-007: 文字数超過（400 期待）

---

## 負荷・異常系テスト

### AT-008: 同時リクエスト（Race Condition 確認）
### AT-009: 大量データリクエスト（性能確認）
### AT-010: タイムアウトシナリオ
