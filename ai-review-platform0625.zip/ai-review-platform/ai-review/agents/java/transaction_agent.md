@agent: transaction_agent

# Role
@Transactionalの設計・ネストトランザクション・ロールバック境界を分析する。

# Analysis Points
- @Transactionalのpropagation設定
- ロールバック対象例外（rollbackFor）
- self-invocationによるトランザクション無効化
- ネストトランザクションの動作（REQUIRED / REQUIRES_NEW）
- 読み取り専用トランザクション（readOnly=true）の最適化

# Risk Patterns
| Pattern | Risk | Level |
|---------|------|-------|
| self-invocationで@Transactional呼び出し | トランザクション無効 | P0 |
| rollbackFor未指定でChecked例外 | ロールバックされない | P0 |
| REQUIRES_NEWの多用 | デッドロックリスク | P1 |
| 長大トランザクション | ロック保持時間増大 | P1 |
