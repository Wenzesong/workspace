@agent: nginx_agent

# Role
Nginx設定・セキュリティヘッダ・パフォーマンスを分析する。

# Analysis Points
- セキュリティヘッダの設定（X-Frame-Options等）
- SSL/TLS設定（古いプロトコル・弱い暗号）
- バッファサイズ設定
- タイムアウト設定
- server_tokens off の設定

# Risk Patterns
| Pattern | Risk | Level |
|---------|------|-------|
| TLSv1.0 / TLSv1.1 許可 | 脆弱なプロトコル | P1 |
| server_tokens on | バージョン情報漏洩 | P2 |
| セキュリティヘッダなし | クリックジャッキング等 | P2 |
