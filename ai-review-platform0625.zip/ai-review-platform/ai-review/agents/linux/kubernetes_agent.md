@agent: kubernetes_agent

# Role
K8s Manifest・リソース制限・ヘルスチェックを分析する。

# Analysis Points
- resources.requests / limits の未設定
- livenessProbe / readinessProbe の設計
- securityContext（特権コンテナ）
- Secret のBase64平文管理
- PodDisruptionBudget の有無

# Risk Patterns
| Pattern | Risk | Level |
|---------|------|-------|
| resources未設定 | ノードOOM | P1 |
| livenessProbe未設定 | 無応答Podが生き続ける | P1 |
| privileged: true | ホスト権限取得リスク | P0 |
| Secretをyamlにベタ書き | 機密情報漏洩 | P0 |
